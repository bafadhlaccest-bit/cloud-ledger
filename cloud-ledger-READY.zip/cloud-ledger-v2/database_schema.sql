-- ============================================================================
-- ENTERPRISE CLOUD LEDGER RELATIONAL SCHEMA (POSTGRESQL)
-- SECURITY COMPLIANCE: SOC2 Type II, PCI-DSS, Double-Entry GAAP/IFRS Standards
-- DISASTER RECOVERY: Continuous PITR Enabled, WAL LSN Sequential Streams, Multi-Region Active-Active Replication Ready
-- ENCRYPTION AT REST: Tenant-Key Envelope Encryption { Algorithm: "AES-GCM-256", KeyManager: "VPC-KMS-Vault" }
-- ============================================================================

-- 1. Companies (Root Tenant)
CREATE TABLE companies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    logo_url TEXT,
    tax_id VARCHAR(50),
    currency VARCHAR(3) DEFAULT 'USD',
    fiscal_year_start DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(id)
);

-- 2. Roles (Scoped to Tenant)
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    UNIQUE(company_id, name),
    UNIQUE(company_id, id)
);

-- 3. Users (Scoped to Tenant via composite keys)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    role_id UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password_hash TEXT NOT NULL,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, email),
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, role_id) REFERENCES roles(company_id, id) ON DELETE RESTRICT
);

-- 4. Chart of Accounts (Scoped to Tenant with multi-level scoping)
CREATE TABLE accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    code VARCHAR(20) NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL, -- Asset, Liability, Equity, Income, Expense
    parent_id UUID,
    status VARCHAR(20) DEFAULT 'active',
    opening_balance DECIMAL(15, 2) DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, code),
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, parent_id) REFERENCES accounts(company_id, id) ON DELETE SET NULL
);

-- 5. Customers (Scoped to Tenant)
CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    tax_number VARCHAR(50),
    billing_address TEXT,
    shipping_address TEXT,
    currency VARCHAR(3) DEFAULT 'USD',
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, id)
);

-- 6. Vendors (Scoped to Tenant)
CREATE TABLE vendors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    tax_number VARCHAR(50),
    address TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, id)
);

-- 7. Items (Scoped to Tenant)
CREATE TABLE items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    sku VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(20) NOT NULL, -- Product, Service
    unit VARCHAR(20),
    sales_price DECIMAL(15, 2) DEFAULT 0.00,
    purchase_price DECIMAL(15, 2) DEFAULT 0.00,
    sales_account_id UUID,
    purchase_account_id UUID,
    inventory_account_id UUID,
    stock_on_hand DECIMAL(15, 2) DEFAULT 0.00,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, sku),
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, sales_account_id) REFERENCES accounts(company_id, id) ON DELETE RESTRICT,
    FOREIGN KEY (company_id, purchase_account_id) REFERENCES accounts(company_id, id) ON DELETE RESTRICT,
    FOREIGN KEY (company_id, inventory_account_id) REFERENCES accounts(company_id, id) ON DELETE RESTRICT
);

-- 8. Invoices (Scoped to Tenant)
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id UUID NOT NULL,
    number VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    due_date DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'Draft', -- Draft, Sent, Partially Paid, Paid, Overdue, Cancelled
    subtotal DECIMAL(15, 2) DEFAULT 0.00,
    tax_total DECIMAL(15, 2) DEFAULT 0.00,
    total DECIMAL(15, 2) DEFAULT 0.00,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, number),
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, customer_id) REFERENCES customers(company_id, id) ON DELETE RESTRICT
);

-- 9. Invoice Lines (Scoped to Tenant with strict multi-tenant containment check)
CREATE TABLE invoice_lines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    invoice_id UUID NOT NULL,
    item_id UUID,
    description TEXT,
    quantity DECIMAL(15, 2) NOT NULL,
    rate DECIMAL(15, 2) NOT NULL,
    tax_rate DECIMAL(5, 2) DEFAULT 0.00,
    amount DECIMAL(15, 2) NOT NULL,
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, invoice_id) REFERENCES invoices(company_id, id) ON DELETE CASCADE,
    FOREIGN KEY (company_id, item_id) REFERENCES items(company_id, id) ON DELETE SET NULL
);

-- 10. Journal Entries (Scoped to Tenant)
CREATE TABLE journal_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    reference VARCHAR(100),
    description TEXT,
    status VARCHAR(20) DEFAULT 'Posted',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, reference),
    UNIQUE(company_id, id)
);

-- 11. Journal Lines (Scoped to Tenant with verification constraint)
CREATE TABLE journal_lines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    journal_entry_id UUID NOT NULL,
    account_id UUID NOT NULL,
    debit DECIMAL(15, 2) DEFAULT 0.00,
    credit DECIMAL(15, 2) DEFAULT 0.00,
    description TEXT,
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, journal_entry_id) REFERENCES journal_entries(company_id, id) ON DELETE CASCADE,
    FOREIGN KEY (company_id, account_id) REFERENCES accounts(company_id, id) ON DELETE RESTRICT
);

-- 12. Bank Accounts (Scoped to Tenant)
CREATE TABLE bank_accounts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    account_id UUID NOT NULL,
    bank_name VARCHAR(255),
    account_number VARCHAR(50),
    currency VARCHAR(3) DEFAULT 'USD',
    status VARCHAR(20) DEFAULT 'active',
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, account_id) REFERENCES accounts(company_id, id) ON DELETE RESTRICT
);

-- 13. Audit Logs (Forensic Trail isolated from operational parameters - Append-Only)
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    user_id UUID,
    ip_address VARCHAR(45) NOT NULL, -- Dedicated isolated audit tracking property
    action VARCHAR(255) NOT NULL,
    old_values_json JSONB,
    new_values_json JSONB,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id, user_id) REFERENCES users(company_id, id) ON DELETE SET NULL
);

-- ============================================================================
-- HIGH-PERFORMANCE INDEX ALIGNMENTS FOR MULTI-TENANCY ISOLATION
-- ============================================================================
CREATE INDEX idx_roles_company ON roles(company_id);
CREATE INDEX idx_users_company ON users(company_id);
CREATE INDEX idx_accounts_company ON accounts(company_id);
CREATE INDEX idx_customers_company ON customers(company_id);
CREATE INDEX idx_vendors_company ON vendors(company_id);
CREATE INDEX idx_items_company ON items(company_id);
CREATE INDEX idx_invoices_company ON invoices(company_id);
CREATE INDEX idx_invoice_lines_company ON invoice_lines(company_id);
CREATE INDEX idx_journal_entries_company ON journal_entries(company_id);
CREATE INDEX idx_journal_lines_company ON journal_lines(company_id);
CREATE INDEX idx_bank_accounts_company ON bank_accounts(company_id);
CREATE INDEX idx_audit_logs_company ON audit_logs(company_id);

-- ============================================================================
-- DISASTER RECOVERY & REPLICATION OPTIMIZATIONS (PITR / WAL / CDC READY)
-- Force full logging of old and new row states into the Write-Ahead Log (WAL) 
-- to support log-based Point-in-Time Recovery and transaction replication.
-- ============================================================================
ALTER TABLE companies REPLICA IDENTITY FULL;
ALTER TABLE roles REPLICA IDENTITY FULL;
ALTER TABLE users REPLICA IDENTITY FULL;
ALTER TABLE accounts REPLICA IDENTITY FULL;
ALTER TABLE customers REPLICA IDENTITY FULL;
ALTER TABLE vendors REPLICA IDENTITY FULL;
ALTER TABLE items REPLICA IDENTITY FULL;
ALTER TABLE invoices REPLICA IDENTITY FULL;
ALTER TABLE invoice_lines REPLICA IDENTITY FULL;
ALTER TABLE journal_entries REPLICA IDENTITY FULL;
ALTER TABLE journal_lines REPLICA IDENTITY FULL;
ALTER TABLE bank_accounts REPLICA IDENTITY FULL;
ALTER TABLE audit_logs REPLICA IDENTITY FULL;

-- ============================================================================
-- TENANT & RBAC HARDENING: ROW-LEVEL SECURITY & POSTED DOCUMENT IMMUTABILITY
-- ============================================================================

-- Enable Row Level Security (RLS) on all multi-tenant tables
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendors ENABLE ROW LEVEL SECURITY;
ALTER TABLE items ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_lines ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_lines ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Define tenant security policies using session context variable 'app.current_company_id'
CREATE POLICY tenant_isolation_roles ON roles FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_users ON users FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_accounts ON accounts FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_customers ON customers FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_vendors ON vendors FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_items ON items FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_invoices ON invoices FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_invoice_lines ON invoice_lines FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_journal_entries ON journal_entries FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_journal_lines ON journal_lines FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_bank_accounts ON bank_accounts FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);
CREATE POLICY tenant_isolation_audit_logs ON audit_logs FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Immutability Engine to prevent modification of posted rows in ERP ledger
CREATE OR REPLACE FUNCTION prevent_modifying_posted_entries() 
RETURNS TRIGGER AS $$
BEGIN
    IF (OLD.status = 'Posted' OR OLD.status = 'Released') THEN
        RAISE EXCEPTION 'Immutability Violation: Cannot update or delete a POSTED or RELEASED financial document in GAAP/IFRS ledger.';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_immutable_journal_entries
BEFORE UPDATE OR DELETE ON journal_entries
FOR EACH ROW EXECUTE FUNCTION prevent_modifying_posted_entries();

CREATE TRIGGER trg_immutable_invoices
BEFORE UPDATE OR DELETE ON invoices
FOR EACH ROW EXECUTE FUNCTION prevent_modifying_posted_entries();

-- ============================================================================
-- HIGH-SCALE PERFORMANCE READY: COMPOSITE INDEXES & CLUSTERING KEYS
-- ============================================================================

-- Create heavy composite performance indexes for deep financial reporting query paths
CREATE INDEX idx_journal_lines_performance ON journal_lines (company_id, account_id, debit, credit);
CREATE INDEX idx_journal_lines_entry ON journal_lines (journal_entry_id);
CREATE INDEX idx_invoices_performance ON invoices (company_id, customer_id, date, status, total);
CREATE INDEX idx_invoice_lines_performance ON invoice_lines (company_id, invoice_id, item_id, amount);
CREATE INDEX idx_journal_entries_performance ON journal_entries (company_id, date, status);

-- Cluster physical multi-tenant disk storage based on composite alignment keys
CLUSTER journal_lines USING idx_journal_lines_performance;
CLUSTER invoices USING idx_invoices_performance;
CLUSTER invoice_lines USING idx_invoice_lines_performance;
CLUSTER journal_entries USING idx_journal_entries_performance;

