/**
 * server.ts — Cloud Ledger Backend
 * ─────────────────────────────────
 * Database: Supabase (PostgreSQL) 
 * AI:       Google Gemini
 * Auth:     Supabase Auth (handled client-side; server validates JWT)
 */
import express from "express";
import axios from "axios";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createClient } from "@supabase/supabase-js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ── Supabase Admin Client (uses service_role key — server only) ──
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_ROLE_KEY || "",
  { auth: { persistSession: false } }
);

// ── In-memory stores for non-critical data ────────────────────────
const customReportDesigns: any[] = [];
const auditHistoryLogs: any[] = [];

// Integration settings per company (persisted in Supabase in production)
const integrationSettings: Record<string, any> = {
  salla: {
    enabled: false, apiKey: "", storeUrl: "",
    mapping: { sales: "sales_revenue", cash: "cash", vat: "vat_output", cogs: "cogs" }
  },
  zid: {
    enabled: false, apiKey: "", storeId: "",
    mapping: { sales: "sales_revenue", cash: "cash", vat: "vat_output", cogs: "cogs" }
  }
};
const integrationLogs: any[] = [];

// ── JWT helper ───────────────────────────────────────────────────
async function getCompanyId(req: express.Request): Promise<string> {
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith("Bearer ")) {
    const token = authHeader.slice(7);
    const { data } = await supabaseAdmin.auth.getUser(token);
    if (data.user?.user_metadata?.company_id) {
      return data.user.user_metadata.company_id;
    }
  }
  // Fallback: header set by frontend
  return String(req.headers["x-company-id"] || "default");
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: "10mb" }));

  // ── CORS for dev ──────────────────────────────────────────────
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", process.env.APP_URL || "*");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, x-company-id");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    if (req.method === "OPTIONS") return res.sendStatus(204);
    next();
  });

  // ── Health check ──────────────────────────────────────────────
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // ── IMF Exchange Rates ────────────────────────────────────────
  app.get("/api/imf-rates", async (_req, res) => {
    try {
      const response = await axios.get(
        "https://dataservices.imf.org/REST/SDMX_JSON.svc/CompactData/EXR/D..SDR..XDC",
        { timeout: 5000 }
      );
      res.json(response.data);
    } catch {
      // Return fallback rates on network failure
      res.json({
        StructureSpecificData: {
          DataSet: {
            Series: [
              { "@UNIT_MEASURE": "USD", "Obs": { "@OBS_VALUE": "1.35" } },
              { "@UNIT_MEASURE": "EUR", "Obs": { "@OBS_VALUE": "1.25" } },
              { "@UNIT_MEASURE": "SAR", "Obs": { "@OBS_VALUE": "5.06" } },
              { "@UNIT_MEASURE": "YER", "Obs": { "@OBS_VALUE": "337.5" } },
              { "@UNIT_MEASURE": "AED", "Obs": { "@OBS_VALUE": "4.95" } },
              { "@UNIT_MEASURE": "EGP", "Obs": { "@OBS_VALUE": "63.45" } },
              { "@UNIT_MEASURE": "KWD", "Obs": { "@OBS_VALUE": "0.415" } },
              { "@UNIT_MEASURE": "BHD", "Obs": { "@OBS_VALUE": "0.509" } },
              { "@UNIT_MEASURE": "OMR", "Obs": { "@OBS_VALUE": "0.520" } },
              { "@UNIT_MEASURE": "QAR", "Obs": { "@OBS_VALUE": "4.91" } },
              { "@UNIT_MEASURE": "GBP", "Obs": { "@OBS_VALUE": "1.06" } },
              { "@UNIT_MEASURE": "JPY", "Obs": { "@OBS_VALUE": "212.4" } },
            ]
          }
        }
      });
    }
  });

  // ── Reports: Query Engine ─────────────────────────────────────
  app.post("/api/reports/query-engine", async (req, res) => {
    try {
      const companyId = await getCompanyId(req);
      const { primaryTable, filters = [], joins = [], limit = 500 } = req.body;

      const tableMap: Record<string, string> = {
        accounts: "accounts",
        journal_entries: "journal_entries",
        journal_lines: "journal_lines",
        invoices: "invoices",
        customers: "customers",
        vendors: "vendors",
        items: "items",
      };

      const table = tableMap[primaryTable];
      if (!table) {
        return res.status(400).json({ error: `Unknown table: ${primaryTable}` });
      }

      let query = supabaseAdmin
        .from(table)
        .select("*")
        .eq("company_id", companyId)
        .limit(limit);

      for (const f of filters) {
        if (f.op === "eq")  query = query.eq(f.field, f.value);
        if (f.op === "gte") query = query.gte(f.field, f.value);
        if (f.op === "lte") query = query.lte(f.field, f.value);
      }

      const { data, error } = await query;
      if (error) throw error;

      res.json({ success: true, data, count: data?.length || 0 });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── Settings: Get ─────────────────────────────────────────────
  app.get("/api/settings", async (req, res) => {
    try {
      const companyId = await getCompanyId(req);
      const { data } = await supabaseAdmin
        .from("company_settings")
        .select("key, value")
        .eq("company_id", companyId);
      
      const settings: Record<string, string> = {};
      (data || []).forEach((row: any) => { settings[row.key] = row.value; });
      res.json(settings);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── Settings: Save ────────────────────────────────────────────
  app.post("/api/settings", async (req, res) => {
    try {
      const companyId = await getCompanyId(req);
      const entries = Object.entries(req.body);
      
      for (const [key, value] of entries) {
        await supabaseAdmin
          .from("company_settings")
          .upsert({ company_id: companyId, key, value: String(value) }, { onConflict: "company_id,key" });
      }
      
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── AI Accountant ─────────────────────────────────────────────
  app.post("/api/ai-accountant/parse", async (req, res) => {
    try {
      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ error: "GEMINI_API_KEY is not configured." });
      }

      const { userPrompt, prompt, accounts = [], metadata_session = {},
              advisorMode = false, systemPrompt: clientSystemPrompt,
              conversationHistory = [] } = req.body;
      const activePrompt = userPrompt || prompt || "";
      const activeUserRole = metadata_session.user_role_permissions || req.body.user_role_permissions || "Admin";
      const companyId = await getCompanyId(req);

      // Role check
      const authorizedRoles = ["Admin", "Accountant", "Auditor"];
      if (!authorizedRoles.includes(activeUserRole)) {
        return res.json({
          explanation: "غير مصرح / Unauthorized: Insufficient role permissions.",
          journal: null,
        });
      }

      // Block raw SQL attempts
      if (/\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|TRUNCATE)\b/i.test(activePrompt)) {
        return res.json({
          explanation: "Security: Direct SQL commands are not allowed.",
          journal: null,
        });
      }

      // Fetch live accounts from Supabase for AI context
      const { data: liveAccounts } = await supabaseAdmin
        .from("accounts")
        .select("id, code, name, type")
        .eq("company_id", companyId)
        .limit(200);

      const accountsForAI = (liveAccounts || accounts).map((a: any) => ({
        id: a.id, code: a.code, name: a.name, type: a.type
      }));

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

      // ── Financial Advisor Mode (free text, conversational) ────
      if (advisorMode && clientSystemPrompt) {
        const contents = [
          // Inject past conversation turns
          ...conversationHistory.slice(-8).map((m: any) => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: m.content }],
          })),
          { role: 'user', parts: [{ text: activePrompt }] },
        ];

        const result = await ai.models.generateContent({
          model: 'gemini-2.0-flash',
          contents,
          config: { systemInstruction: clientSystemPrompt },
        });

        const text = result.text || '';
        return res.json({ explanation: text, journal: null });
      }

      // ── Standard Accountant Mode (JSON structured) ────────────
      const systemPrompt = `You are an expert IFRS/GAAP accounting AI assistant for Cloud Ledger ERP.
Available accounts: ${JSON.stringify(accountsForAI.slice(0, 50))}
Company ID: ${companyId}
User Role: ${activeUserRole}

Respond ONLY with valid JSON matching this schema:
{
  "explanation": "string — Arabic or English explanation",
  "journal": {
    "date": "YYYY-MM-DD",
    "description": "string",
    "lines": [
      { "accountId": "string", "accountCode": "string", "accountName": "string", "debit": number, "credit": number, "description": "string" }
    ]
  } | null,
  "proposedNewAccount": { "code": "string", "name": "string", "type": "string" } | null,
  "forecast": null
}`;

      const result = await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: [{ role: "user", parts: [{ text: activePrompt }] }],
        config: { systemInstruction: systemPrompt, responseMimeType: "application/json" }
      });

      const text = result.text || "{}";
      let parsed: any = {};
      try { parsed = JSON.parse(text); } catch { parsed = { explanation: text, journal: null }; }

      res.json(parsed);
    } catch (err: any) {
      console.error("[AI Accountant]", err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ── Journal entries: sync from frontend ──────────────────────
  app.post("/api/sync-journal-entries", async (req, res) => {
    try {
      const companyId = await getCompanyId(req);
      const { entries } = req.body;
      if (!Array.isArray(entries)) {
        return res.status(400).json({ error: "entries must be an array" });
      }

      for (const je of entries) {
        const lines = je.lines || [];
        const totalDebit  = lines.reduce((s: number, l: any) => s + (l.debit || 0), 0);
        const totalCredit = lines.reduce((s: number, l: any) => s + (l.credit || 0), 0);

        const { data: inserted } = await supabaseAdmin
          .from("journal_entries")
          .upsert({
            id: je.id, company_id: companyId, date: je.date,
            reference: je.reference, description: je.description,
            total_debit: totalDebit, total_credit: totalCredit,
            status: je.status || "Posted",
          }, { onConflict: "id" })
          .select("id")
          .single();

        if (inserted?.id) {
          const lineRows = lines.map((l: any, i: number) => ({
            id: l.id || `${inserted.id}-${i}`,
            company_id: companyId,
            journal_entry_id: inserted.id,
            account_id: l.accountId,
            debit: l.debit || 0,
            credit: l.credit || 0,
            description: l.description || je.description,
          }));
          await supabaseAdmin.from("journal_lines").upsert(lineRows, { onConflict: "id" });
        }
      }

      res.json({ success: true, count: entries.length });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── Report Designs ────────────────────────────────────────────
  app.get("/api/reports/designs", (_req, res) => res.json(customReportDesigns));

  app.post("/api/reports/designs", (req, res) => {
    const layout = req.body;
    if (!layout.id) layout.id = `tpl_${Date.now()}`;
    const idx = customReportDesigns.findIndex(d => d.id === layout.id);
    if (idx >= 0) {
      customReportDesigns[idx] = { ...customReportDesigns[idx], ...layout, version: (customReportDesigns[idx].version || 1) + 1 };
    } else {
      layout.version = 1;
      customReportDesigns.push(layout);
    }
    res.json({ success: true, design: layout });
  });

  // ── Audit Logs ────────────────────────────────────────────────
  app.get("/api/reports/audits", (_req, res) => res.json(auditHistoryLogs));

  app.post("/api/reports/audits", (req, res) => {
    const log = { ...req.body, id: `LOG-${Date.now()}`, timestamp: new Date().toISOString() };
    auditHistoryLogs.unshift(log);
    res.json({ success: true, log });
  });

  app.get("/api/reports/observability-alerts", (_req, res) => {
    res.json({ alerts: [], timestamp: new Date().toISOString() });
  });

  // ── Integrations ──────────────────────────────────────────────
  app.get("/api/integrations/settings", (_req, res) => {
    res.json({ settings: integrationSettings, logs: integrationLogs });
  });

  app.post("/api/integrations/settings", (req, res) => {
    const { salla, zid } = req.body;
    if (salla) integrationSettings.salla = { ...integrationSettings.salla, ...salla };
    if (zid)   integrationSettings.zid   = { ...integrationSettings.zid,   ...zid   };
    res.json({ success: true, settings: integrationSettings });
  });

  app.post("/api/integrations/manual-sync", async (req, res) => {
    const { platform } = req.body;
    const orderNum = Math.floor(Math.random() * 9000) + 1000;
    const invNo = `INV-${platform === "Salla" ? "SAL" : "ZID"}-${orderNum}`;
    const log = {
      id: `LOG-INT-${Date.now()}`,
      timestamp: new Date().toISOString(),
      platform,
      eventType: "Manual Sync",
      status: "Success",
      details: `تم استيراد طلب ${invNo} من ${platform} بنجاح`
    };
    integrationLogs.unshift(log);
    res.json({ success: true, invoiceNumber: invNo, log });
  });

  app.post("/api/integrations/webhooks", (req, res) => {
    const { platform, eventType, payload } = req.body;
    if (!platform || !eventType) {
      return res.status(400).json({ error: "platform and eventType are required" });
    }
    const log = {
      id: `LOG-WH-${Date.now()}`,
      timestamp: new Date().toISOString(),
      platform, eventType, status: "Received",
      details: `Webhook received: ${eventType}`
    };
    integrationLogs.unshift(log);
    res.json({ success: true, log });
  });

  app.post("/api/integrations/logs/retry", (req, res) => {
    const { logId } = req.body;
    const log = integrationLogs.find(l => l.id === logId);
    if (log) log.status = "Retried";
    res.json({ success: true });
  });

  // ── Auth: register new company ────────────────────────────────
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { email, password, companyName, currency = "USD", fiscalYearStart } = req.body;
      if (!email || !password || !companyName) {
        return res.status(400).json({ error: "email, password, companyName are required" });
      }

      // Create Supabase Auth user
      const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email, password, email_confirm: true,
      });
      if (authError) throw authError;

      // Create company record
      const { data: company, error: companyError } = await supabaseAdmin
        .from("companies")
        .insert({ name: companyName, currency, fiscal_year_start: fiscalYearStart || new Date().toISOString().slice(0, 10) })
        .select("id")
        .single();
      if (companyError) throw companyError;

      // Attach company_id to user metadata
      await supabaseAdmin.auth.admin.updateUserById(authData.user!.id, {
        user_metadata: { company_id: company.id, role: "admin", full_name: companyName }
      });

      // Auto-create fiscal periods for current year (non-blocking)
      const year = new Date().getFullYear();
      await supabaseAdmin.rpc('create_default_fiscal_periods', {
        p_company_id: company.id, p_year: year
      }).catch(() => null);

      res.json({ success: true, userId: authData.user!.id, companyId: company.id });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── Vite Dev / Static Production ─────────────────────────────
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`✓ Cloud Ledger running on http://localhost:${PORT}`);
  });
}

startServer();
