# Cloud Ledger — Deployment Guide

## Prerequisites
- Node.js 20+
- Supabase project (free tier works)
- Google Gemini API key

## Step 1: Supabase Setup

1. Go to your Supabase project SQL editor
2. Run `database_schema.sql` first
3. Run `supabase_additions.sql` second
4. In Supabase Dashboard → Authentication → Providers → enable **Google** (for Google login)

## Step 2: Environment Variables

Copy `.env.example` to `.env.local`:
```
VITE_SUPABASE_URL=https://myctjtloozvfgmuucpsq.supabase.co
VITE_SUPABASE_ANON_KEY=<from Supabase Settings > API > anon key>
SUPABASE_URL=https://myctjtloozvfgmuucpsq.supabase.co
SUPABASE_SERVICE_ROLE_KEY=<from Supabase Settings > API > service_role key>
GEMINI_API_KEY=<from Google AI Studio>
APP_URL=https://your-domain.com
```

## Step 3: Install & Run

```bash
npm install
npm run dev        # development
npm run build      # production build
npm run start:prod # production server
```

## Step 4: Deploy to Production

### Option A: Vercel (Frontend only)
```bash
vercel deploy
# Set env vars in Vercel dashboard
```

### Option B: Railway / Render (Full stack)
- Connect your GitHub repo
- Set all env vars
- Deploy command: `npm run build && npm run start:prod`

## Multi-tenancy
- Each company registers via `/api/auth/register`
- Row Level Security (RLS) in Supabase automatically isolates data by `company_id`
- Users are linked to their company via Supabase Auth `user_metadata.company_id`

## Architecture
```
Browser → React (Vite) → Supabase (direct for CRUD + real-time)
                       → Express server (for AI, IMF rates, integrations)
```
