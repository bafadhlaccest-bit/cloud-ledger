-- ============================================================
-- Cloud Ledger — Supabase Additions
-- Run this AFTER database_schema.sql in your Supabase SQL editor
-- ============================================================

-- Company settings (key-value per company)
CREATE TABLE IF NOT EXISTS company_settings (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id  UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    key         VARCHAR(100) NOT NULL,
    value       TEXT,
    updated_at  TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, key)
);
ALTER TABLE company_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_company_settings ON company_settings
    FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Bills table (missing from original schema)
CREATE TABLE IF NOT EXISTS bills (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    vendor_id       UUID NOT NULL,
    number          VARCHAR(50) NOT NULL,
    date            DATE NOT NULL,
    due_date        DATE NOT NULL,
    status          VARCHAR(30) DEFAULT 'Draft',
    subtotal        DECIMAL(15,2) DEFAULT 0,
    tax_total       DECIMAL(15,2) DEFAULT 0,
    total           DECIMAL(15,2) DEFAULT 0,
    notes           TEXT,
    currency        VARCHAR(3) DEFAULT 'USD',
    exchange_rate   DECIMAL(15,6) DEFAULT 1,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, number),
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, vendor_id) REFERENCES vendors(company_id, id) ON DELETE RESTRICT
);
ALTER TABLE bills ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_bills ON bills
    FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Bill lines
CREATE TABLE IF NOT EXISTS bill_lines (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    bill_id         UUID NOT NULL,
    item_id         UUID,
    description     TEXT,
    quantity        DECIMAL(15,2) NOT NULL,
    rate            DECIMAL(15,2) NOT NULL,
    tax_rate        DECIMAL(5,2) DEFAULT 0,
    amount          DECIMAL(15,2) NOT NULL,
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, bill_id) REFERENCES bills(company_id, id) ON DELETE CASCADE
);
ALTER TABLE bill_lines ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_bill_lines ON bill_lines
    FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Bank transactions (missing from original)
CREATE TABLE IF NOT EXISTS bank_transactions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    bank_account_id UUID NOT NULL,
    date            DATE NOT NULL,
    description     TEXT,
    amount          DECIMAL(15,2) NOT NULL,
    type            VARCHAR(20) NOT NULL, -- Deposit, Withdrawal, Transfer
    status          VARCHAR(20) DEFAULT 'Unreconciled',
    reference       VARCHAR(100),
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, id),
    FOREIGN KEY (company_id, bank_account_id) REFERENCES bank_accounts(company_id, id) ON DELETE CASCADE
);
ALTER TABLE bank_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_bank_transactions ON bank_transactions
    FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Currencies
CREATE TABLE IF NOT EXISTS currencies (
    id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code    VARCHAR(3) UNIQUE NOT NULL,
    name    VARCHAR(100) NOT NULL,
    symbol  VARCHAR(10)
);

-- Customer currencies (multi-currency per customer)
CREATE TABLE IF NOT EXISTS customer_currencies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id     UUID NOT NULL,
    currency_code   VARCHAR(3) NOT NULL,
    UNIQUE(company_id, customer_id, currency_code)
);

-- Vendor currencies
CREATE TABLE IF NOT EXISTS vendor_currencies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    vendor_id       UUID NOT NULL,
    currency_code   VARCHAR(3) NOT NULL,
    UNIQUE(company_id, vendor_id, currency_code)
);

-- Stock movements
CREATE TABLE IF NOT EXISTS stock_movements (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    item_id         UUID NOT NULL,
    date            DATE NOT NULL,
    type            VARCHAR(30) NOT NULL, -- IN, OUT, ADJUSTMENT
    quantity        DECIMAL(15,2) NOT NULL,
    unit_cost       DECIMAL(15,2) DEFAULT 0,
    reference       VARCHAR(100),
    notes           TEXT,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, id)
);
ALTER TABLE stock_movements ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_stock_movements ON stock_movements
    FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- ERP Event Bus
CREATE TABLE IF NOT EXISTS erp_event_bus (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    event_type      VARCHAR(100) NOT NULL,
    payload         JSONB,
    status          VARCHAR(20) DEFAULT 'pending',
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
ALTER TABLE erp_event_bus ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_erp_event_bus ON erp_event_bus
    FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Financial audit trails
CREATE TABLE IF NOT EXISTS financial_audit_trails (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    user_id         UUID,
    action          VARCHAR(100) NOT NULL,
    table_name      VARCHAR(100),
    record_id       UUID,
    old_values      JSONB,
    new_values      JSONB,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
ALTER TABLE financial_audit_trails ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_financial_audit_trails ON financial_audit_trails
    FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Contacts (separate from customers/vendors)
CREATE TABLE IF NOT EXISTS contacts (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id  UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name        VARCHAR(255) NOT NULL,
    email       VARCHAR(255),
    phone       VARCHAR(50),
    type        VARCHAR(20) DEFAULT 'general',
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, id)
);
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_contacts ON contacts
    FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Add missing fields to journal_entries
ALTER TABLE journal_entries
    ADD COLUMN IF NOT EXISTS total_debit  DECIMAL(15,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS total_credit DECIMAL(15,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS branch       VARCHAR(100),
    ADD COLUMN IF NOT EXISTS warehouse    VARCHAR(100),
    ADD COLUMN IF NOT EXISTS currency     VARCHAR(3) DEFAULT 'USD',
    ADD COLUMN IF NOT EXISTS is_reversal  BOOLEAN DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS updated_at   TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;

-- Add missing fields to accounts
ALTER TABLE accounts
    ADD COLUMN IF NOT EXISTS budget         DECIMAL(15,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS description    TEXT,
    ADD COLUMN IF NOT EXISTS ifrs_mapping   VARCHAR(50),
    ADD COLUMN IF NOT EXISTS currency       VARCHAR(3) DEFAULT 'USD';

-- Add missing fields to customers/vendors
ALTER TABLE customers
    ADD COLUMN IF NOT EXISTS country        VARCHAR(100),
    ADD COLUMN IF NOT EXISTS governorate    VARCHAR(100),
    ADD COLUMN IF NOT EXISTS street_address TEXT,
    ADD COLUMN IF NOT EXISTS city           VARCHAR(100),
    ADD COLUMN IF NOT EXISTS is_active      BOOLEAN DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS balance        DECIMAL(15,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS updated_at     TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE vendors
    ADD COLUMN IF NOT EXISTS country        VARCHAR(100),
    ADD COLUMN IF NOT EXISTS governorate    VARCHAR(100),
    ADD COLUMN IF NOT EXISTS street_address TEXT,
    ADD COLUMN IF NOT EXISTS city           VARCHAR(100),
    ADD COLUMN IF NOT EXISTS is_active      BOOLEAN DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS balance        DECIMAL(15,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS updated_at     TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;

-- Add missing fields to items
ALTER TABLE items
    ADD COLUMN IF NOT EXISTS product_type       VARCHAR(30),
    ADD COLUMN IF NOT EXISTS costing_method     VARCHAR(10) DEFAULT 'WAC',
    ADD COLUMN IF NOT EXISTS reorder_qty        DECIMAL(15,2) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS weight             DECIMAL(10,3),
    ADD COLUMN IF NOT EXISTS code               VARCHAR(50),
    ADD COLUMN IF NOT EXISTS updated_at         TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP;

-- ── Indexes ───────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_bills_company          ON bills(company_id);
CREATE INDEX IF NOT EXISTS idx_bank_transactions_co   ON bank_transactions(company_id);
CREATE INDEX IF NOT EXISTS idx_company_settings_co    ON company_settings(company_id);
CREATE INDEX IF NOT EXISTS idx_stock_movements_co     ON stock_movements(company_id);

-- ── Supabase Auth: Allow anon to read currencies ──────────────────
CREATE POLICY IF NOT EXISTS allow_read_currencies ON currencies FOR SELECT TO anon USING (true);

-- ── Seed default currencies ───────────────────────────────────────
INSERT INTO currencies (code, name, symbol) VALUES
  ('USD', 'US Dollar', '$'),
  ('EUR', 'Euro', '€'),
  ('SAR', 'Saudi Riyal', 'ر.س'),
  ('AED', 'UAE Dirham', 'د.إ'),
  ('YER', 'Yemeni Rial', '﷼'),
  ('EGP', 'Egyptian Pound', 'E£'),
  ('KWD', 'Kuwaiti Dinar', 'د.ك'),
  ('QAR', 'Qatari Riyal', 'ر.ق'),
  ('GBP', 'British Pound', '£'),
  ('JPY', 'Japanese Yen', '¥')
ON CONFLICT (code) DO NOTHING;

-- ============================================================
-- Secure Ledger Posting Function (called by PostingEngine)
-- ============================================================
CREATE OR REPLACE FUNCTION execute_secure_ledger_posting(
    p_company_id    UUID,
    p_date          DATE,
    p_reference     VARCHAR,
    p_description   TEXT,
    p_fiscal_year   INT,
    p_currency      VARCHAR DEFAULT 'USD',
    p_lines         JSONB DEFAULT '[]'
) RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_entry_id      UUID;
    v_total_debit   DECIMAL(15,2) := 0;
    v_total_credit  DECIMAL(15,2) := 0;
    v_line          JSONB;
BEGIN
    -- Calculate totals from lines
    FOR v_line IN SELECT * FROM jsonb_array_elements(p_lines)
    LOOP
        v_total_debit  := v_total_debit  + COALESCE((v_line->>'debit')::DECIMAL, 0);
        v_total_credit := v_total_credit + COALESCE((v_line->>'credit')::DECIMAL, 0);
    END LOOP;

    -- Validate double-entry balance
    IF ABS(v_total_debit - v_total_credit) > 0.01 THEN
        RAISE EXCEPTION 'Unbalanced entry: debit=% credit=%', v_total_debit, v_total_credit;
    END IF;

    -- Insert journal entry
    INSERT INTO journal_entries (
        company_id, date, reference, description,
        total_debit, total_credit, status, currency
    ) VALUES (
        p_company_id, p_date, p_reference, p_description,
        v_total_debit, v_total_credit, 'Posted', p_currency
    ) RETURNING id INTO v_entry_id;

    -- Insert journal lines
    FOR v_line IN SELECT * FROM jsonb_array_elements(p_lines)
    LOOP
        INSERT INTO journal_lines (
            company_id, journal_entry_id, account_id,
            debit, credit, description
        ) VALUES (
            p_company_id,
            v_entry_id,
            (v_line->>'accountId')::UUID,
            COALESCE((v_line->>'debit')::DECIMAL, 0),
            COALESCE((v_line->>'credit')::DECIMAL, 0),
            COALESCE(v_line->>'description', p_description)
        );

        -- Update account balance
        UPDATE accounts
        SET balance = COALESCE(balance, 0)
            + COALESCE((v_line->>'debit')::DECIMAL, 0)
            - COALESCE((v_line->>'credit')::DECIMAL, 0),
            updated_at = NOW()
        WHERE id = (v_line->>'accountId')::UUID
          AND company_id = p_company_id;
    END LOOP;

    RETURN v_entry_id;
END;
$$;

-- Grant execute to authenticated users
GRANT EXECUTE ON FUNCTION execute_secure_ledger_posting TO authenticated;

-- ============================================================
-- Fiscal Periods table fix (required by PostingEngine)
-- ============================================================
CREATE TABLE IF NOT EXISTS fiscal_periods (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    year            INT NOT NULL,
    period_number   INT NOT NULL,
    name            VARCHAR(50),
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    status          VARCHAR(20) DEFAULT 'Open',  -- Open | Closed | Locked
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, year, period_number)
);
ALTER TABLE fiscal_periods ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS tenant_isolation_fiscal_periods ON fiscal_periods
    FOR ALL USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Add balance column to accounts if missing
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS balance DECIMAL(15,2) DEFAULT 0;
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS opening_balance DECIMAL(15,2) DEFAULT 0;
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;

-- Function: auto-create fiscal periods for new companies
CREATE OR REPLACE FUNCTION create_default_fiscal_periods(p_company_id UUID, p_year INT)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
    FOR i IN 1..12 LOOP
        INSERT INTO fiscal_periods (company_id, year, period_number, name, start_date, end_date, status)
        VALUES (
            p_company_id, p_year, i,
            TO_CHAR(MAKE_DATE(p_year, i, 1), 'Month YYYY'),
            MAKE_DATE(p_year, i, 1),
            (MAKE_DATE(p_year, i, 1) + INTERVAL '1 month - 1 day')::DATE,
            'Open'
        )
        ON CONFLICT (company_id, year, period_number) DO NOTHING;
    END LOOP;
END;
$$;


-- ============================================================
-- جداول الصفحات الجديدة
-- ============================================================

-- Quotations (عروض الأسعار)
CREATE TABLE IF NOT EXISTS quotations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    number          VARCHAR(50) NOT NULL,
    customer_id     UUID NOT NULL,
    customer_name   VARCHAR(255),
    date            DATE NOT NULL,
    expiry_date     DATE NOT NULL,
    status          VARCHAR(20) DEFAULT 'Draft',
    subtotal        DECIMAL(15,2) DEFAULT 0,
    tax_total       DECIMAL(15,2) DEFAULT 0,
    total           DECIMAL(15,2) DEFAULT 0,
    notes           TEXT,
    currency        VARCHAR(3) DEFAULT 'SAR',
    lines           JSONB DEFAULT '[]',
    converted_to    UUID,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(company_id, number)
);
ALTER TABLE quotations ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS rls_quotations ON quotations FOR ALL
    USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Purchase Orders (أوامر الشراء)
CREATE TABLE IF NOT EXISTS purchase_orders (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    number          VARCHAR(50) NOT NULL,
    vendor_id       UUID NOT NULL,
    vendor_name     VARCHAR(255),
    date            DATE NOT NULL,
    expected_date   DATE,
    status          VARCHAR(20) DEFAULT 'Draft',
    subtotal        DECIMAL(15,2) DEFAULT 0,
    tax_total       DECIMAL(15,2) DEFAULT 0,
    total           DECIMAL(15,2) DEFAULT 0,
    notes           TEXT,
    currency        VARCHAR(3) DEFAULT 'SAR',
    lines           JSONB DEFAULT '[]',
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(company_id, number)
);
ALTER TABLE purchase_orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS rls_purchase_orders ON purchase_orders FOR ALL
    USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Expenses (المصروفات)
CREATE TABLE IF NOT EXISTS expenses (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    date            DATE NOT NULL,
    category        VARCHAR(100),
    description     TEXT NOT NULL,
    amount          DECIMAL(15,2) NOT NULL,
    tax_amount      DECIMAL(15,2) DEFAULT 0,
    total           DECIMAL(15,2) NOT NULL,
    payment_method  VARCHAR(50) DEFAULT 'نقداً',
    account_id      UUID,
    reference       VARCHAR(100),
    notes           TEXT,
    status          VARCHAR(20) DEFAULT 'Approved',
    receipt_url     TEXT,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS rls_expenses ON expenses FOR ALL
    USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Recurring Invoices (الفواتير المتكررة)
CREATE TABLE IF NOT EXISTS recurring_invoices (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id          UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    customer_id         UUID NOT NULL,
    customer_name       VARCHAR(255),
    description         TEXT,
    frequency           VARCHAR(20) NOT NULL DEFAULT 'monthly',
    day_of_month        INT DEFAULT 1,
    amount              DECIMAL(15,2) NOT NULL,
    tax_rate            DECIMAL(5,2) DEFAULT 15,
    tax_amount          DECIMAL(15,2) DEFAULT 0,
    total               DECIMAL(15,2) NOT NULL,
    currency            VARCHAR(3) DEFAULT 'SAR',
    start_date          DATE NOT NULL,
    end_date            DATE,
    next_date           DATE,
    last_generated      DATE,
    status              VARCHAR(20) DEFAULT 'Active',
    invoices_generated  INT DEFAULT 0,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
ALTER TABLE recurring_invoices ENABLE ROW LEVEL SECURITY;
CREATE POLICY IF NOT EXISTS rls_recurring_invoices ON recurring_invoices FOR ALL
    USING (company_id = NULLIF(current_setting('app.current_company_id', true), '')::UUID);

-- Add is_recurring to invoices
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS is_recurring BOOLEAN DEFAULT FALSE;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS recurring_id UUID;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS due_date DATE;

-- Indexes
CREATE INDEX IF NOT EXISTS idx_quotations_company    ON quotations(company_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_purchase_orders_co    ON purchase_orders(company_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_expenses_company      ON expenses(company_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_recurring_company     ON recurring_invoices(company_id, next_date);
CREATE INDEX IF NOT EXISTS idx_audit_company_date    ON financial_audit_trails(company_id, created_at DESC);
