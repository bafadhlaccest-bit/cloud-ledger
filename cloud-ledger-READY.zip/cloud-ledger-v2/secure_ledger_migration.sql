-- ============================================================================
-- SECURE TRANSACTIONAL LEDGER POSTING & ROW-LEVEL SECURITY MIGRATION
-- DESIGNED FOR IAS 1 COMPLIANCE, MULTI-TENANCY ISOLATION, AND DOUBLE-ENTRY INTEGRITY
-- ============================================================================

-- 1. Create fiscal_periods table to manage open/locked financial periods per tenant
CREATE TABLE IF NOT EXISTS fiscal_periods (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    year INT NOT NULL,
    month INT NOT NULL,
    status VARCHAR(20) DEFAULT 'OPEN', -- 'OPEN', 'locked'
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    locked_at TIMESTAMP WITH TIME ZONE,
    locked_by VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(company_id, year, month)
);

-- Seed some default open periods for 2026 to prevent unseeded period errors
INSERT INTO fiscal_periods (company_id, year, month, start_date, end_date, status)
SELECT 
    id AS company_id,
    2026 AS year,
    m AS month,
    (2026 || '-' || m || '-01')::DATE AS start_date,
    ((2026 || '-' || m || '-01')::DATE + INTERVAL '1 month' - INTERVAL '1 day')::DATE AS end_date,
    'OPEN' AS status
FROM companies, generate_series(1, 12) AS m
ON CONFLICT (company_id, year, month) DO NOTHING;


-- 2. Add idempotency_key column to journal_entries for double-posting protection
ALTER TABLE journal_entries ADD COLUMN IF NOT EXISTS idempotency_key VARCHAR(255);

-- Ensure clean re-runnability by dropping the constraint if it exists
ALTER TABLE journal_entries DROP CONSTRAINT IF EXISTS uq_company_idempotency;

-- Create composite unique constraint to block double-posting at the database layer
ALTER TABLE journal_entries ADD CONSTRAINT uq_company_idempotency UNIQUE(company_id, idempotency_key);


-- 3. Row-Level Security (RLS) Hardening
-- Enable Row Level Security (RLS) on all target tables
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE journal_lines ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they conflict to ensure smooth migration
DROP POLICY IF EXISTS tenant_isolation_jwt_accounts ON accounts;
DROP POLICY IF EXISTS tenant_isolation_jwt_journal_entries ON journal_entries;
DROP POLICY IF EXISTS tenant_isolation_jwt_journal_lines ON journal_lines;

-- Create strict isolation policies based on auth.jwt() metadata
CREATE POLICY tenant_isolation_jwt_accounts ON accounts
    FOR ALL 
    USING (company_id = ((auth.jwt() ->> 'app_metadata')::jsonb ->> 'company_id')::uuid);

CREATE POLICY tenant_isolation_jwt_journal_entries ON journal_entries
    FOR ALL 
    USING (company_id = ((auth.jwt() ->> 'app_metadata')::jsonb ->> 'company_id')::uuid);

CREATE POLICY tenant_isolation_jwt_journal_lines ON journal_lines
    FOR ALL 
    USING (company_id = ((auth.jwt() ->> 'app_metadata')::jsonb ->> 'company_id')::uuid);


-- 4. Atomic Double-Entry Ledger Posting Stored Procedure (RPC)
-- Implicitly runs inside a single database transaction. 
-- Any unhandled exception/raise exception rolls back all actions in the block.
CREATE OR REPLACE FUNCTION execute_secure_ledger_posting(
    p_company_id UUID,
    p_date DATE,
    p_reference VARCHAR,
    p_description TEXT,
    p_status VARCHAR,
    p_idempotency_key VARCHAR,
    p_lines JSONB -- Array of lines: [{"account_id": "...", "debit": 100.0, "credit": 0.0, "description": "..."}]
) RETURNS UUID AS $$
DECLARE
    v_journal_entry_id UUID;
    v_period_status VARCHAR;
    v_line RECORD;
    v_debit_total NUMERIC(15, 2) := 0;
    v_credit_total NUMERIC(15, 2) := 0;
BEGIN
    -- A. Apply a SELECT ... FOR UPDATE lock on the target row in the fiscal_periods table
    -- based on the year and month of p_date to prevent race conditions during period closure.
    SELECT status INTO v_period_status
    FROM fiscal_periods
    WHERE company_id = p_company_id
      AND year = EXTRACT(YEAR FROM p_date)
      AND month = EXTRACT(MONTH FROM p_date)
    FOR UPDATE;

    -- If no period is found, or if it is locked, raise an exception
    IF v_period_status IS NULL THEN
        RAISE EXCEPTION 'CRITICAL: No open fiscal period found for date %', p_date;
    ELSIF LOWER(v_period_status) = 'locked' THEN
        RAISE EXCEPTION 'CRITICAL: Fiscal period is locked for date %', p_date;
    END IF;

    -- B. Validate double-entry debits vs credits sum in the lines JSONB
    FOR v_line IN SELECT * FROM jsonb_to_recordset(p_lines) AS x(account_id UUID, debit NUMERIC(15, 2), credit NUMERIC(15, 2), description TEXT) LOOP
        v_debit_total := v_debit_total + COALESCE(v_line.debit, 0);
        v_credit_total := v_credit_total + COALESCE(v_line.credit, 0);
    END LOOP;

    IF ABS(v_debit_total - v_credit_total) > 0.001 THEN
        RAISE EXCEPTION 'Double-Entry Asymmetry Error: Total Debits (%) must equal Total Credits (%) perfectly.', v_debit_total, v_credit_total;
    END IF;

    -- C. Insert the journal entry header (protected by composite unique constraint on (company_id, idempotency_key))
    INSERT INTO journal_entries (company_id, date, reference, description, status, idempotency_key)
    VALUES (p_company_id, p_date, p_reference, p_description, p_status, p_idempotency_key)
    RETURNING id INTO v_journal_entry_id;

    -- D. Insert each line dynamically
    FOR v_line IN SELECT * FROM jsonb_to_recordset(p_lines) AS x(account_id UUID, debit NUMERIC(15, 2), credit NUMERIC(15, 2), description TEXT) LOOP
        INSERT INTO journal_lines (company_id, journal_entry_id, account_id, debit, credit, description)
        VALUES (p_company_id, v_journal_entry_id, v_line.account_id, COALESCE(v_line.debit, 0), COALESCE(v_line.credit, 0), COALESCE(v_line.description, p_description));
    END LOOP;

    RETURN v_journal_entry_id;
EXCEPTION
    WHEN OTHERS THEN
        -- Raise exception bubbles the error up, rolling back all intermediate inserts automatically
        RAISE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
