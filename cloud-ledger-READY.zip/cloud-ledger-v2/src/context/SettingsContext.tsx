import React, { createContext, useContext, useState, useEffect } from 'react';
import { safeStorage } from '../utils/safeStorage';
import { db, getDoc, onSnapshot, doc } from '../firebase';

export interface PermissionsMatrix {
  Admin: { read: boolean; create: boolean; update: boolean; delete: boolean };
  Accountant: { read: boolean; create: boolean; update: boolean; delete: boolean };
  Vendor: { read: boolean; create: boolean; update: boolean; delete: boolean };
}

export interface Settings {
  systemName: string;
  systemLogo: string;
  timezone: string;
  theme: 'light' | 'dark';
  currency: string;
  defaultSalesAccountId: string;
  defaultPayableAccountId: string;
  defaultCashAccountId: string;
  vatPercentage: number;
  invoicePrefix: string;
  invoiceSuffix: string;
  billPrefix: string;
  billSuffix: string;
  customerCreditLimitRestriction: boolean;
  vendorPaymentTermThreshold: number;
  enableServiceModule: boolean;
  permissionsMatrix: PermissionsMatrix;
  enable_cost_centers: boolean;
  require_invoice_approval_above: number;
  enforce_budget_expense_ledger: boolean;
  consolidation_company_id: string;
  revaluation_currency: string;
}

export interface SettingsContextType {
  settings: Settings;
  isLoading: boolean;
  updateSettings: (newSettings: Partial<Settings>) => Promise<boolean>;
  refreshSettings: () => Promise<void>;
}

const DEFAULT_SETTINGS: Settings = {
  systemName: "Al-Huraibi Trading Company Ltd.",
  systemLogo: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=128&q=80",
  timezone: "Asia/Aden",
  theme: "light",
  currency: "YER",
  defaultSalesAccountId: "acc_sales_revenue",
  defaultPayableAccountId: "acc_supplier_creditors",
  defaultCashAccountId: "acc_kuraimi",
  vatPercentage: 15,
  invoicePrefix: "INV",
  invoiceSuffix: "",
  billPrefix: "BILL",
  billSuffix: "",
  customerCreditLimitRestriction: true,
  vendorPaymentTermThreshold: 30,
  enableServiceModule: true,
  permissionsMatrix: {
    Admin: { read: true, create: true, update: true, delete: true },
    Accountant: { read: true, create: true, update: true, delete: false },
    Vendor: { read: true, create: false, update: false, delete: false }
  },
  enable_cost_centers: true,
  require_invoice_approval_above: 5000000,
  enforce_budget_expense_ledger: true,
  consolidation_company_id: "c1",
  revaluation_currency: "YER"
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

// Visual layout dynamic auto-theming helper engine
function fallbackHashColor(str: string): string {
  if (!str) return '#4f46e5';
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const palette = [
    '#4F46E5', // Indigo
    '#2563EB', // Blue
    '#059669', // Emerald
    '#D97706', // Amber
    '#DC2626', // Red
    '#7C3AED', // Violet
    '#0891B2', // Cyan
    '#1B3B6F', // Steel Navy
    '#028090', // Teal
  ];
  return palette[Math.abs(hash) % palette.length];
}

function getContrastTextColor(hexColor: string): string {
  let r = 79, g = 70, b = 229;
  if (hexColor.startsWith('#')) {
    const raw = hexColor.slice(1);
    if (raw.length === 3) {
      r = parseInt(raw[0] + raw[0], 16);
      g = parseInt(raw[1] + raw[1], 16);
      b = parseInt(raw[2] + raw[2], 16);
    } else if (raw.length === 6) {
      r = parseInt(raw.slice(0, 2), 16);
      g = parseInt(raw.slice(2, 4), 16);
      b = parseInt(raw.slice(4, 6), 16);
    }
  }
  const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
  return luminance > 140 ? '#1E1E1E' : '#FFFFFF';
}

function getHoverColor(hexColor: string, isLight: boolean): string {
  let r = 79, g = 70, b = 229;
  if (hexColor.startsWith('#')) {
    const raw = hexColor.slice(1);
    if (raw.length === 6) {
      r = parseInt(raw.slice(0, 2), 16);
      g = parseInt(raw.slice(2, 4), 16);
      b = parseInt(raw.slice(4, 6), 16);
    }
  }
  const factor = isLight ? -30 : 30;
  const clamp = (val: number) => Math.min(255, Math.max(0, Math.round(val + factor)));
  const hr = clamp(r).toString(16).padStart(2, '0');
  const hg = clamp(g).toString(16).padStart(2, '0');
  const hb = clamp(b).toString(16).padStart(2, '0');
  return `#${hr}${hg}${hb}`;
}

export function applyThemeVariables(primaryColor: string) {
  const contrastTextColor = getContrastTextColor(primaryColor);
  const isLight = contrastTextColor === '#1E1E1E';
  const hoverColor = getHoverColor(primaryColor, isLight);

  const root = document.documentElement;
  root.style.setProperty('--color-primary', primaryColor);
  root.style.setProperty('--color-primary-text', contrastTextColor);
  root.style.setProperty('--color-primary-hover', hoverColor);
  
  // Update class body light/dark or system styles
  // Just updating theme handles nice color transitions
}

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<Settings>(() => {
    try {
      const cached = safeStorage.getItem('erp_system_settings_cache');
      return cached ? JSON.parse(cached) : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Load from multiple endpoints
  const refreshSettings = async () => {
    setIsLoading(true);
    let loadedSettings = { ...DEFAULT_SETTINGS };

    // 1. Try local storage cache
    try {
      const cached = safeStorage.getItem('erp_system_settings_cache');
      if (cached) {
        loadedSettings = { ...loadedSettings, ...JSON.parse(cached) };
      }
    } catch (e) {
      console.warn("Local storage parse fail", e);
    }

    // 2. Fetch from Postgres simulated backend
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const remote = await res.json();
        if (remote && Object.keys(remote).length > 0) {
          loadedSettings = {
            ...loadedSettings,
            systemName: remote.systemName || remote.companyProfile?.name || loadedSettings.systemName,
            systemLogo: remote.systemLogo || remote.companyProfile?.logo || loadedSettings.systemLogo,
            timezone: remote.timezone || remote.companyProfile?.timezone || loadedSettings.timezone,
            theme: remote.theme || loadedSettings.theme,
            currency: remote.currency || remote.companyProfile?.currency || loadedSettings.currency,
            defaultSalesAccountId: remote.defaultSalesAccountId || loadedSettings.defaultSalesAccountId,
            defaultPayableAccountId: remote.defaultPayableAccountId || loadedSettings.defaultPayableAccountId,
            defaultCashAccountId: remote.defaultCashAccountId || loadedSettings.defaultCashAccountId,
            vatPercentage: typeof remote.vatPercentage !== 'undefined' ? Number(remote.vatPercentage) : loadedSettings.vatPercentage,
            invoicePrefix: remote.invoicePrefix || loadedSettings.invoicePrefix,
            invoiceSuffix: typeof remote.invoiceSuffix !== 'undefined' ? remote.invoiceSuffix : loadedSettings.invoiceSuffix,
            billPrefix: remote.billPrefix || loadedSettings.billPrefix,
            billSuffix: typeof remote.billSuffix !== 'undefined' ? remote.billSuffix : loadedSettings.billSuffix,
            customerCreditLimitRestriction: remote.customerCreditLimitRestriction !== undefined ? !!remote.customerCreditLimitRestriction : loadedSettings.customerCreditLimitRestriction,
            vendorPaymentTermThreshold: typeof remote.vendorPaymentTermThreshold !== 'undefined' ? Number(remote.vendorPaymentTermThreshold) : loadedSettings.vendorPaymentTermThreshold,
            enableServiceModule: remote.enableServiceModule !== undefined ? !!remote.enableServiceModule : loadedSettings.enableServiceModule,
            permissionsMatrix: remote.permissionsMatrix || loadedSettings.permissionsMatrix,
            enable_cost_centers: remote.enable_cost_centers !== undefined ? !!remote.enable_cost_centers : loadedSettings.enable_cost_centers,
            require_invoice_approval_above: typeof remote.require_invoice_approval_above !== 'undefined' ? Number(remote.require_invoice_approval_above) : loadedSettings.require_invoice_approval_above,
            enforce_budget_expense_ledger: remote.enforce_budget_expense_ledger !== undefined ? !!remote.enforce_budget_expense_ledger : loadedSettings.enforce_budget_expense_ledger,
            consolidation_company_id: remote.consolidation_company_id || loadedSettings.consolidation_company_id,
            revaluation_currency: remote.revaluation_currency || loadedSettings.revaluation_currency,
          };
        }
      }
    } catch (e) {
      console.warn("Failed fetching server settings:", e);
    }

    // 3. Try Firebase fallback
    try {
      const docRef = doc(db, 'settings', 'global_config');
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        const fire = snap.data() as any;
        if (fire) {
          loadedSettings = {
            ...loadedSettings,
            ...fire
          };
        }
      }
    } catch (e) {
      console.warn("Failed fetching Firestore settings:", e);
    }

    // Persist and apply
    setSettings(loadedSettings);
    try {
      safeStorage.setItem('erp_system_settings_cache', JSON.stringify(loadedSettings));
    } catch (e) {}

    // Apply corporate theming colors
    const themeColor = fallbackHashColor(loadedSettings.systemLogo || loadedSettings.systemName);
    applyThemeVariables(themeColor);

    setIsLoading(false);
  };

  // On mount, load settings
  useEffect(() => {
    refreshSettings();

    // Attach silent Firestore real-time listener
    let unsubscribe: () => void = () => {};
    try {
      const docRef = doc(db, 'settings', 'global_config');
      unsubscribe = onSnapshot(docRef, (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          if (data) {
            setSettings(prev => {
              const next = { ...prev, ...data };
              try {
                safeStorage.setItem('erp_system_settings_cache', JSON.stringify(next));
              } catch {}
              return next;
            });
          }
        }
      }, (err) => {
        // Safe fail
      });
    } catch (e) {
      console.warn("Failed attaching onSnapshot listener to Firestore settings:", e);
    }

    return () => unsubscribe();
  }, []);

  const updateSettings = async (newSettings: Partial<Settings>): Promise<boolean> => {
    // 1. تجهيز البيانات الجديدة بدمجها مع الإعدادات الحالية لضمان عدم فقدان أي حقل
    const updated = { ...settings, ...newSettings };
    let success = true;

    try {
      const reqPayload = {
        companyProfile: {
          name: updated.systemName || settings.systemName,
          logo: updated.systemLogo || settings.systemLogo,
          timezone: updated.timezone,
          currency: updated.currency,
          address: "Sana'a - Sixty Street, Yemen",
          contact: "+967 1 445566",
          website: "https://huraibi-trading.com",
          language: "ar",
          dateFormat: "YYYY-MM-DD",
          decimalFormat: "2 Decimals (.00)"
        },
        modulesMap: {
          enableServiceModule: updated.enableServiceModule
        }
      };

      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reqPayload)
      });
      if (!res.ok) success = false;
    } catch (e) {
      console.error("Failed saving to Postgres API:", e);
      success = false;
    }

    // 2. الحفظ في Firestore
    try {
      const docRef = doc(db, 'settings', 'global_config');
      await setDoc(docRef, updated, { merge: true });
    } catch (e) {
      console.error("Failed saving to Firestore settings:", e);
    }

    // 3. الخطوة السحرية الناقصة: تحديث الـ State في الواجهة فوراً عند النجاح
    if (success) {
      setSettings(updated);

      // Save to local cache
      try {
        safeStorage.setItem('erp_system_settings_cache', JSON.stringify(updated));
      } catch (e) {}

      // Apply the theme variables reactively
      const themeColor = fallbackHashColor(updated.systemLogo || updated.systemName);
      applyThemeVariables(themeColor);
    }

    return success;
  };

  return (
    <SettingsContext.Provider value={{ settings, isLoading, updateSettings, refreshSettings }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
