import React, { createContext, useContext, useState } from 'react';
import axios from 'axios';

// 1. تعريف واجهات البيانات (Interfaces)
export interface Account {
  id: string;
  code: string;
  name: string;
  type: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'INCOME' | 'EXPENSE';
  balance: number;
  isRoot?: boolean;      // حساب رئيسي محمي
  hasChildren?: boolean; // حساب أب تجميعي
  accountCategory?: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'INCOME' | 'EXPENSE';
  ifrsMapping?: 'CURRENT_ASSET' | 'NON_CURRENT_ASSET' | 'CURRENT_LIABILITY' | 'REVENUE' | 'COGS' | 'OPERATING_EXPENSE' | 'RETAINED_EARNINGS';
}

export interface Product {
  id: string;
  code: string;
  name: string;
  costingMethod: 'FIFO' | 'WAC';
  price: number;
  inventoryAccountId: string; // مربوط بـ 1400
  incomeAccountId: string;    // مربوط بـ 4100
  expenseAccountId: string;   // مربوط بـ 5100
}

interface AccountingContextType {
  accounts: Account[];
  products: Product[];
  baseCurrency: string;
  exchangeRates: Record<string, number>;
  setBaseCurrency: (currency: string) => void;
  updateManualRate: (code: string, rate: number) => void;
  fetchRatesFromIMF: () => Promise<void>;
}

const AccountingContext = createContext<AccountingContextType | undefined>(undefined);

export const AccountingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 2. حقن الحسابات الرئيسية والخمسة مع كامل الحسابات الفرعية والتشغيلية للنظام (Data Seeding)
  const [accounts, setAccounts] = useState<Account[]>([
    // الأصول والحسابات الفرعية لتشغيل الفواتير والبنك
    { id: '1000', code: '1000', name: 'الأصول', type: 'ASSET', balance: 0, isRoot: true, accountCategory: 'ASSET', ifrsMapping: 'CURRENT_ASSET' },
    { id: '1100', code: '1100', name: 'الذمم المدينة (العملاء)', type: 'ASSET', balance: 5000, hasChildren: false, accountCategory: 'ASSET', ifrsMapping: 'CURRENT_ASSET' },
    { id: '1200', code: '1200', name: 'حساب البنك الرئيسي', type: 'ASSET', balance: 25000, hasChildren: false, accountCategory: 'ASSET', ifrsMapping: 'CURRENT_ASSET' },
    { id: '1300', code: '1300', name: 'الصندوق (النقدية)', type: 'ASSET', balance: 1200, hasChildren: false, accountCategory: 'ASSET', ifrsMapping: 'CURRENT_ASSET' },
    { id: '1400', code: '1400', name: 'مخزون البضائع والأصناف', type: 'ASSET', balance: 8000, hasChildren: false, accountCategory: 'ASSET', ifrsMapping: 'CURRENT_ASSET' },

    // الالتزامات الخصوم وإعادتها إلى شجرتها الصحيحة
    { id: '2000', code: '2000', name: 'الالتزامات الخصوم', type: 'LIABILITY', balance: 0, isRoot: true, accountCategory: 'LIABILITY', ifrsMapping: 'CURRENT_LIABILITY' },
    { id: '2100', code: '2100', name: 'الذمم الدائنة (الموردين)', type: 'LIABILITY', balance: 3000, hasChildren: false, accountCategory: 'LIABILITY', ifrsMapping: 'CURRENT_LIABILITY' },
    { id: '2200', code: '2200', name: 'ضريبة القيمة المضافة المستحقة', type: 'LIABILITY', balance: 450, hasChildren: false, accountCategory: 'LIABILITY', ifrsMapping: 'CURRENT_LIABILITY' },

    // حقوق الملكية للملاك وضمان اتزان الميزانية العمومية
    { id: '3000', code: '3000', name: 'حقوق الملكية للملاك', type: 'EQUITY', balance: 0, isRoot: true, accountCategory: 'EQUITY', ifrsMapping: 'RETAINED_EARNINGS' },
    { id: '3100', code: '3100', name: 'رأس المال المدفوع', type: 'EQUITY', balance: 30000, hasChildren: false, accountCategory: 'EQUITY', ifrsMapping: 'RETAINED_EARNINGS' },
    { id: '3200', code: '3200', name: 'الأرباح المبقاة / المحتجزة', type: 'EQUITY', balance: 1750, hasChildren: false, accountCategory: 'EQUITY', ifrsMapping: 'RETAINED_EARNINGS' },

    // الإيرادات ومردودات المبيعات
    { id: '4000', code: '4000', name: 'الإيرادات التشغيلية', type: 'INCOME', balance: 0, isRoot: true, accountCategory: 'INCOME', ifrsMapping: 'REVENUE' },
    { id: '4100', code: '4100', name: 'إيرادات المبيعات العامة', type: 'INCOME', balance: 12000, hasChildren: false, accountCategory: 'INCOME', ifrsMapping: 'REVENUE' },
    { id: '4200', code: '4200', name: 'مردودات ومسموحات المبيعات', type: 'INCOME', balance: 500, hasChildren: false, accountCategory: 'INCOME', ifrsMapping: 'REVENUE' },

    // المصاريف وتكلفة البضاعة المباعة
    { id: '5000', code: '5000', name: 'المصاريف التشغيلية', type: 'EXPENSE', balance: 0, isRoot: true, accountCategory: 'EXPENSE', ifrsMapping: 'COGS' },
    { id: '5100', code: '5100', name: 'تكلفة البضاعة المباعة (COGS)', type: 'EXPENSE', balance: 6500, hasChildren: false, accountCategory: 'EXPENSE', ifrsMapping: 'COGS' },
    { id: '5300', code: '5300', name: 'المصاريف الإدارية والعمومية', type: 'EXPENSE', balance: 1500, hasChildren: false, accountCategory: 'EXPENSE', ifrsMapping: 'OPERATING_EXPENSE' }
  ]);

  // 3. حقن المنتجات التشغيلية لكي تظهر في القوائم المنسدلة لأسطر الفواتير والمخزون
  const [products] = useState<Product[]>([
    { id: 'p1', code: 'PRD-001', name: 'خلاط تجاري بقوة 2000 واط', costingMethod: 'FIFO', price: 250, inventoryAccountId: '1400', incomeAccountId: '4100', expenseAccountId: '5100' },
    { id: 'p2', code: 'PRD-002', name: 'مكسب هواء توربيني حديث', costingMethod: 'WAC', price: 450, inventoryAccountId: '1400', incomeAccountId: '4100', expenseAccountId: '5100' },
    { id: 'p3', code: 'PRD-003', name: 'قطع غيار توربين قياسية', costingMethod: 'FIFO', price: 45, inventoryAccountId: '1400', incomeAccountId: '4100', expenseAccountId: '5100' }
  ]);

  const [baseCurrency, setBaseCurrency] = useState<string>('USD');
  const [exchangeRates, setExchangeRates] = useState<Record<string, number>>({
    'USD': 1.0, 'EUR': 0.92, 'SAR': 3.75, 'YER': 250.0, 'AED': 3.67, 'EGP': 47.5
  });

  // 4. دمج محرك جلب أسعار الصرف من صندوق النقد الدولي (IMF) مع إعادة المعايرة للعملة الأساس
  const fetchRatesFromIMF = async () => {
    try {
      const res = await axios.get('https://dataservices.imf.org/REST/SDMX_JSON.svc/CompactData/EXR/D..SDR..XDC');
      const series = res.data?.StructureSpecificData?.DataSet?.Series;
      const rawRates: Record<string, number> = {};
      
      if (series && Array.isArray(series)) {
        series.forEach((item: any) => {
          const code = item['@UNIT_MEASURE'];
          const obs = item['Obs'];
          const latestObs = Array.isArray(obs) ? obs[obs.length - 1] : obs;
          if (latestObs) rawRates[code] = parseFloat(latestObs['@OBS_VALUE']);
        });
      }

      const baseToSdr = rawRates[baseCurrency] || 1.0;
      const reCalibrated: Record<string, number> = {};
      Object.keys(rawRates).forEach(code => {
        reCalibrated[code] = rawRates[code] / baseToSdr;
      });
      reCalibrated[baseCurrency] = 1.0;
      setExchangeRates(prev => ({ ...prev, ...reCalibrated }));
    } catch (e) {
      console.warn("Using baseline fallback rates due to network timeout.");
    }
  };

  // 5. ميزة التعديل اليدوي الفوري لأسعار الصرف (إدارة السوق المحلية)
  const updateManualRate = (code: string, rate: number) => {
    setExchangeRates(prev => ({
      ...prev,
      [code]: rate
    }));
  };

  return (
    <AccountingContext.Provider value={{ accounts, products, baseCurrency, exchangeRates, setBaseCurrency, updateManualRate, fetchRatesFromIMF }}>
      {children}
    </AccountingContext.Provider>
  );
};

export const useAccounting = () => {
  const context = useContext(AccountingContext);
  if (!context) throw new Error('useAccounting must be used within an AccountingProvider');
  return context;
};
