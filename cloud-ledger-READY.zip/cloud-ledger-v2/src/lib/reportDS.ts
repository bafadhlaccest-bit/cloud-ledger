import { DBTable, TableJoin } from '../types/reports';

export const ERP_TABLES: DBTable[] = [
  {
    id: 'accounts',
    name: 'accounts',
    label: 'Accounts (الحسابات الدليلة)',
    arabicLabel: 'دليل الحسابات',
    module: 'Accounts',
    fields: [
      { name: 'code', type: 'string', label: 'Account Code', arabicLabel: 'رمز الحساب' },
      { name: 'name', type: 'string', label: 'Account Name', arabicLabel: 'اسم الحساب' },
      { name: 'type', type: 'string', label: 'Account Type', arabicLabel: 'نوع الحساب' },
      { name: 'balance', type: 'number', label: 'Current Balance', arabicLabel: 'الرصيد الدفتري' }
    ]
  },
  {
    id: 'journal_entries',
    name: 'journal_entries',
    label: 'Journal Entries (قيود اليومية)',
    arabicLabel: 'اليومية العامة',
    module: 'Accounts',
    fields: [
      { name: 'id', type: 'string', label: 'Journal ID', arabicLabel: 'رقم القيد' },
      { name: 'date', type: 'date', label: 'Date', arabicLabel: 'تاريخ القيد' },
      { name: 'description', type: 'string', label: 'Description', arabicLabel: 'شرح القيد' },
      { name: 'total_debit', type: 'number', label: 'Total Debit', arabicLabel: 'إجمالي المدين' },
      { name: 'total_credit', type: 'number', label: 'Total Credit', arabicLabel: 'إجمالي الدائن' }
    ]
  },
  {
    id: 'journal_lines',
    name: 'journal_lines',
    label: 'Journal Lines (تفاصيل قيود اليومية دائن ومدين)',
    arabicLabel: 'تفاصيل سطور قيد اليومية',
    module: 'Accounts',
    fields: [
      { name: 'id', type: 'string', label: 'Line ID', arabicLabel: 'رقم السطر' },
      { name: 'journal_entry_id', type: 'string', label: 'Journal Entry ID', arabicLabel: 'رقم قيد المعلم' },
      { name: 'account_id', type: 'string', label: 'Account ID', arabicLabel: 'رقم حساب السطر' },
      { name: 'debit', type: 'number', label: 'Debit Amount', arabicLabel: 'مبلغ مدين' },
      { name: 'credit', type: 'number', label: 'Credit Amount', arabicLabel: 'مبلغ دائن' },
      { name: 'description', type: 'string', label: 'Description', arabicLabel: 'الوصف التفصيلي' },
      { name: 'branch', type: 'string', label: 'Branch', arabicLabel: 'الفرع' },
      { name: 'warehouse', type: 'string', label: 'Warehouse', arabicLabel: 'المستودع' }
    ]
  },
  {
    id: 'items',
    name: 'items',
    label: 'Items Registry (دليل الأصناف)',
    arabicLabel: 'دليل المستودعات - الأصناف',
    module: 'Inventory',
    fields: [
      { name: 'item_code', type: 'string', label: 'Item Code', arabicLabel: 'رمز الصنف' },
      { name: 'item_name', type: 'string', label: 'Item Name', arabicLabel: 'اسم الصنف' },
      { name: 'category', type: 'string', label: 'Category', arabicLabel: 'المجموعة' },
      { name: 'avg_cost', type: 'number', label: 'Average Cost', arabicLabel: 'متوسط التكلفة' },
      { name: 'stock_qty', type: 'number', label: 'Stock Quantity', arabicLabel: 'الكمية المتوفرة' }
    ]
  },
  {
    id: 'warehouses',
    name: 'warehouses',
    label: 'Warehouses (المستودعات والخزائن)',
    arabicLabel: 'المخازن والفروع',
    module: 'Inventory',
    fields: [
      { name: 'warehouse_code', type: 'string', label: 'Warehouse Code', arabicLabel: 'رمز المخزن' },
      { name: 'name', type: 'string', label: 'Warehouse Name', arabicLabel: 'اسم المخزن' },
      { name: 'branch', type: 'string', label: 'Branch', arabicLabel: 'الفرع' }
    ]
  },
  {
    id: 'invoices_header',
    name: 'invoices_header',
    label: 'Sales Invoices (فاتورة المبيعات الرئيسية)',
    arabicLabel: 'فواتير المبيعات',
    module: 'Sales',
    fields: [
      { name: 'invoice_no', type: 'string', label: 'Invoice No', arabicLabel: 'رقم الفاتورة' },
      { name: 'date', type: 'date', label: 'Date', arabicLabel: 'التاريخ' },
      { name: 'customer_id', type: 'string', label: 'Customer ID', arabicLabel: 'رقم العميل' },
      { name: 'warehouse_code', type: 'string', label: 'Warehouse Code', arabicLabel: 'رقم المستودع' },
      { name: 'sub_total', type: 'number', label: 'Sub Total', arabicLabel: 'المبلغ الأساسي' },
      { name: 'tax_amount', type: 'number', label: 'Tax Amount', arabicLabel: 'مبلغ الضريبة' },
      { name: 'grand_total', type: 'number', label: 'Grand Total', arabicLabel: 'الإجمالي النهائي' }
    ]
  },
  {
    id: 'invoice_lines',
    name: 'invoice_lines',
    label: 'Invoice Details (تفاصيل الفاتورة مبيعات)',
    arabicLabel: 'تفاصيل المبيعات',
    module: 'Sales',
    fields: [
      { name: 'invoice_no', type: 'string', label: 'Invoice No', arabicLabel: 'رقم الفاتورة' },
      { name: 'item_code', type: 'string', label: 'Item Code', arabicLabel: 'رمز الصنف' },
      { name: 'qty', type: 'number', label: 'Quantity Sold', arabicLabel: 'الكمية المباعة' },
      { name: 'unit_price', type: 'number', label: 'Unit Price', arabicLabel: 'سعر الوحدة' },
      { name: 'total_row', type: 'number', label: 'Total Sales', arabicLabel: 'القيمة النهائية' }
    ]
  },
  {
    id: 'customers',
    name: 'customers',
    label: 'Customers Ledger (دليل العملاء)',
    arabicLabel: 'حسابات العملاء',
    module: 'Sales',
    fields: [
      { name: 'customer_id', type: 'string', label: 'Customer ID', arabicLabel: 'رقم العميل' },
      { name: 'customer_name', type: 'string', label: 'Customer Name', arabicLabel: 'اسم العميل' },
      { name: 'city', type: 'string', label: 'City', arabicLabel: 'المدينة' },
      { name: 'credit_limit', type: 'number', label: 'Credit Limit', arabicLabel: 'سقف الائتمان' }
    ]
  },
  {
    id: 'vendors',
    name: 'vendors',
    label: 'Vendors / Suppliers (الموردين والاعتمادات)',
    arabicLabel: 'دليل الموردين',
    module: 'Purchasing',
    fields: [
      { name: 'vendor_id', type: 'string', label: 'Vendor ID', arabicLabel: 'رقم المورد' },
      { name: 'vendor_name', type: 'string', label: 'Vendor Name', arabicLabel: 'اسم المورد' },
      { name: 'balance', type: 'number', label: 'Balance Outstanding', arabicLabel: 'الرصيد الدائن' }
    ]
  },
  {
    id: 'warehouse_sales_summary',
    name: 'warehouse_sales_summary',
    label: 'Ready-Processed Warehouse Sales (ملخص مبيعات المخازن المجهز)',
    arabicLabel: 'مستودع البيانات - ملخص المبيعات الجاهز',
    module: 'Accounts',
    fields: [
      { name: 'invoice_no', type: 'string', label: 'Invoice No', arabicLabel: 'رقم الفاتورة' },
      { name: 'date', type: 'date', label: 'Date', arabicLabel: 'التاريخ' },
      { name: 'customer_name', type: 'string', label: 'Customer Name', arabicLabel: 'اسم العميل' },
      { name: 'warehouse_code', type: 'string', label: 'Warehouse Code', arabicLabel: 'رمز المستودع' },
      { name: 'sub_total', type: 'number', label: 'Taxable Amount', arabicLabel: 'الوعاء الخاضع للضريبة' },
      { name: 'tax_amount', type: 'number', label: 'Tax Amount', arabicLabel: 'مبلغ الضريبة' },
      { name: 'grand_total', type: 'number', label: 'Grand Total', arabicLabel: 'الإجمالي بالضريبة' },
      { name: 'status', type: 'string', label: 'Status', arabicLabel: 'حالة المعالجة المجمعة' }
    ]
  },
  {
    id: 'warehouse_inventory_status',
    name: 'warehouse_inventory_status',
    label: 'Ready-Processed Warehouse Valuation (تقييم المخزون المجهز للتقارير)',
    arabicLabel: 'مستودع البيانات - حالة المخزون الجاهزة',
    module: 'Inventory',
    fields: [
      { name: 'item_code', type: 'string', label: 'Item Code', arabicLabel: 'رمز الصنف' },
      { name: 'item_name', type: 'string', label: 'Item Name', arabicLabel: 'اسم الصنف' },
      { name: 'category', type: 'string', label: 'Category', arabicLabel: 'فئة الصنف' },
      { name: 'current_quantity', type: 'number', label: 'Aggregated Stock Qty', arabicLabel: 'إجمالي الكمية المتوفرة بالدفتر' },
      { name: 'avg_cost', type: 'number', label: 'Average Cost', arabicLabel: 'متوسط تكلفة الصنف الشراء' },
      { name: 'computed_valuation', type: 'number', label: 'Warehouse Total Valuation', arabicLabel: 'إجمالي تقييم تكلفة المخزون' },
      { name: 'reorder_status', type: 'string', label: 'Safety Reorder Status', arabicLabel: 'حالة حد الأمان للمخزون' }
    ]
  },
  {
    id: 'warehouse_financial_ratios',
    name: 'warehouse_financial_ratios',
    label: 'IFRS Financial Performance KPI (مؤشرات الأداء المالي IFRS المجهزة)',
    arabicLabel: 'مستودع البيانات - المؤشرات المالية الجاهزة للتدقيق',
    module: 'Accounts',
    fields: [
      { name: 'period', type: 'string', label: 'Fiscal Period', arabicLabel: 'الفترة المالية لتقرير' },
      { name: 'gross_margin_pct', type: 'number', label: 'Gross Margin %', arabicLabel: 'نسبة هامش الربح الإجمالي' },
      { name: 'current_ratio', type: 'number', label: 'Current Liquidity Ratio', arabicLabel: 'نسبة السيولة المتداولة الحالية' },
      { name: 'net_profit_margin_pct', type: 'number', label: 'Net Profit Margin %', arabicLabel: 'نسبة هامش صافي الأرباح' }
    ]
  }
];

// Seeded sample dynamic databases for simulated query execution
export const MOCK_DB_RECORDS: Record<string, any[]> = {
  accounts: [
    { id: 'acc_kuraimi', code: '110101', name: 'Al-Kuraimi Cash YER (صندوق المركز رئيسي)', type: 'Assets', balance: 45000000 },
    { id: 'acc_cash_usd', code: '110102', name: 'Cash USD Vault (خزينة العملة أجنبي)', type: 'Assets', balance: 85200 },
    { id: 'acc_receivables', code: '120101', name: 'Trade Receivables (مدينو التجارة مبيعات)', type: 'Assets', balance: 14200000 },
    { id: 'acc_supplier_creditors', code: '210101', name: 'Tadhamon Bank Supplier Creditors', type: 'Liabilities', balance: 9300000 },
    { id: 'acc_sales_revenue', code: '410101', name: 'Standard Product Sales Revenue', type: 'Revenue', balance: 198000000 },
    { id: 'acc_cogs', code: '510101', name: 'Cost of Goods Sold (تكلفة المبيعات)', type: 'Expenses', balance: 110000000 }
  ],
  journal_entries: [
    { id: 'JE-1001', date: '2026-05-15', description: 'Opening Balance Entry Form', total_debit: 5000000, total_credit: 5000000 },
    { id: 'JE-1002', date: '2026-05-20', description: 'Monthly branch payroll transfer', total_debit: 8250000, total_credit: 8250000 },
    { id: 'JE-1003', date: '2026-05-28', description: 'Tax Return calculation remittance YER', total_debit: 1150000, total_credit: 1150000 }
  ],
  journal_lines: [
    { id: 'JL-001', journal_entry_id: 'JE-1001', account_id: 'acc_kuraimi', debit: 5000000, credit: 0, description: 'Bank balance remittance', branch: "Sana'a Main HQ branch", warehouse: "WH-MAIN (Sana'a)" },
    { id: 'JL-002', journal_entry_id: 'JE-1001', account_id: 'acc_supplier_creditors', debit: 0, credit: 5000000, description: 'Opening liability balanced', branch: "Sana'a Main HQ branch", warehouse: "WH-MAIN (Sana'a)" },
    { id: 'JL-003', journal_entry_id: 'JE-1002', account_id: 'acc_cogs', debit: 8250000, credit: 0, description: 'Payroll expense routing', branch: "Taiz Cold Store Branch", warehouse: "WH-TAIZ (Cold Yard)" },
    { id: 'JL-004', journal_entry_id: 'JE-1002', account_id: 'acc_kuraimi', debit: 0, credit: 8250000, description: 'Cash payroll funding transfer', branch: "Taiz Cold Store Branch", warehouse: "WH-TAIZ (Cold Yard)" },
    { id: 'JL-005', journal_entry_id: 'JE-1003', account_id: 'acc_receivables', debit: 1150000, credit: 0, description: 'Credit adjustment for tax dues', branch: "Sana'a Main HQ branch", warehouse: "WH-MAIN (Sana'a)" },
    { id: 'JL-006', journal_entry_id: 'JE-1003', account_id: 'acc_sales_revenue', debit: 0, credit: 1150000, description: 'Refunding offset', branch: "Sana'a Main HQ branch", warehouse: "WH-MAIN (Sana'a)" }
  ],
  items: [
    { item_code: 'ITM-001', item_name: 'Premium Basmati Sella Rice YER', category: 'Foodstuff', avg_cost: 14500, stock_qty: 1200 },
    { item_code: 'ITM-002', item_name: 'Raw Sugarcane Sugar 50KG', category: 'Foodstuff', avg_cost: 22000, stock_qty: 480 },
    { item_code: 'ITM-003', item_name: 'Sunflower Cooking Oil 10L', category: 'Oils', avg_cost: 9800, stock_qty: 1150 },
    { item_code: 'ITM-004', item_name: 'Premium Wheat Flour 50kg', category: 'Grains', avg_cost: 16200, stock_qty: 2400 }
  ],
  warehouses: [
    { warehouse_code: 'WH-MAIN', name: 'Sana\'a Main Store (مخزن صنعاء الرئيسي)', branch: 'Sana\'a Hub' },
    { warehouse_code: 'WH-ADEN', name: 'Aden Sea Port Storage Yard (مخزن ميناء عدن)', branch: 'Aden Freezone' },
    { warehouse_code: 'WH-TAIZ', name: 'Taiz West Sector Cold Storage', branch: 'Taiz Division' }
  ],
  invoices_header: [
    { invoice_no: 'INV-2026-001', date: '2026-05-01', customer_id: 'CUST-01', warehouse_code: 'WH-MAIN', sub_total: 1560000, tax_amount: 234000, grand_total: 1794000 },
    { invoice_no: 'INV-2026-002', date: '2026-05-03', customer_id: 'CUST-02', warehouse_code: 'WH-MAIN', sub_total: 890000, tax_amount: 133500, grand_total: 1023500 },
    { invoice_no: 'INV-2026-003', date: '2026-05-12', customer_id: 'CUST-01', warehouse_code: 'WH-ADEN', sub_total: 3450000, tax_amount: 517500, grand_total: 3967500 },
    { invoice_no: 'INV-2026-004', date: '2026-05-22', customer_id: 'CUST-03', warehouse_code: 'WH-TAIZ', sub_total: 1120000, tax_amount: 168000, grand_total: 1288000 }
  ],
  invoice_lines: [
    { invoice_no: 'INV-2026-001', item_code: 'ITM-001', qty: 50, unit_price: 18000, total_row: 900000 },
    { invoice_no: 'INV-2026-001', item_code: 'ITM-003', qty: 67, unit_price: 11000, total_row: 660000 },
    { invoice_no: 'INV-2026-002', item_code: 'ITM-002', qty: 35, unit_price: 25428, total_row: 890000 },
    { invoice_no: 'INV-2026-003', item_code: 'ITM-004', qty: 150, unit_price: 23000, total_row: 3450000 },
    { invoice_no: 'INV-2026-004', item_code: 'ITM-001', qty: 62, unit_price: 18000, total_row: 1120000 }
  ],
  customers: [
    { customer_id: 'CUST-01', customer_name: 'Sabafon Telecommunications Corp (سبأفون)', city: 'Sana\'a', credit_limit: 50000000 },
    { customer_id: 'CUST-02', customer_name: 'Hayel Saeed Anam Group (هائل سعيد)', city: 'Taiz', credit_limit: 120000000 },
    { customer_id: 'CUST-03', customer_name: 'Al-Thuraiya Trading Agency (الثريا)', city: 'Aden', credit_limit: 15000000 }
  ],
  vendors: [
    { vendor_id: 'VEND-01', vendor_name: 'Yemen Flour Mills & Silos Co.', balance: 13200000 },
    { vendor_id: 'VEND-02', vendor_name: 'Red Sea Refineries Ltd.', balance: 24700000 }
  ],
  warehouse_sales_summary: [
    { invoice_no: 'INV-2026-001', date: '2026-05-01', customer_name: 'Sabafon Telecommunications Corp (سبأفون)', warehouse_code: 'WH-MAIN', sub_total: 1560000, tax_amount: 234000, grand_total: 1794000, status: 'Processed' },
    { invoice_no: 'INV-2026-002', date: '2026-05-03', customer_name: 'Hayel Saeed Anam Group (هائل سعيد)', warehouse_code: 'WH-MAIN', sub_total: 890000, tax_amount: 133500, grand_total: 1023500, status: 'Processed' },
    { invoice_no: 'INV-2026-003', date: '2026-05-12', customer_name: 'Sabafon Telecommunications Corp (سبأفون)', warehouse_code: 'WH-ADEN', sub_total: 3450000, tax_amount: 517500, grand_total: 3967500, status: 'Processed' },
    { invoice_no: 'INV-2026-004', date: '2026-05-22', customer_name: 'Al-Thuraiya Trading Agency (الثريا)', warehouse_code: 'WH-TAIZ', sub_total: 1120000, tax_amount: 168000, grand_total: 1288000, status: 'Processed' }
  ],
  warehouse_inventory_status: [
    { item_code: 'ITM-001', item_name: 'Premium Basmati Sella Rice YER', category: 'Foodstuff', current_quantity: 1200, avg_cost: 14500, computed_valuation: 17400000, reorder_status: 'Optimal' },
    { item_code: 'ITM-002', item_name: 'Raw Sugarcane Sugar 50KG', category: 'Foodstuff', current_quantity: 480, avg_cost: 22000, computed_valuation: 10560000, reorder_status: 'Reorder Level' },
    { item_code: 'ITM-003', item_name: 'Sunflower Cooking Oil 10L', category: 'Oils', current_quantity: 1150, avg_cost: 9800, computed_valuation: 11270000, reorder_status: 'Optimal' },
    { item_code: 'ITM-004', item_name: 'Premium Wheat Flour 50kg', category: 'Grains', current_quantity: 2400, avg_cost: 16200, computed_valuation: 38880000, reorder_status: 'Optimal' }
  ],
  warehouse_financial_ratios: [
    { period: 'May-2026', gross_margin_pct: 44.4, current_ratio: 4.8, net_profit_margin_pct: 12.5 }
  ]
};

// SQL-style dynamic joint simulation for previewing raw queries
export function executeSimulatedQuery(
  primaryTableId: string, 
  joins: TableJoin[]
): any[] {
  let results = MOCK_DB_RECORDS[primaryTableId] ? [...MOCK_DB_RECORDS[primaryTableId]] : [];
  
  if (results.length === 0) return [];

  // Iterate over each join statement to mix in fields
  for (const join of joins) {
    const isLeftPrimary = join.leftTable === primaryTableId;
    const isRightPrimary = join.rightTable === primaryTableId;

    const targetTableId = isLeftPrimary ? join.rightTable : join.leftTable;
    const targetPayload = MOCK_DB_RECORDS[targetTableId];
    if (!targetPayload) continue;

    // The primary key and target key fields
    const primaryKey = isLeftPrimary ? join.leftField : join.rightField;
    const targetKey = isLeftPrimary ? join.rightField : join.leftField;

    results = results.map(row => {
      const pValue = row[primaryKey];
      // Find matching item in target payload
      const matched = targetPayload.find(tItem => String(tItem[targetKey]) === String(pValue));
      
      const enriched: Record<string, any> = { ...row };
      if (join.joinType === 'Inner Join' && !matched) {
        return null; // drop row
      }

      if (matched) {
        // Namespace keys correctly
        for (const [key, val] of Object.entries(matched)) {
          if (enriched[key] === undefined) {
            enriched[`${targetTableId}_${key}`] = val;
            enriched[key] = val; // direct access if unique
          } else {
            enriched[`${targetTableId}_${key}`] = val;
          }
        }
      }
      return enriched;
    }).filter(Boolean);
  }

  return results;
}

// Generates simulated raw SQL queries in real-time
export function buildSimulatedSQL(
  primaryTableId: string, 
  joins: TableJoin[],
  groupField?: string
): string {
  if (!primaryTableId) return '-- Configure data source tables --';
  
  let sql = `SELECT \n  ${primaryTableId}.*`;
  
  joins.forEach(join => {
    const isLeftPrim = join.leftTable === primaryTableId;
    const targetTable = isLeftPrim ? join.rightTable : join.leftTable;
    sql += `,\n  ${targetTable}.*`;
  });

  sql += `\nFROM ${primaryTableId}`;

  joins.forEach(join => {
    sql += `\n${join.joinType.toUpperCase()} ${join.rightTable} ON ${join.leftTable}.${join.leftField} = ${join.rightTable}.${join.rightField}`;
  });

  if (groupField) {
    sql += `\nGROUP BY ${groupField}`;
  }

  return sql;
}
