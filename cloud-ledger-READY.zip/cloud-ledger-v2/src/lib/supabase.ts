import { createClient } from '@supabase/supabase-js';
import { safeStorage } from '../utils/safeStorage';

const SUPABASE_URL  = import.meta.env.VITE_SUPABASE_URL  as string;
const SUPABASE_ANON = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!SUPABASE_URL || !SUPABASE_ANON) {
  console.error('[Supabase] Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY in .env');
}

const supabaseStorage = {
  getItem:    (k: string) => { try { return safeStorage.getItem(k); } catch { return null; } },
  setItem:    (k: string, v: string) => { try { safeStorage.setItem(k, v); } catch {} },
  removeItem: (k: string) => { try { safeStorage.removeItem(k); } catch {} },
};

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON, {
  auth: {
    storage: supabaseStorage,
    persistSession: true,
    detectSessionInUrl: true,
  },
});
