import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { safeStorage } from '../utils/safeStorage';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function getActiveLanguage(): 'ar' | 'en' {
  try {
    const i18nOption = safeStorage.getItem('i18nextLng');
    if (i18nOption) {
      return i18nOption.toLowerCase().startsWith('en') ? 'en' : 'ar';
    }
  } catch (e) {}

  try {
    const localSettingsStr = safeStorage.getItem('cloud_ledger_settings');
    if (localSettingsStr) {
      const parsed = JSON.parse(localSettingsStr);
      const lang = parsed.companyProfile?.language || '';
      if (lang) {
        return lang.toLowerCase().includes('english') || lang.toLowerCase().includes('en-us') ? 'en' : 'ar';
      }
    }
  } catch (e) {}
  
  try {
    const saved = safeStorage.getItem('system_language') || '';
    if (saved) {
      return saved.toLowerCase().includes('english') || saved.toLowerCase().includes('en-us') ? 'en' : 'ar';
    }
  } catch (e) {}

  try {
    const htmlLang = document.documentElement.getAttribute('lang');
    if (htmlLang) {
      return htmlLang.toLowerCase().startsWith('en') ? 'en' : 'ar';
    }
  } catch (e) {}

  return 'ar';
}

export function formatCurrency(amount: number, currency?: string) {
  const lang = getActiveLanguage();
  let defaultCurrency = 'USD';
  
  try {
    const localSettingsStr = safeStorage.getItem('cloud_ledger_settings');
    if (localSettingsStr) {
      const parsed = JSON.parse(localSettingsStr);
      if (parsed.companyProfile?.currency) {
        defaultCurrency = parsed.companyProfile.currency;
      }
    }
  } catch (e) {}

  const activeCurrency = currency || defaultCurrency;
  const locale = lang === 'ar' ? 'ar-YE' : 'en-US';
  
  const currencySymbolsAr: Record<string, string> = {
    'YER': 'ر.ي',
    'USD': '$',
    'SAR': 'ر.س'
  };
  
  const currencySymbolsEn: Record<string, string> = {
    'YER': 'YER',
    'USD': '$',
    'SAR': 'SAR'
  };

  const formattedAmount = new Intl.NumberFormat(locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);

  const symbol = lang === 'ar' 
    ? (currencySymbolsAr[activeCurrency] || activeCurrency) 
    : (currencySymbolsEn[activeCurrency] || activeCurrency);

  return lang === 'ar' 
    ? `${formattedAmount} ${symbol}` 
    : `${symbol}${formattedAmount}`;
}

export function formatDate(date: string | Date) {
  const lang = getActiveLanguage();
  const locale = lang === 'ar' ? 'ar-YE' : 'en-US';
  return new Intl.DateTimeFormat(locale, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(new Date(date));
}

/**
 * Returns localized name for dynamic database objects (Account, Customer, Vendor, Item).
 * Supports name_ar/name_en, nested JSONB dynamic models name: { ar, en }, and translation dictionary lookup fallbacks.
 */
export function getLocalizedName(obj: any): string {
  if (!obj) return '';
  const langKey = getActiveLanguage();
  
  // 1. JSONB style check
  if (obj.name && typeof obj.name === 'object') {
    return obj.name[langKey] || obj.name.ar || obj.name.en || '';
  }
  
  // 2. Localized flat fields check
  if (langKey === 'en' && obj.name_en) return obj.name_en;
  if (langKey === 'ar' && obj.name_ar) return obj.name_ar;
  if (langKey === 'en' && obj.englishName) return obj.englishName;
  if (langKey === 'ar' && obj.arabicName) return obj.arabicName;

  // 3. Flat name string fallback + built-in dictionary
  const nameStr = obj.name || '';
  
  const coaTranslations: Record<string, { ar: string, en: string }> = {
    'Assets': { ar: 'الأصول', en: 'Assets' },
    'Liabilities': { ar: 'الالتزامات الخصوم', en: 'Liabilities' },
    'Owners\' Rights': { ar: 'حقوق الملكية للملاك', en: "Owners' Rights" },
    'Revenues': { ar: 'الإيرادات التشغيلية', en: 'Revenues' },
    'Expenses': { ar: 'المصاريف التشغيلية', en: 'Expenses' },
    'Cash': { ar: 'النقدية بالصندوق', en: 'Cash' },
    'Bank': { ar: 'الحساب الجاري بالبنك', en: 'Bank' },
    'Accounts Receivable': { ar: 'حسابات العملاء الذمم المدينة', en: 'Accounts Receivable' },
    'Accounts Payable': { ar: 'حسابات الموردين الذمم الدائنة', en: 'Accounts Payable' },
    'Sales Revenue': { ar: 'إيرادات المبيعات', en: 'Sales Revenue' },
    'Cost of Goods Sold': { ar: 'تكلفة البضاعة المباعة', en: 'Cost of Goods Sold' },
    'Rent Expense': { ar: 'مصاريف الإيجار والمقرات', en: 'Rent Expense' },
    'Salaries Expense': { ar: 'مصاريف الرواتب والأجور', en: 'Salaries Expense' },
    'Yemeni Riyal': { ar: 'الريال اليمني', en: 'Yemeni Riyal' },
    'Default Customer': { ar: 'العميل الافتراضي', en: 'Default Customer' },
    'Default Vendor': { ar: 'المورد الرئيسي الافتراضي', en: 'Default Vendor' },
    'Yemen Mobile': { ar: 'يمن موبايل الاتصالات', en: 'Yemen Mobile' },
  };

  if (coaTranslations[nameStr]) {
    return coaTranslations[nameStr][langKey];
  }

  // Look up if string is either the ar or en representation itself
  for (const key of Object.keys(coaTranslations)) {
    const item = coaTranslations[key];
    if (item.ar === nameStr || item.en === nameStr) {
      return item[langKey];
    }
  }

  // Check the global label dictionary as well for db names
  const fallback = getLocalizedLabel(nameStr);
  if (fallback !== nameStr) return fallback;

  return nameStr;
}

// 100% Comprehensive Label, Table Column and Form Input Localization Dictionary
const LABEL_DICTIONARY: Record<string, { ar: string; en: string }> = {
  // Common action buttons and validation messages
  "Save": { ar: "حفظ", en: "Save" },
  "Cancel": { ar: "إلغاء", en: "Cancel" },
  "Edit": { ar: "تعديل", en: "Edit" },
  "Delete": { ar: "حذف", en: "Delete" },
  "View": { ar: "عرض", en: "View" },
  "Actions": { ar: "الإجراءات", en: "Actions" },
  "Status": { ar: "الحالة", en: "Status" },
  "Date": { ar: "التاريخ", en: "Date" },
  "Description": { ar: "الوصف", en: "Description" },
  "Reference": { ar: "المرجع", en: "Reference" },
  "Total": { ar: "الإجمالي", en: "Total" },
  "Balance": { ar: "الرصيد", en: "Balance" },
  "Code": { ar: "الكود", en: "Code" },
  "Name": { ar: "الاسم", en: "Name" },
  "Type": { ar: "النوع", en: "Type" },
  "Loading...": { ar: "جاري التحميل...", en: "Loading..." },
  "Success": { ar: "تم بنجاح", en: "Success" },
  "Error": { ar: "خطأ", en: "Error" },
  "Confirm": { ar: "تأكيد", en: "Confirm" },
  "Back": { ar: "رجوع", en: "Back" },
  "Required": { ar: "مطلوب", en: "Required" },
  "This field is required": { ar: "هذا الحقل مطلوب", en: "This field is required" },
  "Invalid format": { ar: "تنسيق غير صالح", en: "Invalid format" },
  "Invalid number format": { ar: "تنسيق غير عادل للرقم مالي", en: "Invalid number format" },
  "Required Field": { ar: "حقل مطلوب", en: "Required Field" },

  // Columns & Headers
  "Account Code": { ar: "رمز الحساب", en: "Account Code" },
  "Account Name": { ar: "اسم الحساب", en: "Account Name" },
  "Account Type": { ar: "نوع الحساب", en: "Account Type" },
  "Parent Account": { ar: "الحساب الرئيسي (الأب)", en: "Parent Account" },
  "Active": { ar: "نشط", en: "Active" },
  "Inactive": { ar: "غير نشط", en: "Inactive" },
  "Asset": { ar: "أصول (Asset)", en: "Asset" },
  "Liability": { ar: "خصوم وإلتزامات (Liability)", en: "Liability" },
  "Equity": { ar: "حقوق ملكية (Equity)", en: "Equity" },
  "Income": { ar: "إيرادات (Income)", en: "Income" },
  "Expense": { ar: "مصاريف (Expense)", en: "Expense" },
  "All Account Types": { ar: "جميع أنواع الحسابات", en: "All Account Types" },
  "Account Code (Auto)": { ar: "رمز الحساب (تلقائي)", en: "Account Code (Auto)" },
  "Create New Account": { ar: "إضافة حساب مالي جديد", en: "Create New Account" },
  "Edit Account": { ar: "تعديل الحساب المالي", en: "Edit Account" },
  "Main Account (Root)": { ar: "الحساب الرئيسي (الجذر)", en: "Main Account (Root)" },
  "Existing Accounts": { ar: "الحسابات الموجودة بالنظام", en: "Existing Accounts" },
  "Create Account": { ar: "إنشاء الحساب", en: "Create Account" },

  // Customers & Vendors
  "Customer Name": { ar: "اسم العميل", en: "Customer Name" },
  "Vendor Name": { ar: "اسم المورد", en: "Vendor Name" },
  "Email Address": { ar: "البريد الإلكتروني", en: "Email Address" },
  "Phone Number": { ar: "رقم الهاتف", en: "Phone Number" },
  "Tax Registration ID (VAT/GST)": { ar: "الرقم الضريبي المستهدف", en: "Tax Registration ID (VAT/GST)" },
  "Street Address": { ar: "عنوان الشارع", en: "Street Address" },
  "City": { ar: "المدينة", en: "City" },
  "Outstanding Balance": { ar: "الرصيد القائم المستحق", en: "Outstanding Balance" },
  "Credit Limit": { ar: "الحد الائتماني", en: "Credit Limit" },
  "Add Customer": { ar: "إضافة عميل جديد", en: "Add Customer" },
  "Add Vendor": { ar: "إضافة مورد جديد", en: "Add Vendor" },
  "Edit Customer": { ar: "تعديل حساب العميل", en: "Edit Customer" },
  "Edit Vendor": { ar: "تعديل حساب المورد", en: "Edit Vendor" },
  "Customer Details": { ar: "تفاصيل العميل", en: "Customer Details" },
  "Vendor Details": { ar: "تفاصيل المورد", en: "Vendor Details" },

  // Sales & Purchases
  "Sales Invoices": { ar: "فواتير المبيعات", en: "Sales Invoices" },
  "Purchase Invoices": { ar: "فواتير المشتريات", en: "Purchase Invoices" },
  "Invoice Number": { ar: "رقم الفاتورة", en: "Invoice Number" },
  "Customer": { ar: "العميل", en: "Customer" },
  "Vendor": { ar: "المورد", en: "Vendor" },
  "Subtotal": { ar: "المجموع الفرعي", en: "Subtotal" },
  "Tax Amount": { ar: "قيمة الضريبة", en: "Tax Amount" },
  "Total Amount": { ar: "المبلغ الإجمالي المالي", en: "Total Amount" },
  "Payment Status": { ar: "حالة الدفع", en: "Payment Status" },
  "Paid": { ar: "مدفوع بالكامل", en: "Paid" },
  "Unpaid": { ar: "غير مدفوع", en: "Unpaid" },
  "Partial": { ar: "مدفوع جزئياً", en: "Partial" },
  "Create Invoice": { ar: "إنشاء فاتورة جديدة", en: "Create Invoice" },
  "New Sales Invoice": { ar: "فاتورة مبيعات جديدة", en: "New Sales Invoice" },
  "New Purchase Invoice": { ar: "فاتورة مشتريات جديدة", en: "New Purchase Invoice" },
  "Invoice Date": { ar: "تاريخ الفاتورة", en: "Invoice Date" },
  "Due Date": { ar: "تاريخ الاستحقاق والوفاء", en: "Due Date" },
  "Add Line Item": { ar: "إضافة بند فاتورة", en: "Add Line Item" },

  // Items / Inventory
  "Item Code": { ar: "كود الصنف", en: "Item Code" },
  "Item Name": { ar: "اسم الصنف", en: "Item Name" },
  "Sales Price": { ar: "سعر البيع", en: "Sales Price" },
  "Purchase Price": { ar: "سعر الشراء", en: "Purchase Price" },
  "Stock Qty": { ar: "الكمية بالمخزن", en: "Stock Qty" },
  "SKU": { ar: "الرمز SKU", en: "SKU" },
  "Unit of Measure": { ar: "وحدة القياس", en: "Unit of Measure" },
  "Create Item": { ar: "إضافة صنف جديد", en: "Create Item" },

  // Manual Journals
  "Manual Journal Entries": { ar: "القيود اليومية المتوازنة والمرحلة", en: "Manual Journal Entries" },
  "New Journal Entry": { ar: "قيد يومية متوازن جديد", en: "New Journal Entry" },
  "Edit Journal Entry": { ar: "تعديل سند قيد اليومية", en: "Edit Journal Entry" },
  "Debit": { ar: "مدين", en: "Debit" },
  "Credit": { ar: "دائن", en: "Credit" },
  "Lines": { ar: "تفاصيل حركات القيد", en: "Lines" },
  "Total Debit": { ar: "إجمالي المدين", en: "Total Debit" },
  "Total Credit": { ar: "إجمالي الدائن", en: "Total Credit" },
  "Draft": { ar: "مسودة غير مرحلة", en: "Draft" },
  "Posted": { ar: "مرحل نهائي للدفاتر", en: "Posted" },
  "Auto-Reverse": { ar: "عكس تلقائي للقيد", en: "Auto-Reverse" },
  "Narration": { ar: "البيان الإجمالي", en: "Narration" },
  "Account": { ar: "الحساب المالي", en: "Account" },
  "Balanced Check": { ar: "فحص توازن القيد", en: "Balanced Check" },

  // Reports Center
  "Profit and Loss": { ar: "قائمة الربح والخسارة (الدخل)", en: "Profit and Loss" },
  "Balance Sheet": { ar: "الميزانية العمومية", en: "Balance Sheet" },
  "Trial Balance": { ar: "ميزان المراجعة بقيد اليومية", en: "Trial Balance" },
  "Total Balance": { ar: "إجمالي الرصيد", en: "Total Balance" },
  "Group Subtotal": { ar: "المجموع الفرعي", en: "Group Subtotal" },
  "Sum debit": { ar: "إجمالي مدين", en: "Sum Debit" },
  "Sum credit": { ar: "إجمالي دائن", en: "Sum Credit" },
  "Net Profit": { ar: "صافي الأرباح", en: "Net Profit" },
  "Net Profit/Loss": { ar: "صافي الأرباح والخسائر", en: "Net Profit/Loss" },
  "Total Assets": { ar: "إجمالي الأصول", en: "Total Assets" },
  "Total Liabilities": { ar: "إجمالي الالتزامات", en: "Total Liabilities" },
  "Total Equity": { ar: "إجمالي حقوق الملكية", en: "Total Equity" },
  "Contact": { ar: "معلومات الاتصال", en: "Contact" },
  "Location": { ar: "الموقع / العنوان", en: "Location" },
  "Currencies": { ar: "العملات", en: "Currencies" },
  "Receivables": { ar: "الذمم المدينة المستحقة", en: "Receivables" },
  "Payables": { ar: "الذمم الدائنة المستحقة", en: "Payables" },
  "Supplier": { ar: "المورد", en: "Supplier" },
  "Purchases Qty": { ar: "الكميات المشتراة", en: "Purchases Qty" },
  "Income vs Expenses": { ar: "الإيرادات مقابل المصروفات", en: "Income vs Expenses" },
  "Cash Flow Trend": { ar: "حركة التدفق النقدي", en: "Cash Flow Trend" },
  "Recent Invoices": { ar: "أحدث الفواتير", en: "Recent Invoices" },
  "View all": { ar: "عرض الكل", en: "View all" },
  "Invoice #": { ar: "رقم الفاتورة", en: "Invoice #" },
  "Amount": { ar: "المبلغ", en: "Amount" },
};

/**
 * Returns localized label/header statically/dynamically based on the current active session language.
 */
export function getLocalizedLabel(label: string): string {
  if (!label) return '';
  const langKey = getActiveLanguage();
  const trimmed = label.trim();
  const item = LABEL_DICTIONARY[trimmed] || LABEL_DICTIONARY[label];
  if (item) {
    return item[langKey];
  }
  return label;
}

/**
 * Returns localized field from an object (e.g. description, name, category, status).
 * Handles JSONB fields like description: { ar: '..', en: '..' }, localized fields like description_ar/description_en,
 * and built-in dictionary lookups.
 */
export function getLocalizedField(obj: any, fieldName: string): any {
  if (!obj) return '';
  const langKey = getActiveLanguage();
  
  // 1. Check if the exact property exists and is a JSONB language map object
  const value = obj[fieldName];
  if (value && typeof value === 'object') {
    return value[langKey] || value.ar || value.en || '';
  }

  // 2. Check localized flat variants (e.g. description_ar, description_en)
  const arField = `${fieldName}_ar`;
  const enField = `${fieldName}_en`;
  if (langKey === 'ar' && obj[arField] !== undefined) return obj[arField];
  if (langKey === 'en' && obj[enField] !== undefined) return obj[enField];

  // 3. Check specific title capitalized formats (e.g. statusAr, statusEn)
  const capitalized = fieldName.charAt(0).toUpperCase() + fieldName.slice(1);
  const camelAr = `${langKey === 'ar' ? 'arabic' : 'english'}${capitalized}`;
  if (obj[camelAr] !== undefined) return obj[camelAr];

  // 4. Default return with dictionary lookup
  const rawString = obj[fieldName];
  if (typeof rawString === 'string') {
    return getLocalizedLabel(rawString);
  }
  return rawString;
}

