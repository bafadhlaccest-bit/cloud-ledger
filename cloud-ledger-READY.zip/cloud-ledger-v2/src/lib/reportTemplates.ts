import { ReportLayout } from '../types/reports';

export const CORE_TEMPLATES: ReportLayout[] = [
  {
    id: 'tpl_general_ledger',
    name: 'General Ledger Report',
    arabicName: 'دفتر الأستاذ العام',
    description: 'Detailed accounts transaction ledger including opening balances, incremental debits, credits, and progressive running balance aggregates.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'accountant'],
    selectedTables: ['accounts', 'journal_lines', 'journal_entries'],
    joins: [
      {
        id: 'gl_join_1',
        leftTable: 'accounts',
        rightTable: 'journal_lines',
        joinType: 'Left Join',
        leftField: 'id',
        rightField: 'account_id'
      },
      {
        id: 'gl_join_2',
        leftTable: 'journal_lines',
        rightTable: 'journal_entries',
        joinType: 'Left Join',
        leftField: 'journal_entry_id',
        rightField: 'id'
      }
    ],
    groupField: 'accounts.code',
    showChart: true,
    chartType: 'bar',
    chartXField: 'name',
    chartYField: 'balance',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header (رأس التقرير)',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'rh_elem_1',
            type: 'label',
            label: 'Company Name',
            value: 'YEMEN FOOD INGREDIENTS LTD (شركة المواد الغذائية)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'rh_elem_2',
            type: 'label',
            label: 'Report Title',
            value: 'GENERAL LEDGER ACC REGISTERS (الأستاذ العام التفصيلي)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'rh_elem_3',
            type: 'qrcode',
            label: 'Compliance QR Code',
            value: 'https://tax-yemen.gov.ye/compliance/verify?tax_id=983-492&ledger=all',
            width: 25,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header (رأس الصفحة)',
        arabicName: 'رأس الصفحة',
        elements: [
          {
            id: 'ph_elem_1',
            type: 'variable',
            label: 'Date',
            value: 'system.current_date',
            width: 30,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'DD/MM/YYYY' }
          },
          {
            id: 'ph_elem_2',
            type: 'variable',
            label: 'Active User',
            value: 'system.execution_user',
            width: 30,
            align: 'right',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupHeader',
        name: 'Group Header (رأس المجموعة الحساب)',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'gh_elem_1',
            type: 'label',
            label: 'Group Label/Account',
            value: 'Account Partition Header:',
            width: 30,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'gh_elem_2',
            type: 'field',
            label: 'Account Code',
            value: 'accounts.code',
            width: 20,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'gh_elem_3',
            type: 'field',
            label: 'Account Name',
            value: 'accounts.name',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section (بند التفاصيل)',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'dt_elem_1',
            type: 'field',
            label: 'Acct Code',
            value: 'accounts.code',
            width: 15,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'prefix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'dt_elem_2',
            type: 'field',
            label: 'Primary Account Descr',
            value: 'accounts.name',
            width: 35,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'prefix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'dt_elem_3',
            type: 'field',
            label: 'Account Type',
            value: 'accounts.type',
            width: 20,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'prefix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'dt_elem_4',
            type: 'field',
            label: 'Balance Due',
            value: 'accounts.balance',
            width: 30,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer (تذييل وعلاوات المجموعة)',
        arabicName: 'تذييل المجموعة',
        elements: [
          {
            id: 'gf_elem_1',
            type: 'label',
            label: 'Subtotal title',
            value: 'Account Aggregate Subtotal:',
            width: 40,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'gf_elem_2',
            type: 'field',
            label: 'Calculated Sum balance',
            value: 'accounts.balance',
            width: 60,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'SUM(accounts.balance)'
          }
        ]
      },
      {
        id: 'pageFooter',
        name: 'Page Footer (تذييل الصفحة وطابع الوقت)',
        arabicName: 'تذييل الصفحة',
        elements: [
          {
            id: 'pf_elem_1',
            type: 'label',
            label: 'Confidentiality Footer',
            value: 'CONFIDENTIAL PRINT • Live Export Engine v8.8',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'pf_elem_2',
            type: 'variable',
            label: 'Page Indicator',
            value: 'system.page_number',
            width: 50,
            align: 'right',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'reportFooter',
        name: 'Report Footer (التذييل الختامي للتقرير والغمد)',
        arabicName: 'تذييل التقرير',
        elements: [
          {
            id: 'rf_elem_1',
            type: 'label',
            label: 'Sign Title',
            value: 'Accounting Manager Signature: _______________________',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'rf_elem_2',
            type: 'label',
            label: 'Auditor Sign',
            value: 'External Auditor Stamp: _______________________',
            width: 50,
            align: 'right',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      }
    ]
  },
  {
    id: 'tpl_trial_balance',
    name: 'Trial Balance Ledger',
    arabicName: 'ميزان المراجعة بالمجاميع والأرصدة',
    description: 'Preconfigured columns displaying Trial Balance aggregates for the full accounting year grouped by Assets, Liabilities, Revenue, and Expenses with multi-level accounts layout.',
    version: 2,
    isShared: true,
    roleAccess: ['admin', 'manager', 'accountant'],
    selectedTables: ['accounts'],
    joins: [],
    groupField: 'accounts.type',
    showChart: true,
    chartType: 'pie',
    chartXField: 'type',
    chartYField: 'balance',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header (رأس التقرير)',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'tb_rh_elem_1',
            type: 'label',
            label: 'Company header',
            value: 'YEMEN COOPERATIVE OIL & FLOUR MILLS SYSTEM',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'tb_rh_elem_2',
            type: 'label',
            label: 'Title TB',
            value: 'TRIAL BALANCE STATEMENT (ميزان المراجعة التحليلي)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header (رأس الصفحة)',
        arabicName: 'رأس الصفحة',
        elements: [
          {
            id: 'tb_ph_1',
            type: 'variable',
            label: 'Execution timestamp',
            value: 'system.current_date',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'DD/MM/YYYY' }
          }
        ]
      },
      {
        id: 'groupHeader',
        name: 'Group Header (رأس نوع الحساب)',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'tb_gh_1',
            type: 'field',
            label: 'Cat Name',
            value: 'accounts.type',
            width: 100,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section (بند التفاصيل)',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'tb_dt_1',
            type: 'field',
            label: 'Code',
            value: 'accounts.code',
            width: 25,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'tb_dt_2',
            type: 'field',
            label: 'Description',
            value: 'accounts.name',
            width: 45,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'tb_dt_3',
            type: 'field',
            label: 'Current Balance YER',
            value: 'accounts.balance',
            width: 30,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer (تذييل الحساب)',
        arabicName: 'تذييل المجموعة',
        elements: [
          {
            id: 'tb_gf_1',
            type: 'label',
            label: 'Sum text',
            value: 'Group Balance Aggregation Sum:',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'tb_gf_2',
            type: 'field',
            label: 'Summed balance',
            value: 'accounts.balance',
            width: 50,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'SUM(accounts.balance)'
          }
        ]
      },
      {
        id: 'pageFooter',
        name: 'Page Footer (تذييل الصفحة)',
        arabicName: 'تذييل الصفحة',
        elements: [
          {
            id: 'tb_pf_1',
            type: 'variable',
            label: 'Page count',
            value: 'system.page_number',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'reportFooter',
        name: 'Report Footer (تذييل التقرير المائة)',
        arabicName: 'تذييل التقرير',
        elements: [
          {
            id: 'tb_rf_1',
            type: 'label',
            label: 'Audit Check',
            value: 'WARNING: Ensure debit groups and credit groups align fully for tax reporting standards.',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      }
    ]
  },
  {
    id: 'tpl_income_statement',
    name: 'Income Statement (P&L)',
    arabicName: 'قائمة الدخل - الأرباح والخسائر',
    description: 'Dynamic revenue, COGS, operational expenses, and consolidated net profit calculation engine in real-time.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'accountant'],
    selectedTables: ['accounts'],
    joins: [],
    groupField: 'accounts.type',
    showChart: true,
    chartType: 'bar',
    chartXField: 'type',
    chartYField: 'balance',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'is_rh_1',
            type: 'label',
            label: 'Company Name',
            value: 'GLOBAL DISTRIBUTORS CORPORATION',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'is_rh_2',
            type: 'label',
            label: 'Report Title',
            value: 'INCOME STATEMENT / PROFIT AND LOSS (قائمة الأرباح والخسائر للشركة)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header',
        arabicName: 'رأس الصفحة',
        elements: [
          {
            id: 'is_ph_1',
            type: 'variable',
            label: 'Current timestamp',
            value: 'system.current_date',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'DD/MM/YYYY' }
          }
        ]
      },
      {
        id: 'groupHeader',
        name: 'Group Header',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'is_gh_1',
            type: 'field',
            label: 'Category',
            value: 'accounts.type',
            width: 100,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'is_dt_1',
            type: 'field',
            label: 'Code',
            value: 'accounts.code',
            width: 20,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'is_dt_2',
            type: 'field',
            label: 'Account Name',
            value: 'accounts.name',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'is_dt_3',
            type: 'field',
            label: 'Current Amount YER',
            value: 'accounts.balance',
            width: 30,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer',
        arabicName: 'تذييل المجموعة',
        elements: [
          {
            id: 'is_gf_1',
            type: 'label',
            label: 'Subtotal title',
            value: 'Summed balance for category:',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'is_gf_2',
            type: 'field',
            label: 'Group sum',
            value: 'accounts.balance',
            width: 50,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'SUM(accounts.balance)'
          }
        ]
      },
      {
        id: 'pageFooter',
        name: 'Page Footer',
        arabicName: 'تذييل الصفحة',
        elements: [
          {
            id: 'is_pf_1',
            type: 'variable',
            label: 'Page count',
            value: 'system.page_number',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'reportFooter',
        name: 'Report Footer',
        arabicName: 'تذييل التقرير',
        elements: [
          {
            id: 'is_rf_1',
            type: 'label',
            label: 'CFO Stamp',
            value: 'Consolidated Net Profit Verification Seal: APPROVED',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      }
    ]
  },
  {
    id: 'tpl_balance_sheet',
    name: 'Balance Sheet',
    arabicName: 'الميزانية العمومية',
    description: 'Financial snapshot statement summarizing company Assets, Liabilities, and Shareholder Equity balances.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'accountant'],
    selectedTables: ['accounts'],
    joins: [],
    groupField: 'accounts.type',
    showChart: true,
    chartType: 'pie',
    chartXField: 'type',
    chartYField: 'balance',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'bs_rh_1',
            type: 'label',
            label: 'Company header',
            value: 'YEMEN UNITED MANUFACTURERS LTD',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'bs_rh_2',
            type: 'label',
            label: 'Balance Sheet Title',
            value: 'CONSOLIDATED BALANCE SHEET STATEMENT (الميزانية العمومية الشاملة)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header',
        arabicName: 'رأس الصفحة',
        elements: [
          {
            id: 'bs_ph_1',
            type: 'variable',
            label: 'Timestamp',
            value: 'system.current_date',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'DD/MM/YYYY' }
          }
        ]
      },
      {
        id: 'groupHeader',
        name: 'Group Header',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'bs_gh_1',
            type: 'field',
            label: 'Ledger Category',
            value: 'accounts.type',
            width: 100,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'bs_dt_1',
            type: 'field',
            label: 'Account Code',
            value: 'accounts.code',
            width: 25,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'bs_dt_2',
            type: 'field',
            label: 'Account Name',
            value: 'accounts.name',
            width: 45,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'bs_dt_3',
            type: 'field',
            label: 'Balance',
            value: 'accounts.balance',
            width: 30,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer',
        arabicName: 'تذييل المجموعة',
        elements: [
          {
            id: 'bs_gf_1',
            type: 'label',
            label: 'Aggregate title',
            value: 'Category Balance Total:',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'bs_gf_2',
            type: 'field',
            label: 'Aggregate sum',
            value: 'accounts.balance',
            width: 50,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'SUM(accounts.balance)'
          }
        ]
      },
      {
        id: 'pageFooter',
        name: 'Page Footer',
        arabicName: 'تذييل الصفحة',
        elements: [
          {
            id: 'bs_pf_1',
            type: 'variable',
            label: 'Pages count',
            value: 'system.page_number',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'reportFooter',
        name: 'Report Footer',
        arabicName: 'تذييل التقرير',
        elements: [
          {
            id: 'bs_rf_1',
            type: 'label',
            label: 'Board Signature',
            value: 'Chairman Signature: _______________________     Auditor Stamp: [SEALED]',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      }
    ]
  },
  {
    id: 'tpl_journal_entries',
    name: 'Journal Entries Audit',
    arabicName: 'دفتر قيود اليومية التفصيلية',
    description: 'Complete list of general journal transitions, manual ledger adjustments, tax vouchers, and compliant audit trails.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'accountant'],
    selectedTables: ['journal_entries'],
    joins: [],
    groupField: '',
    showChart: true,
    chartType: 'line',
    chartXField: 'id',
    chartYField: 'total_debit',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'je_rh_1',
            type: 'label',
            label: 'Company',
            value: 'YEMEN PHARMACEUTICAL INDUSTRIES',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'je_rh_2',
            type: 'label',
            label: 'Title',
            value: 'JOURNAL ENTRIES REPORT & TRANSACTION LOG (سجل قيود اليومية العامة المستندية)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header',
        arabicName: 'رأس الصفحة',
        elements: [
          {
            id: 'je_ph_1',
            type: 'variable',
            label: 'Date',
            value: 'system.current_date',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'DD/MM/YYYY' }
          }
        ]
      },
      {
        id: 'groupHeader',
        name: 'Group Header',
        arabicName: 'رأس المجموعة',
        elements: []
      },
      {
        id: 'detail',
        name: 'Detail Section',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'je_dt_1',
            type: 'field',
            label: 'Journal ID',
            value: 'journal_entries.id',
            width: 20,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'je_dt_2',
            type: 'field',
            label: 'Entry Date',
            value: 'journal_entries.date',
            width: 25,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'je_dt_3',
            type: 'field',
            label: 'Description Narrative',
            value: 'journal_entries.description',
            width: 35,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'je_dt_4',
            type: 'field',
            label: 'Debit amount YER',
            value: 'journal_entries.total_debit',
            width: 20,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer',
        arabicName: 'تذييل المجموعة',
        elements: []
      },
      {
        id: 'pageFooter',
        name: 'Page Footer',
        arabicName: 'تذييل الصفحة',
        elements: [
          {
            id: 'je_pf_1',
            type: 'variable',
            label: 'Pages',
            value: 'system.page_number',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'reportFooter',
        name: 'Report Footer',
        arabicName: 'تذييل التقرير',
        elements: [
          {
            id: 'je_rf_1',
            type: 'label',
            label: 'Auditor signature',
            value: 'Lead Auditor Signature Check: Certified Ledger Balances matched correctly.',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      }
    ]
  },
  {
    id: 'tpl_cash_flow',
    name: 'Cash Flow Statement',
    arabicName: 'قائمة التدفقات النقدية والسيولة',
    description: 'Consolidated tracking of cash movements and operational, historical investment, and financing liquidity streams.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'accountant'],
    selectedTables: ['accounts'],
    joins: [],
    groupField: 'accounts.type',
    showChart: true,
    chartType: 'bar',
    chartXField: 'type',
    chartYField: 'balance',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'cf_rh_1',
            type: 'label',
            label: 'Company header',
            value: 'YEMEN PHARMACEUTICAL INDUSTRIES',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'cf_rh_2',
            type: 'label',
            label: 'CF statement',
            value: 'CASH FLOW STATEMENT (قائمة التدفقات النقدية السنوية)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header',
        arabicName: 'رأس الصفحة',
        elements: []
      },
      {
        id: 'groupHeader',
        name: 'Group Header',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'cf_gh_1',
            type: 'field',
            label: 'Category',
            value: 'accounts.type',
            width: 100,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'cf_dt_1',
            type: 'field',
            label: 'Account',
            value: 'accounts.code',
            width: 25,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'cf_dt_2',
            type: 'field',
            label: 'Description',
            value: 'accounts.name',
            width: 45,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'cf_dt_3',
            type: 'field',
            label: 'Cash Flow Effect',
            value: 'accounts.balance',
            width: 30,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer',
        arabicName: 'تذييل المجموعة',
        elements: [
          {
            id: 'cf_gf_1',
            type: 'label',
            label: 'Subtotal title',
            value: 'Cash Aggregate for category:',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'cf_gf_2',
            type: 'field',
            label: 'Category Total',
            value: 'accounts.balance',
            width: 50,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'SUM(accounts.balance)'
          }
        ]
      },
      {
        id: 'pageFooter',
        name: 'Page Footer',
        arabicName: 'تذييل الصفحة',
        elements: []
      },
      {
        id: 'reportFooter',
        name: 'Report Footer',
        arabicName: 'تذييل التقرير',
        elements: [
          {
            id: 'cf_rf_1',
            type: 'label',
            label: 'Cash Auditor Signature',
            value: 'Internal Audit: Cash and Cash Equivalents verified and balanced. Sign: __________________',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      }
    ]
  },
  {
    id: 'tpl_stock_balance',
    name: 'Stock Balance Report',
    arabicName: 'تقرير جرد كميات الأصناف والمخزون',
    description: 'Asset quantities on hand, safety thresholds, and active storage reservations mapped across active warehouses.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'inventory_clerk'],
    selectedTables: ['items'],
    joins: [],
    groupField: 'items.category',
    showChart: true,
    chartType: 'bar',
    chartXField: 'item_name',
    chartYField: 'stock_qty',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'sb_rh_1',
            type: 'label',
            label: 'Company header',
            value: 'SANA\'A COOPERATIVE TRADING HUBS',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'sb_rh_2',
            type: 'label',
            label: 'Title stock',
            value: 'PHYSICAL STOCK BALANCE REPORT (جرد ومطابقة المخزون والعهد)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header',
        arabicName: 'رأس الصفحة',
        elements: []
      },
      {
        id: 'groupHeader',
        name: 'Group Header',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'sb_gh_1',
            type: 'field',
            label: 'Category',
            value: 'items.category',
            width: 100,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'sb_dt_1',
            type: 'field',
            label: 'Item Code',
            value: 'items.item_code',
            width: 25,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'sb_dt_2',
            type: 'field',
            label: 'Item Name',
            value: 'items.item_name',
            width: 45,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'sb_dt_3',
            type: 'field',
            label: 'Available Quantity',
            value: 'items.stock_qty',
            width: 30,
            align: 'right',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer',
        arabicName: 'تذييل المجموعة',
        elements: [
          {
            id: 'sb_gf_1',
            type: 'label',
            label: 'Sum units title',
            value: 'Total Units Available for Category:',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'sb_gf_2',
            type: 'field',
            label: 'Aggregate stock total',
            value: 'items.stock_qty',
            width: 50,
            align: 'right',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'SUM(items.stock_qty)'
          }
        ]
      },
      {
        id: 'pageFooter',
        name: 'Page Footer',
        arabicName: 'تذييل الصفحة',
        elements: []
      },
      {
        id: 'reportFooter',
        name: 'Report Footer',
        arabicName: 'تذييل التقرير',
        elements: [
          {
            id: 'sb_rf_1',
            type: 'label',
            label: 'Signature store controller',
            value: 'Main Storekeeper Seal & Authorizations Sign: ___________________________',
            width: 100,
            align: 'right',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      }
    ]
  },
  {
    id: 'tpl_inventory_valuation',
    name: 'Inventory Valuation Report',
    arabicName: 'تقرير تقييم المخزون المالي',
    description: 'Operational and financial summary of current inventory listing items, cost tracking basis (FIFO/AVCO), stock quantities, and aggregated valuation metrics.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'inventory_clerk'],
    selectedTables: ['items'],
    joins: [],
    groupField: 'items.category',
    showChart: true,
    chartType: 'bar',
    chartXField: 'item_name',
    chartYField: 'stock_qty',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header (رأس التقرير)',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'val_rh_1',
            type: 'label',
            label: 'Company header',
            value: 'YEMEN TRADING & IMPORT SECTOR STORES',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'val_rh_2',
            type: 'label',
            label: 'Title Stock',
            value: 'INVENTORY FINANCIAL VALUATION SYSTEM (تقييم المخزون - التكلفة والمتحصل)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header (رأس الصفحة)',
        arabicName: 'رأس الصفحة',
        elements: [
          {
            id: 'val_ph_1',
            type: 'variable',
            label: 'Current timestamp',
            value: 'system.current_date',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'DD/MM/YYYY' }
          }
        ]
      },
      {
        id: 'groupHeader',
        name: 'Group Header (المجموعة السلعية)',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'val_gh_1',
            type: 'field',
            label: 'Category',
            value: 'items.category',
            width: 100,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section (بند التفاصيل)',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'val_dt_1',
            type: 'field',
            label: 'Code',
            value: 'items.item_code',
            width: 15,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'val_dt_2',
            type: 'field',
            label: 'Item Name',
            value: 'items.item_name',
            width: 35,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'val_dt_3',
            type: 'field',
            label: 'Stock Level',
            value: 'items.stock_qty',
            width: 15,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'val_dt_4',
            type: 'field',
            label: 'AVCO Cost',
            value: 'items.avg_cost',
            width: 15,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'val_dt_5',
            type: 'field',
            label: 'Valuation Subtotal',
            value: 'items.stock_qty',
            width: 20,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'Detail.qty * Detail.avg_cost'
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer (تذييل وعلاوات المجموعة)',
        arabicName: 'تذييل المجموعة',
        elements: [
          {
            id: 'val_gf_1',
            type: 'label',
            label: 'Subtotal label',
            value: 'Category Subtotal Valuation Balance:',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'val_gf_2',
            type: 'field',
            label: 'Summed value',
            value: 'items.stock_qty',
            width: 50,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'USD', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'SUM(items.stock_qty * items.avg_cost)'
          }
        ]
      },
      {
        id: 'pageFooter',
        name: 'Page Footer (تذييل الصفحة)',
        arabicName: 'تذييل الصفحة',
        elements: [
          {
            id: 'val_pf_1',
            type: 'variable',
            label: 'Page index',
            value: 'system.page_number',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'reportFooter',
        name: 'Report Footer (تذييل التقرير المائة)',
        arabicName: 'تذييل التقرير',
        elements: [
          {
            id: 'val_rf_1',
            type: 'label',
            label: 'Authorizer Signature',
            value: 'Warehouse Controller Stamp: _______________________',
            width: 100,
            align: 'right',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      }
    ]
  },
  {
    id: 'tpl_item_ledger',
    name: 'Item Ledger (Item Movement)',
    arabicName: 'تقرير حركة الصنف التفصيلية',
    description: 'Detailed analysis auditing unit incoming and outgoing movements, sold values, and running quantity balances.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'inventory_clerk'],
    selectedTables: ['invoice_lines'],
    joins: [],
    groupField: 'invoice_lines.item_code',
    showChart: true,
    chartType: 'bar',
    chartXField: 'invoice_no',
    chartYField: 'total_row',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'il_rh_1',
            type: 'label',
            label: 'Company header',
            value: 'YEMEN COOPERATIVE OIL & FLOUR MILLS SYSTEM',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'il_rh_2',
            type: 'label',
            label: 'Title ledger',
            value: 'ITEM LEDGER & TRANSACTION REGISTER (حواز وحركات الأصناف الرئيسية)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header',
        arabicName: 'رأس الصفحة',
        elements: []
      },
      {
        id: 'groupHeader',
        name: 'Group Header',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'il_gh_1',
            type: 'field',
            label: 'Active Item',
            value: 'invoice_lines.item_code',
            width: 100,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'il_dt_1',
            type: 'field',
            label: 'Invoice Ref',
            value: 'invoice_lines.invoice_no',
            width: 25,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'il_dt_2',
            type: 'field',
            label: 'Item Code',
            value: 'invoice_lines.item_code',
            width: 25,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'il_dt_3',
            type: 'field',
            label: 'Quantity Traded',
            value: 'invoice_lines.qty',
            width: 25,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'il_dt_4',
            type: 'field',
            label: 'Total Value YER',
            value: 'invoice_lines.total_row',
            width: 25,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer',
        arabicName: 'تذييل المجموعة',
        elements: [
          {
            id: 'il_gf_1',
            type: 'label',
            label: 'Total Item movement value',
            value: 'Total Item Value Aggregated:',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'il_gf_2',
            type: 'field',
            label: 'Sum Value',
            value: 'invoice_lines.total_row',
            width: 50,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'SUM(invoice_lines.total_row)'
          }
        ]
      },
      {
        id: 'pageFooter',
        name: 'Page Footer',
        arabicName: 'تذييل الصفحة',
        elements: []
      },
      {
        id: 'reportFooter',
        name: 'Report Footer',
        arabicName: 'تذييل التقرير',
        elements: []
      }
    ]
  },
  {
    id: 'tpl_reorder_alerts',
    name: 'Reorder Alerts (Safety Stock)',
    arabicName: 'تقرير حد الطلب ومستويات المخزون الصفري',
    description: 'Predictive warning list showcasing cataloged items falling below safety levels with auto-alert recommendations.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'inventory_clerk'],
    selectedTables: ['items'],
    joins: [],
    groupField: 'items.category',
    showChart: true,
    chartType: 'bar',
    chartXField: 'item_name',
    chartYField: 'stock_qty',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'ro_rh_1',
            type: 'label',
            label: 'Company header',
            value: 'SANA\'A COOPERATIVE TRADING HUBS',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'ro_rh_2',
            type: 'label',
            label: 'Title alert',
            value: 'REORDER & MIN-MAX THRESHOLD ALERTS (تقرير حد الطلب ونقص الأصناف)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header',
        arabicName: 'رأس الصفحة',
        elements: []
      },
      {
        id: 'groupHeader',
        name: 'Group Header',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'ro_gh_1',
            type: 'field',
            label: 'Category',
            value: 'items.category',
            width: 100,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'ro_dt_1',
            type: 'field',
            label: 'Item Code',
            value: 'items.item_code',
            width: 25,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'ro_dt_2',
            type: 'field',
            label: 'Item Name',
            value: 'items.item_name',
            width: 45,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'ro_dt_3',
            type: 'field',
            label: 'Current Quantity',
            value: 'items.stock_qty',
            width: 30,
            align: 'right',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD', conditionalFormatting: { expression: 'items.stock_qty < 500', textColor: '#dc2626', bgColor: '#fef2f2', isBold: true } }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer',
        arabicName: 'تذييل المجموعة',
        elements: [
          {
            id: 'ro_gf_1',
            type: 'label',
            label: 'Sum units title',
            value: 'Category Stock Item count below levels:',
            width: 50,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'ro_gf_2',
            type: 'field',
            label: 'Aggregate total stock',
            value: 'items.stock_qty',
            width: 50,
            align: 'right',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' },
            expression: 'COUNT(items.item_code)'
          }
        ]
      },
      {
        id: 'pageFooter',
        name: 'Page Footer',
        arabicName: 'تذييل الصفحة',
        elements: []
      },
      {
        id: 'reportFooter',
        name: 'Report Footer',
        arabicName: 'تذييل التقرير',
        elements: [
          {
            id: 'ro_rf_1',
            type: 'label',
            label: 'Recommended action list',
            value: 'Alert Status: Active. Purchase order request dispatch recommended for items in red.',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      }
    ]
  },
  {
    id: 'tpl_account_ledger_statement',
    name: 'Account Ledger Statement',
    arabicName: 'تقرير كشف حساب تفصيلي (Account Ledger Statement)',
    description: 'Detailed analysis of account ledger activity detailing transactions, balance carryforward, debit and credit streams.',
    version: 1,
    isShared: true,
    roleAccess: ['admin', 'manager', 'accountant'],
    selectedTables: ['accounts', 'journal_lines', 'journal_entries'],
    joins: [
      {
        id: 'als_join_1',
        leftTable: 'accounts',
        rightTable: 'journal_lines',
        joinType: 'Left Join',
        leftField: 'id',
        rightField: 'account_id'
      },
      {
        id: 'als_join_2',
        leftTable: 'journal_lines',
        rightTable: 'journal_entries',
        joinType: 'Left Join',
        leftField: 'journal_entry_id',
        rightField: 'id'
      }
    ],
    groupField: 'accounts.code',
    showChart: true,
    chartType: 'bar',
    chartXField: 'name',
    chartYField: 'balance',
    pageSize: 'A4',
    orientation: 'Portrait',
    bands: [
      {
        id: 'reportHeader',
        name: 'Report Header',
        arabicName: 'رأس التقرير',
        elements: [
          {
            id: 'als_rh_1',
            type: 'label',
            label: 'Company header',
            value: 'YEMEN ENTERPRISE HUBS',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'als_rh_2',
            type: 'label',
            label: 'Title',
            value: 'ACCOUNT LEDGER STATEMENT (كشف الحساب التفصيلي للعملاء والشركاء)',
            width: 100,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'pageHeader',
        name: 'Page Header',
        arabicName: 'رأس الصفحة',
        elements: []
      },
      {
        id: 'groupHeader',
        name: 'Group Header',
        arabicName: 'رأس المجموعة',
        elements: [
          {
            id: 'als_gh_1',
            type: 'field',
            label: 'Core Account Code',
            value: 'accounts.code',
            width: 100,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'detail',
        name: 'Detail Section',
        arabicName: 'بند التفاصيل',
        elements: [
          {
            id: 'als_dt_1',
            type: 'field',
            label: 'Trans Ref',
            value: 'journal_entries.reference',
            width: 25,
            align: 'left',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'als_dt_2',
            type: 'field',
            label: 'Date',
            value: 'journal_entries.date',
            width: 25,
            align: 'center',
            formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'als_dt_3',
            type: 'field',
            label: 'Debit amount YER',
            value: 'journal_lines.debit',
            width: 25,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          },
          {
            id: 'als_dt_4',
            type: 'field',
            label: 'Credit amount YER',
            value: 'journal_lines.credit',
            width: 25,
            align: 'right',
            formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
          }
        ]
      },
      {
        id: 'groupFooter',
        name: 'Group Footer',
        arabicName: 'تذييل المجموعة',
        elements: []
      },
      {
        id: 'pageFooter',
        name: 'Page Footer',
        arabicName: 'تذييل الصفحة',
        elements: []
      },
      {
        id: 'reportFooter',
        name: 'Report Footer',
        arabicName: 'تذييل التقرير',
        elements: []
      }
    ]
  }
];
