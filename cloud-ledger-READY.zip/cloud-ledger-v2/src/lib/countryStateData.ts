import countriesRaw from '../data/countries.csv?raw';
import statesRaw from '../data/states.csv?raw';

export interface CountryData {
  id: string;
  name: string;
  iso2: string;
  currencyCode: string;
  currencyName: string;
  currencySymbol: string;
}

export interface StateData {
  id: string;
  name: string;
  countryId: string;
  countryCode: string;
  countryName: string;
}

export interface CurrencyData {
  code: string;
  name: string;
  symbol: string;
}

function parseCSV(text: string): string[][] {
  const result: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let inQuotes = false;
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];
    
    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        cell += '"';
        i++; // skip next quote
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      row.push(cell.trim());
      cell = '';
    } else if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && nextChar === '\n') {
        i++;
      }
      row.push(cell.trim());
      if (row.length > 0 && row.some(c => c !== '')) {
        result.push(row);
      }
      row = [];
      cell = '';
    } else {
      cell += char;
    }
  }
  
  if (cell || row.length > 0) {
    row.push(cell.trim());
    if (row.some(c => c !== '')) {
      result.push(row);
    }
  }
  
  return result;
}

// Parse countries
const parsedCountries = parseCSV(countriesRaw);
const countriesHeader = parsedCountries[0] || [];
const countryRows = parsedCountries.slice(1);

const idIndex = countriesHeader.indexOf('id');
const nameIndex = countriesHeader.indexOf('name');
const iso2Index = countriesHeader.indexOf('iso2');
const currencyIndex = countriesHeader.indexOf('currency');
const currencyNameIndex = countriesHeader.indexOf('currency_name');
const currencySymbolIndex = countriesHeader.indexOf('currency_symbol');

export const countries: CountryData[] = countryRows.map(row => ({
  id: row[idIndex] || '',
  name: row[nameIndex] || '',
  iso2: row[iso2Index] || '',
  currencyCode: row[currencyIndex] || '',
  currencyName: row[currencyNameIndex] || '',
  currencySymbol: row[currencySymbolIndex] || '',
})).filter(c => c.id && c.name);

// Parse states
const parsedStates = parseCSV(statesRaw);
const statesHeader = parsedStates[0] || [];
const stateRows = parsedStates.slice(1);

const sIdIndex = statesHeader.indexOf('id');
const sNameIndex = statesHeader.indexOf('name');
const sCountryIdIndex = statesHeader.indexOf('country_id');
const sCountryCodeIndex = statesHeader.indexOf('country_code');
const sCountryNameIndex = statesHeader.indexOf('country_name');

export const states: StateData[] = stateRows.map(row => ({
  id: row[sIdIndex] || '',
  name: row[sNameIndex] || '',
  countryId: row[sCountryIdIndex] || '',
  countryCode: row[sCountryCodeIndex] || '',
  countryName: row[sCountryNameIndex] || '',
})).filter(s => s.id && s.name);

// Extract predefined list of unique currencies driven from the country list
const seenCurrencies = new Set<string>();
const currencyList: CurrencyData[] = [];

countries.forEach(c => {
  if (c.currencyCode && !seenCurrencies.has(c.currencyCode)) {
    seenCurrencies.add(c.currencyCode);
    currencyList.push({
      code: c.currencyCode,
      name: c.currencyName || c.currencyCode,
      symbol: c.currencySymbol || '$',
    });
  }
});

// Sort currencies alphabetically by code
export const currencies: CurrencyData[] = currencyList.sort((a, b) => a.code.localeCompare(b.code));
