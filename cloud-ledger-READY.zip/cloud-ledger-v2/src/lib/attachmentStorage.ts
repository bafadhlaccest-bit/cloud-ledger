import { Attachment } from '../types';

const DB_NAME = 'system_attachments_db';
const STORE_NAME = 'attachments';
const DB_VERSION = 1;

function getIndexedDB(): IDBFactory | null {
  try {
    if (typeof window === 'undefined') return null;
    const idb = window.indexedDB || (window as any).mozIndexedDB || (window as any).webkitIndexedDB || (window as any).msIndexedDB;
    if (!idb) return null;
    return idb;
  } catch (e) {
    return null;
  }
}

// Memory fallback store to prevent SecurityErrors in sandboxed iframe environments
const memoryStore: Record<string, Attachment[]> = {};

function initDB(): Promise<IDBDatabase> {
  const idb = getIndexedDB();
  if (!idb) {
    return Promise.reject(new Error('IndexedDB is not supported or is blocked in this environment.'));
  }
  return new Promise((resolve, reject) => {
    try {
      const request = idb.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
          store.createIndex('entityId', 'entityId', { unique: false });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    } catch (e) {
      reject(e);
    }
  });
}

export async function getAttachments(entityId: string): Promise<Attachment[]> {
  const idb = getIndexedDB();
  if (!idb) {
    return memoryStore[entityId] || [];
  }

  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      try {
        const transaction = db.transaction(STORE_NAME, 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const index = store.index('entityId');
        const request = index.getAll(entityId);

        request.onsuccess = () => {
          resolve(request.result || []);
        };

        request.onerror = () => {
          reject(request.error);
        };
      } catch (e) {
        reject(e);
      }
    });
  } catch (err) {
    console.warn('IndexedDB getAttachments fallback usage active:', err);
    return memoryStore[entityId] || [];
  }
}

export async function saveAttachment(
  entityId: string,
  name: string,
  size: number,
  type: string,
  url: string
): Promise<Attachment> {
  const attachment: Attachment = {
    id: `${entityId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    entityId,
    name,
    size,
    type,
    url,
    createdAt: new Date().toISOString(),
  };

  const idb = getIndexedDB();
  if (!idb) {
    if (!memoryStore[entityId]) {
      memoryStore[entityId] = [];
    }
    memoryStore[entityId].push(attachment);
    return attachment;
  }

  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      try {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.put(attachment);

        request.onsuccess = () => {
          resolve(attachment);
        };

        request.onerror = () => {
          reject(request.error);
        };
      } catch (e) {
        reject(e);
      }
    });
  } catch (err) {
    console.warn('IndexedDB saveAttachment fallback usage active:', err);
    if (!memoryStore[entityId]) {
      memoryStore[entityId] = [];
    }
    memoryStore[entityId].push(attachment);
    return attachment;
  }
}

export async function deleteAttachment(id: string): Promise<void> {
  const idb = getIndexedDB();
  if (!idb) {
    Object.keys(memoryStore).forEach((key) => {
      memoryStore[key] = memoryStore[key].filter((att) => att.id !== id);
    });
    return;
  }

  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      try {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.delete(id);

        request.onsuccess = () => {
          resolve();
        };

        request.onerror = () => {
          reject(request.error);
        };
      } catch (e) {
        reject(e);
      }
    });
  } catch (err) {
    console.warn('IndexedDB deleteAttachment fallback usage active:', err);
    Object.keys(memoryStore).forEach((key) => {
      memoryStore[key] = memoryStore[key].filter((att) => att.id !== id);
    });
  }
}

export async function saveDraftAttachments(
  tempEntityId: string,
  finalEntityId: string
): Promise<void> {
  const idb = getIndexedDB();
  if (!idb) {
    const tempAttachments = memoryStore[tempEntityId] || [];
    if (tempAttachments.length === 0) return;

    if (!memoryStore[finalEntityId]) {
      memoryStore[finalEntityId] = [];
    }

    tempAttachments.forEach((att) => {
      const updated: Attachment = {
        ...att,
        id: att.id.replace(tempEntityId, finalEntityId),
        entityId: finalEntityId,
      };
      memoryStore[finalEntityId].push(updated);
    });

    delete memoryStore[tempEntityId];
    return;
  }

  try {
    const db = await initDB();
    const tempAttachments = await getAttachments(tempEntityId);

    if (tempAttachments.length === 0) return;

    return new Promise((resolve, reject) => {
      try {
        const transaction = db.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);

        transaction.oncomplete = () => {
          resolve();
        };

        transaction.onerror = () => {
          reject(transaction.error);
        };

        tempAttachments.forEach((att) => {
          const updated: Attachment = {
            ...att,
            id: att.id.replace(tempEntityId, finalEntityId),
            entityId: finalEntityId,
          };
          
          store.delete(att.id);
          store.put(updated);
        });
      } catch (e) {
        reject(e);
      }
    });
  } catch (err) {
    console.warn('IndexedDB saveDraftAttachments fallback usage active:', err);
    const tempAttachments = memoryStore[tempEntityId] || [];
    if (tempAttachments.length === 0) return;

    if (!memoryStore[finalEntityId]) {
      memoryStore[finalEntityId] = [];
    }

    tempAttachments.forEach((att) => {
      const updated: Attachment = {
        ...att,
        id: att.id.replace(tempEntityId, finalEntityId),
        entityId: finalEntityId,
      };
      memoryStore[finalEntityId].push(updated);
    });

    delete memoryStore[tempEntityId];
  }
}
