/**
 * Enterprise Read-Only Intermediary Controller (Financial Service Bridge)
 * Decouples raw database access from the AI copilot to prevent hallucinations,
 * enforces strict role permissions, and tracks source verification metadata.
 */
export interface AccountingMetadata {
  reportingPeriod: { from: string; to: string };
  transactionCount: number;
  sourceAccountIds: string[];
}

export interface ForecastDataPoint {
  name: string;
  value: number;
  projected: number;
  isForecast: boolean;
}

export interface ForecastResult {
  title: string;
  type: 'Revenue' | 'CashFlow';
  slope: number;
  intercept: number;
  data: ForecastDataPoint[];
}

export class FinancialService {
  /**
   * Safe, permission-aware catalog query aggregator.
   * Leveraged by copilot to acquire strictly validated DB facts before verbalizing constants.
   */
  public static queryLiveFactCatalog(
    dbRecords: Record<string, any[]>,
    tableName: string,
    userRole: string,
    searchQuery?: string,
    limit: number = 20
  ): { data: any[]; count: number; metadata: AccountingMetadata; error?: string } {
    const isAllowed = ["Admin", "Accountant", "Auditor"].includes(userRole);
    if (!isAllowed) {
      return {
        data: [],
        count: 0,
        metadata: { reportingPeriod: { from: 'N/A', to: 'N/A' }, transactionCount: 0, sourceAccountIds: [] },
        error: `Security Validation Blocked: Role '${userRole}' has insufficient permissions to read table '${tableName}'.`
      };
    }

    const records = dbRecords[tableName] || [];
    let filtered = JSON.parse(JSON.stringify(records));

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter((r: any) =>
        Object.values(r).some(val => String(val).toLowerCase().includes(q))
      );
    }

    const sliced = filtered.slice(0, Math.min(limit, 50));
    const activeJournalLines = dbRecords.journal_lines || [];
    const sourceCodes = [...new Set<string>(sliced.map((r: any) => r.code || r.id || ''))].filter(Boolean);

    return {
      data: sliced,
      count: records.length,
      metadata: {
        reportingPeriod: { from: '2026-01-01', to: '2026-12-31' },
        transactionCount: activeJournalLines.length,
        sourceAccountIds: sourceCodes
      }
    };
  }

  /**
   * Computes statistical linear regressions for predictive modeling of revenues or cash flow.
   * Absolute constraint: Rejects calculations and blocks compilation if the log density is under 30.
   */
  public static calculateTrendProjection(
    dbRecords: Record<string, any[]>,
    type: 'Revenue' | 'CashFlow'
  ): { forecast: ForecastResult | null; error?: string } {
    const listLines = dbRecords.journal_lines || [];
    const totalLinesCount = listLines.length;

    // Strict 30-entry minimum density rule
    if (totalLinesCount < 30) {
      return {
        forecast: null,
        error: `البيانات المقيدة غير كافية لعمل تنبؤ إحصائي دقيق. يتطلب النظام وجود 30 قيدًا عملياتيًا على الأقل في قاعدة البيانات الحالية. (المقيد حاليًا: ${totalLinesCount} قيود) / Insufficient data density: At least 30 operational ledger lines are required (Current: ${totalLinesCount}).`
      };
    }

    // Initialize historical months
    const monthlyValues: Record<string, number> = {
      'Jan-26': 0, 'Feb-26': 0, 'Mar-26': 0, 'Apr-26': 0, 'May-26': 0
    };

    listLines.forEach((jl: any) => {
      const header = dbRecords.journal_entries?.find(h => h.id === jl.journal_entry_id);
      if (header && header.date) {
        const month = header.date.split('-')[1];
        let key = '';
        if (month === '01') key = 'Jan-26';
        else if (month === '02') key = 'Feb-26';
        else if (month === '03') key = 'Mar-26';
        else if (month === '04') key = 'Apr-26';
        else if (month === '05') key = 'May-26';

        if (key) {
          const acc = dbRecords.accounts?.find(a => a.id === jl.account_id);
          if (acc) {
            const accType = acc.type.toLowerCase();
            if (type === 'Revenue') {
              if (accType === 'revenue' || accType === 'income') {
                monthlyValues[key] += (jl.credit || 0) - (jl.debit || 0);
              }
            } else {
              if (jl.account_id === 'acc_kuraimi' || jl.account_id === 'acc_cash_usd' || accType.includes('asset')) {
                monthlyValues[key] += (jl.debit || 0) - (jl.credit || 0);
              }
            }
          }
        }
      }
    });

    const dataPoints: ForecastDataPoint[] = Object.keys(monthlyValues).map(key => ({
      name: key,
      value: monthlyValues[key],
      projected: monthlyValues[key],
      isForecast: false
    }));

    // Math Linear Regression modeling (y = m * x + c)
    const n = dataPoints.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
    for (let i = 0; i < n; i++) {
      const x = i;
      const y = dataPoints[i].value;
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumXX += x * x;
    }
    
    const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX) || 0;
    const intercept = (sumY - slope * sumX) / n || 0;

    // Project upcoming 3 months: June, July, August 2026
    const projectMonthValues = [5, 6, 7];
    const projectMonthNames = ['Jun-26', 'Jul-26', 'Aug-26'];

    projectMonthValues.forEach((x, idx) => {
      const projectedVal = Math.max(0, Math.round(slope * x + intercept));
      dataPoints.push({
        name: projectMonthNames[idx],
        value: 0,
        projected: projectedVal,
        isForecast: true
      });
    });

    return {
      forecast: {
        title: `${type === 'Revenue' ? 'Revenue / Sales' : 'Net Cash Flow'} Statistical Linear Forecast Projection`,
        type,
        slope,
        intercept,
        data: dataPoints
      }
    };
  }
}
