import { useAuthStore } from '../store/useAuthStore';
import { db, collection, updateDoc, query, where, doc } from '../firebase';

// 1. الدالة المحدثة للحذف الناعم (Soft Delete) مع معالجة الأخطاء
export const handleDelete = async (vendorId: string, callbackRefresh: () => void) => {
  const { user } = useAuthStore.getState();
  const companyId = user?.companyId || companyId;

  if (!companyId) {
    alert("خطأ: لا توجد شركة نشطة معرّفة!");
    return;
  }

  const isConfirmed = window.confirm("هل أنت متأكد من إلغاء تنشيط هذا المورد؟");
  if (!isConfirmed) return;

  try {
    const vendorRef = doc(db, 'vendors', vendorId);
    
    // التحديث الفعلي للحالة
    await updateDoc(vendorRef, {
      is_active: false,
      status: 'inactive',
      updatedAt: new Date()
    });

    // استدعاء دالة تحديث الواجهة فوراً لتصفية القائمة
    callbackRefresh();
    
  } catch (error: any) {
    console.error("فشل التحديث في Firestore. تحقق من الـ Rules أو الفواتير المعلقة:", error);
    alert(`لم يتم الحذف: ${error.message}`);
  }
};

// 2. الاستعلام الصحيح للشاشة (يجب أن يستثني الـ inactive ويتحقق من الشركة)
export const getActiveVendorsQuery = (companyId: string) => {
  return query(
    collection(db, 'vendors'),
    where('companyId', '==', companyId),
    where('is_active', '==', true) // 🌟 هذا السطر هو السحر الذي سيجعل المورد يختفي فوراً عند الضغط على الحذف
  );
};
