
import { db, getDoc, doc } from '../firebase';
export class PeriodLockingService {

  /**
   * فحص حالة الفترة المحاسبية (مفتوحة / مغلقة)
   */
  public static async validatePeriodIsOpen(companyId: string, dateString: string): Promise<void> {
    // استخراج السنة والشهر من التاريخ (مثال: '2026-06')
    const periodId = dateString.substring(0, 7); 
    
    const periodRef = doc(db, 'companies', companyId, 'fiscal_periods', periodId);
    const periodSnap = await getDoc(periodRef);

    if (periodSnap.exists()) {
      const { is_closed } = periodSnap.data();
      if (is_closed === true) {
        throw new Error(`[معايير IFRS] لا يمكن ترحيل الحركة. الفترة المالية ${periodId} مغلقة ومقفلة نهائياً من قبل الإدارة المالية.`);
      }
    }
  }
}
