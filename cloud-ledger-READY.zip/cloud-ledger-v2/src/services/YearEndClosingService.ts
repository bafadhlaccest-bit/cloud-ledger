// src/services/YearEndClosingService.ts
import { PostingEngine, JournalEntry, JournalLine, PostingResult } from './PostingEngine';
import { db, collection, getDocs, updateDoc, query, where, serverTimestamp, doc } from '../firebase';

export class YearEndClosingService {
  /**
   * توليد قيود الإقفال السنوي وتصفير الحسابات المؤقتة تماشياً مع معايير IFRS (للتوافق القديم)
   */
  public static generateClosingEntry(
    currentYear: number, 
    activeLines: JournalLine[], 
    retainedEarningsAccountId: string
  ): JournalEntry {
    const closingLines: JournalLine[] = [];
    let closingBalanceSum = 0;

    activeLines.forEach(line => {
      if (line.accountType === 'INCOME' && line.amountInBaseCurrency !== 0) {
        closingLines.push({
          ...line,
          id: `close-inc-${line.id}`,
          debit: (line.amountInBaseCurrency || 0) > 0 ? 0 : Math.abs(line.amountInBaseCurrency || 0),
          credit: (line.amountInBaseCurrency || 0) > 0 ? Math.abs(line.amountInBaseCurrency || 0) : 0,
          amountInBaseCurrency: (line.amountInBaseCurrency || 0) * -1
        });
        closingBalanceSum += (line.amountInBaseCurrency || 0);
      } else if (line.accountType === 'EXPENSE' && line.amountInBaseCurrency !== 0) {
        closingLines.push({
          ...line,
          id: `close-exp-${line.id}`,
          debit: (line.amountInBaseCurrency || 0) > 0 ? 0 : Math.abs(line.amountInBaseCurrency || 0),
          credit: (line.amountInBaseCurrency || 0) > 0 ? Math.abs(line.amountInBaseCurrency || 0) : 0,
          amountInBaseCurrency: (line.amountInBaseCurrency || 0) * -1
        });
        closingBalanceSum += (line.amountInBaseCurrency || 0);
      }
    });

    closingLines.push({
      id: `close-retained-${currentYear}`,
      accountId: retainedEarningsAccountId,
      accountCode: '3200',
      accountType: 'EQUITY',
      ifrsMapping: 'EQUITY_BASE',
      debit: closingBalanceSum > 0 ? 0 : Math.abs(closingBalanceSum),
      credit: closingBalanceSum > 0 ? Math.abs(closingBalanceSum) : 0,
      currencyCode: 'USD',
      exchangeRate: 1.0,
      amountInBaseCurrency: closingBalanceSum
    });

    return {
      id: `closing-entry-${currentYear}`,
      date: `${currentYear}-12-31`,
      reference: `YEC-${currentYear}`,
      description: `قيد الإقفال السنوي الختامي للعام المالي ${currentYear} وتدوير الأرباح المبقاة`,
      status: 'DRAFT',
      lines: closingLines
    };
  }

  /**
   * 1. Year-End Closing Processor (إجراء الإقفال السنوي الفعلي):
   * - Scans all active posting lines for a specific financial calendar window.
   * - Identifies all temporary balances tagged as 'INCOME' or 'EXPENSE'.
   * - Creates a single batch settlement journal ledger entry that offsets these balances to zero.
   * - Consolidates the net outcome balance sum and posts it as a single credit/debit adjustment line directly
   *   to sub-account '3200 - Retained Earnings' (الأرباح المبقاة) under the Equity tree.
   */
  public static async executeYearEndClosing(
    companyId: string,
    year: number,
    retainedEarningsAccountId: string = 'acc_retained_earnings'
  ): Promise<PostingResult> {
    try {
      // 1. Gather all posted general ledger rows for the active year
      const q = query(
        collection(db, 'journalEntries'),
        where('companyId', '==', companyId),
        where('status', '==', 'Posted')
      );
      const snapshot = await getDocs(q);

      const targetYearEntries: any[] = [];
      snapshot.forEach(docSnap => {
        const d = docSnap.data();
        const entryDate = new Date(d.date);
        if (entryDate.getFullYear() === year) {
          // Verify that we do not double collect any existing YEC closing entry of this year
          if (d.reference !== `YEC-${year}`) {
            targetYearEntries.push({ id: docSnap.id, ...d });
          }
        }
      });

      // 2. Rollup ledger balances
      const balances: Record<string, number> = {};
      const accountMap: Record<string, { code: string; name: string; type: string }> = {};

      const coaSnap = await getDocs(collection(db, 'accounts'));
      coaSnap.forEach(docSnap => {
        const d = docSnap.data();
        accountMap[docSnap.id] = {
          code: d.code || '',
          name: d.name || '',
          type: d.type || ''
        };
      });

      // Dynamic ledger row scanner
      targetYearEntries.forEach(entry => {
        if (entry.lines) {
          entry.lines.forEach((line: any) => {
            const accId = line.accountId;
            if (accId) {
              if (balances[accId] === undefined) {
                balances[accId] = 0;
              }
              const debitAmt = Number(line.debit) || 0;
              const creditAmt = Number(line.credit) || 0;
              balances[accId] += debitAmt - creditAmt;

              if (!accountMap[accId]) {
                accountMap[accId] = {
                  code: line.accountCode || '',
                  name: line.accountName || '',
                  type: line.accountType || 'Asset'
                };
              }
            }
          });
        }
      });

      // 3. Separate Income Statement vs Balance Sheet accounts and build offset lines
      const closingLines: JournalLine[] = [];
      let totalRevenueClosed = 0;
      let totalExpenseClosed = 0;

      Object.entries(balances).forEach(([accId, bal]) => {
        if (Math.abs(bal) < 0.001) return;
        const meta = accountMap[accId];
        if (!meta) return;

        const typeLower = (meta.type || '').toLowerCase();
        const code = meta.code || '';

        const isRevenue = typeLower.startsWith('rev') || typeLower.startsWith('inc') || code.startsWith('4');
        const isExpense = typeLower.startsWith('exp') || typeLower.startsWith('cost') || code.startsWith('5');

        if (isRevenue) {
          // Revenue normally has Credit balance (Debit - Credit is negative).
          // To zero-out revenue, we DEBIT the account
          const isNormalCredit = bal < 0;
          closingLines.push({
            accountId: accId,
            accountName: meta.name,
            accountCode: meta.code,
            accountType: 'INCOME',
            debit: isNormalCredit ? Math.abs(bal) : 0,
            credit: isNormalCredit ? 0 : bal,
            exchangeRate: 1.0,
            amountInBaseCurrency: isNormalCredit ? Math.abs(bal) : -bal,
            description: `إقفال حساب إيرادات سنوي لتصفير الرصيد تحت معايير IFRS (${meta.name})`
          });
          totalRevenueClosed += isNormalCredit ? Math.abs(bal) : -bal;
        } else if (isExpense) {
          // Expense normally has Debit balance (Debit - Credit is positive).
          // To zero-out expense, we CREDIT the account for bal
          const isNormalDebit = bal > 0;
          closingLines.push({
            accountId: accId,
            accountName: meta.name,
            accountCode: meta.code,
            accountType: 'EXPENSE',
            debit: isNormalDebit ? 0 : Math.abs(bal),
            credit: isNormalDebit ? bal : 0,
            exchangeRate: 1.0,
            amountInBaseCurrency: isNormalDebit ? -bal : Math.abs(bal),
            description: `إقفال حساب مصاريف سنوي لتصفير الرصيد تحت معايير IFRS (${meta.name})`
          });
          totalExpenseClosed += isNormalDebit ? bal : -Math.abs(bal);
        }
      });

      const netIncome = Number((totalRevenueClosed - totalExpenseClosed).toFixed(2));

      // Locate or default the '3200' Retained Earnings account
      let reAccountId = retainedEarningsAccountId;
      const reAccountEntry = Object.entries(accountMap).find(([_, acc]) => acc.code === '3200');
      
      let reMeta = reAccountEntry ? { id: reAccountEntry[0], ...reAccountEntry[1] } : {
        id: retainedEarningsAccountId,
        code: '3200',
        name: 'Retained Earnings (الأرباح المبقاة)',
        type: 'Equity'
      };

      if (Math.abs(netIncome) > 0.001) {
        closingLines.push({
          accountId: reMeta.id,
          accountName: reMeta.name,
          accountCode: '3200',
          accountType: 'EQUITY',
          debit: netIncome < 0 ? Math.abs(netIncome) : 0, // debit if net loss
          credit: netIncome > 0 ? netIncome : 0, // credit if net profit
          exchangeRate: 1.0,
          amountInBaseCurrency: netIncome,
          description: `ترحيل صافي الأرباح والخسائر للعام المالي ${year} لحساب الأرباح المبقاة`
        });
      }

      if (closingLines.length === 0) {
        return { success: false, error: `لا توجد أرصدة للحسابات المؤقتة (الإيرادات والمصاريف) ليتم تصفيرها للعام المالي ${year}` };
      }

      // Save and post YEC closing transaction using PostingEngine
      const yecResult = await PostingEngine.postToLedger({
        date: `${year}-12-31`,
        reference: `YEC-${year}`,
        description: `أتمتة قيد الإقفال السنوي الختامي وتصفير الحسابات المؤقتة للعام المالي ${year}`,
        lines: closingLines,
        companyId,
        status: 'Posted',
        isAutoGenerated: true
      });

      return yecResult;
    } catch (error: any) {
      console.error("[Year-End Closing Service Failure]:", error);
      return { success: false, error: error.message || "Failed execution of Year-End closing sequence." };
    }
  }

  /**
   * 2. Accrual Reversal Module (القيود العكسية التلقائية):
   * - clones a selected adjusting entry (like accrued expenses),
   * - flips the debit/credit vectors on every individual line item row,
   * - sets the date token to day 1 of the new reporting month,
   * - and posts it securely with a cross-referenced audit trail tag.
   */
  public static async createReversingEntry(
    companyId: string,
    parentEntryId: string,
    reversalUser?: string
  ): Promise<PostingResult> {
    try {
      // Fetch all entries under the tenant company to locate the target parent transaction securely
      const entrySnap = await getDocs(query(collection(db, 'journalEntries'), where('companyId', '==', companyId)));
      let parentEntry: any = null;
      
      entrySnap.forEach(snap => {
        if (snap.id === parentEntryId) {
          parentEntry = { id: snap.id, ...snap.data() };
        }
      });

      if (!parentEntry) {
        throw new Error(`القيد الأساسي غير موجود أو لا ينتمي لهذا المنشأة: #${parentEntryId}`);
      }

      const parentDate = new Date(parentEntry.date);
      if (isNaN(parentDate.getTime())) {
        throw new Error(`تاريخ القيد الأب غير صحيح: ${parentEntry.date}`);
      }

      const year = parentDate.getFullYear();
      const month = parentDate.getMonth(); // 0-indexed, 0 = January

      // Day 1 of the next reporting month
      const nextYear = month === 11 ? year + 1 : year;
      const nextMonth = month === 11 ? 1 : month + 2; 
      const firstDayOfNext = `${nextYear}-${nextMonth.toString().padStart(2, '0')}-01`;

      // Clone and reverse debit/credit directions
      const reversedLines: JournalLine[] = parentEntry.lines.map((line: any) => {
        const rate = Number(line.exchangeRate) || 1.0;
        const flippedDebit = Number(line.credit) || 0;
        const flippedCredit = Number(line.debit) || 0;
        
        let flippedAmtInBase = undefined;
        if (line.amountInBaseCurrency !== undefined) {
          flippedAmtInBase = line.amountInBaseCurrency * -1;
        } else {
          flippedAmtInBase = flippedDebit > 0 ? (flippedDebit / rate) : -1 * (flippedCredit / rate);
        }

        return {
          accountId: line.accountId,
          accountName: line.accountName || '',
          accountCode: line.accountCode,
          accountType: line.accountType || '',
          debit: flippedDebit,
          credit: flippedCredit,
          exchangeRate: rate,
          amountInBaseCurrency: flippedAmtInBase,
          description: `عكس قيد تسوية مستحق: ${line.description || parentEntry.description}`,
          branchId: line.branchId || '',
          costCenterId: line.costCenterId || '',
          projectId: line.projectId || '',
          departmentId: line.departmentId || ''
        };
      });

      // Post reversing journal entry
      const result = await PostingEngine.postToLedger({
        date: firstDayOfNext,
        reference: `REV-${parentEntry.reference}`,
        description: `قيد عكسي تلقائي للتسويات المستحقة - مرتبط بالقيد الرئيسي #${parentEntry.reference}`,
        lines: reversedLines,
        companyId,
        isReversal: true,
        parentJournalId: parentEntry.id,
        isAutoGenerated: true,
        status: 'Posted'
      });

      if (result.success && result.journalEntryId) {
        // Link reversal details back inside the parent document
        await updateDoc(doc(db, 'journalEntries', parentEntryId), {
          reversalDate: firstDayOfNext,
          reversalEntryId: result.journalEntryId,
          updatedAt: serverTimestamp()
        });
      }

      return result;
    } catch (error: any) {
      console.error("[Accrual Reversal Service Failure]:", error);
      return { success: false, error: error.message || "Failed executing accrual reversal sequence." };
    }
  }
}
