import { Account } from '../types';
import { db, collection, getDocs, updateDoc, deleteDoc, query, where, doc } from '../firebase';

/**
 * 1. تحديث بيانات حساب فرعي مع التحقق المحاسبي
 */
export async function updateSubAccount(accountId: string, updatedFields: Partial<Account>): Promise<{ success: boolean; message: string }> {
  try {
    // التحقق أولاً: إذا كان المستخدم يحاول تغيير "النوع" والحساب لديه معاملات مسبقة
    if (updatedFields.type) {
      const journalLinesRef = collection(db, 'journal_lines');
      const q = query(journalLinesRef, where('accountId', '==', accountId));
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        return { 
          success: false, 
          message: 'لا يمكن تغيير نوع الحساب بسبب وجود قيود يومية مسجلة عليه مسبقاً.' 
        };
      }
    }

    const accountRef = doc(db, 'accounts', accountId);
    await updateDoc(accountRef, updatedFields);
    
    return { success: true, message: 'تم تحديث الحساب بنجاح.' };
  } catch (error) {
    console.error('Error updating account:', error);
    return { success: false, message: 'حدث خطأ أثناء تحديث الحساب.' };
  }
}

/**
 * 2. حذف حساب فرعي مع التحقق المحاسبي المشدد لمنع تلف البيانات المالية
 */
export async function deleteSubAccount(account: Account): Promise<{ success: boolean; message: string }> {
  try {
    // أ. التحقق من الرصيد والتحقق من عدم وجود رصيد معلق
    if (account.balance !== 0) {
      return { 
        success: false, 
        message: 'لا يمكن حذف الحساب لأن رصيده الحالي ليس صفراً. يرجى تصفية الرصيد بقيد تسوية أولاً.' 
      };
    }

    // ب. التحقق من وجود أي قيود ماليّة مرتبطة بالحساب (حتى لو كان الرصيد صفراً) لمنع فقدان الأثريات التاريخية
    const journalLinesRef = collection(db, 'journal_lines');
    const q = query(journalLinesRef, where('accountId', '==', account.id));
    const querySnapshot = await getDocs(q);

    if (!querySnapshot.empty) {
      return { 
        success: false, 
        message: 'تحذير محاسبي: لا يمكن حذف هذا الحساب لوجود حركات مالية سابقة مسجلة عليه. يمكنك تعطيله (خيار غير نشط) بدلاً من الحذف.' 
      };
    }

    // ج. تنفيذ الحذف الفعلي في حال اجتياز الشروط
    const accountRef = doc(db, 'accounts', account.id);
    await deleteDoc(accountRef);

    return { success: true, message: 'تم حذف الحساب الفرعي بنجاح من النظام.' };
  } catch (error) {
    console.error('Error deleting account:', error);
    return { success: false, message: 'حدث خطأ أثناء محاولة حذف الحساب.' };
  }
}
