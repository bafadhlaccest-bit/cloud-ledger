// src/services/FinancialReportEngine.ts

// واجهة تمثل السطر المسترجع من قاعدة البيانات للقيود المجمعة لكل حساب
export interface AccountBalanceRow {
  accountCode: string;
  accountName: string;
  classification: 'ASSETS' | 'LIABILITIES' | 'EQUITY' | 'REVENUE' | 'EXPENSES' | 'COGS' | 'OTHER_INCOME';
  totalDebit: number;
  totalCredit: number;
}

export class FinancialReportEngine {

  /**
   * توليد قائمة الدخل والأرباح والخسائر ديناميكياً
   */
  public static generateIncomeStatement(accountBalances: AccountBalanceRow[]) {
    // 1. حساب إيرادات النشاط (الدائن - المدين)
    const operatingRevenue = accountBalances
      .filter(acc => acc.classification === 'REVENUE')
      .reduce((sum, acc) => sum + (acc.totalCredit - acc.totalDebit), 0);

    // 2. حساب تكلفة المبيعات (المدين - الدائن)
    const costOfSales = accountBalances
      .filter(acc => acc.classification === 'COGS')
      .reduce((sum, acc) => sum + (acc.totalDebit - acc.totalCredit), 0);

    // 3. حساب مجمل الربح
    const grossProfit = operatingRevenue - costOfSales;

    // 4. حساب المصاريف التشغيلية والعمومية (المدين - الدائن)
    const operatingExpenses = accountBalances
      .filter(acc => acc.classification === 'EXPENSES')
      .reduce((sum, acc) => sum + (acc.totalDebit - acc.totalCredit), 0);

    // 5. حساب الإيرادات الأخرى (الدائن - المدين)
    const otherIncome = accountBalances
      .filter(acc => acc.classification === 'OTHER_INCOME')
      .reduce((sum, acc) => sum + (acc.totalCredit - acc.totalDebit), 0);

    // 6. صافي الربح أو الخسارة النهائي حسب المعايير الدولية
    const netProfitOrLoss = grossProfit - operatingExpenses + otherIncome;

    return {
      operatingRevenue,
      costOfSales,
      grossProfit,
      operatingExpenses,
      otherIncome,
      netProfitOrLoss // هذا الرقم سيرحل تلقائياً للميزانية
    };
  }

  /**
   * توليد تقرير المركز المالي (الميزانية العمومية)
   */
  public static generateBalanceSheet(accountBalances: AccountBalanceRow[], netProfitFromIncomeStatement: number) {
    
    // 1. إجمالي الأصول (المدين - الدائن)
    const totalAssets = accountBalances
      .filter(acc => acc.classification === 'ASSETS')
      .reduce((sum, acc) => sum + (acc.totalDebit - acc.totalCredit), 0);

    // 2. إجمالي الالتزامات (الدائن - المدين)
    const totalLiabilities = accountBalances
      .filter(acc => acc.classification === 'LIABILITIES')
      .reduce((sum, acc) => sum + (acc.totalCredit - acc.totalDebit), 0);

    // 3. حقوق الملكية الأساسية من الشجرة (رأس المال مثلاً)
    const baseEquity = accountBalances
      .filter(acc => acc.classification === 'EQUITY')
      .reduce((sum, acc) => sum + (acc.totalCredit - acc.totalDebit), 0);

    // 4. إجمالي حقوق الملكية = الحقوق الأساسية + صافي أرباح الفترة الحالية
    const totalEquity = baseEquity + netProfitFromIncomeStatement;

    // التحقق من توازن الميزانية (صمام الأمان لـ Cloud Ledger)
    const isBalanced = Math.abs(totalAssets - (totalLiabilities + totalEquity)) < 0.01;

    return {
      totalAssets,
      totalLiabilities,
      totalEquity,
      retainedEarningsFromPeriod: netProfitFromIncomeStatement,
      accountingEquationCheck: {
        assets: totalAssets,
        liabilitiesAndEquity: totalLiabilities + totalEquity,
        isBalanced: isBalanced
      }
    };
  }
}
