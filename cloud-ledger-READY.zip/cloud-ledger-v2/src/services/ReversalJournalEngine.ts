
import { db, collection, serverTimestamp, runTransaction, doc } from '../firebase';
export class ReversalJournalEngine {

  /**
   * إنشاء قيد عكسي تلقائي متوازن بالكامل
   */
  public static async reversePostedEntry(companyId: string, originalEntryId: string, userId: string): Promise<void> {
    
    await runTransaction(db, async (transaction) => {
      const originalRef = doc(db, 'companies', companyId, 'journal_entries', originalEntryId);
      const originalSnap = await transaction.get(originalRef);

      if (!originalSnap.exists()) throw new Error("القيد الأصلي غير موجود.");
      const originalData = originalSnap.data();

      if (originalData.status !== 'Posted') throw new Error("لا يمكن عكس قيد غير مرحل.");
      if (originalData.status === 'Reversed') throw new Error("هذا القيد تم عكسه مسبقاً.");

      // بناء أسطر القيد العكسي (قلب المدين دائن والدائن مدين)
      const reversedLines = originalData.lines.map((line: any) => ({
        ...line,
        type: line.type === 'debit' ? 'credit' : 'debit' // 🌟 قلب الطبيعة المحاسبية حركياً لخصم المبلغ
      }));

      const reversalEntryRef = doc(collection(db, 'companies', companyId, 'journal_entries'));
      
      // 1. تسجيل القيد العكسي الجديد
      transaction.set(reversalEntryRef, {
        description: `قيد عكسي تلقائي للقيد رقم: ${originalEntryId}`,
        lines: reversedLines,
        status: 'Posted',
        isReversal: true,
        originalEntryId: originalEntryId,
        createdBy: userId,
        timestamp: serverTimestamp()
      });

      // 2. تحديث حالة القيد الأصلي ليكون Reversed ومقفل ضد أي عمليات أخرى
      transaction.update(originalRef, {
        status: 'Reversed',
        reversedBy: userId,
        reversalEntryId: reversalEntryRef.id,
        updatedAt: serverTimestamp()
      });
    });
  }
}
