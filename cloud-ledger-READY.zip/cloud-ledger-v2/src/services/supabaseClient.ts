import { supabase } from '../lib/supabase';

export { supabase };

/**
 * دالة حذف قيد يومية نهائياً من قاعدة بيانات سوبابيس
 */
export async function deleteJournalEntry(entryId: string, refreshUI: () => void) {
  // بدلاً من الـ alert التقليدي، استخدم رسالة تأكيد احترافية
  const isConfirmed = window.confirm("هل أنت متأكد من حذف هذا القيد نهائياً؟");
  if (!isConfirmed) return;

  const { error } = await supabase
    .from('journal_entries')
    .delete()
    .eq('id', entryId);

  if (error) {
    console.error("فشل الحذف:", error.message);
  } else {
    // استدعاء دالة تحديث الشاشة فوراً ليختفي السطر أمامك
    refreshUI(); 
  }
}

