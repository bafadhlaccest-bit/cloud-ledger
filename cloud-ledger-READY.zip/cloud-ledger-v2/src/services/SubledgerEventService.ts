
import { db, serverTimestamp, runTransaction, doc } from '../firebase';
export interface BusinessEvent {
  eventId: string;        // Idempotency Key الفريد (مثلاً: invoice_id + '_post')
  companyId: string;
  eventType: 'SALES_INVOICE' | 'PURCHASE_BILL' | 'CASH_RECEIPT';
  payload: any;           // بيانات الفاتورة أو الحركة التجارية بالكامل
  userId: string;
}

export class SubledgerEventService {

  /**
   * إرسال الحدث التجاري إلى الـ Queue (Event Store) بدلاً من الترحيل المباشر
   */
  public static async emitAccountingEvent(event: BusinessEvent): Promise<void> {
    
    // تنفيذ العملية داخل Transaction للتحقق من الـ Idempotency Key ومنع التكرار
    await runTransaction(db, async (transaction) => {
      
      const eventRef = doc(db, 'companies', event.companyId, 'accounting_event_store', event.eventId);
      const eventSnap = await transaction.get(eventRef);

      // صمام أمان لمنع الترحيل المكرر (Idempotency Check)
      if (eventSnap.exists()) {
        throw new Error(`[خطأ حوكمي] هذا الحدث المالي تم إرساله ومعالجته مسبقاً! الرقم المرجعي: ${event.eventId}`);
      }

      // 1. تسجيل الحدث في الـ Event Store (حالة الانتظار في الطابور PENDING)
      transaction.set(eventRef, {
        eventType: event.eventType,
        payload: event.payload,
        status: 'PENDING',
        createdBy: event.userId,
        emittedAt: serverTimestamp()
      });

      // 2. هنا تلتقط الـ Cloud Function في الخلفية (Background Worker) هذا الحدث
      // وتقوم بتشغيل الـ Posting Engine لتعديل الأستاذ العام (General Ledger) بعيداً عن المتصفح
    });
  }
}
