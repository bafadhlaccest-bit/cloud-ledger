// src/services/ReportingEngine.ts
import Big from 'big.js';
import { JournalLine } from './PostingEngine';

export class ReportingEngine {
  /**
   * Helper utility to resolve the precise Debit amount in Base Currency
   */
  private static getBaseDebit(line: JournalLine): Big {
    if (line.debit > 0) {
      if (line.amountInBaseCurrency !== undefined && line.amountInBaseCurrency > 0) {
        return new Big(line.amountInBaseCurrency);
      }
      const rate = line.exchangeRate || 1;
      return new Big(line.debit).div(rate);
    }
    return new Big(0);
  }

  /**
   * Helper utility to resolve the precise Credit amount in Base Currency
   */
  private static getBaseCredit(line: JournalLine): Big {
    if (line.credit > 0) {
      if (line.amountInBaseCurrency !== undefined) {
        if (line.amountInBaseCurrency < 0) {
          return new Big(line.amountInBaseCurrency).times(-1);
        }
        return new Big(line.amountInBaseCurrency);
      }
      const rate = line.exchangeRate || 1;
      return new Big(line.credit).div(rate);
    }
    return new Big(0);
  }

  /**
   * إنشاء قائمة الدخل المطابقة لمعايير IFRS بناءً على نوع التصنيف المحاسبي وليس كود الحساب
   */
  public static calculateIncomeStatement(journalLines: JournalLine[]) {
    let revenue = new Big(0);
    let cogs = new Big(0);
    let operatingExpenses = new Big(0);

    journalLines.forEach(line => {
      const debit = this.getBaseDebit(line);
      const credit = this.getBaseCredit(line);

      if (line.ifrsMapping === 'REVENUE') {
        // Revenues: Net Balance = TotalCredits - TotalDebits
        revenue = revenue.plus(credit.minus(debit));
      } else if (line.ifrsMapping === 'COGS') {
        // Cost of Goods Sold (Expenses nature): Net Balance = TotalDebits - TotalCredits
        cogs = cogs.plus(debit.minus(credit));
      } else if (line.ifrsMapping === 'OPERATING_EXPENSE') {
        // Operating Expenses: Net Balance = TotalDebits - TotalCredits
        operatingExpenses = operatingExpenses.plus(debit.minus(credit));
      }
    });

    const grossProfit = revenue.minus(cogs);
    const netProfit = grossProfit.minus(operatingExpenses);

    return {
      revenue: revenue.toNumber(),
      cogs: cogs.toNumber(),
      grossProfit: grossProfit.toNumber(),
      operatingExpenses: operatingExpenses.toNumber(),
      netProfit: netProfit.toNumber()
    };
  }

  /**
   * إنشاء قائمة المركز المالي (الميزانية العمومية) بدون أي حسابات احتياطية Fallback تماماً
   */
  public static calculateBalanceSheet(journalLines: JournalLine[]) {
    let currentAssets = new Big(0);
    let currentLiabilities = new Big(0);
    let equityBase = new Big(0);
    let retainedEarningsLedger = new Big(0);

    journalLines.forEach(line => {
      const debit = this.getBaseDebit(line);
      const credit = this.getBaseCredit(line);

      // التجميع بناءً على تصنيف الـ IFRS الممرر من القوائم المنسدلة والمنتجات
      if (line.ifrsMapping === 'CURRENT_ASSET') {
        // Assets: Net Balance = TotalDebits - TotalCredits
        currentAssets = currentAssets.plus(debit.minus(credit));
      } else if (line.ifrsMapping === 'CURRENT_LIABILITY') {
        // Liabilities: Net Balance = TotalCredits - TotalDebits
        currentLiabilities = currentLiabilities.plus(credit.minus(debit));
      } else if (line.ifrsMapping === 'EQUITY_BASE') {
        // Equity Base: Net Balance = TotalCredits - TotalDebits
        equityBase = equityBase.plus(credit.minus(debit));
      } else if ((line.ifrsMapping as string) === 'RETAINED_EARNINGS' || line.accountId === 'acc_retained_earnings') {
        // Retained Earnings in Ledger: Net Balance = TotalCredits - TotalDebits
        retainedEarningsLedger = retainedEarningsLedger.plus(credit.minus(debit));
      }
    });

    // جلب صافي ربح الفترة الحالية ديناميكياً لربطه بالأرباح المبقاة لإغلاق القوائم المالية
    const { netProfit } = this.calculateIncomeStatement(journalLines);
    const netProfitBig = new Big(netProfit);

    // تجميع الأرباح المبقاة بشكل تراكمي ديناميكي (رصيد الأستاذ السابق + صافي ربح السنة الحالية)
    const retainedEarnings = retainedEarningsLedger.plus(netProfitBig);
    const totalEquity = equityBase.plus(retainedEarnings);

    // التحقق المالي المعياري من التوازن (الأصول = الالتزامات + حقوق الملكية) دون استخدام Math.abs
    const liabilitiesAndEquity = currentLiabilities.plus(totalEquity);
    const isBalanced = currentAssets.eq(liabilitiesAndEquity);

    return {
      currentAssets: currentAssets.toNumber(),
      currentLiabilities: currentLiabilities.toNumber(),
      equityBase: equityBase.toNumber(),
      retainedEarnings: retainedEarnings.toNumber(),
      totalEquity: totalEquity.toNumber(),
      isBalanced // badge الحماية الأخضر: متزنة طبقاً لمعايير IFRS
    };
  }

  /**
   * إنشاء ميزان المراجعة المطابق لمعايير IFRS
   */
  public static calculateTrialBalance(journalLines: JournalLine[]) {
    let totalDebits = new Big(0);
    let totalCredits = new Big(0);

    const accountBalances: Record<string, {
      accountId: string;
      accountCode: string;
      accountName: string;
      accountType: string;
      debit: Big;
      credit: Big;
      netBalance: Big;
    }> = {};

    journalLines.forEach(line => {
      const debit = this.getBaseDebit(line);
      const credit = this.getBaseCredit(line);

      totalDebits = totalDebits.plus(debit);
      totalCredits = totalCredits.plus(credit);

      const accId = line.accountId;
      if (!accountBalances[accId]) {
        accountBalances[accId] = {
          accountId: accId,
          accountCode: line.accountCode || '',
          accountName: line.accountName || '',
          accountType: line.accountType || '',
          debit: new Big(0),
          credit: new Big(0),
          netBalance: new Big(0)
        };
      }

      const acc = accountBalances[accId];
      acc.debit = acc.debit.plus(debit);
      acc.credit = acc.credit.plus(credit);
    });

    // احتساب صافي الأرصدة لكل حساب بناءً على طبيعته المحاسبية ومعايير عرض IFRS
    Object.values(accountBalances).forEach(acc => {
      const typeLower = (acc.accountType || '').toLowerCase();
      const isDebitNature = 
        typeLower === 'asset' || 
        typeLower === 'expense' || 
        typeLower === 'costs' || 
        acc.accountCode.startsWith('1') || 
        acc.accountCode.startsWith('5');

      if (isDebitNature) {
        // المدين والمصاريف: صافي الرصيد = المدين - الدائن
        acc.netBalance = acc.debit.minus(acc.credit);
      } else {
        // الالتزامات وحقوق الملكية والإيرادات: صافي الرصيد = الدائن - المدين
        acc.netBalance = acc.credit.minus(acc.debit);
      }
    });

    const isBalanced = totalDebits.eq(totalCredits);

    return {
      totalDebits: totalDebits.toNumber(),
      totalCredits: totalCredits.toNumber(),
      isBalanced,
      accounts: Object.values(accountBalances).map(acc => ({
        ...acc,
        debit: acc.debit.toNumber(),
        credit: acc.credit.toNumber(),
        netBalance: acc.netBalance.toNumber()
      }))
    };
  }
}
