import axios from 'axios';
import { safeStorage } from '../utils/safeStorage';

export interface Currency {
  code: string;
  name: string;
  symbol: string;
  flag: string;
  customRate?: number; // لإتاحة التعديل اليدوي من قبل المحاسب
}

export const GLOBAL_CURRENCIES: Currency[] = [
  { code: 'USD', name: 'دولار أمريكي', symbol: '$', flag: '🇺🇸' },
  { code: 'EUR', name: 'يورو', symbol: '€', flag: '🇪🇺' },
  { code: 'YER', name: 'ريال يمني', symbol: '﷼', flag: '🇾🇪' },
  { code: 'SAR', name: 'ريال سعودي', symbol: '﷼', flag: '🇸🇦' },
  { code: 'AED', name: 'درهم إماراتي', symbol: 'د.إ', flag: '🇦🇪' },
  { code: 'EGP', name: 'جنيه مصري', symbol: 'ج.م', flag: '🇪🇬' },
  { code: 'KWD', name: 'دينار كويتي', symbol: 'د.ك', flag: '🇰🇼' },
  { code: 'BHD', name: 'دينار بحريني', symbol: 'د.ب', flag: '🇧🇭' },
  { code: 'OMR', name: 'ريال عماني', symbol: 'ر.ع.', flag: '🇴🇲' },
  { code: 'QAR', name: 'ريال قطري', symbol: 'ر.ق', flag: '🇶🇦' },
  { code: 'GBP', name: 'جنيه إسترليني', symbol: '£', flag: '🇬🇧' },
  { code: 'JPY', name: 'ين ياباني', symbol: '¥', flag: '🇯🇵' }
];

export const custom_exchange_rates: Record<string, number> = (() => {
  try {
    const saved = safeStorage.getItem('custom_exchange_rates');
    return saved ? JSON.parse(saved) : {};
  } catch {
    return {};
  }
})();

if (typeof window !== 'undefined') {
  (window as any).custom_exchange_rates = custom_exchange_rates;
}

export class CurrencyService {
  // رابط واجهة بيانات أسعار الصرف الرسمية كمصدر أولي وثانوي بديل
  private static OXR_API_URL = 'https://openexchangerates.org/api/latest.json';

  /**
   * جلب أسعار الصرف من Open Exchange Rates وإعادة حسابها بناءً على العملة الأساسية للمنشأة
   * مع دمج مصفوفة التعديلات والمحددات اليدوية المحلية التي تمنح المحاسب اليد العليا فوراً
   */
  public static async fetchIMFRates(baseCurrency: string): Promise<Record<string, number>> {
    try {
      const appId = (import.meta as any).env?.VITE_OPEN_EXCHANGE_RATES_APP_ID || '';
      let response;
      
      try {
        response = await axios.get(`${this.OXR_API_URL}${appId ? `?app_id=${appId}` : ''}`);
      } catch (err) {
        console.warn('Open Exchange Rates direct query failed or returned unauthorized. Falling back to public Er-Api fallback oracle...');
        response = await axios.get('https://open.er-api.com/v6/latest/USD');
      }

      const rates = response.data?.rates || response.data?.rates_by_base || response.data?.conversion_rates;
      if (!rates || typeof rates !== 'object') {
        throw new Error('Oracle payload is missing structured currency mappings.');
      }

      const calibratedRates: Record<string, number> = {};
      const baseValue = parseFloat(rates[baseCurrency]) || 1.0;

      Object.keys(rates).forEach((code) => {
        calibratedRates[code] = parseFloat(rates[code]) / baseValue;
      });

      // تثبيت العملة الأساسية لتساوي 1 دائماً
      calibratedRates[baseCurrency] = 1.0;

      // تطبيق التجاوزات اليدوية المحلية فوراً لضمان السيادة المطلقة للمشغل البشري
      Object.keys(custom_exchange_rates).forEach((code) => {
        const localOverride = custom_exchange_rates[code];
        if (localOverride !== undefined && !isNaN(localOverride) && localOverride > 0) {
          calibratedRates[code] = localOverride;
        }
      });

      return calibratedRates;
    } catch (error) {
      console.warn('Oracle Engine Status: Operating with standby baseline values.', error);
      // Fallback الاحتياطي لضمان عدم توقف الفواتير والقيود
      const standbyRates: Record<string, number> = { 'USD': 1.0, 'EUR': 0.92, 'SAR': 3.75, 'YER': 250.0, 'AED': 3.67, 'EGP': 47.0 };
      const calibrated: Record<string, number> = {};
      const baseValue = standbyRates[baseCurrency] || 1.0;
      
      Object.keys(standbyRates).forEach((code) => {
        calibrated[code] = standbyRates[code] / baseValue;
      });
      calibrated[baseCurrency] = 1.0;

      // دمج التجاوزات اليدوية في وضع الطوارئ أيضاً
      Object.keys(custom_exchange_rates).forEach((code) => {
        const localOverride = custom_exchange_rates[code];
        if (localOverride !== undefined && !isNaN(localOverride) && localOverride > 0) {
          calibrated[code] = localOverride;
        }
      });

      return calibrated;
    }
  }

  /**
   * تحويل مبلغ مالي من عملة المعاملة الحالية (Invoice/Bill) إلى العملة الأساسية للقيد الدفتري
   */
  public static convertToBase(amount: number, fromCurrencyRate: number): number {
    if (fromCurrencyRate <= 0) return amount;
    return amount / fromCurrencyRate;
  }

  /**
   * تحديث السعر الفعلي المخصص
   */
  public static saveCustomRate(currencyCode: string, rate: number | undefined) {
    if (rate === undefined || isNaN(rate) || rate <= 0) {
      delete custom_exchange_rates[currencyCode];
    } else {
      custom_exchange_rates[currencyCode] = rate;
    }
    try {
      safeStorage.setItem('custom_exchange_rates', JSON.stringify(custom_exchange_rates));
    } catch (e) {
      console.error(e);
    }
  }
}
