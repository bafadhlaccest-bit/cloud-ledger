import { supabase } from '../lib/supabase';

/**
 * دالة استدعاء وتجميع التقارير ديناميكياً من شجرة الحسابات والقيود
 */
export async function getFinancialStatements(companyId: string) {
  try {
    // 1. استدعاء الدالة التجميعية (RPC) التي تجمع حركات القيود لكل حساب في السيرفر
    const { data: dbRows, error } = await supabase
      .rpc('get_account_balances_v1', { target_company_id: companyId });

    if (error) {
      console.error("خطأ في جلب أرصدة الحسابات التراكمية:", error.message);
      return null;
    }

    const rows = (dbRows as any[]) || [];

    // ----------------------------------------------------------------
    // 2. معالجة حسابات قائمة الدخل (الأرباح والخسائر) طبقاً للمعايير الدولية
    // ----------------------------------------------------------------
    
    // إيراد النشاط: حسابات الـ REVENUE (الدائن - المدين)
    const operatingRevenue = rows
      .filter(r => r.classification === 'REVENUE')
      .reduce((sum, r) => sum + (Number(r.total_credit) - Number(r.total_debit)), 0);

    // تكلفة المبيعات: حسابات الـ COGS (المدين - الدائن)
    const costOfGoodsSold = rows
      .filter(r => r.classification === 'COGS')
      .reduce((sum, r) => sum + (Number(r.total_debit) - Number(r.total_credit)), 0);

    // مجمل الربح = إيراد النشاط - تكلفة المبيعات
    const grossProfit = operatingRevenue - costOfGoodsSold;

    // المصاريف التشغيلية والعمومية (المدين - الدائن)
    const operatingExpenses = rows
      .filter(r => r.classification === 'EXPENSES')
      .reduce((sum, r) => sum + (Number(r.total_debit) - Number(r.total_credit)), 0);

    // الإيرادات الأخرى (الدائن - المدين)
    const otherIncome = rows
      .filter(r => r.classification === 'OTHER_INCOME')
      .reduce((sum, r) => sum + (Number(r.total_credit) - Number(r.total_debit)), 0);

    // صافي الربح أو الخسارة النهائي للفترة
    const netProfitOrLoss = grossProfit - operatingExpenses + otherIncome;


    // ----------------------------------------------------------------
    // 3. معالجة حسابات المركز المالي (الميزانية العمومية) طبقاً للمعايير الدولية
    // ----------------------------------------------------------------
    
    // إجمالي الأصول: حسابات الـ ASSETS (المدين - الدائن) مثل الصندوق والعملاء
    const totalAssets = rows
      .filter(r => r.classification === 'ASSETS')
      .reduce((sum, r) => sum + (Number(r.total_debit) - Number(r.total_credit)), 0);

    // إجمالي الالتزامات: حسابات الـ LIABILITIES (الدائن - المدين) مثل الموردين
    const totalLiabilities = rows
      .filter(r => r.classification === 'LIABILITIES')
      .reduce((sum, r) => sum + (Number(r.total_credit) - Number(r.total_debit)), 0);

    // حقوق الملكية الأساسية من الشجرة (مثل رأس المال المدفوع)
    const baseEquity = rows
      .filter(r => r.classification === 'EQUITY')
      .reduce((sum, r) => sum + (Number(r.total_credit) - Number(r.total_debit)), 0);

    // إجمالي حقوق الملكية = رأس المال + الأرباح المبقاة (صافي ربح الفترة الحالية ديناميكياً)
    const totalEquity = baseEquity + netProfitOrLoss;


    // ----------------------------------------------------------------
    // 4. تصدر البيانات جاهزة وموزونة بالكامل لواجهة المستخدم (UI)
    // ----------------------------------------------------------------
    return {
      incomeStatement: {
        operatingRevenue,
        costOfGoodsSold,
        grossProfit,
        operatingExpenses,
        otherIncome,
        netProfitOrLoss
      },
      balanceSheet: {
        totalAssets,
        totalLiabilities,
        totalEquity,
        retainedEarnings: netProfitOrLoss,
        // فحص توازن الميزانية (صمام أمان النظام)
        isBalanced: Math.abs(totalAssets - (totalLiabilities + totalEquity)) < 0.01
      },
      rawBalances: rows // أسطر الحسابات الفردية لعرضها في الجدول المباشر
    };

  } catch (err) {
    console.error("فشل تجميع التقارير المالية:", err);
    return null;
  }
}

export async function loadFinancialReports(companyId: string) {
  try {
    const { data: dbRows, error } = await supabase
      .rpc('get_account_balances_v1', { target_company_id: companyId });

    if (error) throw error;

    // 🔴 سطر الفحص المؤقت: سيطبع لك البيانات القادمة من Supabase في الـ Console
    console.log("البيانات الفعلية القادمة من السوبابيس:", dbRows);

    if (!dbRows || dbRows.length === 0) {
      console.warn("تحذير: قاعدة البيانات متصلة ولكن الجداول فارغة، يرجى التحقق من إدخال الحسابات!");
    }

    const rows = (dbRows as any[]) || [];

    // ----------------------------------------------------------------
    // 2. معالجة حسابات قائمة الدخل (الأرباح والخسائر) طبقاً للمعايير الدولية
    // ----------------------------------------------------------------
    
    // إيراد النشاط: حسابات الـ REVENUE (الدائن - المدين)
    const operatingRevenue = rows
      .filter(r => r.classification === 'REVENUE')
      .reduce((sum, r) => sum + (Number(r.total_credit) - Number(r.total_debit)), 0);

    // تكلفة المبيعات: حسابات الـ COGS (المدين - الدائن)
    const costOfGoodsSold = rows
      .filter(r => r.classification === 'COGS')
      .reduce((sum, r) => sum + (Number(r.total_debit) - Number(r.total_credit)), 0);

    // مجمل الربح = إيراد النشاط - تكلفة المبيعات
    const grossProfit = operatingRevenue - costOfGoodsSold;

    // المصاريف التشغيلية والعمومية (المدين - الدائن)
    const operatingExpenses = rows
      .filter(r => r.classification === 'EXPENSES')
      .reduce((sum, r) => sum + (Number(r.total_debit) - Number(r.total_credit)), 0);

    // الإيرادات الأخرى (الدائن - المدين)
    const otherIncome = rows
      .filter(r => r.classification === 'OTHER_INCOME')
      .reduce((sum, r) => sum + (Number(r.total_credit) - Number(r.total_debit)), 0);

    // صافي الربح أو الخسارة النهائي للفترة
    const netProfitOrLoss = grossProfit - operatingExpenses + otherIncome;


    // ----------------------------------------------------------------
    // 3. معالجة حسابات المركز المالي (الميزانية العمومية) طبقاً للمعايير الدولية
    // ----------------------------------------------------------------
    
    // إجمالي الأصول: حسابات الـ ASSETS (المدين - الدائن) مثل الصندوق والعملاء
    const totalAssets = rows
      .filter(r => r.classification === 'ASSETS')
      .reduce((sum, r) => sum + (Number(r.total_debit) - Number(r.total_credit)), 0);

    // إجمالي الالتزامات: حسابات الـ LIABILITIES (الدائن - المدين) مثل الموردين
    const totalLiabilities = rows
      .filter(r => r.classification === 'LIABILITIES')
      .reduce((sum, r) => sum + (Number(r.total_credit) - Number(r.total_debit)), 0);

    // حقوق الملكية الأساسية من الشجرة (مثل رأس المال المدفوع)
    const baseEquity = rows
      .filter(r => r.classification === 'EQUITY')
      .reduce((sum, r) => sum + (Number(r.total_credit) - Number(r.total_debit)), 0);

    // إجمالي حقوق الملكية = رأس المال + الأرباح المبقاة (صافي ربح الفترة الحالية ديناميكياً)
    const totalEquity = baseEquity + netProfitOrLoss;


    // ----------------------------------------------------------------
    // 4. تصدير البيانات جاهزة وموزونة بالكامل لواجهة المستخدم (UI)
    // ----------------------------------------------------------------
    return {
      incomeStatement: {
        operatingRevenue,
        costOfGoodsSold,
        grossProfit,
        operatingExpenses,
        otherIncome,
        netProfitOrLoss
      },
      balanceSheet: {
        totalAssets,
        totalLiabilities,
        totalEquity,
        retainedEarnings: netProfitOrLoss,
        // فحص توازن الميزانية (صمام أمان النظام)
        isBalanced: Math.abs(totalAssets - (totalLiabilities + totalEquity)) < 0.01
      },
      rawBalances: rows // أسطر الحسابات الفردية لعرضها في الجدول المباشر
    };

  } catch (err) {
    console.error("فشل تجميع التقارير المالية:", err);
    return null;
  }
}

export async function fetchInternationalReports(companyId: string) {
  const result = await getFinancialStatements(companyId);
  if (!result) return null;
  return {
    incomeStatement: {
      operatingRevenue: result.incomeStatement.operatingRevenue,
      costOfGoodsSold: result.incomeStatement.costOfGoodsSold,
      netProfitOrLoss: result.incomeStatement.netProfitOrLoss
    },
    balanceSheet: {
      totalAssets: result.balanceSheet.totalAssets,
      totalLiabilities: result.balanceSheet.totalLiabilities,
      totalEquity: result.balanceSheet.totalEquity,
      isBalanced: result.balanceSheet.isBalanced
    }
  };
}

/**
 * دالة حذف عنصر (سواءً قيد، فاتورة، أو حساب) من قاعدة بيانات سوبابيس
 */
export async function handleDeleteItem(tableName: string, itemId: string, updateStateCallback: () => void) {
  const confirmDelete = window.confirm("هل أنت متأكد من رغبتك في حذف هذا العنصر نهائياً؟");
  if (!confirmDelete) return;

  try {
    const { error } = await supabase
      .from(tableName)
      .delete()
      .eq('id', itemId);

    if (error) throw error;

    // تحديث الشاشة فوراً بعد الحذف الناجح
    updateStateCallback();
    alert("تم الحذف بنجاح من قاعدة البيانات.");
  } catch (err: any) {
    console.error("فشل عملية الحذف:", err.message);
    alert(`عذراً، لا يمكن الحذف: ${err.message}`);
  }
}

/**
 * دالة حذف قيد يومية نهائياً من قاعدة بيانات سوبابيس
 */
export async function deleteJournalEntry(entryId: string, refreshUI: () => void) {
  // بدلاً من الـ alert التقليدي، استخدم رسالة تأكيد احترافية
  const isConfirmed = window.confirm("هل أنت متأكد من حذف هذا القيد نهائياً؟");
  if (!isConfirmed) return;

  const { error } = await supabase
    .from('journal_entries')
    .delete()
    .eq('id', entryId);

  if (error) {
    console.error("فشل الحذف:", error.message);
  } else {
    // استدعاء دالة تحديث الشاشة فوراً ليختفي السطر أمامك
    refreshUI(); 
  }
}
