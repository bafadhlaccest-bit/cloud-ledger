// src/utils/secureDelete.ts
import { db, collection, getDocs, getDoc, deleteDoc, query, where, doc } from '../firebase';

interface DeleteValidationParams {
  itemId: string;
  targetCollection: 'contacts' | 'invoices' | 'purchaseBills' | 'products';
  companyId: string;
}

export interface SecurityCheckResult {
  success: boolean;
  reason?: 'INTEGRITY_VIOLATION' | 'STOCK_MOVEMENTS_EXIST' | 'DOCUMENT_ALREADY_POSTED' | 'USER_CANCELLED' | 'ERROR';
  error?: string;
  message?: string;
}

/**
 * Executes a safe secure delete cascade protecting the accounting ledger,
 * validating foreign key structures, and ledger closing constraints across the system.
 */
export const executeSafeSecureDelete = async ({ 
  itemId, 
  targetCollection, 
  companyId 
}: DeleteValidationParams): Promise<SecurityCheckResult> => {
  try {
    // 1. If entity is a Customer or Vendor (Contact)
    if (targetCollection === 'contacts') {
      const invoicesQuery = query(
        collection(db, 'invoices'),
        where('companyId', '==', companyId),
        where('contactId', '==', itemId)
      );
      const querySnapshot = await getDocs(invoicesQuery);
      
      if (!querySnapshot.empty) {
        const errorMsg = "🚨 حظر أمني محاسبي: لا يمكن حذف هذا العميل/المورد لارتباطه بفواتير قيود مالية سابقة في النظام!";
        if (typeof window !== 'undefined') {
          alert(errorMsg);
        }
        return { 
          success: false, 
          reason: 'INTEGRITY_VIOLATION', 
          message: errorMsg 
        };
      }
    }

    // 2. If entity is an Inventory Item (Product)
    if (targetCollection === 'products') {
      const movementsQuery = query(
        collection(db, 'stockMovements'),
        where('productId', '==', itemId)
      );
      const querySnapshot = await getDocs(movementsQuery);
      
      if (!querySnapshot.empty) {
        const errorMsg = "🚨 حظر مخزني: الصنف مقيد بحركات جرد ومخازن (وارد/صادر)، حذفه يكسر دقة تقييم تكلفة المخزون!";
        if (typeof window !== 'undefined') {
          alert(errorMsg);
        }
        return { 
          success: false, 
          reason: 'STOCK_MOVEMENTS_EXIST', 
          message: errorMsg 
        };
      }
    }

    // 3. If entity is a Sales Invoice or Purchase Bill (Invoices/Bills)
    if (targetCollection === 'invoices' || targetCollection === 'purchaseBills') {
      // Fetch document to examine its posting and validation status
      const docRef = doc(db, targetCollection, itemId);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const docData = docSnap.data();
        const status = (docData.status || '').toUpperCase();
        if (status === 'POSTED' || status === 'APPROVED') {
          const errorMsg = "🚨 حماية القانون المحاسبي الدفتري: لا يمكن حذف فاتورة تم ترحيلها واعتماد قيدها المركب! يرجى إصدار إشعار تسوية عكسي (Storno).";
          if (typeof window !== 'undefined') {
            alert(errorMsg);
          }
          return { 
            success: false, 
            reason: 'DOCUMENT_ALREADY_POSTED', 
            message: errorMsg 
          };
        }
      }
    }

    // If all security and ledger integrity validations pass
    let confirmed = true;
    if (typeof window !== 'undefined') {
      confirmed = window.confirm("هل أنت متأكد من تنفيذ أمر الحذف النهائي لهذا السجل؟");
    }

    if (confirmed) {
      await deleteDoc(doc(db, targetCollection, itemId));
      const successMsg = "✅ تم الحذف وتحديث الجداول بنجاح.";
      if (typeof window !== 'undefined') {
        alert(successMsg);
      }
      return { success: true, message: successMsg };
    }
    
    return { success: false, reason: 'USER_CANCELLED', message: 'User aborted the deletion.' };
  } catch (error: any) {
    console.error("🚨 Error executing secure delete cascade:", error);
    const failMsg = `فشل تحميل وتنفيذ العملية: ${error.message}`;
    if (typeof window !== 'undefined') {
      alert(failMsg);
    }
    return { success: false, reason: 'ERROR', error: error.message, message: failMsg };
  }
};
