// Local Offline IndexedDB Schema & Database Manager
const DB_NAME = 'ErpOfflineDB';
const DB_VERSION = 2;

export interface OfflineTransaction {
  id: string; // fallback matching UUID
  payload: any;
  type: 'sale_invoice' | 'purchase_bill' | 'journal_entry';
  createdAt: string;
  sync_status: 'PENDING' | 'SYNCED';
}

function getIndexedDB(): IDBFactory | null {
  try {
    if (typeof window === 'undefined') return null;
    const idb = window.indexedDB || (window as any).mozIndexedDB || (window as any).webkitIndexedDB || (window as any).msIndexedDB;
    if (!idb) return null;
    return idb;
  } catch (e) {
    return null;
  }
}

// Memory fallback to prevent SecurityErrors in sandboxed iframe environments
const memoryStore: Record<string, OfflineTransaction[]> = {
  offline_sales_invoices: [],
  offline_purchase_bills: [],
  offline_journal_entries: []
};

function openDB(): Promise<IDBDatabase> {
  const idb = getIndexedDB();
  if (!idb) {
    return Promise.reject(new Error('IndexedDB is not supported or is blocked in this environment.'));
  }
  return new Promise((resolve, reject) => {
    try {
      const request = idb.open(DB_NAME, DB_VERSION);

      request.onerror = (e) => {
        console.warn('Failed to open offline IndexedDB:', e);
        reject(e);
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onupgradeneeded = (event) => {
        const db = request.result;
        
        // Mimicking core transactional database schemas
        if (!db.objectStoreNames.contains('offline_sales_invoices')) {
          db.createObjectStore('offline_sales_invoices', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('offline_purchase_bills')) {
          db.createObjectStore('offline_purchase_bills', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('offline_journal_entries')) {
          db.createObjectStore('offline_journal_entries', { keyPath: 'id' });
        }
      };
    } catch (e) {
      reject(e);
    }
  });
}

export const offlineDb = {
  /**
   * Save a record to IndexedDB
   */
  async saveRecord(
    storeName: 'offline_sales_invoices' | 'offline_purchase_bills' | 'offline_journal_entries',
    record: any
  ): Promise<void> {
    const item: OfflineTransaction = {
      id: record.id || `offline-${Math.random().toString(36).substr(2, 9)}`,
      payload: record,
      type: storeName === 'offline_sales_invoices' 
        ? 'sale_invoice' 
        : storeName === 'offline_purchase_bills' 
          ? 'purchase_bill' 
          : 'journal_entry',
      createdAt: new Date().toISOString(),
      sync_status: 'PENDING'
    };

    const idb = getIndexedDB();
    if (!idb) {
      memoryStore[storeName] = memoryStore[storeName].filter(x => x.id !== item.id);
      memoryStore[storeName].push(item);
      try {
        window.dispatchEvent(new CustomEvent('offline-db-updated'));
      } catch {}
      return;
    }

    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.put(item);

        request.onsuccess = () => {
          // Trigger a global custom event so header badges update instantly!
          try {
            window.dispatchEvent(new CustomEvent('offline-db-updated'));
          } catch {}
          resolve();
        };
        request.onerror = (e) => reject(e);
      });
    } catch (e) {
      console.warn('IndexedDB saveRecord fallback usage active:', e);
      memoryStore[storeName] = memoryStore[storeName].filter(x => x.id !== item.id);
      memoryStore[storeName].push(item);
      try {
        window.dispatchEvent(new CustomEvent('offline-db-updated'));
      } catch {}
    }
  },

  /**
   * Fetch all pending records from a specific store
   */
  async getPendingRecords(
    storeName: 'offline_sales_invoices' | 'offline_purchase_bills' | 'offline_journal_entries'
  ): Promise<OfflineTransaction[]> {
    const idb = getIndexedDB();
    if (!idb) {
      return memoryStore[storeName].filter((x: OfflineTransaction) => x.sync_status === 'PENDING');
    }

    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, 'readonly');
        const store = transaction.objectStore(storeName);
        const request = store.getAll();

        request.onsuccess = () => {
          const all = request.result || [];
          resolve(all.filter((x: OfflineTransaction) => x.sync_status === 'PENDING'));
        };
        request.onerror = (e) => reject(e);
      });
    } catch (e) {
      console.warn('IndexedDB getPendingRecords fallback usage active:', e);
      return memoryStore[storeName].filter((x: OfflineTransaction) => x.sync_status === 'PENDING');
    }
  },

  /**
   * Remove a synced record cleanly or update status to SYNCED
   */
  async removeRecord(
    storeName: 'offline_sales_invoices' | 'offline_purchase_bills' | 'offline_journal_entries',
    id: string
  ): Promise<void> {
    const idb = getIndexedDB();
    if (!idb) {
      memoryStore[storeName] = memoryStore[storeName].filter(x => x.id !== id);
      try {
        window.dispatchEvent(new CustomEvent('offline-db-updated'));
      } catch {}
      return;
    }

    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.delete(id);

        request.onsuccess = () => {
          try {
            window.dispatchEvent(new CustomEvent('offline-db-updated'));
          } catch {}
          resolve();
        };
        request.onerror = (e) => reject(e);
      });
    } catch (e) {
      console.warn('IndexedDB removeRecord fallback usage active:', e);
      memoryStore[storeName] = memoryStore[storeName].filter(x => x.id !== id);
      try {
        window.dispatchEvent(new CustomEvent('offline-db-updated'));
      } catch {}
    }
  },

  /**
   * Combined counter utility across all client-side offline tables
   */
  async countAllPending(): Promise<number> {
    try {
      const invoices = await this.getPendingRecords('offline_sales_invoices');
      const bills = await this.getPendingRecords('offline_purchase_bills');
      const journals = await this.getPendingRecords('offline_journal_entries');
      return invoices.length + bills.length + journals.length;
    } catch (e) {
      console.warn('Error counting pending records:', e);
      return 0;
    }
  }
};
