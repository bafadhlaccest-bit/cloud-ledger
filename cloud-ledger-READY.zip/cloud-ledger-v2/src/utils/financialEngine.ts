// src/utils/financialEngine.ts

export interface JournalLine {
  accountId: string;
  accountCode: string;
  accountName: string;
  ifrsMapping: string;
  debit: number;
  credit: number;
  currency: string;       // العملة الأصلية للقيد (مثال: USD, SAR)
  exchangeRate: number;   // سعر الصرف وقت إدخال القيد
}

export interface EnterpriseReportRow {
  accountId: string;
  accountCode: string;
  accountName: string;
  ifrsMapping: string;
  localDebit: number;     // بالعملة الرئيسية للنظام (YER مثلاً)
  localCredit: number;
  systemDebit: number;    // بعملة التقرير الموحدة (USD مثلاً)
  systemCredit: number;
  forexVariance: number;  // فروقات أسعار الصرف غير المحققة للسطر
}

/**
 * محرك التجميع الاحترافي للقوائم المالية مع حماية الفروقات الصرفية وتطابق المعايير الدولية
 */
export function processEnterpriseLedger(
  journalLines: JournalLine[],
  systemTargetCurrency: string,
  currentMarketRates: Record<string, number> // أسعار الصرف الحركية اليومية المحدثة آلياً
): EnterpriseReportRow[] {
  
  const reportRows: Record<string, EnterpriseReportRow> = {};

  journalLines.forEach((line) => {
    const accId = line.accountId;
    
    if (!reportRows[accId]) {
      reportRows[accId] = {
        accountId: accId,
        accountCode: line.accountCode,
        accountName: line.accountName,
        ifrsMapping: line.ifrsMapping,
        localDebit: 0,
        localCredit: 0,
        systemDebit: 0,
        systemCredit: 0,
        forexVariance: 0,
      };
    }

    // 1. القيمة بالعملة المحلية التاريخية (كما سُجلت في القيد)
    const originalDebit = Number(line.debit) || 0;
    const originalCredit = Number(line.credit) || 0;
    const historicalRate = Number(line.exchangeRate) || 1;

    const localDebitValue = line.currency === systemTargetCurrency ? originalDebit : originalDebit * historicalRate;
    const localCreditValue = line.currency === systemTargetCurrency ? originalCredit : originalCredit * historicalRate;

    reportRows[accId].localDebit += localDebitValue;
    reportRows[accId].localCredit += localCreditValue;

    // 2. إعادة التقييم الفوري بحسب أسعار الصرف الحالية لإظهار فروقات الصرف الحقيقية
    const currentRate = currentMarketRates[line.currency] || historicalRate;
    const dynamicSystemDebit = line.currency === systemTargetCurrency ? originalDebit : originalDebit * currentRate;
    const dynamicSystemCredit = line.currency === systemTargetCurrency ? originalCredit : originalCredit * currentRate;

    reportRows[accId].systemDebit += dynamicSystemDebit;
    reportRows[accId].systemCredit += dynamicSystemCredit;

    // 3. احتساب فارق الصرف (Forex Variance) لحماية الحسابات من التضخم ونهب القيمة
    const debitDiff = dynamicSystemDebit - localDebitValue;
    const creditDiff = dynamicSystemCredit - localCreditValue;
    reportRows[accId].forexVariance += (debitDiff - creditDiff);
  });

  return Object.values(reportRows);
}
