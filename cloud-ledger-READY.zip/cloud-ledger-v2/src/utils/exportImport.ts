import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { db, collection, addDoc, serverTimestamp, doc } from '../firebase';

// Define standard headers and samples for standard modules
export interface ModuleSchema {
  id: string;
  name: string;
  collectionName: string;
  headers: string[];
  sampleRows: Record<string, any>[];
  validators: (row: any, index: number, existing: any[]) => string | null;
  transform: (row: any) => Record<string, any>;
}

export const MODULE_SCHEMAS: Record<string, ModuleSchema> = {
  accounts: {
    id: 'accounts',
    name: 'Chart of Accounts',
    collectionName: 'accounts',
    headers: ['Code', 'Account Name', 'Account Type', 'Description'],
    sampleRows: [
      { 'Code': '110103', 'Account Name': 'Yemen International Cash Fund', 'Account Type': 'Asset', 'Description': 'Central Treasury Box Sanaa main branch' },
      { 'Code': '210102', 'Account Name': 'Tadhamon Supplier Payables', 'Account Type': 'Liability', 'Description': 'Vendor balances for raw materials' },
      { 'Code': '510105', 'Account Name': 'Aden Warehouse Port Logistical Expenses', 'Account Type': 'Expense', 'Description': 'Shipping tax and logistics' }
    ],
    validators: (row, index, existing) => {
      const code = String(row['Code'] || '').trim();
      const name = String(row['Account Name'] || '').trim();
      const type = String(row['Account Type'] || '').trim();
      
      if (!code) return `Row ${index + 1}: Account Code is required.`;
      if (!name) return `Row ${index + 1}: Account Name is required.`;
      if (!type) return `Row ${index + 1}: Account Type is required.`;
      
      const allowedTypes = ['Asset', 'Liability', 'Equity', 'Income', 'Expense', 'Revenue', 'Expenses'];
      const normalizedType = allowedTypes.find(t => t.toLowerCase() === type.toLowerCase());
      if (!normalizedType) {
        return `Row ${index + 1}: Invalid Account Type "${type}". Must be one of: ${allowedTypes.join(', ')}.`;
      }
      
      // Check code format (must be numeric digits or letters, sensible length)
      if (!/^[a-zA-Z0-9_\-]+$/.test(code)) {
        return `Row ${index + 1}: Code contains invalid characters. Pattern supported: a-z, 0-9, dashes.`;
      }
      
      // Check existing accounts for code collision
      const dupeInExisting = existing?.some(e => String(e.code) === code);
      if (dupeInExisting) {
        return `Row ${index + 1}: Code "${code}" is already in use by another Account in the system.`;
      }
      return null;
    },
    transform: (row) => ({
      code: String(row['Code'] || '').trim(),
      name: String(row['Account Name'] || '').trim(),
      type: String(row['Account Type'] || '').trim(),
      description: String(row['Description'] || '').trim(),
      parentId: 'root',
      balance: 0,
      status: 'active',
      companyId: companyId
    })
  },
  customers: {
    id: 'customers',
    name: 'Customers',
    collectionName: 'customers',
    headers: ['Name', 'Email', 'Phone', 'Tax Number', 'Street Address', 'City'],
    sampleRows: [
      { 'Name': 'Saba Food Industries Co.', 'Email': 'finance@sabafoods.com', 'Phone': '+9671444222', 'Tax Number': '399432', 'Street Address': '60 Meter Road', 'City': 'Sana\'a' },
      { 'Name': 'Ahmed Saeed General Trading', 'Email': 'ahmed.saeed@gmail.com', 'Phone': '+967771234567', 'Tax Number': '201994', 'Street Address': 'Al-Minaa Boulevard', 'City': 'Aden' }
    ],
    validators: (row, index) => {
      const name = String(row['Name'] || '').trim();
      if (!name) return `Row ${index + 1}: Customer Name is required.`;
      
      const email = String(row['Email'] || '').trim();
      if (email && !email.includes('@')) {
        return `Row ${index + 1}: Invalid email address syntax "${email}".`;
      }
      return null;
    },
    transform: (row) => ({
      name: String(row['Name'] || '').trim(),
      email: String(row['Email'] || '').trim(),
      phone: String(row['Phone'] || '').trim(),
      taxNumber: String(row['Tax Number'] || '').trim(),
      streetAddress: String(row['Street Address'] || '').trim(),
      city: String(row['City'] || '').trim(),
      balance: 0,
      status: 'active',
      currencies: ['YER', 'USD'],
      country: 'Yemen',
      countryId: 'yem',
      companyId: companyId
    })
  },
  vendors: {
    id: 'vendors',
    name: 'Vendors',
    collectionName: 'vendors',
    headers: ['Name', 'Email', 'Phone', 'Tax Number', 'Street Address', 'City'],
    sampleRows: [
      { 'Name': 'Tehama Import & Logistics Ltd', 'Email': 'logistics@tehama.net', 'Phone': '+9673244111', 'Tax Number': '58122', 'Street Address': 'Al-Huraish Street', 'City': 'Al-Hudaydah' },
      { 'Name': 'Yemen General Oil Refinery', 'Email': 'procurement@ygoref.gov.ye', 'Phone': '+9672202020', 'Tax Number': '1554', 'Street Address': 'Aden Refinery Complex', 'City': 'Aden' }
    ],
    validators: (row, index) => {
      const name = String(row['Name'] || '').trim();
      if (!name) return `Row ${index + 1}: Vendor Name is required.`;
      
      const email = String(row['Email'] || '').trim();
      if (email && !email.includes('@')) {
        return `Row ${index + 1}: Invalid email address syntax "${email}".`;
      }
      return null;
    },
    transform: (row) => ({
      name: String(row['Name'] || '').trim(),
      email: String(row['Email'] || '').trim(),
      phone: String(row['Phone'] || '').trim(),
      taxNumber: String(row['Tax Number'] || '').trim(),
      streetAddress: String(row['Street Address'] || '').trim(),
      city: String(row['City'] || '').trim(),
      balance: 0,
      status: 'active',
      currencies: ['YER', 'USD'],
      country: 'Yemen',
      countryId: 'yem',
      companyId: companyId
    })
  },
  items: {
    id: 'items',
    name: 'Catalog Items',
    collectionName: 'items',
    headers: ['Name', 'SKU', 'Product Type', 'Unit', 'Sales Price', 'Purchase Price', 'Stock On Hand'],
    sampleRows: [
      { 'Name': 'Standard Basmati Rice bag 10kg', 'SKU': 'ITM-BMR-10', 'Product Type': 'Storable', 'Unit': 'bag', 'Sales Price': 14500, 'Purchase Price': 12000, 'Stock On Hand': 350 },
      { 'Name': 'Vegetable sunflower Oil Cooking 5L', 'SKU': 'ITM-SOIL-5L', 'Product Type': 'Storable', 'Unit': 'can', 'Sales Price': 7200, 'Purchase Price': 5800, 'Stock On Hand': 180 },
      { 'Name': 'General Financial Audit Service', 'SKU': 'SRV-COA-AUDIT', 'Product Type': 'Service', 'Unit': 'Hour', 'Sales Price': 20000, 'Purchase Price': 0, 'Stock On Hand': 0 }
    ],
    validators: (row, index, existing) => {
      const name = String(row['Name'] || '').trim();
      const sku = String(row['SKU'] || '').trim();
      const salesPrice = Number(row['Sales Price'] || 0);
      const purchasePrice = Number(row['Purchase Price'] || 0);
      const stockOnHand = Number(row['Stock On Hand'] || 0);
      
      if (!name) return `Row ${index + 1}: Product Name is required.`;
      if (!sku) return `Row ${index + 1}: Product SKU is required.`;
      
      if (isNaN(salesPrice) || salesPrice < 0) return `Row ${index + 1}: Sales Price must be a positive number.`;
      if (isNaN(purchasePrice) || purchasePrice < 0) return `Row ${index + 1}: Purchase Price must be a positive number.`;
      if (isNaN(stockOnHand)) return `Row ${index + 1}: Stock On Hand must be a valid number.`;
      
      const dupeSKU = existing?.some(e => String(e.sku).toLowerCase() === sku.toLowerCase());
      if (dupeSKU) {
        return `Row ${index + 1}: SKU "${sku}" already exists in the system.`;
      }
      return null;
    },
    transform: (row) => ({
      name: String(row['Name'] || '').trim(),
      sku: String(row['SKU'] || '').trim(),
      type: String(row['Product Type'] || 'Product').toLowerCase().includes('service') ? 'Service' : 'Product',
      productType: String(row['Product Type'] || 'Storable'),
      unit: String(row['Unit'] || 'pcs').trim(),
      salesPrice: Number(row['Sales Price'] || 0),
      purchasePrice: Number(row['Purchase Price'] || 0),
      stockOnHand: Number(row['Stock On Hand'] || 0),
      invoicingPolicy: 'Ordered',
      routesBuy: true,
      routesMTO: false,
      traceability: 'None',
      weight: 0,
      volume: 0,
      customerLeadTime: 0,
      incomeAccountId: '',
      expenseAccountId: '',
      priceDiffAccountId: '',
      minReorderingQty: 0,
      maxReorderingQty: 0,
      reorderingEnabled: false,
      companyId: companyId
    })
  },
  invoices: {
    id: 'invoices',
    name: 'Sales Invoices',
    collectionName: 'invoices',
    headers: ['Invoice Number', 'Customer Name', 'Invoice Date', 'Due Date', 'Sub Total', 'Discount Percent', 'Shipping Charges', 'Total'],
    sampleRows: [
      { 'Invoice Number': 'INV/2026/0012', 'Customer Name': 'Saba Food Industries Co.', 'Invoice Date': '2026-06-01', 'Due Date': '2026-06-15', 'Sub Total': 250000, 'Discount Percent': 5, 'Shipping Charges': 12000, 'Total': 249500 },
      { 'Invoice Number': 'INV/2026/0013', 'Customer Name': 'Ahmed Saeed General Trading', 'Invoice Date': '2026-06-03', 'Due Date': '2026-06-30', 'Sub Total': 320000, 'Discount Percent': 0, 'Shipping Charges': 8500, 'Total': 328500 }
    ],
    validators: (row, index, existing) => {
      const num = String(row['Invoice Number'] || '').trim();
      const customer = String(row['Customer Name'] || '').trim();
      const total = Number(row['Total'] || 0);
      
      if (!num) return `Row ${index + 1}: Invoice Number is required.`;
      if (!customer) return `Row ${index + 1}: Customer Name is required.`;
      if (isNaN(total) || total < 0) return `Row ${index + 1}: Total must be a positive number.`;
      
      const dupeNum = existing?.some(e => String(e.number).toLowerCase() === num.toLowerCase());
      if (dupeNum) {
        return `Row ${index + 1}: Invoice Number "${num}" is already in use.`;
      }
      return null;
    },
    transform: (row) => ({
      number: String(row['Invoice Number'] || '').trim(),
      customerName: String(row['Customer Name'] || '').trim(),
      customerId: '', // Manual lookup on import placeholder
      date: String(row['Invoice Date'] || new Date().toISOString().split('T')[0]),
      dueDate: String(row['Due Date'] || new Date().toISOString().split('T')[0]),
      subTotal: Number(row['Sub Total'] || row['Total'] || 0),
      discountPercent: Number(row['Discount Percent'] || 0),
      shippingCharges: Number(row['Shipping Charges'] || 0),
      adjustment: 0,
      total: Number(row['Total'] || 0),
      status: 'Sent',
      customerNotes: 'Imported via bulk operations',
      termsConditions: 'Standard payment within terms.',
      companyId: companyId,
      items: [
        {
          itemId: 'imported',
          sku: 'SKU-GENERIC',
          name: 'Bulk imported aggregate line item',
          quantity: 1,
          rate: Number(row['Sub Total'] || row['Total'] || 0),
          taxPercent: 0,
          taxLabel: 'No Tax',
          amount: Number(row['Sub Total'] || row['Total'] || 0)
        }
      ]
    })
  },
  bills: {
    id: 'bills',
    name: 'Purchase Bills',
    collectionName: 'bills',
    headers: ['Bill Number', 'Vendor Name', 'Bill Date', 'Due Date', 'Total', 'Status'],
    sampleRows: [
      { 'Bill Number': 'BILL/2026/04', 'Vendor Name': 'Tehama Import & Logistics Ltd', 'Bill Date': '2026-05-18', 'Due Date': '2026-06-18', 'Total': 1420000, 'Status': 'Unpaid' },
      { 'Bill Number': 'BILL/2026/05', 'Vendor Name': 'Yemen General Oil Refinery', 'Bill Date': '2026-05-20', 'Due Date': '2026-06-20', 'Total': 5800000, 'Status': 'Paid' }
    ],
    validators: (row, index, existing) => {
      const num = String(row['Bill Number'] || '').trim();
      const vendorName = String(row['Vendor Name'] || '').trim();
      const total = Number(row['Total'] || 0);
      
      if (!num) return `Row ${index + 1}: Bill Number is required.`;
      if (!vendorName) return `Row ${index + 1}: Vendor Name is required.`;
      if (isNaN(total) || total < 0) return `Row ${index + 1}: Total must be a positive number.`;
      
      const dupe = existing?.some(e => String(e.number).toLowerCase() === num.toLowerCase());
      if (dupe) {
        return `Row ${index + 1}: Bill Number "${num}" is already in use.`;
      }
      return null;
    },
    transform: (row) => ({
      number: String(row['Bill Number'] || '').trim(),
      vendorName: String(row['Vendor Name'] || '').trim(),
      vendorId: '',
      date: String(row['Bill Date'] || new Date().toISOString().split('T')[0]),
      dueDate: String(row['Due Date'] || new Date().toISOString().split('T')[0]),
      shippingCharges: 0,
      adjustment: 0,
      total: Number(row['Total'] || 0),
      status: String(row['Status'] || 'Unpaid'),
      customerNotes: 'Imported invoice bill balance',
      termsConditions: 'Imported record',
      companyId: companyId,
      items: [
        {
          itemId: 'imported',
          sku: 'SKU-GENERIC',
          name: 'Bulk imported expense balance',
          quantity: 1,
          rate: Number(row['Total'] || 0),
          taxPercent: 0,
          taxLabel: 'No Tax',
          amount: Number(row['Total'] || 0)
        }
      ]
    })
  },
  journalEntries: {
    id: 'journalEntries',
    name: 'Manual Journals',
    collectionName: 'journalEntries',
    headers: ['Reference', 'Date', 'Description', 'Total Debit', 'Total Credit', 'Status'],
    sampleRows: [
      { 'Reference': 'JE-2026-MAY-01', 'Date': '2026-05-15', 'Description': 'Monthly office space adjustment', 'Total Debit': 850000, 'Total Credit': 850000, 'Status': 'Posted' },
      { 'Reference': 'JE-2026-MAY-02', 'Date': '2026-05-18', 'Description': 'Amortization calculation', 'Total Debit': 120000, 'Total Credit': 120000, 'Status': 'Draft' }
    ],
    validators: (row, index, existing) => {
      const ref = String(row['Reference'] || '').trim();
      const debit = Number(row['Total Debit'] || 0);
      const credit = Number(row['Total Credit'] || 0);
      
      if (!ref) return `Row ${index + 1}: Journal Reference is required.`;
      if (Math.abs(debit - credit) > 0.001) return `Row ${index + 1}: Journal entry must be balanced! Total Debit (${debit}) must equal Total Credit (${credit}).`;
      
      const dupe = existing?.some(e => String(e.reference).toLowerCase() === ref.toLowerCase());
      if (dupe) {
        return `Row ${index + 1}: Reference "${ref}" already exists in journals database.`;
      }
      return null;
    },
    transform: (row) => {
      const dt = Number(row['Total Debit'] || 0);
      const cr = Number(row['Total Credit'] || 0);
      return {
        reference: String(row['Reference'] || '').trim(),
        date: String(row['Date'] || new Date().toISOString().split('T')[0]),
        description: String(row['Description'] || 'Bulk imported manual journal entry').trim(),
        totalDebit: dt,
        totalCredit: cr,
        status: String(row['Status'] || 'Draft'),
        taxTreatment: 'NoTax',
        autoReverse: false,
        companyId: companyId,
        lines: [
          {
            accountId: 'imported_debit_place',
            accountName: 'Undefined Asset Asset Block',
            accountCode: '1000',
            debit: dt,
            credit: 0,
            description: String(row['Description'] || 'Imported debit leg').trim(),
            taxRate: 0,
            taxLabel: 'No Tax',
            region: 'Sanaa',
            department: 'Administration'
          },
          {
            accountId: 'imported_credit_place',
            accountName: 'Undefined Equity Offset Block',
            accountCode: '3000',
            debit: 0,
            credit: cr,
            description: String(row['Description'] || 'Imported credit leg').trim(),
            taxRate: 0,
            taxLabel: 'No Tax',
            region: 'Sanaa',
            department: 'Administration'
          }
        ]
      };
    }
  }
};

// Generates worksheet, packages, and downloads template excel
export function downloadExcelTemplate(moduleId: string) {
  const schema = MODULE_SCHEMAS[moduleId];
  if (!schema) {
    throw new Error(`Module ${moduleId} has no configured bulk import schema.`);
  }
  
  const ws = XLSX.utils.json_to_sheet(schema.sampleRows, { header: schema.headers });
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Sample Template");
  XLSX.writeFile(wb, `System_${moduleId}_Template.xlsx`);
}

// Exports UI grid rows directly to excel
export function exportToExcel(data: any[], colKeys: string[], colLabels: string[], fileName: string) {
  // Map raw keys to human-friendly Arabic/English column titles
  const formattedData = data.map(row => {
    const freshRow: Record<string, any> = {};
    colKeys.forEach((key, valIndex) => {
      freshRow[colLabels[valIndex]] = row[key] !== undefined ? row[key] : '';
    });
    return freshRow;
  });
  
  const ws = XLSX.utils.json_to_sheet(formattedData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
  XLSX.writeFile(wb, `${fileName}.xlsx`);
}

// Professional native print-layout PDF generator
export function exportToPDF(data: any[], colKeys: string[], colLabels: string[], title: string, fileName: string) {
  const doc = new jsPDF('l', 'mm', 'a4'); // Elegant wide Landscape format
  
  // Custom font styling
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text(title, 14, 18);
  
  // Small corporate info subtitle
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139); // slate-500
  doc.text(`Advanced Enterprise Cloud ERP System`, 14, 24);
  doc.text(`Extraction Timestamp: ${new Date().toLocaleString()} (UTC +3)`, 14, 29);
  
  // Draw top slate rule
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.setLineWidth(0.5);
  doc.line(14, 32, 283, 32); 
  
  // Prepare columns & rows
  const tableRows = data.map(row => colKeys.map(key => {
    const val = row[key];
    if (val === null || val === undefined) return '';
    if (typeof val === 'object') return JSON.stringify(val);
    return String(val);
  }));
  
  // AutoTable render
  autoTable(doc, {
    startY: 36,
    head: [colLabels],
    body: tableRows,
    theme: 'grid',
    styles: {
      fontSize: 8,
      cellPadding: 3,
      font: 'helvetica',
      textColor: [51, 65, 85]
    },
    headStyles: {
      fillColor: [15, 23, 42], // Slate dark
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 8.5
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252] // light background
    },
    margin: { left: 14, right: 14 },
    didDrawPage: (dt) => {
      // Elegant running absolute footer
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184); // slate-400
      doc.text(`Page ${dt.pageNumber} of standard deployment`, 14, doc.internal.pageSize.height - 10);
      doc.text(`Strictly Confidential / External Audit Document`, doc.internal.pageSize.width - 90, doc.internal.pageSize.height - 10);
    }
  });
  
  doc.save(`${fileName}.pdf`);
}
