class SafeStorage {
  private memoryStore: Record<string, string> = {};

  private hasStorage(): boolean {
    try {
      if (typeof window === 'undefined') return false;
      // Accessing 'localStorage' can throw SecurityError in sandbox, keep it secure in try
      const storage = window.localStorage;
      if (!storage) return false;
      const x = '__storage_test__';
      storage.setItem(x, x);
      storage.removeItem(x);
      return true;
    } catch (e) {
      return false;
    }
  }

  public getItem(key: string): string | null {
    try {
      if (this.hasStorage()) {
        return window.localStorage.getItem(key);
      }
    } catch (e) {
      // safe fallback
    }
    return this.memoryStore[key] || null;
  }

  public setItem(key: string, value: string): void {
    try {
      if (this.hasStorage()) {
        window.localStorage.setItem(key, value);
        return;
      }
    } catch (e) {
      // safe fallback
    }
    this.memoryStore[key] = value;
  }

  public removeItem(key: string): void {
    try {
      if (this.hasStorage()) {
        window.localStorage.removeItem(key);
        return;
      }
    } catch (e) {
      // safe fallback
    }
    delete this.memoryStore[key];
  }

  public clear(): void {
    try {
      if (this.hasStorage()) {
        window.localStorage.clear();
        return;
      }
    } catch (e) {
      // safe fallback
    }
    this.memoryStore = {};
  }
}

export const safeStorage = new SafeStorage();
