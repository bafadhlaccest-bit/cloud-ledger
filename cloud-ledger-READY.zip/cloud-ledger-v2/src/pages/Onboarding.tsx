import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, ChevronRight, BarChart3, Users, ShoppingCart, BookOpen, Sparkles, ArrowLeft } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useRBAC } from '../hooks/useRBAC';

const STEPS = [
  {
    id: 'welcome',
    title: 'مرحباً بك في Cloud Ledger',
    desc: 'نظام محاسبة سحابي متكامل للمنشآت الصغيرة والمتوسطة',
  },
  {
    id: 'accounts',
    title: 'دليل الحسابات',
    desc: 'سنُعدّ لك دليل حسابات جاهزاً وفق المعايير الدولية IFRS',
  },
  {
    id: 'modules',
    title: 'اختر الوحدات التي تحتاجها',
    desc: 'يمكنك تفعيل المزيد لاحقاً من الإعدادات',
  },
];

const CHART_TEMPLATES = [
  { id: 'trading',      label: 'شركة تجارية',         icon: '🏪', desc: 'مناسب للاستيراد والتصدير والبيع بالجملة' },
  { id: 'services',     label: 'شركة خدمات',           icon: '💼', desc: 'مناسب للمكاتب والشركات الاستشارية' },
  { id: 'restaurant',   label: 'مطاعم وأغذية',         icon: '🍽️', desc: 'مع تكاليف المواد الخام والتشغيل' },
  { id: 'construction', label: 'مقاولات وإنشاءات',     icon: '🏗️', desc: 'مع إدارة المشاريع والمراحل' },
  { id: 'blank',        label: 'دليل حسابات فارغ',    icon: '📋', desc: 'ابدأ من الصفر وأضف حساباتك' },
];

const MODULES = [
  { id: 'sales',     label: 'المبيعات والفواتير',    icon: <ShoppingCart className="w-5 h-5" />, required: true },
  { id: 'purchases', label: 'المشتريات والموردين',   icon: <BarChart3 className="w-5 h-5" />,    required: true },
  { id: 'banking',   label: 'البنوك والصندوق',       icon: <BookOpen className="w-5 h-5" />,     required: false },
  { id: 'inventory', label: 'إدارة المخزون',         icon: <Users className="w-5 h-5" />,        required: false },
  { id: 'ai',        label: 'المحاسب الذكي (AI)',    icon: <Sparkles className="w-5 h-5" />,     required: false },
];

// Default Chart of Accounts per template
const COA_SEEDS: Record<string, Array<{ code: string; name: string; type: string; ifrs_mapping: string }>> = {
  trading: [
    { code: '1000', name: 'الأصول',                      type: 'ASSET',     ifrs_mapping: '' },
    { code: '1100', name: 'الأصول المتداولة',              type: 'ASSET',     ifrs_mapping: 'CURRENT_ASSET' },
    { code: '1110', name: 'الصندوق',                     type: 'ASSET',     ifrs_mapping: 'CURRENT_ASSET' },
    { code: '1120', name: 'البنك',                       type: 'ASSET',     ifrs_mapping: 'CURRENT_ASSET' },
    { code: '1130', name: 'العملاء والذمم المدينة',       type: 'ASSET',     ifrs_mapping: 'CURRENT_ASSET' },
    { code: '1140', name: 'المخزون',                     type: 'ASSET',     ifrs_mapping: 'CURRENT_ASSET' },
    { code: '1200', name: 'الأصول الثابتة',               type: 'ASSET',     ifrs_mapping: 'NON_CURRENT_ASSET' },
    { code: '1210', name: 'معدات وأجهزة',                type: 'ASSET',     ifrs_mapping: 'NON_CURRENT_ASSET' },
    { code: '2000', name: 'المطلوبات',                   type: 'LIABILITY', ifrs_mapping: '' },
    { code: '2100', name: 'المطلوبات المتداولة',           type: 'LIABILITY', ifrs_mapping: 'CURRENT_LIAB' },
    { code: '2110', name: 'الموردون والذمم الدائنة',      type: 'LIABILITY', ifrs_mapping: 'CURRENT_LIAB' },
    { code: '2120', name: 'ضريبة القيمة المضافة',        type: 'LIABILITY', ifrs_mapping: 'CURRENT_LIAB' },
    { code: '2130', name: 'رواتب مستحقة',               type: 'LIABILITY', ifrs_mapping: 'CURRENT_LIAB' },
    { code: '3000', name: 'حقوق الملكية',               type: 'EQUITY',    ifrs_mapping: 'EQUITY' },
    { code: '3100', name: 'رأس المال',                  type: 'EQUITY',    ifrs_mapping: 'EQUITY' },
    { code: '3200', name: 'الأرباح المبقاة',             type: 'EQUITY',    ifrs_mapping: 'EQUITY' },
    { code: '4000', name: 'الإيرادات',                  type: 'REVENUE',   ifrs_mapping: 'REVENUE' },
    { code: '4100', name: 'إيرادات المبيعات',            type: 'REVENUE',   ifrs_mapping: 'REVENUE' },
    { code: '4200', name: 'إيرادات أخرى',               type: 'REVENUE',   ifrs_mapping: 'REVENUE' },
    { code: '5000', name: 'تكلفة البضاعة المباعة',       type: 'EXPENSE',   ifrs_mapping: 'COGS' },
    { code: '6000', name: 'المصروفات التشغيلية',         type: 'EXPENSE',   ifrs_mapping: 'EXPENSE' },
    { code: '6100', name: 'الرواتب والأجور',             type: 'EXPENSE',   ifrs_mapping: 'EXPENSE' },
    { code: '6200', name: 'الإيجار',                    type: 'EXPENSE',   ifrs_mapping: 'EXPENSE' },
    { code: '6300', name: 'الكهرباء والمياه',            type: 'EXPENSE',   ifrs_mapping: 'EXPENSE' },
    { code: '6400', name: 'مصروفات إدارية',             type: 'EXPENSE',   ifrs_mapping: 'EXPENSE' },
    { code: '6500', name: 'مصروفات تسويق',             type: 'EXPENSE',   ifrs_mapping: 'EXPENSE' },
  ],
  services: [
    { code: '1100', name: 'الصندوق',                    type: 'ASSET',     ifrs_mapping: 'CURRENT_ASSET' },
    { code: '1110', name: 'البنك',                      type: 'ASSET',     ifrs_mapping: 'CURRENT_ASSET' },
    { code: '1120', name: 'ذمم مدينة',                  type: 'ASSET',     ifrs_mapping: 'CURRENT_ASSET' },
    { code: '2110', name: 'ذمم دائنة',                  type: 'LIABILITY', ifrs_mapping: 'CURRENT_LIAB' },
    { code: '2120', name: 'ضريبة القيمة المضافة',        type: 'LIABILITY', ifrs_mapping: 'CURRENT_LIAB' },
    { code: '3100', name: 'رأس المال',                  type: 'EQUITY',    ifrs_mapping: 'EQUITY' },
    { code: '4100', name: 'إيرادات الخدمات',            type: 'REVENUE',   ifrs_mapping: 'REVENUE' },
    { code: '6100', name: 'الرواتب',                    type: 'EXPENSE',   ifrs_mapping: 'EXPENSE' },
    { code: '6200', name: 'الإيجار',                    type: 'EXPENSE',   ifrs_mapping: 'EXPENSE' },
    { code: '6300', name: 'مصروفات عامة',               type: 'EXPENSE',   ifrs_mapping: 'EXPENSE' },
  ],
};
COA_SEEDS.restaurant   = COA_SEEDS.trading;
COA_SEEDS.construction = COA_SEEDS.trading;
COA_SEEDS.blank        = [];

export default function Onboarding() {
  const navigate = useNavigate();
  const { companyId } = useRBAC();
  const [step, setStep] = useState(0);
  const [coaTemplate, setCoaTemplate] = useState('trading');
  const [selectedModules, setSelectedModules] = useState<string[]>(['sales', 'purchases']);
  const [isSeeding, setIsSeeding] = useState(false);

  const toggleModule = (id: string) => {
    if (['sales', 'purchases'].includes(id)) return; // required
    setSelectedModules(p => p.includes(id) ? p.filter(m => m !== id) : [...p, id]);
  };

  const finishOnboarding = async () => {
    setIsSeeding(true);
    try {
      const accounts = COA_SEEDS[coaTemplate] || [];
      if (accounts.length > 0 && companyId && companyId !== 'default-company') {
        const rows = accounts.map(a => ({ ...a, company_id: companyId, level: a.code.length <= 4 ? 1 : 2 }));
        await supabase.from('accounts').insert(rows);
      }
      // Save module preferences
      await supabase.from('company_settings').upsert(
        [{ company_id: companyId, key: 'active_modules', value: JSON.stringify(selectedModules) }],
        { onConflict: 'company_id,key' }
      );
    } catch (err) {
      console.error('Onboarding seed error:', err);
    }
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-2xl">
        {/* Progress */}
        <div className="flex items-center gap-2 mb-8">
          {STEPS.map((s, i) => (
            <React.Fragment key={s.id}>
              <div className={`flex items-center justify-center w-9 h-9 rounded-full text-sm font-bold border-2 transition-all ${i <= step ? 'border-indigo-600 bg-indigo-600 text-white' : 'border-slate-300 bg-white text-slate-400'}`}>
                {i < step ? <CheckCircle2 className="w-5 h-5" /> : i + 1}
              </div>
              {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 rounded transition-all ${i < step ? 'bg-indigo-600' : 'bg-slate-200'}`} />}
            </React.Fragment>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          {step === 0 && (
            <div className="text-center space-y-6">
              <div className="w-16 h-16 bg-indigo-100 rounded-2xl flex items-center justify-center mx-auto">
                <Sparkles className="w-8 h-8 text-indigo-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-slate-800">{STEPS[0].title}</h2>
                <p className="text-slate-500 mt-2">
                  في خطوات بسيطة سنُعدّ نظامك المحاسبي الكامل جاهزاً للعمل فوراً
                </p>
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                {[
                  { icon: '📊', label: 'تقارير مالية فورية' },
                  { icon: '🤖', label: 'محاسب ذكي بالذكاء الاصطناعي' },
                  { icon: '🔒', label: 'بيانات مشفرة وآمنة' },
                ].map(f => (
                  <div key={f.label} className="p-4 bg-slate-50 rounded-xl">
                    <div className="text-2xl mb-2">{f.icon}</div>
                    <div className="text-xs text-slate-600 font-medium">{f.label}</div>
                  </div>
                ))}
              </div>
              <button onClick={() => setStep(1)} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 rounded-xl transition-colors flex items-center justify-center gap-2">
                ابدأ الإعداد <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold text-slate-800">{STEPS[1].title}</h2>
                <p className="text-slate-500 text-sm mt-1">{STEPS[1].desc}</p>
              </div>
              <div className="space-y-3">
                {CHART_TEMPLATES.map(t => (
                  <button key={t.id} onClick={() => setCoaTemplate(t.id)}
                    className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 text-right transition-all ${coaTemplate === t.id ? 'border-indigo-600 bg-indigo-50' : 'border-slate-200 hover:border-slate-300'}`}>
                    <span className="text-2xl">{t.icon}</span>
                    <div className="flex-1">
                      <div className="font-semibold text-slate-800">{t.label}</div>
                      <div className="text-xs text-slate-500 mt-0.5">{t.desc}</div>
                    </div>
                    {coaTemplate === t.id && <CheckCircle2 className="w-5 h-5 text-indigo-600 shrink-0" />}
                  </button>
                ))}
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setStep(0)} className="px-5 py-2.5 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50">رجوع</button>
                <button onClick={() => setStep(2)} className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-2">
                  التالي <ArrowLeft className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-5">
              <div>
                <h2 className="text-xl font-bold text-slate-800">{STEPS[2].title}</h2>
                <p className="text-slate-500 text-sm mt-1">{STEPS[2].desc}</p>
              </div>
              <div className="space-y-3">
                {MODULES.map(m => (
                  <div key={m.id} onClick={() => toggleModule(m.id)}
                    className={`flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all ${selectedModules.includes(m.id) ? 'border-indigo-600 bg-indigo-50' : 'border-slate-200 hover:border-slate-300'} ${m.required ? 'opacity-90' : ''}`}>
                    <div className={`p-2 rounded-lg ${selectedModules.includes(m.id) ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-500'}`}>{m.icon}</div>
                    <div className="flex-1">
                      <span className="font-medium text-slate-800">{m.label}</span>
                      {m.required && <span className="text-xs text-indigo-600 mr-2 bg-indigo-50 px-1.5 py-0.5 rounded">أساسي</span>}
                    </div>
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${selectedModules.includes(m.id) ? 'border-indigo-600 bg-indigo-600' : 'border-slate-300'}`}>
                      {selectedModules.includes(m.id) && <div className="w-2 h-2 bg-white rounded-full" />}
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setStep(1)} className="px-5 py-2.5 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50">رجوع</button>
                <button onClick={finishOnboarding} disabled={isSeeding}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-2 disabled:opacity-70">
                  {isSeeding ? (
                    <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> جارٍ الإعداد...</>
                  ) : (
                    <>ابدأ العمل <ChevronRight className="w-4 h-4" /></>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
