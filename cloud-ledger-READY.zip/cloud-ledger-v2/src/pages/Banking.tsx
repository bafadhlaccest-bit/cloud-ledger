import React from 'react';
import { useTranslation } from 'react-i18next';
import * as XLSX from 'xlsx';
import { ColumnDef } from '@tanstack/react-table';
import { DataTable } from '../components/DataTable';
import { BankAccount, BankTransaction, Invoice, Bill, Account } from '../types';
import { formatCurrency, cn, formatDate, getLocalizedLabel } from '../lib/utils';
import { 
  Plus, 
  Search, 
  Landmark, 
  CreditCard, 
  ArrowRightLeft, 
  Upload, 
  Loader2, 
  Trash2, 
  Edit2, 
  Check, 
  X, 
  Filter, 
  AlertTriangle, 
  ShieldCheck, 
  Coins, 
  FileCheck, 
  Settings, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Terminal, 
  Zap, 
  ChevronRight, 
  Info,
  RefreshCw
} from 'lucide-react';
import Modal from '../components/Modal';
import { AccountDropdownSelector } from '../components/AccountDropdownSelector';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  serverTimestamp,
  orderBy,
  writeBatch
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';
import { PostingEngine } from '../services/PostingEngine';
import { db, collection, addDoc, updateDoc, deleteDoc, onSnapshot, query, where, orderBy, serverTimestamp, doc } from '../firebase';

// Predefined Automated Mapping Rules
interface AutomatedRule {
  id: string;
  keyword: string;
  accountType: 'Income' | 'Expense';
  accountCode: string;
  accountName: string;
}

const DEFAULT_RULES: AutomatedRule[] = [
  { id: 'rule_1', keyword: 'Uber', accountType: 'Expense', accountCode: '5200', accountName: 'Travel & Local Transportation' },
  { id: 'rule_2', keyword: 'Google Cloud', accountType: 'Expense', accountCode: '5300', accountName: 'IT & Cloud Infrastructure' },
  { id: 'rule_3', keyword: 'Starbucks', accountType: 'Expense', accountCode: '5400', accountName: 'Meals & Entertainment' },
  { id: 'rule_4', keyword: 'Office Depot', accountType: 'Expense', accountCode: '5500', accountName: 'Office Assets and Supplies' },
  { id: 'rule_5', keyword: 'Stripe Payout', accountType: 'Income', accountCode: '4000', accountName: 'Sales Revenue' }
];

export default function Banking() {
  const { t } = useTranslation();
  const [isAccountModalOpen, setIsAccountModalOpen] = React.useState(false);
  const [isTransactionModalOpen, setIsTransactionModalOpen] = React.useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = React.useState(false);
  
  // Datasets from Firestore
  const [bankAccounts, setBankAccounts] = React.useState<BankAccount[]>([]);
  const [transactions, setTransactions] = React.useState<BankTransaction[]>([]);
  const [invoices, setInvoices] = React.useState<Invoice[]>([]);
  const [bills, setBills] = React.useState<Bill[]>([]);
  const [accounts, setAccounts] = React.useState<Account[]>([]);
  
  // UI states
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSaving, setIsSaving] = React.useState(false);
  const [isImporting, setIsImporting] = React.useState(false);
  const [isDragActive, setIsDragActive] = React.useState(false);
  const [uploadedFileName, setUploadedFileName] = React.useState<string | null>(null);
  const [parsedTransactions, setParsedTransactions] = React.useState<any[]>([]);
  const [editingAccount, setEditingAccount] = React.useState<BankAccount | null>(null);
  
  // Selection states for Split-Screen Workspace
  const [activeAccountId, setActiveAccountId] = React.useState<string | null>(null);
  const [selectedTransactionId, setSelectedTransactionId] = React.useState<string | null>(null);
  const [detailTab, setDetailTab] = React.useState<'uncategorized' | 'all' | 'excluded' | 'rules'>('uncategorized');
  const [matchingTab, setMatchingTab] = React.useState<'match' | 'categorize'>('match');
  
  // Search & Filters
  const [searchTerm, setSearchTerm] = React.useState('');
  const [leftPaneSearch, setLeftPaneSearch] = React.useState('');
  const [amountFilter, setAmountFilter] = React.useState<'all' | 'deposits' | 'withdrawals'>('all');

  // Manual transaction form inputs
  const [manualTxType, setManualTxType] = React.useState<'Deposit' | 'Withdrawal'>('Withdrawal');

  // Custom User Defined Rules State
  const [rules, setRules] = React.useState<AutomatedRule[]>(DEFAULT_RULES);
  const [newRuleKeyword, setNewRuleKeyword] = React.useState('');
  const [newRuleAccountCode, setNewRuleAccountCode] = React.useState('5000');
  const [newRuleAccountName, setNewRuleAccountName] = React.useState('Cost of Goods Sold');

  // Categorize manual form fields
  const [catAccountId, setCatAccountId] = React.useState('');
  const [catAccountName, setCatAccountName] = React.useState('');
  const [catPayeeName, setCatPayeeName] = React.useState('');
  const [catTaxRate, setCatTaxRate] = React.useState<number>(0);
  const [catReference, setCatReference] = React.useState('');

  const { companyId } = useRBAC();

  // Firestore Subscriptions
  React.useEffect(() => {
    const companyQuery = where('companyId', '==', companyId);

    const unsubAccounts = onSnapshot(query(collection(db, 'bankAccounts'), companyQuery), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as BankAccount[];
      setBankAccounts(data);
      setIsLoading(false);
    }, (error) => {
      console.warn('Real-time bank accounts synchronization status (using local/fallback state):', error.message);
      setIsLoading(false);
    });

    const unsubTransactions = onSnapshot(query(collection(db, 'bankTransactions'), companyQuery), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as BankTransaction[];
      // Sorting descending by date as fallback
      data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setTransactions(data);
    }, (error) => {
      console.warn('Real-time bank transactions synchronization status (using local/fallback state):', error.message);
    });

    const unsubInvoices = onSnapshot(query(collection(db, 'invoices'), companyQuery), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Invoice[];
      setInvoices(data);
    }, (error) => {
      console.warn('Real-time invoices synchronization status (using local/fallback state):', error.message);
    });

    const unsubBills = onSnapshot(query(collection(db, 'bills'), companyQuery), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Bill[];
      setBills(data);
    }, (error) => {
      console.warn('Real-time bills synchronization status (using local/fallback state):', error.message);
    });

    const unsubLedgerAccounts = onSnapshot(query(collection(db, 'accounts'), companyQuery), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Account[];
      setAccounts(data);
    }, (error) => {
      console.warn('Real-time standard accounts synchronization status (using local/fallback state):', error.message);
    });

    return () => {
      unsubAccounts();
      unsubTransactions();
      unsubInvoices();
      unsubBills();
      unsubLedgerAccounts();
    };
  }, [companyId]);

  // Safe Seeder Trigger: Seed defaults if collections are empty so workspace feels polished
  const triggerDemoSeeding = async () => {
    setIsSaving(true);
    try {
      const batch = writeBatch(db);

      // Create Demo Bank Account 1
      const bank1Ref = doc(collection(db, 'bankAccounts'));
      const bank1Id = bank1Ref.id;
      batch.set(bank1Ref, {
        name: 'Silicon Valley Operating Checking',
        bankName: 'Silicon Valley Bank',
        accountNumber: '•••• 9412',
        balance: 450000,
        currency: 'USD',
        status: 'active',
        companyId,
        createdAt: serverTimestamp()
      });

      // Create Demo Bank Account 2
      const bank2Ref = doc(collection(db, 'bankAccounts'));
      batch.set(bank2Ref, {
        name: 'Chase Platinum business Credit Card',
        bankName: 'Chase Retail',
        accountNumber: '•••• 2844',
        balance: -6800,
        currency: 'USD',
        status: 'active',
        companyId,
        createdAt: serverTimestamp()
      });

      // Seed 6 Uncategorized Statement Transactions for SVB checking account
      const t1Ref = doc(collection(db, 'bankTransactions'));
      batch.set(t1Ref, {
        bankAccountId: bank1Id,
        date: '2026-05-30',
        description: 'Google Cloud Platform Monthly Consumables',
        amount: -1240.50,
        type: 'Withdrawal',
        status: 'Unreconciled',
        companyId
      });

      const t2Ref = doc(collection(db, 'bankTransactions'));
      batch.set(t2Ref, {
        bankAccountId: bank1Id,
        date: '2026-05-28',
        description: 'Acme Corp Strategic Retainer Payout - Stripe Premium Payout',
        amount: 8500.00,
        type: 'Deposit',
        status: 'Unreconciled',
        companyId
      });

      const t3Ref = doc(collection(db, 'bankTransactions'));
      batch.set(t3Ref, {
        bankAccountId: bank1Id,
        date: '2026-05-27',
        description: 'Uber Business Cab fare - San Francisco HQ Lunch',
        amount: -45.60,
        type: 'Withdrawal',
        status: 'Unreconciled',
        companyId
      });

      const t4Ref = doc(collection(db, 'bankTransactions'));
      batch.set(t4Ref, {
        bankAccountId: bank1Id,
        date: '2026-05-25',
        description: 'Office Depot - Conference Room Swivel chairs',
        amount: -450.00,
        type: 'Withdrawal',
        status: 'Unreconciled',
        companyId
      });

      const t5Ref = doc(collection(db, 'bankTransactions'));
      batch.set(t5Ref, {
        bankAccountId: bank1Id,
        date: '2026-05-24',
        description: 'Starbucks Morning refreshments for engineering sprints',
        amount: -32.80,
        type: 'Withdrawal',
        status: 'Unreconciled',
        companyId
      });

      const t6Ref = doc(collection(db, 'bankTransactions'));
      batch.set(t6Ref, {
        bankAccountId: bank1Id,
        date: '2026-05-20',
        description: 'Unmatched Invoice Deposit reference ID INV-2026-403',
        amount: 1500.00,
        type: 'Deposit',
        status: 'Unreconciled',
        companyId
      });

      // Build 2 standard Accounts if missing
      const defaultAccs = [
        { code: '4000', name: 'Sales Revenue', type: 'Income' },
        { code: '5200', name: 'Travel & Local Transportation', type: 'Expense' },
        { code: '5300', name: 'IT & Cloud Infrastructure', type: 'Expense' },
        { code: '5400', name: 'Meals & Entertainment', type: 'Expense' },
        { code: '5500', name: 'Office Assets and Supplies', type: 'Expense' }
      ];

      defaultAccs.forEach(acc => {
        const accRef = doc(collection(db, 'accounts'));
        batch.set(accRef, {
          code: acc.code,
          name: acc.name,
          type: acc.type,
          balance: 0,
          status: 'active',
          companyId
        });
      });

      await batch.commit();
      setActiveAccountId(bank1Id);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  // Automated Calculation Engine
  const getAccountFinances = (accountId: string) => {
    const account = bankAccounts.find(a => a.id === accountId);
    if (!account) return { amountInBank: 0, amountInBooks: 0, uncategorizedCount: 0, lastImported: 'N/A' };

    const matchingTx = transactions.filter(t => t.bankAccountId === accountId);
    
    // Amount in Bank: Physical starting balance of the account plus all transacted statement amounts (excluding manually written exclusions)
    const validStatements = matchingTx.filter(t => !(t as any).isExcluded);
    const statementSum = validStatements.reduce((sum, tx) => sum + tx.amount, 0);
    const amountInBank = account.balance + statementSum;

    // Amount in Books (Ledger Balance): physical starting balance plus ONLY Reconciled/matched or categorized items
    const reconciledStatements = matchingTx.filter(t => t.status === 'Reconciled' && !(t as any).isExcluded);
    const ledgerSum = reconciledStatements.reduce((sum, tx) => sum + tx.amount, 0);
    const amountInBooks = account.balance + ledgerSum;

    const uncategorizedCount = matchingTx.filter(t => t.status === 'Unreconciled' && !(t as any).isExcluded).length;

    // Last imported date calculation
    const importDates = matchingTx.map(t => new Date(t.date).getTime());
    let lastImported = 'Jun 01, 2026';
    if (importDates.length > 0) {
      const maxTime = Math.max(...importDates);
      lastImported = new Date(maxTime).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }

    return {
      amountInBank,
      amountInBooks,
      uncategorizedCount,
      lastImported
    };
  };

  // Rule Application Rule Lookup
  const getAutomatedRuleSuggestion = (desc: string) => {
    const trimmed = (desc || '').toLowerCase();
    const matchedRule = rules.find(rule => trimmed.includes(rule.keyword.toLowerCase()));
    return matchedRule || null;
  };

  // Left side list rendering filters
  const selectedAccountTx = transactions.filter(t => t.bankAccountId === activeAccountId);
  const selectedAccount = bankAccounts.find(a => a.id === activeAccountId);

  const leftPaneTxList = selectedAccountTx.filter(t => {
    // Exclude matching rule constraints
    const isExcluded = !!(t as any).isExcluded;
    
    if (detailTab === 'uncategorized') {
      if (t.status !== 'Unreconciled' || isExcluded) return false;
    } else if (detailTab === 'excluded') {
      if (!isExcluded) return false;
    } else if (detailTab === 'all') {
      // Show everything
    }

    // Amount Filter
    if (amountFilter === 'deposits' && t.amount < 0) return false;
    if (amountFilter === 'withdrawals' && t.amount >= 0) return false;

    // Keyword Search
    if (leftPaneSearch) {
      return t.description.toLowerCase().includes(leftPaneSearch.toLowerCase()) || 
             Math.abs(t.amount).toString().includes(leftPaneSearch);
    }
    return true;
  });

  // Pick Selected Transaction details for right pane
  const activeTx = transactions.find(t => t.id === selectedTransactionId);

  // When active transaction changes, prepopulate the manual categorization input values & look for auto-rules
  React.useEffect(() => {
    if (activeTx) {
      const suggestion = getAutomatedRuleSuggestion(activeTx.description);
      if (suggestion) {
        // Pre-fill categories with matching rule criteria automatically
        const foundAcc = accounts.find(a => a.code === suggestion.accountCode) || 
                         accounts.find(a => a.name.toLowerCase().includes(suggestion.accountName.toLowerCase()));
        
        setCatAccountId(foundAcc?.id || 'manual_acc_rule');
        setCatAccountName(foundAcc?.name || suggestion.accountName);
      } else {
        setCatAccountId('');
        setCatAccountName('');
      }
      setCatPayeeName('');
      setCatTaxRate(0);
      setCatReference('');
    }
  }, [selectedTransactionId]);

  // Find system match candidates (invoices or bills)
  const getMatchCandidates = (tx: BankTransaction | undefined) => {
    if (!tx) return [];
    const absoluteVal = Math.abs(tx.amount);
    
    if (tx.amount > 0) {
      // Find open Invoices to match deposits
      return invoices.map(inv => {
        // Calculate dynamic similarity
        const parsedInvoiceTotal = Number(inv.total) || 0;
        const matchesExact = Math.abs(parsedInvoiceTotal - absoluteVal) < 0.1;
        
        return {
          id: inv.id,
          number: inv.number || `INV-${inv.id.slice(0, 5)}`,
          partnerName: inv.customerName || 'Standard Client',
          date: inv.date || '',
          total: parsedInvoiceTotal,
          status: inv.status,
          type: 'Invoice' as const,
          exactMatch: matchesExact
        };
      });
    } else {
      // Find open Bills to match expenses
      return bills.map(b => {
        const parsedBillTotal = Number(b.total) || 0;
        const matchesExact = Math.abs(parsedBillTotal - absoluteVal) < 0.1;

        return {
          id: b.id,
          number: b.number || `BILL-${b.id.slice(0, 5)}`,
          partnerName: b.vendorName || 'Supplier Merchant',
          date: b.date || '',
          total: parsedBillTotal,
          status: b.status,
          type: 'Bill' as const,
          exactMatch: matchesExact
        };
      });
    }
  };

  const matchCandidates = getMatchCandidates(activeTx);

  // Saving of Bank or Credit Card Account Modal
  const handleSaveAccount = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    const cardOrBank = formData.get('accountType') as string;

    const data = {
      name: formData.get('name') as string,
      bankName: formData.get('bankName') as string,
      accountNumber: `•••• ${formData.get('accountNumber')}`.trim(),
      balance: Number(formData.get('balance')) || 0,
      currency: formData.get('currency') as string,
      status: 'active' as const,
      companyId,
      updatedAt: serverTimestamp(),
    };

    try {
      if (editingAccount) {
        await updateDoc(doc(db, 'bankAccounts', editingAccount.id), data);
      } else {
        const newRef = await addDoc(collection(db, 'bankAccounts'), {
          ...data,
          createdAt: serverTimestamp(),
        });
        setActiveAccountId(newRef.id);
      }
      setIsAccountModalOpen(false);
      setEditingAccount(null);
    } catch (error) {
      handleFirestoreError(error, editingAccount ? OperationType.UPDATE : OperationType.CREATE, 'bankAccounts');
    } finally {
      setIsSaving(false);
    }
  };

  // Add manually keyed transaction row
  const handleCreateManualTx = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!activeAccountId) return;
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    const absoluteAmt = Math.abs(Number(formData.get('amount')));
    const finalAmount = manualTxType === 'Deposit' ? absoluteAmt : -absoluteAmt;

    const txData = {
      bankAccountId: activeAccountId,
      date: formData.get('date') as string,
      description: formData.get('description') as string,
      amount: finalAmount,
      type: manualTxType,
      status: 'Unreconciled' as const,
      companyId,
    };

    try {
      const addedDoc = await addDoc(collection(db, 'bankTransactions'), txData);
      setSelectedTransactionId(addedDoc.id);
      setIsTransactionModalOpen(false);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  // Download Sample Bank Statement CSV template helper
  const downloadSampleTemplate = () => {
    const csvContent = [
      'Date,Description,Reference,Debit,Credit,Balance',
      '2026-06-01,Opening Bank Balance,BAL-001,0.00,0.00,25000.00',
      '2026-06-05,Customer Invoice Payment,INV-1002,1500.00,0.00,26500.00',
      '2026-06-10,Office Rent Payout,PAY-204,0.00,800.00,25700.00'
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'bank_statement_sample.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Map parsed dictionary objects into structured system objects strictly
  const mapParsedDataRows = (rows: any[]): any[] => {
    const result: any[] = [];

    for (const row of rows) {
      if (!row) continue;
      const keys = Object.keys(row);
      const findKey = (candidates: string[]) => {
        return keys.find(k => candidates.some(c => k.toLowerCase().replace(/_/g, ' ').trim() === c.toLowerCase())) || '';
      };

      const dateKey = findKey(['date', 'التاريخ', 'transaction date']);
      const descKey = findKey(['description', 'البيان', 'details', 'name']);
      const refKey = findKey(['reference', 'المرجع', 'ref', 'code']);
      const debitKey = findKey(['debit', 'amount debit', 'مدينة', 'مدين', 'withdrawal']);
      const creditKey = findKey(['credit', 'amount credit', 'دائنة', 'دائن', 'deposit']);
      const balanceKey = findKey(['balance', 'الرصيد', 'total balance']);
      const amountKey = findKey(['amount', 'value', 'المبلغ', 'sum', 'total']);

      const rawDate = row[dateKey];
      const rawDesc = row[descKey];
      
      // Stop or skip if date or description is missing
      if (!rawDate && !rawDesc) continue;

      const rawRef = row[refKey] || `IMP-${Math.floor(Math.random() * 100000)}`;
      let debitVal = parseFloat(row[debitKey]) || 0;
      let creditVal = parseFloat(row[creditKey]) || 0;
      const balanceVal = parseFloat(row[balanceKey]) || 0;

      if (debitVal === 0 && creditVal === 0 && amountKey) {
        const amountVal = parseFloat(row[amountKey]) || 0;
        if (amountVal > 0) {
          debitVal = amountVal;
        } else if (amountVal < 0) {
          creditVal = Math.abs(amountVal);
        }
      }

      let formattedDate = '';
      if (typeof rawDate === 'number') {
        const excelEpoch = new Date(1899, 11, 30);
        formattedDate = new Date(excelEpoch.getTime() + rawDate * 86400000).toISOString().split('T')[0];
      } else if (rawDate) {
        try {
          const parsedD = new Date(rawDate);
          if (!isNaN(parsedD.getTime())) {
            formattedDate = parsedD.toISOString().split('T')[0];
          } else {
            formattedDate = new Date().toISOString().split('T')[0];
          }
        } catch (e) {
          formattedDate = new Date().toISOString().split('T')[0];
        }
      } else {
        formattedDate = new Date().toISOString().split('T')[0];
      }

      result.push({
        date: formattedDate,
        description: rawDesc || 'Imported Line Transaction',
        reference: rawRef,
        debit: debitVal,
        credit: creditVal,
        balance: balanceVal
      });
    }

    return result;
  };

  // Raw file array buffer and string parsing logic for CSV and spreadsheets
  const handleFileImport = async (file: File) => {
    if (!activeAccountId) {
      alert("Please select a bank account first before importing statements.");
      return;
    }
    
    setIsImporting(true);
    setUploadedFileName(file.name);
    setParsedTransactions([]);

    const fileExt = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();

    if (fileExt === '.csv') {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const text = e.target?.result as string;
          if (!text) {
            throw new Error("Could not read CSV text content.");
          }

          // Robust regex / line parser
          const lines = text.split(/\r?\n/);
          if (lines.length <= 1) {
            throw new Error("The uploaded CSV file is empty or contains no transaction rows.");
          }

          const rawHeaders = lines[0].split(',').map(h => h.trim().replace(/^["']|["']$/g, ''));
          const rows = [];

          for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;

            // Handle quoted commas correctly
            const values = [];
            let current = '';
            let inQuotes = false;
            for (let c = 0; c < line.length; c++) {
              const char = line[c];
              if (char === '"') {
                inQuotes = !inQuotes;
              } else if (char === ',' && !inQuotes) {
                values.push(current.trim().replace(/^["']|["']$/g, ''));
                current = '';
              } else {
                current += char;
              }
            }
            values.push(current.trim().replace(/^["']|["']$/g, ''));

            if (values.length > 0 && values.some(v => v !== '')) {
              const obj: any = {};
              rawHeaders.forEach((h, index) => {
                obj[h] = values[index] || '';
              });
              rows.push(obj);
            }
          }

          const structuredRows = mapParsedDataRows(rows);
          if (structuredRows.length === 0) {
            throw new Error("No valid financial data parsed from CSV layout.");
          }

          setParsedTransactions(structuredRows);
        } catch (err: any) {
          console.error(err);
          alert(`CSV Parsing Failed: ${err.message || err}`);
          setUploadedFileName(null);
        } finally {
          setIsImporting(false);
        }
      };
      reader.readAsText(file);
    } else {
      // Excel spreadsheet
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const arrayBuffer = e.target?.result;
          if (!arrayBuffer) {
            throw new Error("Could not parse file array buffer.");
          }

          const workbook = XLSX.read(arrayBuffer, { type: 'array' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const rows = XLSX.utils.sheet_to_json<any>(worksheet);

          if (!rows || rows.length === 0) {
            throw new Error("No readable rows found in the selected spreadsheet.");
          }

          const structuredRows = mapParsedDataRows(rows);
          if (structuredRows.length === 0) {
            throw new Error("No valid financial data parsed from spreadsheet layout.");
          }

          setParsedTransactions(structuredRows);
        } catch (err: any) {
          console.error(err);
          alert(`Excel Parsing Failed: ${err.message || err}`);
          setUploadedFileName(null);
        } finally {
          setIsImporting(false);
        }
      };
      reader.readAsArrayBuffer(file);
    }
  };

  // Commit parsed transaction array securely to Firestore bankTransactions schema
  const commitParsedTransactions = async () => {
    if (!activeAccountId) {
      alert("Please select a bank account first.");
      return;
    }
    if (parsedTransactions.length === 0) {
      alert("No parsed transactions to commit.");
      return;
    }

    setIsImporting(true);
    try {
      const batch = writeBatch(db);
      let committedCount = 0;

      for (const row of parsedTransactions) {
        // Debit is Deposit (positive flow), Credit is Withdrawal (negative flow)
        let finalAmount = 0;
        if (row.debit > 0 && row.credit === 0) {
          finalAmount = row.debit;
        } else if (row.credit > 0 && row.debit === 0) {
          finalAmount = -row.credit;
        } else if (row.debit > 0 && row.credit > 0) {
          finalAmount = row.debit - row.credit;
        } else {
          // If both debit and credit are zero, fallback to balance change or default
          continue;
        }

        const docRef = doc(collection(db, 'bankTransactions'));
        batch.set(docRef, {
          bankAccountId: activeAccountId,
          date: row.date,
          description: row.description + (row.reference ? ` (${row.reference})` : ''),
          amount: finalAmount,
          type: finalAmount > 0 ? 'Deposit' : 'Withdrawal',
          status: 'Unreconciled',
          companyId,
          reference: row.reference
        });
        committedCount++;
      }

      if (committedCount === 0) {
        throw new Error("No transactions to import. Please review debit/credit values.");
      }

      await batch.commit();
      
      // Clean states
      setIsImportModalOpen(false);
      setUploadedFileName(null);
      setParsedTransactions([]);
    } catch (err: any) {
      console.error(err);
      alert(`Import Failed: ${err.message || err}`);
    } finally {
      setIsImporting(false);
    }
  };

  // Trigger Bulk simulation Import Statement CSV
  const handleSimulateStatementImport = async (preset: string) => {
    if (!activeAccountId) return;
    setIsImporting(true);

    const statementStreams = [
      { date: '2026-05-29', description: 'Uber Trip Ride - Cloud client support visit', amount: -65.00 },
      { date: '2026-05-28', description: 'Acme LLC Settlement payout - Stripe Payout #241', amount: 4800.00 },
      { date: '2026-05-25', description: 'Starbucks coffee catering and muffins', amount: -42.90 },
      { date: '2026-05-22', description: 'Amazon Supply procurement order ID 112-AS-193', amount: -850.50 },
      { date: '2026-05-18', description: 'Stripe Payout - Monthly SaaS checkout collection', amount: 1350.00 },
    ];

    try {
      const batch = writeBatch(db);
      statementStreams.forEach(item => {
        const docRef = doc(collection(db, 'bankTransactions'));
        batch.set(docRef, {
          bankAccountId: activeAccountId,
          date: item.date,
          description: item.description,
          amount: item.amount,
          type: item.amount > 0 ? 'Deposit' : 'Withdrawal',
          status: 'Unreconciled',
          companyId
        });
      });
      await batch.commit();
      setIsImportModalOpen(false);
    } catch (err) {
      console.error(err);
    } finally {
      setIsImporting(false);
    }
  };

  // Perform Match Document Confirmation
  const confirmMatchRow = async (candidateId: string, candType: 'Invoice' | 'Bill') => {
    if (!activeTx) return;
    setIsSaving(true);
    try {
      const batch = writeBatch(db);
      
      // Update statement line status to Reconciled
      const txRef = doc(db, 'bankTransactions', activeTx.id);
      batch.update(txRef, {
        status: 'Reconciled',
        matchedDocId: candidateId,
        matchedDocType: candType,
        reconciledAt: serverTimestamp()
      });

      // Update actual invoice/bill document status to Paid in the system representing proper accounting
      if (candType === 'Invoice') {
        const invRef = doc(db, 'invoices', candidateId);
        batch.update(invRef, { status: 'Paid' });
      } else {
        const billRef = doc(db, 'bills', candidateId);
        batch.update(billRef, { status: 'Paid' });
      }

      await batch.commit();
      
      // Auto-advance selection if list is not empty
      const nextIdx = leftPaneTxList.findIndex(t => t.id === activeTx.id);
      if (nextIdx !== -1 && leftPaneTxList[nextIdx + 1]) {
        setSelectedTransactionId(leftPaneTxList[nextIdx + 1].id);
      } else {
        setSelectedTransactionId(null);
      }
    } catch (err) {
      console.error('Match Transaction failed', err);
    } finally {
      setIsSaving(false);
    }
  };

  // Perform Manual Categorization Save & Reconcile
  const saveAndReconcileManual = async () => {
    if (!activeTx) return;
    setIsSaving(true);
    try {
      const txRef = doc(db, 'bankTransactions', activeTx.id);
      await updateDoc(txRef, {
        status: 'Reconciled',
        category: catAccountName || 'General Expense Mapping',
        payeeName: catPayeeName || 'Manual Custom Payee',
        taxRate: Number(catTaxRate) || 0,
        reference: catReference || 'No Ref Written',
        reconciledAt: serverTimestamp()
      });

      // Post dynamic double-entry ledger lines immediately
      if (catAccountId) {
        const matchingAcc = accounts.find(a => a.id === catAccountId);
        await PostingEngine.postBankTransaction({
          id: activeTx.id,
          date: activeTx.date || new Date().toISOString().split('T')[0],
          description: activeTx.description || 'Manual Statement Categorization',
          amount: activeTx.amount,
          accountId: activeTx.bankAccountId || 'acc_kuraimi',
          mappedAccountId: catAccountId,
          mappedAccountCode: matchingAcc?.code || '510101',
          mappedAccountName: catAccountName || matchingAcc?.name || 'General Expense Mapping'
        }, companyId || companyId);
      }

      // Advance left list
      const nextIdx = leftPaneTxList.findIndex(t => t.id === activeTx.id);
      if (nextIdx !== -1 && leftPaneTxList[nextIdx + 1]) {
        setSelectedTransactionId(leftPaneTxList[nextIdx + 1].id);
      } else {
        setSelectedTransactionId(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  // Exclude transaction feeding error
  const toggleExclusionState = async (txId: string, excludeVal: boolean) => {
    try {
      const txRef = doc(db, 'bankTransactions', txId);
      await updateDoc(txRef, {
        isExcluded: excludeVal
      });
      if (selectedTransactionId === txId) {
        setSelectedTransactionId(null);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Add new automated rule on rules tab
  const handleAddNewRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleKeyword) return;
    const ruleObj: AutomatedRule = {
      id: 'rule_' + Math.random().toString(36).substring(2, 11),
      keyword: newRuleKeyword,
      accountType: 'Expense',
      accountCode: newRuleAccountCode,
      accountName: newRuleAccountName
    };
    setRules([...rules, ruleObj]);
    setNewRuleKeyword('');
  };

  // Delete manual rule
  const handleDeleteRule = (id: string) => {
    setRules(rules.filter(r => r.id !== id));
  };

  const activeFinance = activeAccountId ? getAccountFinances(activeAccountId) : null;

  return (
    <div className="space-y-6">
      {/* Top Banner Action Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Landmark className="w-6 h-6 text-indigo-600" />
            {t('sidebar.banking', 'Banking Center')}
          </h1>
          <p className="text-slate-500 text-sm">
            {t('banking.subtitle', 'Exact Cloud Banking integration workflow, dual-ledger statements matching, and discrepancy exclusions.')}
          </p>
        </div>
        <div className="flex items-center gap-3">
          {bankAccounts.length === 0 && (
            <button 
              onClick={triggerDemoSeeding}
              className="flex items-center gap-1.5 px-3.5 py-2 border border-dashed border-indigo-300 text-indigo-600 hover:bg-indigo-50 font-semibold rounded-lg text-sm transition cursor-pointer"
            >
              <RefreshCw className="w-4 h-4 animate-spin-slow" />
              {t('banking.seed_demo', 'Seed Demo Workspace')}
            </button>
          )}

          <button 
            onClick={() => {
              setEditingAccount(null);
              setIsAccountModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition font-bold text-sm shadow-sm hover:shadow-md cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            {t('banking.add_bank_card', 'Add Bank or Credit Card')}
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      ) : activeAccountId === null ? (
        /* Part 1: Dashboard Overview Grid when not viewing a single bank account */
        <div className="space-y-8 animate-fade-in">
          {bankAccounts.length === 0 ? (
            <div className="text-center py-20 bg-white border border-dashed border-slate-200 rounded-2xl max-w-2xl mx-auto space-y-4">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-400">
                <Landmark className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="font-bold text-slate-800 text-lg">No Activated Bank Accounts</h3>
                <p className="text-sm text-slate-500 max-w-sm mx-auto">
                  Click the Seed Demo Workspace below to import pre-populated feeds, or register your custom SVB / Chase ledger card to get begun.
                </p>
              </div>
              <div className="flex pt-3 gap-3 justify-center">
                <button
                  type="button"
                  onClick={triggerDemoSeeding}
                  className="px-5 py-2.5 bg-indigo-600 font-bold text-white rounded-xl shadow-sm hover:bg-indigo-700 text-sm flex items-center gap-2 transition cursor-pointer"
                >
                  <RefreshCw className="w-4.5 h-4.5" />
                  Quick Seed Sample Feeds
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {bankAccounts.map((account) => {
                  const fin = getAccountFinances(account.id);
                  const isCreditCard = account.balance < 0 || account.name.toLowerCase().includes('card') || account.name.toLowerCase().includes('credit');

                  return (
                    <div 
                      key={account.id} 
                      className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs hover:shadow-md transition duration-200 flex flex-col justify-between"
                    >
                      {/* Top color tag */}
                      <div className={cn(
                        "h-1.5 w-full",
                        isCreditCard ? "bg-amber-500" : "bg-indigo-600"
                      )} />
                      
                      <div className="p-6 space-y-6 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-3">
                            <div className={cn(
                              "p-2.5 rounded-xl",
                              isCreditCard ? "bg-amber-50 text-amber-600" : "bg-indigo-50 text-indigo-600"
                            )}>
                              {isCreditCard ? <CreditCard className="w-5.5 h-5.5" /> : <Landmark className="w-5.5 h-5.5" />}
                            </div>
                            <div>
                              <h4 className="font-extrabold text-slate-900 border-none outline-none leading-snug">{account.name}</h4>
                              <p className="text-[10px] uppercase font-bold text-slate-400 mt-0.5 tracking-wider font-mono">
                                {account.bankName || 'General Bank'} • {account.accountNumber}
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* Balance Feeds comparison display */}
                        <div className="grid grid-cols-2 gap-2 bg-slate-50 border border-slate-100 p-3 rounded-lg divide-x divide-slate-200">
                          <div>
                            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wide leading-none">Amount in Bank</span>
                            <span className="block text-base font-extrabold text-slate-800 tracking-tight mt-1">
                              {formatCurrency(fin.amountInBank, account.currency)}
                            </span>
                          </div>
                          <div className="pl-3">
                            <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wide leading-none">Amount in Books</span>
                            <span className="block text-base font-extrabold text-indigo-600 tracking-tight mt-1">
                              {formatCurrency(fin.amountInBooks, account.currency)}
                            </span>
                          </div>
                        </div>

                        {/* Unreconciled count indicator */}
                        <div className="flex items-center justify-between pt-1">
                          {fin.uncategorizedCount > 0 ? (
                            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-amber-50 border border-amber-200 text-amber-700 text-[10px] font-bold rounded-md">
                              <AlertTriangle className="w-3.5 h-3.5 mt-0.5" />
                              <span>{fin.uncategorizedCount} Uncategorized Feeds</span>
                            </div>
                          ) : (
                            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-bold rounded-md">
                              <ShieldCheck className="w-3.5 h-3.5" />
                              <span>Ledgers Reconciled!</span>
                            </div>
                          )}

                          <span className="text-[10px] font-bold text-slate-400">
                            Last imported: {fin.lastImported}
                          </span>
                        </div>
                      </div>

                      {/* Footer row action buttons */}
                      <div className="border-t border-slate-100 bg-slate-50/50 p-4 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingAccount(account);
                              setIsAccountModalOpen(true);
                            }}
                            className="p-1 px-2.5 py-1.5 text-xs text-slate-500 hover:text-indigo-600 hover:bg-slate-100 border border-transparent hover:border-slate-200 rounded-lg transition"
                          >
                            <Settings className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              if (confirm(`Remove bank account "${account.name}" and delete all its historical feeds?`)) {
                                await deleteDoc(doc(db, 'bankAccounts', account.id));
                              }
                            }}
                            className="p-1 px-2 py-1.5 text-xs text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <button
                          onClick={() => {
                            setActiveAccountId(account.id);
                            // Auto select first transaction
                            const accountTx = transactions.filter(t => t.bankAccountId === account.id && t.status === 'Unreconciled' && !(t as any).isExcluded);
                            if (accountTx.length > 0) {
                              setSelectedTransactionId(accountTx[0].id);
                            }
                          }}
                          className="flex items-center gap-1.5 px-4.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs tracking-wide uppercase rounded-xl transition shadow-xs hover:shadow-md cursor-pointer"
                        >
                          <span>Manage Feeds</span>
                          <ChevronRight className="w-3.5 h-3.5 text-indigo-200" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Transactions table below representing general transactions tracker log */}
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-lg">General Transactions Log</h3>
                    <p className="text-slate-400 text-xs mt-0.5">Summary of statement imports sorted by most recent date.</p>
                  </div>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Search general feed description..." 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none w-64 text-slate-700"
                    />
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm text-slate-600">
                    <thead className="bg-slate-50 border-b border-slate-100 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      <tr>
                        <th className="px-6 py-3">Date</th>
                        <th className="px-6 py-3">Account</th>
                        <th className="px-6 py-3">Description Statement line</th>
                        <th className="px-6 py-3">Flow Type</th>
                        <th className="px-6 py-3">Import Amount</th>
                        <th className="px-6 py-3">Reconciliation Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {transactions.filter(t => t.description.toLowerCase().includes(searchTerm.toLowerCase())).slice(0, 15).map(tx => {
                        const accName = bankAccounts.find(a => a.id === tx.bankAccountId)?.name || 'Direct feed';
                        return (
                          <tr key={tx.id} className="hover:bg-slate-50/50 transition">
                            <td className="px-6 py-4 text-xs font-mono text-slate-400 font-medium">
                              {formatDate(tx.date)}
                            </td>
                            <td className="px-6 py-4 font-bold text-xs text-slate-800">
                              {accName}
                            </td>
                            <td className="px-6 py-4 font-semibold text-slate-800 max-w-xs truncate" title={tx.description}>
                              {tx.description}
                            </td>
                            <td className="px-6 py-4">
                              <span className={cn(
                                "inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider",
                                tx.amount > 0 ? "bg-emerald-50 text-emerald-700 font-bold" : "bg-slate-150 text-slate-700 font-semibold"
                              )}>
                                {tx.amount > 0 ? (
                                  <>
                                    <ArrowDownLeft className="w-3 h-3" />
                                    <span>Deposit / Cr</span>
                                  </>
                                ) : (
                                  <>
                                    <ArrowUpRight className="w-3 h-3" />
                                    <span>Withdrawal / Dr</span>
                                  </>
                                )}
                              </span>
                            </td>
                            <td className={cn(
                              "px-6 py-4 text-xs font-extrabold tracking-tight",
                              tx.amount > 0 ? "text-emerald-600" : "text-slate-900"
                            )}>
                              {formatCurrency(tx.amount)}
                            </td>
                            <td className="px-6 py-4">
                              <span className={cn(
                                "inline-flex items-center gap-1.5 px-2.5 py-1 text-[9px] font-bold uppercase rounded-md border",
                                tx.status === 'Reconciled' 
                                  ? "bg-emerald-50/50 border-emerald-100 text-emerald-700" 
                                  : "bg-amber-50/50 border-amber-100 text-amber-700"
                              )}>
                                <span className={cn("w-1.5 h-1.5 rounded-full", tx.status === 'Reconciled' ? "bg-emerald-500" : "bg-amber-500")} />
                                <span>{tx.status}</span>
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Part 2: Inside Bank Account View (Split-Screen Layout) */
        <div className="space-y-6 animate-fade-in text-slate-800">
          
          {/* Top Breadcrumb row */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div className="flex items-center gap-3">
              <button 
                onClick={() => {
                  setActiveAccountId(null);
                  setSelectedTransactionId(null);
                }}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-extrabold text-xs uppercase tracking-wide rounded-lg transition flex items-center gap-1"
              >
                ← Back to overview
              </button>
              <div className="h-4 w-[1px] bg-slate-300" />
              <div>
                <h2 className="font-extrabold text-lg text-slate-950 flex items-center gap-2">
                  {selectedAccount?.name}
                </h2>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  {selectedAccount?.bankName} • {selectedAccount?.accountNumber}
                </p>
              </div>
            </div>

            {/* Action Buttons Row */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsImportModalOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-2 border border-slate-200 hover:border-indigo-400 bg-white text-slate-700 text-xs font-semibold rounded-lg transition cursor-pointer"
              >
                <Upload className="w-4 h-4 text-slate-500" />
                <span>Import Statement</span>
              </button>

              <button
                onClick={() => {
                  setManualTxType('Withdrawal');
                  setIsTransactionModalOpen(true);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 border border-slate-200 hover:border-indigo-400 bg-white text-slate-700 text-xs font-semibold rounded-lg transition cursor-pointer"
              >
                <Plus className="w-4 h-4 text-slate-500" />
                <span>Add Transaction</span>
              </button>

              <button
                onClick={() => {
                  if (activeAccountId) {
                    const acc = bankAccounts.find(a => a.id === activeAccountId);
                    if (acc) {
                      setEditingAccount(acc);
                      setIsAccountModalOpen(true);
                    }
                  }
                }}
                className="p-2 border border-slate-200 text-slate-500 hover:text-indigo-600 bg-white hover:bg-slate-50 rounded-lg transition cursor-pointer"
                title="Bank Settings"
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Top Metrics Cards Row representing Account balance compare feed */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-50 text-slate-800 p-4 border border-slate-200 rounded-xl">
              <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none">Account Balance (Amount in Bank)</span>
              <p className="text-xl font-black text-slate-900 tracking-tight mt-1.5">
                {formatCurrency(activeFinance?.amountInBank || 0, selectedAccount?.currency)}
              </p>
              <span className="text-[9px] text-slate-400 mt-1 block">Dynamic Statement Total feed</span>
            </div>

            <div className="bg-indigo-50/30 border border-indigo-100 p-4 rounded-xl">
              <span className="block text-[9px] font-bold text-indigo-500 uppercase tracking-widest leading-none">Ledger Balance (Amount in Books)</span>
              <p className="text-xl font-black text-indigo-700 tracking-tight mt-1.5">
                {formatCurrency(activeFinance?.amountInBooks || 0, selectedAccount?.currency)}
              </p>
              <span className="text-[9px] text-indigo-700 bg-indigo-50 px-1 py-0.5 rounded border border-indigo-100 inline-block mt-1 font-bold">Starts reconciled ledger</span>
            </div>

            <div className="bg-white text-slate-800 p-4 border border-slate-200 rounded-xl">
              <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none">Unreconciled Feed Lines</span>
              <p className="text-xl font-black text-slate-900 tracking-tight mt-1.5">
                {activeFinance?.uncategorizedCount} Lines
              </p>
              <span className="text-[9px] text-slate-400 mt-1 block">Awaiting automatic matching categorization</span>
            </div>

            <div className="bg-white text-slate-800 p-4 border border-slate-200 rounded-xl">
              <span className="block text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none">Last Statements Sync</span>
              <p className="text-xl font-black text-slate-900 tracking-tight mt-1.5">
                {activeFinance?.lastImported}
              </p>
              <span className="text-[9px] text-emerald-600 font-bold mt-1 block flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>Live Feed Active</span>
              </span>
            </div>
          </div>

          {/* Advanced Books Dual-Tab Control Bar */}
          <div className="flex border-b border-slate-200 bg-slate-50/50 p-1.5 rounded-lg border">
            <button
              onClick={() => {
                setDetailTab('uncategorized');
                setSelectedTransactionId(null);
              }}
              className={cn(
                "px-5 py-2 rounded-lg text-xs font-bold transition flex items-center gap-2 uppercase tracking-wider",
                detailTab === 'uncategorized' 
                  ? "bg-white text-indigo-600 shadow-xs border" 
                  : "text-slate-500 hover:text-slate-800"
              )}
            >
              <span>Uncategorized Feed</span>
              {activeFinance && activeFinance.uncategorizedCount > 0 && (
                <span className="px-1.5 py-0.5 text-[9px] bg-amber-500 text-white font-extrabold rounded-md">
                  {activeFinance.uncategorizedCount}
                </span>
              )}
            </button>

            <button
              onClick={() => {
                setDetailTab('all');
                setSelectedTransactionId(null);
              }}
              className={cn(
                "px-5 py-2 rounded-lg text-xs font-bold transition uppercase tracking-wider",
                detailTab === 'all' 
                  ? "bg-white text-indigo-600 shadow-xs border" 
                  : "text-slate-500 hover:text-slate-800"
              )}
            >
              All Transactions
            </button>

            <button
              onClick={() => {
                setDetailTab('excluded');
                setSelectedTransactionId(null);
              }}
              className={cn(
                "px-5 py-2 rounded-lg text-xs font-bold transition uppercase tracking-wider flex items-center gap-1.5",
                detailTab === 'excluded' 
                  ? "bg-white text-indigo-600 shadow-xs border" 
                  : "text-slate-500 hover:text-slate-800"
              )}
            >
              Excluded Feed
              {selectedAccountTx.filter(t => (t as any).isExcluded).length > 0 && (
                <span className="px-1.5 py-0.5 text-[9px] bg-slate-400 text-white font-extrabold rounded-md">
                  {selectedAccountTx.filter(t => (t as any).isExcluded).length}
                </span>
              )}
            </button>

            <button
              onClick={() => {
                setDetailTab('rules');
                setSelectedTransactionId(null);
              }}
              className={cn(
                "px-5 py-2 rounded-lg text-xs font-bold transition uppercase tracking-wider flex items-center gap-1.5",
                detailTab === 'rules' 
                  ? "bg-white text-indigo-600 shadow-xs border" 
                  : "text-slate-500 hover:text-slate-800"
              )}
            >
              <Zap className="w-3.5 h-3.5 text-indigo-500" />
              Automated Feed Rules
            </button>
          </div>

          {/* Dynamic Tab Body Renderings */}
          {detailTab === 'rules' ? (
            /* Rules list setup view */
            <div className="bg-white border rounded-xl p-6 space-y-6">
              <div className="flex flex-col md:flex-row justify-between items-start gap-4 pb-4 border-b">
                <div>
                  <h4 className="font-extrabold text-slate-900 flex items-center gap-1.5">
                    <Zap className="w-5 h-5 text-indigo-600" />
                    Automated Reconciliation Mapping Rules
                  </h4>
                  <p className="text-slate-400 text-xs mt-1">
                    When dynamic statements import, transactions containing the matching keywords are prefilled in categorization form automatically.
                  </p>
                </div>
              </div>

              {/* Add New Rule Inline form */}
              <form onSubmit={handleAddNewRule} className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-50 border border-slate-200 p-4 rounded-xl">
                <div>
                  <label className="block text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">If Description Fits</label>
                  <input
                    type="text"
                    required
                    value={newRuleKeyword}
                    onChange={(e) => setNewRuleKeyword(e.target.value)}
                    placeholder="e.g. Uber, AWS, Chevron"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded outline-none text-xs bg-white focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">Map to Account Code</label>
                  <input
                    type="text"
                    required
                    value={newRuleAccountCode}
                    onChange={(e) => setNewRuleAccountCode(e.target.value)}
                    placeholder="e.g. 5200"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded outline-none text-xs bg-white focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">Account Label Name</label>
                  <input
                    type="text"
                    required
                    value={newRuleAccountName}
                    onChange={(e) => setNewRuleAccountName(e.target.value)}
                    placeholder="e.g. Travel Expenses"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded outline-none text-xs bg-white focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full bg-slate-900 border border-slate-850 hover:bg-slate-800 text-white font-bold py-1.5 rounded text-xs tracking-wider uppercase transition cursor-pointer"
                  >
                    Add Automation Map
                  </button>
                </div>
              </form>

              {/* Active Rules Mapping */}
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <table className="w-full text-left text-xs text-slate-600">
                  <thead className="bg-slate-50 border-b text-[10px] font-bold text-slate-400 uppercase tracking-wide">
                    <tr>
                      <th className="px-6 py-3">Import Rule Phrase Match</th>
                      <th className="px-6 py-3">Bookkeeping Target Account Destination</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3">Removals</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {rules.map(rule => (
                      <tr key={rule.id} className="hover:bg-slate-50">
                        <td className="px-6 py-4">
                          <span className="font-mono bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded border border-indigo-100 font-extrabold">
                            Contains "{rule.keyword}"
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-bold text-slate-800 text-xs text-slate-850">
                            {rule.accountCode} - {rule.accountName}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded w-max">
                            <Check className="w-3.5 h-3.5" />
                            <span>Active Trigger</span>
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <button
                            type="button"
                            onClick={() => handleDeleteRule(rule.id)}
                            className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            /* Part 3: Unique Match & Categorize Interface (Two-Column View) */
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              
              {/* Left Pane (Uncategorized Statements) - Span 5 */}
              <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
                
                {/* Search / Filter header bar */}
                <div className="p-4 border-b bg-slate-50/50 flex items-center justify-between gap-3">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Filter feeds by keyword..."
                      value={leftPaneSearch}
                      onChange={(e) => setLeftPaneSearch(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-300 roundedoutline-none focus:ring-1 focus:ring-indigo-500 text-xs outline-none"
                    />
                  </div>

                  <select
                    value={amountFilter}
                    onChange={(e) => setAmountFilter(e.target.value as any)}
                    className="px-2 py-1.5 border border-slate-300 bg-white rounded-md text-[10px] font-bold uppercase tracking-wider outline-none text-slate-600"
                  >
                    <option value="all">All Flows</option>
                    <option value="deposits">Deposits (+)</option>
                    <option value="withdrawals">Withdrawals (-)</option>
                  </select>
                </div>

                {/* Left vertical transactions list */}
                {leftPaneTxList.length === 0 ? (
                  <div className="p-12 text-center text-slate-400 space-y-2">
                    <Check className="w-10 h-10 text-slate-300 mx-auto" />
                    <p className="font-bold text-slate-700 text-sm">No Statements Found</p>
                    <p className="text-xs text-slate-400">
                      All imported statements in this filtered bracket are fully accounted for or excluded.
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
                    {leftPaneTxList.map((tx) => {
                      const isSelected = tx.id === selectedTransactionId;
                      const isDeposit = tx.amount > 0;
                      const hasRuleSuggestion = getAutomatedRuleSuggestion(tx.description);

                      return (
                        <div
                          key={tx.id}
                          onClick={() => setSelectedTransactionId(tx.id)}
                          className={cn(
                            "p-4 cursor-pointer transition flex items-start justify-between gap-4 border-l-4",
                            isSelected 
                              ? "bg-indigo-50/45 border-l-indigo-600" 
                              : "hover:bg-slate-50 border-l-transparent"
                          )}
                        >
                          <div className="space-y-1 min-w-0">
                            <span className="block text-[10px] font-bold font-mono text-slate-400">
                              {new Date(tx.date).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                            </span>
                            <span className="block font-bold text-xs text-slate-800 leading-tight truncate pr-4" title={tx.description}>
                              {tx.description}
                            </span>
                            
                            {/* Auto-matching Rule indicator banner badges */}
                            {hasRuleSuggestion && (
                              <div className="inline-flex items-center gap-1 bg-emerald-50 px-1.5 py-0.5 border border-emerald-100 text-emerald-800 rounded font-semibold text-[9px] uppercase tracking-wide">
                                <Zap className="w-3 h-3 text-emerald-600 animate-pulse" />
                                <span>Auto-Rule: {hasRuleSuggestion.accountName}</span>
                              </div>
                            )}

                            {tx.status === 'Reconciled' && (
                              <span className="inline-block text-[9px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 uppercase tracking-widest leading-none">
                                Sorted Reconciled
                              </span>
                            )}
                          </div>

                          <div className="text-right shrink-0 space-y-2">
                            <span className={cn(
                              "block text-xs font-black tracking-tight",
                              isDeposit ? "text-emerald-600" : "text-slate-900"
                            )}>
                              {isDeposit ? `+${formatCurrency(tx.amount)}` : formatCurrency(tx.amount)}
                            </span>

                            {/* Drop Transaction action for discrepancy exclusion */}
                            {detailTab === 'uncategorized' && (
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleExclusionState(tx.id, true);
                                }}
                                className="block text-[9px] text-slate-400 hover:text-rose-600 ml-auto font-bold uppercase tracking-wider cursor-pointer"
                                title="Exclude statement raw feed"
                              >
                                Exclude
                              </button>
                            )}

                            {/* Restore to feed action under EXCLUDED Tab */}
                            {detailTab === 'excluded' && (
                              <div className="space-x-1.5">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleExclusionState(tx.id, false);
                                  }}
                                  className="text-[9px] text-indigo-600 hover:underline font-bold uppercase cursor-pointer"
                                >
                                  Restore
                                </button>
                                <button
                                  type="button"
                                  onClick={async (e) => {
                                    e.stopPropagation();
                                    if (confirm('Permanently delete this imported statement entry?')) {
                                      await deleteDoc(doc(db, 'bankTransactions', tx.id));
                                    }
                                  }}
                                  className="text-[9px] text-rose-500 hover:underline font-bold uppercase cursor-pointer"
                                >
                                  Delete
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Right Pane (Action/Matching Console) - Span 7 */}
              <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs min-h-[450px]">
                {!activeTx ? (
                  <div className="p-16 text-center text-slate-400 space-y-4 flex flex-col justify-center items-center h-full min-h-[450px]">
                    <div className="p-4 bg-slate-50 border rounded-full text-slate-300">
                      <FileCheck className="w-12 h-12" />
                    </div>
                    <div className="max-w-xs space-y-1">
                      <h3 className="font-extrabold text-slate-700 text-sm">Review Statement Record Details</h3>
                      <p className="text-xs text-slate-400">
                        Choose a bank statement transaction line from the left sidebar to perform instant system ledger matches or key-in custom accounts manually.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="animate-fade-in p-6 space-y-6">
                    
                    {/* Header summary of currently select transaction inside right pane */}
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Selected Import File Row</span>
                        <span className={cn(
                          "px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wide",
                          activeTx.status === 'Reconciled' ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                        )}>
                          {activeTx.status}
                        </span>
                      </div>

                      <div className="flex justify-between items-start gap-4">
                        <div className="space-y-1">
                          <h4 className="font-extrabold text-slate-900 text-sm leading-snug">
                            {activeTx.description}
                          </h4>
                          <span className="block text-[10px] text-slate-400 font-bold uppercase tracking-wider font-mono">
                            Transacted On: {formatDate(activeTx.date)}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className={cn(
                            "text-lg font-black tracking-tight block",
                            activeTx.amount > 0 ? "text-emerald-600" : "text-slate-950"
                          )}>
                            {activeTx.amount > 0 ? `+${formatCurrency(activeTx.amount)}` : formatCurrency(activeTx.amount)}
                          </span>
                          <span className="text-[10px] text-slate-400 font-semibold block uppercase">
                            {activeTx.amount > 0 ? 'Inward Flow' : 'Outward Flow'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Matching workflow selection tabs */}
                    <div className="flex border-b border-slate-200 gap-4">
                      <button
                        type="button"
                        onClick={() => setMatchingTab('match')}
                        className={cn(
                          "pb-2 text-xs font-bold border-b-2 transition uppercase tracking-wider",
                          matchingTab === 'match'
                            ? "border-indigo-600 text-indigo-600 font-extrabold"
                            : "border-transparent text-slate-500 hover:text-slate-800"
                        )}
                      >
                        Match Transaction
                      </button>

                      <button
                        type="button"
                        onClick={() => setMatchingTab('categorize')}
                        className={cn(
                          "pb-2 text-xs font-bold border-b-2 transition uppercase tracking-wider",
                          matchingTab === 'categorize'
                            ? "border-indigo-600 text-indigo-600 font-extrabold"
                            : "border-transparent text-slate-500 hover:text-slate-800"
                        )}
                      >
                        Categorize Manually
                      </button>
                    </div>

                    {/* Tab 1 matching screen */}
                    {matchingTab === 'match' && (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center bg-indigo-50/40 p-3 rounded-lg border border-indigo-100/50">
                          <span className="text-slate-600 text-xs font-medium">Seeking matching amount of:</span>
                          <span className="font-extrabold text-xs text-indigo-700 font-mono">
                            {formatCurrency(Math.abs(activeTx.amount))}
                          </span>
                        </div>

                        {matchCandidates.length === 0 ? (
                          <div className="text-center py-10 bg-slate-50 border border-dashed rounded-xl border-slate-200">
                            <Info className="w-8 h-8 text-slate-450 mx-auto mb-2 text-slate-400" />
                            <h5 className="font-bold text-slate-700 text-xs">No System Documents Registered</h5>
                            <p className="text-[11px] text-slate-400 mt-1 max-w-xs mx-auto">
                              No invoices / bills matching this exact denomination are logged in the database yet. Click "Categorize Manually" to map to account manually.
                            </p>
                          </div>
                        ) : (
                          <div className="space-y-3">
                            <h5 className="font-bold text-slate-450 text-[10px] uppercase tracking-wider block">Candidate System Match Results</h5>
                            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                              {matchCandidates.map((cand) => {
                                return (
                                  <div 
                                    key={cand.id}
                                    className={cn(
                                      "border p-4 rounded-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-indigo-400 transition",
                                      cand.exactMatch ? "bg-emerald-50/20 border-emerald-200" : "bg-white border-slate-200"
                                    )}
                                  >
                                    <div className="min-w-0">
                                      <div className="flex items-center gap-1.5 flex-wrap">
                                        <span className="text-xs font-bold text-indigo-600 font-semibold">{cand.number}</span>
                                        <span className="px-1.5 py-0.5 text-[9px] bg-slate-100 text-slate-500 rounded font-bold">
                                          {cand.type}
                                        </span>
                                        {cand.exactMatch && (
                                          <span className="px-1.5 py-0.5 text-[9px] bg-emerald-500 text-white rounded font-extrabold uppercase tracking-wide">
                                            Exact Amount Match!
                                          </span>
                                        )}
                                      </div>
                                      <h6 className="font-bold text-slate-800 text-xs mt-1 truncate">{cand.partnerName}</h6>
                                      <p className="text-[9px] text-slate-400 mt-0.5 font-bold">Date: {cand.date}</p>
                                    </div>

                                    <div className="text-right shrink-0 flex items-center gap-4">
                                      <div>
                                        <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider leading-none">Registered Price</span>
                                        <span className="block text-sm font-black text-slate-800 font-mono mt-0.5">
                                          {formatCurrency(cand.total)}
                                        </span>
                                      </div>

                                      <button
                                        type="button"
                                        onClick={() => confirmMatchRow(cand.id, cand.type)}
                                        className="px-4.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer"
                                      >
                                        Match & Clear
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Tab 2 manual categorizing manual setup form */}
                    {matchingTab === 'categorize' && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">
                              Select Expense / Income Account *
                            </label>
                            <AccountDropdownSelector
                              accountsList={accounts}
                              selectedAccountId={catAccountId}
                              filterByType={['Expense', 'Income', 'Asset', 'Liability', 'Equity']}
                              placeholder="-- Associate Ledger Account / اربط الحساب المالي --"
                              className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-xs bg-white text-slate-700 font-semibold focus:ring-2 focus:ring-indigo-500 text-right"
                              onAccountChange={(newAccountId) => {
                                setCatAccountId(newAccountId);
                                const found = accounts.find(acc => acc.id === newAccountId);
                                setCatAccountName(found ? found.name : 'Custom mapped account');
                              }}
                            />
                          </div>

                          <div>
                            <label className="block text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">
                              Contact / Payee Name (Customer/Vendor)
                            </label>
                            <input
                              type="text"
                              value={catPayeeName}
                              onChange={(e) => setCatPayeeName(e.target.value)}
                              placeholder="e.g. Uber Technologies, Amazon US"
                              className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-xs bg-white text-slate-700 focus:ring-2 focus:ring-indigo-500"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">
                              Tax Treatment Model
                            </label>
                            <select
                              value={catTaxRate}
                              onChange={(e) => setCatTaxRate(Number(e.target.value))}
                              className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-xs bg-white text-slate-700 focus:ring-2 focus:ring-indigo-500"
                            >
                              <option value="0">Tax Exempt / Out of Scope (0%)</option>
                              <option value="5">GST Standard Rate (5%)</option>
                              <option value="15">VAT Standard Levy (15%)</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">
                              Reconciliation Memo Reference
                            </label>
                            <input
                              type="text"
                              value={catReference}
                              onChange={(e) => setCatReference(e.target.value)}
                              placeholder="e.g. Conf call chairs, lunch billing"
                              className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-xs bg-white text-slate-700 focus:ring-2 focus:ring-indigo-500"
                            />
                          </div>
                        </div>

                        <div className="pt-4 border-t flex justify-end">
                          <button
                            type="button"
                            onClick={saveAndReconcileManual}
                            className="bg-indigo-600 text-white font-extrabold text-xs tracking-wider uppercase px-6 py-3 rounded-xl hover:bg-indigo-700 transition shadow-xs hover:shadow-md cursor-pointer"
                          >
                            Save & Reconcile Account
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* MODAL 1: Add or Edit Bank Account */}
      <Modal
        isOpen={isAccountModalOpen}
        onClose={() => {
          setIsAccountModalOpen(false);
          setEditingAccount(null);
        }}
        title={editingAccount ? "Edit Bank Account Panel" : "Register New Bank Account"}
      >
        <form onSubmit={handleSaveAccount} className="space-y-5">
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-500">
            Setup activated checking or credit ledger profiles. Mashed codes are shown on general dashboards.
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Display Account Name *</label>
            <input 
              name="name" 
              type="text" 
              required 
              defaultValue={editingAccount?.name}
              placeholder="e.g. SVB Payroll checkings" 
              className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-sm bg-white text-slate-800 font-medium focus:ring-2 focus:ring-indigo-500" 
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Bank Name / Issuer *</label>
              <input 
                name="bankName" 
                type="text" 
                required 
                defaultValue={editingAccount?.bankName}
                placeholder="e.g. Chase Bank" 
                className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-sm bg-white text-slate-800 focus:ring-2 focus:ring-indigo-500" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Last 4 Digits of Acc *</label>
              <input 
                name="accountNumber" 
                type="text" 
                maxLength={4}
                required 
                defaultValue={editingAccount?.accountNumber ? editingAccount.accountNumber.replace('•••• ', '') : ''}
                placeholder="e.g. 9412" 
                className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-sm bg-white text-slate-800 font-mono focus:ring-2 focus:ring-indigo-500" 
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Initial Base Starting Balance</label>
              <input 
                name="balance" 
                type="number" 
                step="0.01"
                required 
                defaultValue={editingAccount?.balance || 0}
                placeholder="0.00" 
                className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-sm bg-white text-slate-800 font-bold focus:ring-2 focus:ring-indigo-500" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Base Currency</label>
              <select 
                name="currency" 
                defaultValue={editingAccount?.currency || 'USD'}
                className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-sm bg-white text-slate-850 font-medium focus:ring-2 focus:ring-indigo-500"
              >
                <option value="USD">USD - US Dollars</option>
                <option value="EUR">EUR - Euro</option>
                <option value="GBP">GBP - British Pounds</option>
                <option value="YER">YER - Yemeni Rial</option>
              </select>
            </div>
          </div>

          <div className="flex pt-4 border-t gap-3">
            <button 
              type="button" 
              onClick={() => setIsAccountModalOpen(false)}
              className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold uppercase tracking-wider rounded-lg transition"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              disabled={isSaving}
              className="flex-1 py-2 bg-indigo-600 text-white text-xs font-bold uppercase tracking-wider rounded-lg transition hover:bg-indigo-700 flex items-center justify-center gap-1.5"
            >
              {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>{isSaving ? "Saving Configuration..." : "Register Profile"}</span>
            </button>
          </div>
        </form>
      </Modal>

      {/* MODAL 2: Add Manual Bank Transaction */}
      <Modal
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
        title="Key Manual Statement Row"
      >
        <form onSubmit={handleCreateManualTx} className="space-y-4">
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-500">
            Write manual transactions directly to feed. Reconciles via Match Console under active Account dashboards.
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Flow Type</label>
              <select 
                value={manualTxType}
                onChange={(e) => setManualTxType(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 bg-white rounded outline-none text-xs focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Withdrawal">Withdrawal / Debit (Outflow)</option>
                <option value="Deposit">Deposit / Credit (Inflow)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Transaction date *</label>
              <input
                name="date"
                type="date"
                required
                defaultValue={new Date().toISOString().split('T')[0]}
                className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-xs bg-white text-slate-840 focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Raw Feed Description *</label>
            <input
              name="description"
              type="text"
              required
              placeholder="e.g. AWS hosting, customer wire transfer"
              className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-xs bg-white text-slate-840 focus:ring-2 focus:ring-indigo-500 font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">Statement Amount *</label>
            <input
              name="amount"
              type="number"
              step="0.01"
              required
              placeholder="0.00"
              className="w-full px-3 py-2 border border-slate-300 rounded outline-none text-xs bg-white text-slate-840 focus:ring-2 focus:ring-indigo-500 font-black text-slate-900"
            />
          </div>

          <div className="flex pt-4 border-t gap-3">
            <button
              type="button"
              onClick={() => setIsTransactionModalOpen(false)}
              className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold uppercase tracking-wider rounded-lg transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex-1 py-2 bg-indigo-600 text-white text-xs font-bold uppercase tracking-wider rounded-lg transition hover:bg-indigo-700 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
              <span>{isSaving ? "Posting Statement..." : "Post Statement"}</span>
            </button>
          </div>
        </form>
      </Modal>

      {/* MODAL 3: Import Statement Dropdown Simulator */}
      <Modal
        isOpen={isImportModalOpen}
        onClose={() => {
          setIsImportModalOpen(false);
          setIsDragActive(false);
          setUploadedFileName(null);
          setParsedTransactions([]);
        }}
        title="Statement Feed Importer"
      >
        <div className="space-y-6 text-slate-800">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <h5 className="font-bold text-slate-800 text-xs uppercase tracking-wide flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-indigo-500" />
                Import Statement (XLSX / CSV)
              </h5>
              
              {/* DOWNLOAD COMPLIANT STATIC TEMPLATE */}
              <button
                type="button"
                onClick={downloadSampleTemplate}
                className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-extrabold text-[11px] rounded transition shadow-2xs hover:shadow-xs flex items-center gap-1 cursor-pointer select-none"
                title="Download preformatted Excel template"
              >
                📥 Download Sample Template (تحميل ملف نموذج)
              </button>
            </div>
            
            <p className="text-slate-500 text-xs leading-relaxed">
              Upload bank checking or credit card transaction spreadsheets immediately. The parser will capture <strong>Date</strong>, <strong>Description</strong>, <strong>Reference</strong>, <strong>Amount_Debit/Credit</strong> columns to reconcile ledgers instantly.
            </p>
          </div>

          {/* EXCLUSIVE DROPZONE ZONE OR PREVIEW GRID */}
          {!uploadedFileName ? (
            <div
              onDragEnter={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsDragActive(true);
              }}
              onDragOver={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsDragActive(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsDragActive(false);
              }}
              onDrop={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsDragActive(false);
                const files = e.dataTransfer.files;
                if (files && files.length > 0) {
                  const file = files[0];
                  const ext = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
                  if (ext === '.xlsx' || ext === '.csv') {
                    handleFileImport(file);
                  } else {
                    alert('Unsupported file type. Please upload spreadsheet file formats (.xlsx or .csv) only.');
                  }
                }
              }}
              className={cn(
                "relative rounded-2xl border-2 border-dashed p-8 text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-4 select-none min-h-[180px]",
                isDragActive 
                  ? "border-indigo-500 bg-indigo-50/40 shadow-xs" 
                  : "border-slate-300 hover:border-indigo-400 bg-white"
              )}
            >
              <input
                type="file"
                id="bank-file-upload-input"
                accept=".csv, .xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, text/csv"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                onChange={(e) => {
                  const files = e.target.files;
                  if (files && files.length > 0) {
                    handleFileImport(files[0]);
                  }
                }}
              />
              
              {isImporting ? (
                <div className="flex flex-col items-center justify-center gap-2">
                  <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
                  <p className="text-xs font-bold text-slate-700 uppercase tracking-widest animate-pulse">
                    Processing matrix tables...
                  </p>
                </div>
              ) : (
                <div className="space-y-2 pointer-events-none">
                  <div className="w-12 h-12 bg-slate-50 border border-slate-200 rounded-full flex items-center justify-center mx-auto text-slate-400">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm font-extrabold text-slate-800">
                      Drag & Drop transaction files here
                    </p>
                    <p className="text-xs text-slate-400 font-medium">
                      or click to browse your local device
                    </p>
                  </div>
                  <span className="inline-block text-[10px] text-slate-400 font-bold bg-slate-100 border px-2 py-0.5 rounded font-mono uppercase tracking-wider">
                    Supports CSV, XLSX up to 10MB
                  </span>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-5 space-y-4 animate-fade-in text-slate-800">
              <div className="flex items-start gap-3">
                <div className="bg-emerald-100 text-emerald-700 p-2 rounded-xl mt-0.5">
                  <Check className="w-5 h-5 text-emerald-650" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs uppercase font-black text-emerald-800/80 tracking-widest">Active File Loaded Successfully</p>
                  <p className="text-sm font-extrabold text-slate-900 truncate mt-0.5">{uploadedFileName}</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Correctly parsed <strong>{parsedTransactions.length}</strong> rows into system-compliant mapping keys: <code>[date, description, reference, debit, credit, balance]</code>.
                  </p>
                </div>
              </div>

              {/* Parsed List Micro Preview Table */}
              <div className="border border-emerald-200/60 bg-white rounded-xl overflow-hidden shadow-2xs">
                <div className="max-h-36 overflow-y-auto">
                  <table className="w-full text-left text-[10px] text-slate-600 font-mono">
                    <thead className="bg-slate-50 text-slate-500 border-b border-slate-100 font-bold uppercase select-none">
                      <tr>
                        <th className="px-3 py-2">Date</th>
                        <th className="px-3 py-2">Description</th>
                        <th className="px-3 py-2 text-right">Debit</th>
                        <th className="px-3 py-2 text-right">Credit</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {parsedTransactions.slice(0, 5).map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50">
                          <td className="px-3 py-1.5 whitespace-nowrap">{row.date}</td>
                          <td className="px-3 py-1.5 truncate max-w-[140px]" title={row.description}>{row.description}</td>
                          <td className="px-3 py-1.5 text-right font-extrabold text-emerald-600">{row.debit > 0 ? `$${row.debit.toFixed(2)}` : '-'}</td>
                          <td className="px-3 py-1.5 text-right font-extrabold text-rose-600">{row.credit > 0 ? `$${row.credit.toFixed(2)}` : '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {parsedTransactions.length > 5 && (
                    <div className="p-2 bg-slate-50 text-center border-t text-[9px] text-slate-400 font-bold uppercase select-none">
                      And {parsedTransactions.length - 5} more transactions...
                    </div>
                  )}
                </div>
              </div>

              {/* Action grid */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={commitParsedTransactions}
                  disabled={isImporting}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-wider rounded-xl transition shadow-md hover:shadow-lg flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isImporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  <span>{isImporting ? 'Posting Matrix...' : 'Commit & Import to Feed'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setUploadedFileName(null);
                    setParsedTransactions([]);
                  }}
                  className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider rounded-xl border border-slate-200 transition cursor-pointer"
                >
                  Retry File
                </button>
              </div>
            </div>
          )}

          {/* SIMULATE FEED OPTION SECTION FOR SAFETY IN TRIAL RUNS */}
          <div className="relative flex py-2 items-center">
            <div className="flex-grow border-t border-slate-200"></div>
            <span className="flex-shrink mx-4 text-[10px] text-slate-400 font-extrabold uppercase tracking-widest bg-white px-2">
              Or Sandbox Fast Trial
            </span>
            <div className="flex-grow border-t border-slate-200"></div>
          </div>

          <div className="space-y-2">
            <button
              onClick={() => handleSimulateStatementImport('may_2026')}
              disabled={isImporting}
              className="w-full py-4 px-4 border border-indigo-200 hover:border-indigo-400 bg-indigo-50/20 hover:bg-indigo-50 rounded-xl text-left transition flex items-center justify-between gap-4 select-none cursor-pointer"
            >
              <div className="space-y-1">
                <span className="block text-xs font-extrabold text-indigo-900 uppercase">May Monthly Checks Feed</span>
                <span className="block text-[11px] text-indigo-600 leading-normal">
                  Imports 5 realistic SVB transactions (Stripe wire, Amazon procurement, Uber and Starbucks slips).
                </span>
              </div>
              <ChevronRight className="w-5 h-5 text-indigo-500 shrink-0" />
            </button>
          </div>

          <div className="border-t pt-4 flex justify-end">
            <button
              type="button"
              onClick={() => {
                setIsImportModalOpen(false);
                setIsDragActive(false);
                setUploadedFileName(null);
                setParsedTransactions([]);
              }}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs uppercase tracking-wider rounded-xl transition cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </Modal>

    </div>
  );
}
