import React from 'react';
import { useTranslation } from 'react-i18next';
import { Account, AccountType } from '../types';
import { SEEDED_ACCOUNTS, getMergedAccounts } from '../data/initialData';
import { formatCurrency, cn, getLocalizedName, getLocalizedLabel, getLocalizedField } from '../lib/utils';
import { Plus, Filter, Download, Loader2, ChevronRight, ChevronDown, FolderTree, UploadCloud } from 'lucide-react';
import Modal from '../components/Modal';
import ImportModal from '../components/ImportModal';
import { exportToExcel, exportToPDF } from '../utils/exportImport';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc,
  deleteDoc,
  doc,
  query, 
  where, 
  serverTimestamp,
  getDocs,
  limit
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';
import { useAuthStore } from '../store/useAuthStore';
import { motion, AnimatePresence } from 'motion/react';
import { Eye, Edit2, Trash2, X, Check, Search as SearchIcon, Lock } from 'lucide-react';
import { db, collection, addDoc, getDocs, updateDoc, deleteDoc, onSnapshot, query, where, serverTimestamp, doc } from '../firebase';

const CORE_SYSTEM_ACCOUNTS = [
  // 1. ASSETS
  { code: '1000', name: 'الأصول (Assets)', type: 'Asset', status: 'active', parentId: 'root', description: 'أصول المنشأة والموارد الاقتصادية والتشغيلية' },
  { code: '1100', name: 'الذمم المدينة - العملاء (Accounts Receivable)', type: 'Asset', status: 'active', parentCode: '1000', description: 'العملاء والذمم المدينة التجارية النشطة المتصلة بالفواتير والمبيعات' },
  { code: '1200', name: 'حساب البنك الرئيسي (Bank Account)', type: 'Asset', status: 'active', parentCode: '1000', description: 'الحساب الجاري البنكي الرئيسي للتسويات والعمليات المصرفية والمدفوعات' },
  { code: '1300', name: 'الصندوق / النقدية (Cash on Hand)', type: 'Asset', status: 'active', parentCode: '1000', description: 'النقدية المقبوضة والجاهزة للتسويات بالخزائن والصناديق' },
  { code: '1400', name: 'مخزون البضائع (Inventory Asset)', type: 'Asset', status: 'active', parentCode: '1000', description: 'مخزون السلع المتاحة للبيع وفق تقييم Costing FIFO/WAC' },

  // 2. LIABILITIES
  { code: '2000', name: 'الالتزامات الخصوم (Liabilities)', type: 'LIABILITY', status: 'ACTIVE', parentId: 'root', description: 'الالتزامات والخصوم المتداولة وغير المتداولة المطالب بها' },
  { code: '2100', name: 'الذمم الدائنة - الموردين (Accounts Payable)', type: 'LIABILITY', status: 'ACTIVE', parentCode: '2000', description: 'الالتزامات للموردين وشراء البضائع والخدمات التجارية الآجلة' },
  { code: '2200', name: 'ضريبة القيمة المضافة المستحقة (Sales Tax Payable)', type: 'LIABILITY', status: 'ACTIVE', parentCode: '2000', description: 'حساب الضرائب المحتسبة للمشتريات والمبيعات المستحقة للجهة الضريبية' },

  // 3. EQUITY
  { code: '3000', name: "حقوق الملكية للملاك (Owners' Rights)", type: 'Equity', status: 'active', parentId: 'root', description: 'حقوق ملكية الملاك والشركاء والاحتياطيات والأرباح' },
  { code: '3100', name: 'رأس المال (Capital)', type: 'Equity', status: 'active', parentCode: '3000', description: 'رأس المال المدفوع والمستثمر الرئيسي بالمنشأة' },
  { code: '3200', name: 'الأرباح المبقاة (Retained Earnings)', type: 'Equity', status: 'active', parentCode: '3000', description: 'الأرباح والخسائر المتراكمة والمحققة غير الموزعة حتى نهاية الفترة' },

  // 4. INCOME
  { code: '4000', name: 'الإيرادات التشغيلية (Revenues)', type: 'Income', status: 'active', parentId: 'root', description: 'العائد الإجمالي المحقق من النشاط والتشغيل الرئيسي للمنشأة' },
  { code: '4100', name: 'إيرادات المبيعات (Sales Revenue)', type: 'Income', status: 'active', parentCode: '4000', description: 'إيرادات مبيعات البضائع والمنتجات والخدمات للعملاء والنشاط' },
  { code: '4200', name: 'مردودات ومسموحات المبيعات (Sales Returns & Allowances)', type: 'Income', status: 'active', parentCode: '4000', description: 'مرتجع المبيعات والخصومات المسموح بها والموافق عليها من قبل الإدارة' },

  // 5. EXPENSES
  { code: '5000', name: 'المصاريف التشغيلية (Expenses)', type: 'Expense', status: 'active', parentId: 'root', description: 'مصاريف النشاط والتشغيل وخدمة الأعمال بمختلف أنواعها الإدارية والتشغيلية' },
  { code: '5100', name: 'تكلفة البضاعة المباعة (Cost of Goods Sold - COGS)', type: 'Expense', status: 'active', parentCode: '5000', description: 'تكاليف البضائع المباعة الفعلية والمسلمة للعملاء وقياس الهامش' },
  { code: '5200', name: 'مردودات المشتريات (Purchase Returns)', type: 'Expense', status: 'active', parentCode: '5000', description: 'مرتجع المشتريات والخصومات المكتسبة والمستردّة من الموردين' },
  { code: '5300', name: 'المصاريف الإدارية والعمومية (Operating Expenses)', type: 'Expense', status: 'active', parentCode: '5000', description: 'كافة مصاريف التشغيل والمصاريف الإدارية والعمومية العامة والمباني والأدوات' },
];

// فقط الحسابات الجذرية الخمسة محمية — لا يمكن حذفها أو تعديلها
export const IMMUTABLE_ROOT_CODES = ['1000', '2000', '3000', '4000', '5000'];

export const isImmutableRootAccount = (code: string | undefined): boolean => {
  if (!code) return false;
  return IMMUTABLE_ROOT_CODES.includes(code);
};

interface TreeNode extends Partial<Account> {
  id: string;
  name: string;
  code: string;
  type: AccountType;
  children: TreeNode[];
  isRoot?: boolean;
}

export default function ChartOfAccounts() {
  const { t } = useTranslation();
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = React.useState(false);
  const [isExportDropdownOpen, setIsExportDropdownOpen] = React.useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = React.useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = React.useState(false);
  const [selectedAccount, setSelectedAccount] = React.useState<Account | null>(null);
  const [accounts, setAccounts] = React.useState<Account[]>(SEEDED_ACCOUNTS);
  const [isLoading, setIsLoading] = React.useState(true);
  const [filterType, setFilterType] = React.useState<string>('All Account Types');
  const [isSaving, setIsSaving] = React.useState(false);
  const [expandedNodes, setExpandedNodes] = React.useState<Set<string>>(new Set());
  const [editingId, setEditingId] = React.useState<string | null>(null);
  const [editForm, setEditForm] = React.useState({ name: '', status: 'active' as 'active' | 'inactive', description: '' });
  const [nextCode, setNextCode] = React.useState('1000');
  const [selectedParentId, setSelectedParentId] = React.useState<string>('root');
  const [error, setError] = React.useState<string | null>(null);
  
  const { user } = useAuthStore();
  const { companyId } = useRBAC();

  React.useEffect(() => {
    const path = 'accounts';
    const q = query(
      collection(db, path),
      where('companyId', '==', companyId)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const rawData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Account[];
      
      if (rawData.length === 0 && !isLoading) {
        // Seed initial roots if empty
        seedInitialRoots();
      }

      let accountsData = [...rawData];
      const codeToIdMap = new Map<string, string>();
      accountsData.forEach(a => {
        codeToIdMap.set(a.code, a.id);
      });

      // Inject / Validate all 18 core accounts dynamically to prevent empty spaces or wrong configurations
      CORE_SYSTEM_ACCOUNTS.forEach(core => {
        const existing = accountsData.find(a => a.code === core.code);
        if (!existing) {
          let parentId = core.parentId || 'root';
          if (core.parentCode) {
            const parentIdInDb = codeToIdMap.get(core.parentCode);
            if (parentIdInDb) {
              parentId = parentIdInDb;
            } else {
              parentId = `virtual-${core.parentCode}`;
            }
          }

          const virtualId = core.parentId === 'root' ? `virtual-${core.code}` : `virtual-sub-${core.code}`;
          accountsData.push({
            id: virtualId,
            code: core.code,
            name: core.name,
            type: core.type as any,
            balance: 0.00,
            status: core.status as any,
            parentId: parentId,
            description: core.description,
          });
          codeToIdMap.set(core.code, virtualId);
        } else {
          // Normalize existing accounts to fit strict core specifications
          accountsData = accountsData.map(a => {
            if (a.code === core.code) {
              return {
                ...a,
                name: core.name,
                type: core.type as any,
                status: core.status as any,
                balance: a.balance || 0.00,
              };
            }
            return a;
          });
        }
      });
      
      setAccounts(accountsData);
      setIsLoading(false);
      
      // Auto-expand roots on first load
      if (expandedNodes.size === 0) {
        const roots = accountsData.filter(a => !a.parentId || a.parentId === 'root');
        setExpandedNodes(new Set(roots.map(r => r.id)));
      }

      // Default the selected parent to the Assets root (1000) once loaded
      const rootAsset = accountsData.find(a => a.code === '1000');
      if (rootAsset) {
        setSelectedParentId(prev => (prev === 'root' ? rootAsset.id : prev));
      }
    }, (error) => {
      console.warn('Real-time chart of accounts synchronization status (using local/fallback state):', error.message);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [isLoading]);

  const seedInitialRoots = async () => {
    try {
      // 1. Assets (1000)
      const assetRef = await addDoc(collection(db, 'accounts'), {
        code: '1000',
        name: 'الأصول (Assets)',
        type: 'Asset',
        balance: 0.00,
        status: 'active',
        parentId: 'root',
        companyId,
        createdAt: serverTimestamp(),
      });
      const subAssets = [
        { code: '1100', name: 'الذمم المدينة - العملاء (Accounts Receivable)', type: 'Asset', description: 'العملاء والذمم المدينة التجارية النشطة المتصلة بالفواتير والمبيعات' },
        { code: '1200', name: 'حساب البنك الرئيسي (Bank Account)', type: 'Asset', description: 'الحساب الجاري البنكي الرئيسي للتسويات والعمليات المصرفية والمدفوعات' },
        { code: '1300', name: 'الصندوق / النقدية (Cash on Hand)', type: 'Asset', description: 'النقدية المقبوضة والجاهزة للتسويات بالخزائن والصناديق' },
        { code: '1400', name: 'مخزون البضائع (Inventory Asset)', type: 'Asset', description: 'مخزون السلع المتاحة للبيع وفق تقييم Costing FIFO/WAC' },
      ];
      for (const sub of subAssets) {
        await addDoc(collection(db, 'accounts'), {
          ...sub,
          balance: 0.00,
          status: 'active',
          parentId: assetRef.id,
          companyId,
          createdAt: serverTimestamp(),
        });
      }

      // 2. Liabilities (2000)
      const liabilityRef = await addDoc(collection(db, 'accounts'), {
        code: '2000',
        name: 'الالتزامات الخصوم (Liabilities)',
        type: 'LIABILITY',
        balance: 0.00,
        status: 'ACTIVE',
        parentId: 'root',
        companyId,
        createdAt: serverTimestamp(),
      });
      const subLiabilities = [
        { code: '2100', name: 'الذمم الدائنة - الموردين (Accounts Payable)', type: 'LIABILITY', description: 'الالتزامات للموردين وشراء البضائع والخدمات التجارية الآجلة' },
        { code: '2200', name: 'ضريبة القيمة المضافة المستحقة (Sales Tax Payable)', type: 'LIABILITY', description: 'حساب الضرائب المحتسب للمشتريات والمبيعات المستحقة للجهة الضريبية' },
      ];
      for (const sub of subLiabilities) {
        await addDoc(collection(db, 'accounts'), {
          ...sub,
          balance: 0.00,
          status: 'ACTIVE',
          parentId: liabilityRef.id,
          companyId,
          createdAt: serverTimestamp(),
        });
      }

      // 3. Equity (3000)
      const equityRef = await addDoc(collection(db, 'accounts'), {
        code: '3000',
        name: "حقوق الملكية للملاك (Owners' Rights)",
        type: 'Equity',
        balance: 0.00,
        status: 'active',
        parentId: 'root',
        companyId,
        createdAt: serverTimestamp(),
      });
      const subEquity = [
        { code: '3100', name: 'رأس المال (Capital)', type: 'Equity', description: 'رأس المال المدفوع والمستثمر الرئيسي بالمنشأة' },
        { code: '3200', name: 'الأرباح المبقاة (Retained Earnings)', type: 'Equity', description: 'الأرباح والخسائر المتراكمة والمحققة غير الموزعة حتى نهاية الفترة' },
      ];
      for (const sub of subEquity) {
        await addDoc(collection(db, 'accounts'), {
          ...sub,
          balance: 0.00,
          status: 'active',
          parentId: equityRef.id,
          companyId,
          createdAt: serverTimestamp(),
        });
      }

      // 4. Income (4000)
      const incomeRef = await addDoc(collection(db, 'accounts'), {
        code: '4000',
        name: 'الإيرادات التشغيلية (Revenues)',
        type: 'Income',
        balance: 0.00,
        status: 'active',
        parentId: 'root',
        companyId,
        createdAt: serverTimestamp(),
      });
      const subIncome = [
        { code: '4100', name: 'إيرادات المبيعات (Sales Revenue)', type: 'Income', description: 'إيرادات مبيعات البضائع والمنتجات والخدمات للعملاء والنشاط' },
        { code: '4200', name: 'مردودات ومسموحات المبيعات (Sales Returns & Allowances)', type: 'Income', description: 'مرتجع المبيعات والخصومات المسموح بها والموافق عليها من قبل الإدارة' },
      ];
      for (const sub of subIncome) {
        await addDoc(collection(db, 'accounts'), {
          ...sub,
          balance: 0.00,
          status: 'active',
          parentId: incomeRef.id,
          companyId,
          createdAt: serverTimestamp(),
        });
      }

      // 5. Expenses (5000)
      const expenseRef = await addDoc(collection(db, 'accounts'), {
        code: '5000',
        name: 'المصاريف التشغيلية (Expenses)',
        type: 'Expense',
        balance: 0.00,
        status: 'active',
        parentId: 'root',
        companyId,
        createdAt: serverTimestamp(),
      });
      const subExpenses = [
        { code: '5100', name: 'تكلفة البضاعة المباعة (Cost of Goods Sold - COGS)', type: 'Expense', description: 'تكاليف البضائع المبيعة الفعلية والمسلمة للعملاء وقياس الهامش' },
        { code: '5200', name: 'مردودات المشتريات (Purchase Returns)', type: 'Expense', description: 'مرتجع المشتريات والخصومات المكتسبة والمستردّة من الموردين' },
        { code: '5300', name: 'المصاريف الإدارية والعمومية (Operating Expenses)', type: 'Expense', description: 'كافة مصاريف التشغيل والمصاريف الإدارية والعمومية العامة والمباني والأدوات' },
      ];
      for (const sub of subExpenses) {
        await addDoc(collection(db, 'accounts'), {
          ...sub,
          balance: 0.00,
          status: 'active',
          parentId: expenseRef.id,
          companyId,
          createdAt: serverTimestamp(),
        });
      }
    } catch (e) {
      console.error("Seeding initial core accounts failed:", e);
    }
  };

  const generateNextCode = (parentId: string) => {
    let code: number;
    if (parentId === 'root') {
      const roots = accounts.filter(a => a.parentId === 'root').sort((a, b) => b.code.localeCompare(a.code));
      const lastRoot = roots[0];
      code = lastRoot ? Math.floor(parseInt(lastRoot.code) / 1000) * 1000 + 1000 : 1000;
    } else {
      const parent = accounts.find(a => a.id === parentId);
      const siblings = accounts.filter(a => a.parentId === parentId).sort((a, b) => b.code.localeCompare(a.code));
      const lastSibling = siblings[0];
      
      if (lastSibling) {
        code = parseInt(lastSibling.code) + 1;
      } else if (parent) {
        code = parseInt(parent.code) + 1;
      } else {
        code = 1001;
      }
    }

    // Ensure uniqueness across all accounts
    let finalCode = code;
    while (accounts.some(a => a.code === finalCode.toString().padStart(4, '0'))) {
      finalCode++;
    }

    return finalCode.toString().padStart(4, '0');
  };

  React.useEffect(() => {
    setNextCode(generateNextCode(selectedParentId));
  }, [selectedParentId, accounts]);

  const buildTree = (nodes: Account[]): TreeNode[] => {
    const accountMap = new Map<string, TreeNode>();
    const tree: TreeNode[] = [];

    nodes.forEach(acc => {
      accountMap.set(acc.id, { ...acc, children: [] });
    });

    nodes.forEach(acc => {
      const node = accountMap.get(acc.id)!;
      if (!acc.parentId || acc.parentId === 'root') {
        node.isRoot = true;
        tree.push(node);
      } else {
        const parent = accountMap.get(acc.parentId);
        if (parent) {
          parent.children.push(node);
        } else {
          // Orphaned or root-level without explicit 'root' parentId
          node.isRoot = true;
          tree.push(node);
        }
      }
    });

    const sortNodes = (n: TreeNode[]) => {
      n.sort((a, b) => a.code.localeCompare(b.code));
      n.forEach(child => sortNodes(child.children));
    };

    sortNodes(tree);
    return tree;
  };

  const treeData = React.useMemo(() => buildTree(accounts), [accounts]);

  const toggleNode = (id: string) => {
    const newExpanded = new Set(expandedNodes);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedNodes(newExpanded);
  };

  const handleCreateAccount = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    
    const parentId = formData.get('parentId') as string;
    const parent = accounts.find(a => a.id === parentId);

    // PARENT-CHILD ENFORCEMENT: Adding any new sub-account requires selecting one of the 5 validated immutable roots as a parent.
    if (!parent || !isImmutableRootAccount(parent.code)) {
      setError("Compliance Failure: Any new sub-account must select one of the 5 validated immutable roots as its parent.");
      setIsSaving(false);
      return;
    }

    const newAccount = {
      code: nextCode,
      name: formData.get('name') as string,
      type: parent.type,
      parentId: parentId,
      description: formData.get('description') as string,
      balance: 0,
      status: 'active',
      companyId,
      createdAt: serverTimestamp(),
    };

    try {
      await addDoc(collection(db, 'accounts'), newAccount);
      setIsModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'accounts');
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateAccount = async (id: string) => {
    const targetAccount = accounts.find(a => a.id === id);
    if (targetAccount && isImmutableRootAccount(targetAccount.code)) {
      setError("System safety restriction: core system root accounts are strictly immutable.");
      return;
    }
    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'accounts', id), {
        name: editForm.name,
        status: editForm.status,
        description: editForm.description
      });
      setEditingId(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'accounts');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!selectedAccount) return;
    
    if (isImmutableRootAccount(selectedAccount.code)) {
      setError("System safety restriction: core system root accounts are strictly immutable and cannot be deleted.");
      return;
    }

    const hasChildren = accounts.some(a => a.parentId === selectedAccount.id);
    if (hasChildren) {
      setError("Cannot delete account with sub-accounts. Please delete children first.");
      return;
    }

    setIsSaving(true);
    try {
      await deleteDoc(doc(db, 'accounts', selectedAccount.id));
      setIsDeleteModalOpen(false);
      setSelectedAccount(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'accounts');
    } finally {
      setIsSaving(false);
    }
  };

  const startEditing = (node: TreeNode) => {
    if (isImmutableRootAccount(node.code)) {
      setError("System safety restriction: core system root accounts are strictly immutable.");
      return;
    }
    setEditingId(node.id);
    setEditForm({ 
      name: node.name, 
      status: node.status || 'active',
      description: node.description || ''
    });
  };

  const renderTreeRows = (nodes: TreeNode[], depth = 0) => {
    return nodes.map(node => {
      const isExpanded = expandedNodes.has(node.id);
      const hasChildren = node.children.length > 0;
      const isEditing = editingId === node.id;
      
      if (filterType !== 'All Account Types' && node.type?.toUpperCase() !== filterType?.toUpperCase() && !node.isRoot) {
        return null;
      }

      return (
        <React.Fragment key={node.id}>
          <tr 
            className={cn(
              "group hover:bg-slate-50 transition-colors border-b border-slate-100",
              node.isRoot ? "bg-slate-50/50" : "bg-white"
            )}
          >
            <td className="py-3 px-4">
              <div className="flex items-center gap-2" style={{ paddingLeft: `${depth * 1.5}rem` }}>
                {hasChildren ? (
                  <button 
                    onClick={() => toggleNode(node.id)}
                    className="p-1 hover:bg-slate-200 rounded transition-colors"
                  >
                    {isExpanded ? <ChevronDown className="w-4 h-4 text-slate-500" /> : <ChevronRight className="w-4 h-4 text-slate-500" />}
                  </button>
                ) : (
                  <div className="w-6" />
                )}
                <span className={cn("font-mono text-sm", node.isRoot ? "font-bold text-slate-900" : "text-slate-600")}>
                  {node.code}
                </span>
                {isImmutableRootAccount(node.code) && (
                  <span title="حساب جذري محمي — لا يمكن حذفه أو تعديله"
                    className="flex items-center gap-0.5 text-[9px] font-bold text-amber-700 bg-amber-100 border border-amber-200 px-1.5 py-0.5 rounded-full">
                    <Lock className="w-2.5 h-2.5" /> محمي
                  </span>
                )}
              </div>
            </td>
            <td className="py-3 px-4">
              {isEditing ? (
                <div className="space-y-2 min-w-[200px]">
                  <input 
                    type="text"
                    value={editForm.name}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    className="w-full px-2 py-1 border border-indigo-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium"
                    placeholder="Account Name"
                    autoFocus
                  />
                  <textarea 
                    value={editForm.description}
                    onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                    className="w-full px-2 py-1 border border-indigo-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 text-[10px] h-12 resize-none"
                    placeholder="Add description..."
                  />
                </div>
              ) : (
                <div className="flex flex-col">
                  <span className={cn("text-sm", node.isRoot ? "font-bold text-slate-900" : "font-medium text-slate-700")}>
                    {getLocalizedName(node)}
                  </span>
                  {node.description && (
                    <span className="text-[10px] text-slate-400 line-clamp-1 max-w-[250px]">
                      {node.description}
                    </span>
                  )}
                </div>
              )}
            </td>
            <td className="py-3 px-4">
              <span className={cn(
                "px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider",
                {
                  Asset: 'bg-emerald-50 text-emerald-700',
                  Liability: 'bg-rose-50 text-rose-700',
                  LIABILITY: 'bg-rose-50 text-rose-700',
                  Equity: 'bg-indigo-50 text-indigo-700',
                  Income: 'bg-blue-50 text-blue-700',
                  Expense: 'bg-amber-50 text-amber-700',
                }[node.type] || 'bg-slate-50 text-slate-600'
              )}>
                {node.type}
              </span>
            </td>
            <td className="py-3 px-4 text-right">
              <span className="font-bold text-slate-900 text-sm">
                {formatCurrency(node.balance || 0)}
              </span>
            </td>
            <td className="py-3 px-4 text-right">
              {isEditing ? (
                <select 
                  value={editForm.status}
                  onChange={(e) => setEditForm({ ...editForm, status: e.target.value as 'active' | 'inactive' })}
                  className="px-2 py-1 border border-indigo-300 rounded outline-none text-[10px] font-bold uppercase"
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              ) : (
                <span className={cn(
                  "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase",
                  (node.status as any === 'active' || node.status as any === 'ACTIVE') ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"
                )}>
                  {node.status}
                </span>
              )}
            </td>
            <td className="py-3 px-4 text-right">
              <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                {isEditing ? (
                  <>
                    <button 
                      onClick={() => handleUpdateAccount(node.id)}
                      className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                      title="Save"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => setEditingId(null)}
                      className="p-1.5 text-slate-400 hover:bg-slate-50 rounded-lg transition-colors"
                      title="Cancel"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <>
                    <button 
                      onClick={() => {
                        setSelectedAccount(node as Account);
                        setIsViewModalOpen(true);
                      }}
                      className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                      title="View"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    {!isImmutableRootAccount(node.code) && (
                      <button 
                        onClick={() => startEditing(node)}
                        className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors cursor-pointer"
                        title="Edit"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                    )}
                    {!isImmutableRootAccount(node.code) && (
                      <button 
                        onClick={() => {
                          setSelectedAccount(node as Account);
                          setIsDeleteModalOpen(true);
                          setError(null);
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </>
                )}
              </div>
            </td>
          </tr>
          {isExpanded && hasChildren && renderTreeRows(node.children, depth + 1)}
        </React.Fragment>
      );
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
            <FolderTree className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">{t('accounts.title', 'Chart of Accounts')}</h1>
            <p className="text-slate-500 text-sm">{t('accounts.coa_loaded', 'Hierarchical view of your general ledger.')}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-indigo-650 transition-all text-sm font-semibold text-slate-605 cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            {t('global.import_excel', 'Import from Excel')}
          </button>

          <div className="relative">
            <button
              onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
              className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              {t('global.export', 'Export')}
            </button>
            {isExportDropdownOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setIsExportDropdownOpen(false)} />
                <div className="absolute right-0 mt-1.5 w-48 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 z-20">
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToExcel(
                        accounts,
                        ['code', 'name', 'type', 'description', 'balance', 'status'],
                        ['Account Code', 'Account Name', 'Account Type', 'Description', 'Balance', 'Status'],
                        'System_Chart_Of_Accounts'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    {t('global.export_excel', 'Export to Excel (.xlsx)')}
                  </button>
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToPDF(
                        accounts,
                        ['code', 'name', 'type', 'description', 'balance', 'status'],
                        ['Account Code', 'Account Name', 'Account Type', 'Description', 'Balance', 'Status'],
                        'Advanced Accounting - Chart of Accounts General Ledger',
                        'System_Chart_Of_Accounts'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    {t('global.export_pdf', 'Export to PDF (.pdf)')}
                  </button>
                </div>
              </>
            )}
          </div>

          <button 
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-semibold shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            {t('accounts.new_account', 'New Account')}
          </button>
        </div>
      </div>

      <div className="flex items-center gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <div className="flex-1 relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder={t('common.search', 'Search accounts...')} 
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
        <select 
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        >
          <option value="All Account Types">{getLocalizedLabel('All Account Types')}</option>
          <option value="Asset">{getLocalizedLabel('Asset')}</option>
          <option value="Liability">{getLocalizedLabel('Liability')}</option>
          <option value="Equity">{getLocalizedLabel('Equity')}</option>
          <option value="Income">{getLocalizedLabel('Income')}</option>
          <option value="Expense">{getLocalizedLabel('Expense')}</option>
        </select>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="py-3 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">{getLocalizedLabel('Code')}</th>
              <th className="py-3 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">{getLocalizedLabel('Account Name')}</th>
              <th className="py-3 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">{getLocalizedLabel('Type')}</th>
              <th className="py-3 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">{getLocalizedLabel('Balance')}</th>
              <th className="py-3 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">{getLocalizedLabel('Status')}</th>
              <th className="py-3 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">{getLocalizedLabel('Actions')}</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td colSpan={6} className="py-20 text-center">
                  <div className="flex flex-col items-center gap-2 text-slate-400">
                    <Loader2 className="w-8 h-8 animate-spin" />
                    <p>Building account tree...</p>
                  </div>
                </td>
              </tr>
            ) : (
              renderTreeRows(treeData)
            )}
          </tbody>
        </table>
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title={getLocalizedLabel("Create New Account")}
      >
        <form onSubmit={handleCreateAccount} className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">{getLocalizedLabel("Account Code (Auto)")}</label>
              <input 
                name="code" 
                required 
                type="text" 
                readOnly
                value={nextCode}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none text-slate-500 font-mono" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">{getLocalizedLabel("Parent Account")}</label>
              <select 
                name="parentId" 
                required 
                value={selectedParentId}
                onChange={(e) => setSelectedParentId(e.target.value)}
                className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {accounts.length > 0 && (
                  <optgroup label={getLocalizedLabel("System Root Accounts")}>
                    {accounts.filter(acc => isImmutableRootAccount(acc.code)).map(acc => (
                      <option key={acc.id} value={acc.id}>{acc.code} - {getLocalizedName(acc)}</option>
                    ))}
                  </optgroup>
                )}
              </select>
            </div>
          </div>
          {false && (
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">{getLocalizedLabel("Account Type")}</label>
              <select name="type" required className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="Asset">{getLocalizedLabel("Asset")}</option>
                <option value="Liability">{getLocalizedLabel("Liability")}</option>
                <option value="Equity">{getLocalizedLabel("Equity")}</option>
                <option value="Income">{getLocalizedLabel("Income")}</option>
                <option value="Expense">{getLocalizedLabel("Expense")}</option>
              </select>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">{getLocalizedLabel("Account Name")}</label>
            <input name="name" required type="text" className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" placeholder="e.g. Petty Cash" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">{getLocalizedLabel("Description")}</label>
            <textarea name="description" className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 h-24" placeholder="Briefly describe..."></textarea>
          </div>
          <div className="flex items-center gap-4 pt-4">
            <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-semibold text-slate-600">{getLocalizedLabel("Cancel")}</button>
            <button 
              type="submit" 
              disabled={isSaving}
              className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-semibold shadow-sm flex items-center justify-center gap-2"
            >
              {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
              {isSaving ? getLocalizedLabel('Loading...') : getLocalizedLabel('Save')}
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        title="Account Details"
      >
        {selectedAccount && (
          <div className="space-y-6">
            <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center shadow-sm">
                <FolderTree className="w-6 h-6 text-indigo-600" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">{selectedAccount.name}</h3>
                <p className="text-sm text-slate-500 font-mono">{selectedAccount.code}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Type</p>
                <p className="font-semibold text-slate-700">{selectedAccount.type}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Status</p>
                <p className="font-semibold text-slate-700 capitalize">{selectedAccount.status}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Balance</p>
                <p className="text-xl font-bold text-indigo-600">{formatCurrency(selectedAccount.balance)}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Parent ID</p>
                <p className="font-semibold text-slate-700">{selectedAccount.parentId || 'None'}</p>
              </div>
            </div>

            {selectedAccount.description && (
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Description</p>
                <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-100">
                  {selectedAccount.description}
                </p>
              </div>
            )}

            <div className="pt-4 border-t border-slate-100">
              <button 
                onClick={() => setIsViewModalOpen(false)}
                className="w-full py-2 bg-slate-100 text-slate-600 rounded-lg font-semibold hover:bg-slate-200 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        title="Delete Account"
      >
        <div className="space-y-6">
          <div className="p-4 bg-rose-50 text-rose-700 rounded-lg border border-rose-100 text-sm">
            <p className="font-bold mb-1">Warning</p>
            <p>Are you sure you want to delete the account <strong>{selectedAccount?.name}</strong>? This action cannot be undone.</p>
          </div>

          {error && (
            <div className="p-3 bg-rose-100 text-rose-800 rounded-lg text-xs font-medium">
              {error}
            </div>
          )}

          <div className="flex items-center gap-4">
            <button 
              type="button" 
              onClick={() => setIsDeleteModalOpen(false)} 
              className="flex-1 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-semibold text-slate-600"
            >
              Cancel
            </button>
            <button 
              onClick={handleDeleteAccount}
              disabled={isSaving}
              className="flex-1 px-4 py-2 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition-colors font-semibold shadow-sm flex items-center justify-center gap-2"
            >
              {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
              {isSaving ? 'Deleting...' : 'Delete Account'}
            </button>
          </div>
        </div>
      </Modal>

      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        moduleId="accounts"
        existingRecords={accounts}
        onImportSuccess={(count) => {
          setIsImportModalOpen(false);
        }}
      />
    </div>
  );
}
