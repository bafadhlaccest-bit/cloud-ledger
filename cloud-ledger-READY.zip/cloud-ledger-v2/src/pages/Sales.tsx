import React from 'react';
import { ColumnDef } from '@tanstack/react-table';
import { DataTable } from '../components/DataTable';
import { Invoice, Customer, Item, Account } from '../types';
import { SEEDED_ITEMS, SEEDED_ACCOUNTS, getMergedItems, getMergedAccounts } from '../data/initialData';
import { formatCurrency, cn, formatDate } from '../lib/utils';
import { AccountDropdownSelector } from '../components/AccountDropdownSelector';
import { 
  Plus, 
  Search, 
  FileText, 
  Send, 
  CheckCircle, 
  Clock, 
  Loader2, 
  Trash2, 
  Edit2, 
  HelpCircle,
  Scan,
  Layers,
  PlusCircle,
  ChevronDown,
  Barcode,
  Printer,
  Palette
} from 'lucide-react';
import Modal from '../components/Modal';
import ImportModal from '../components/ImportModal';
import { exportToExcel, exportToPDF } from '../utils/exportImport';
import { Download, UploadCloud } from 'lucide-react';
import TemplateCustomizer from '../components/TemplateCustomizer';
import InvoicePaperPreview from '../components/InvoicePaperPreview';
import JournalPreviewModal from '../components/modals/JournalPreviewModal';
import { postInvoiceJournal, postToLedger } from '../utils/postingEngine';
import { PostingEngine } from '../services/PostingEngine';
import FileAttachments from '../components/FileAttachments';
import { saveDraftAttachments, getAttachments } from '../lib/attachmentStorage';
import { Paperclip as PaperclipIcon } from 'lucide-react';

import { safeStorage } from '../utils/safeStorage';

import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  serverTimestamp,
  orderBy
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';
import { useSettings } from '../context/SettingsContext';
import { CurrencyService, GLOBAL_CURRENCIES, custom_exchange_rates } from '../services/CurrencyService';
import { db, collection, addDoc, updateDoc, deleteDoc, onSnapshot, query, where, orderBy, serverTimestamp, doc } from '../firebase';

function InvoiceAttachmentsBadge({ invoiceId }: { invoiceId: string }) {
  const [count, setCount] = React.useState(0);
  const [isOpen, setIsOpen] = React.useState(false);

  React.useEffect(() => {
    let active = true;
    getAttachments(invoiceId).then(list => {
      if (active) setCount(list.length);
    });
    // check periodically
    const interval = setInterval(() => {
      getAttachments(invoiceId).then(list => {
        if (active) setCount(list.length);
      });
    }, 4000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [invoiceId]);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className={cn(
          "flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] font-bold shadow-xs hover:bg-slate-50 transition cursor-pointer select-none",
          count > 0 
            ? "bg-indigo-50 border-indigo-200 text-indigo-700 font-extrabold" 
            : "bg-white border-slate-200 text-slate-500"
        )}
      >
        <PaperclipIcon className="w-3.5 h-3.5" />
        <span>{count > 0 ? `${count} files` : 'Attach'}</span>
      </button>

      {isOpen && (
        <Modal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          title="Manage Invoice Attachments"
          size="md"
        >
          <div className="space-y-4 p-1">
            <p className="text-xs text-slate-500 font-medium">
              View and manage attached backup documents and files for this invoice directly.
            </p>
            <FileAttachments 
              entityId={invoiceId} 
              onAttachmentsChange={(list) => setCount(list.length)} 
            />
            <div className="flex justify-end pt-4 border-t">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 font-bold rounded-lg text-xs shadow-sm transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}

export default function Sales() {
  const { settings } = useSettings();
  const [transactionCurrency, setTransactionCurrency] = React.useState<string>('YER');
  const [transactionExchangeRate, setTransactionExchangeRate] = React.useState<number>(1.0);
  const [officialRates, setOfficialRates] = React.useState<Record<string, number>>({});

  // Fetch official rates calibrated relative to System Base currency
  React.useEffect(() => {
    if (settings && settings.currency) {
      CurrencyService.fetchIMFRates(settings.currency)
        .then(rates => setOfficialRates(rates))
        .catch(err => {
          console.warn("Failed to fetch official rates, fallback to simplified system:", err);
          const simpleFallbacks: Record<string, number> = {
            'USD': 1.0, 'EUR': 0.92, 'SAR': 3.75, 'YER': 250.0, 'AED': 3.67, 'EGP': 47.0
          };
          const baseRateInUSD = simpleFallbacks[settings.currency] || 1.0;
          const calibrated: Record<string, number> = {};
          Object.keys(simpleFallbacks).forEach((k) => {
            calibrated[k] = simpleFallbacks[k] / baseRateInUSD;
          });
          calibrated[settings.currency] = 1.0;
          setOfficialRates(calibrated);
        });
    }
  }, [settings?.currency]);

  // Helper code to grab prioritised rate (custom override inside setting map first, then IMF official rate inverted as base per target)
  const getCurrencyExchangeRate = React.useCallback((currCode: string) => {
    if (!currCode) return 1.0;
    if (settings && currCode === settings.currency) return 1.0;

    // 1. Check custom override from settings
    const savedCustom = (window as any).custom_exchange_rates?.[currCode] || custom_exchange_rates?.[currCode];
    if (savedCustom && typeof savedCustom === 'number' && savedCustom > 0) {
      return savedCustom;
    }

    // 2. Fallback to official IMF rate (inverted to Base per Target)
    const officialRate = officialRates[currCode];
    if (officialRate && officialRate > 0) {
      return 1 / officialRate;
    }

    // 3. Simple static fallback
    const simpleFallbacks: Record<string, number> = {
      'USD': 1.0, 'EUR': 0.92, 'SAR': 3.75, 'YER': 250.0, 'AED': 3.67, 'EGP': 47.0
    };
    const targetInUSD = simpleFallbacks[currCode] || 1.0;
    const baseInUSD = simpleFallbacks[settings?.currency || 'YER'] || 1.0;
    return baseInUSD / targetInUSD;
  }, [settings, officialRates]);

  const handleCurrencyChange = (newCurrency: string) => {
    setTransactionCurrency(newCurrency);
    const rate = getCurrencyExchangeRate(newCurrency);
    setTransactionExchangeRate(rate);
  };

  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = React.useState(false);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = React.useState(false);
  const [pendingLedgerTx, setPendingLedgerTx] = React.useState<{ reference: string; date: string; description: string; lines: any[] }>({
    reference: '',
    date: '',
    description: '',
    lines: []
  });
  const [isExportDropdownOpen, setIsExportDropdownOpen] = React.useState(false);
  const [invoices, setInvoices] = React.useState<Invoice[]>([]);
  const [customers, setCustomers] = React.useState<Customer[]>([]);
  const [items, setItems] = React.useState<Item[]>(SEEDED_ITEMS);
  const [accounts, setAccounts] = React.useState<Account[]>(SEEDED_ACCOUNTS);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSaving, setIsSaving] = React.useState(false);
  const [editingInvoice, setEditingInvoice] = React.useState<Invoice | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');

  // States for Invoice Builder Form
  const [invoiceCustomerId, setInvoiceCustomerId] = React.useState('');
  const [invoiceSubTotal, setInvoiceSubTotal] = React.useState<number>(0);
  const [invoiceDiscountPercent, setInvoiceDiscountPercent] = React.useState<number>(0);
  const [invoiceShippingCharges, setInvoiceShippingCharges] = React.useState<number>(0);
  const [invoiceAdjustment, setInvoiceAdjustment] = React.useState<number>(0);
  const [invoiceCustomerNotes, setInvoiceCustomerNotes] = React.useState('Thanks for your business.');
  const [invoiceTermsConditions, setInvoiceTermsConditions] = React.useState('');
  const [invoiceBranchId, setInvoiceBranchId] = React.useState<string>("Sana'a Main HQ branch");
  const [invoiceCostCenterId, setInvoiceCostCenterId] = React.useState<string>("Admin HQ Operations Center");
  const [saveStatus, setSaveStatus] = React.useState<'Draft' | 'Sent' | 'Posted' | null>(null);
  const [currentEntityId, setCurrentEntityId] = React.useState<string>('');

  // States for Recording Payment
  const [isPaymentModalOpen, setIsPaymentModalOpen] = React.useState(false);
  const [paymentInvoice, setPaymentInvoice] = React.useState<Invoice | null>(null);
  const [paymentAmount, setPaymentAmount] = React.useState<number>(0);
  const [paymentDate, setPaymentDate] = React.useState<string>(new Date().toISOString().split('T')[0]);
  const [paymentReference, setPaymentReference] = React.useState<string>('');
  const [paymentAccountId, setPaymentAccountId] = React.useState<string>('acc_bank_cash');
  const [paymentAccountName, setPaymentAccountName] = React.useState<string>('Al-Kuraimi Cash YER (صندوق المركز رئيسي)');
  const [paymentSettlementRate, setPaymentSettlementRate] = React.useState<number>(1.0);
  const [isRecordingPayment, setIsRecordingPayment] = React.useState(false);

  // States for Credit Note / Return
  const [isCreditNoteModalOpen, setIsCreditNoteModalOpen] = React.useState(false);
  const [creditNoteInvoice, setCreditNoteInvoice] = React.useState<Invoice | null>(null);
  const [creditNoteAmount, setCreditNoteAmount] = React.useState<number>(0);
  const [creditNoteDate, setCreditNoteDate] = React.useState<string>(new Date().toISOString().split('T')[0]);
  const [creditNoteReason, setCreditNoteReason] = React.useState<string>('Return of goods');
  const [isCreatingCreditNote, setIsCreatingCreditNote] = React.useState(false);


  // Layout customization states
  const [templateCustomizer, setTemplateCustomizer] = React.useState<{
    templateStyle: 'standard' | 'professional' | 'modern';
    logoUrl: string;
    logoAlignment: 'left' | 'center' | 'right';
    logoSize: 'small' | 'medium' | 'large';
    primaryColor: string;
    secondaryColor: string;
    fontFamily: 'Inter' | 'Arial' | 'Roboto' | 'Tajawal' | 'Courier New';
    hideTaxColumn: boolean;
    hideShippingCharges: boolean;
    hideTermsAndConditions: boolean;
    hideCustomerNotes: boolean;
  }>(() => {
    try {
      const saved = safeStorage.getItem('invoice_template_customizer');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn("Could not load template customizer from safeStorage", e);
    }
    return {
      templateStyle: 'standard',
      logoUrl: '',
      logoAlignment: 'left',
      logoSize: 'medium',
      primaryColor: '#4f46e5',
      secondaryColor: '#475569',
      fontFamily: 'Inter',
      hideTaxColumn: false,
      hideShippingCharges: false,
      hideTermsAndConditions: false,
      hideCustomerNotes: false,
    };
  });

  const [isCustomizerOpen, setIsCustomizerOpen] = React.useState(false);

  // Keep saved to localStorage safely
  React.useEffect(() => {
    try {
      safeStorage.setItem('invoice_template_customizer', JSON.stringify(templateCustomizer));
    } catch {}
  }, [templateCustomizer]);

  // Handle Logo file uploaded convert to base64
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTemplateCustomizer(prev => ({
          ...prev,
          logoUrl: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const compileCustomStyles = () => {
    const {
      primaryColor,
      secondaryColor,
      fontFamily,
      logoAlignment,
      logoSize
    } = templateCustomizer;

    let fontCSS = '';
    if (fontFamily === 'Tajawal') {
      fontCSS = `font-family: 'Tajawal', sans-serif !important;`;
    } else if (fontFamily === 'Roboto') {
      fontCSS = `font-family: 'Roboto', sans-serif !important;`;
    } else if (fontFamily === 'Arial') {
      fontCSS = `font-family: Arial, sans-serif !important;`;
    } else if (fontFamily === 'Courier New') {
      fontCSS = `font-family: 'Courier New', Courier, monospace !important;`;
    } else {
      fontCSS = `font-family: 'Inter', sans-serif !important;`;
    }

    return `
      .custom-font, .custom-font * {
        ${fontCSS}
      }
      .custom-primary-bg {
        background-color: ${primaryColor} !important;
      }
      .custom-primary-text {
        color: ${primaryColor} !important;
      }
      .custom-secondary-text {
        color: ${secondaryColor} !important;
      }
      .custom-primary-border {
        border-color: ${primaryColor} !important;
      }
      .custom-secondary-border {
        border-color: ${secondaryColor} !important;
      }
      /* Custom selection rings overrides */
      .focus\\:ring-indigo-500:focus,
      .focus\\:ring-2:focus {
        --tw-ring-color: ${primaryColor} !important;
        border-color: ${primaryColor} !important;
      }
      /* Standard buttons hover states */
      .bg-indigo-600 {
        background-color: ${primaryColor} !important;
      }
      .bg-indigo-600:hover {
        filter: brightness(0.9) !important;
      }
      .text-indigo-600 {
        color: ${primaryColor} !important;
      }
      .text-indigo-700 {
        color: ${primaryColor} !important;
      }
      .bg-indigo-50 {
        background-color: ${primaryColor}1a !important; /* 10% opacity hex */
      }
      .border-indigo-100 {
        border-color: ${primaryColor}2b !important; /* 17% opacity hex */
      }

      /* Media Print Styles (overrides) */
      @media print {
        .custom-font, .custom-font * {
          ${fontCSS}
        }
        body > div:not(.fixed),
        #root > div:not(.fixed) {
          display: none !important;
          height: 0 !important;
          overflow: hidden !important;
        }
        .fixed.inset-0.z-50 {
          position: static !important;
          display: block !important;
          padding: 0 !important;
          margin: 0 !important;
          width: 100% !important;
          height: auto !important;
          overflow: visible !important;
        }
        .bg-slate-900\\/60,
        .backdrop-blur-sm,
        .border-b.shrink-0 {
          display: none !important;
        }
        .relative.w-full.bg-white {
          box-shadow: none !important;
          border: none !important;
          border-radius: 0 !important;
          max-height: none !important;
          height: auto !important;
          overflow: visible !important;
          padding: 0 !important;
        }
        .p-6.overflow-y-auto {
          padding: 0 !important;
          overflow: visible !important;
        }
        .print-hidden,
        button,
        .print\\:hidden,
        .flex.items-center.gap-2.pt-1,
        .pt-8.border-t,
        .trash-column,
        td:last-child,
        th:last-child {
          display: none !important;
        }
        input, select, textarea {
          border: none !important;
          background: transparent !important;
          box-shadow: none !important;
          padding: 0 !important;
          color: #000 !important;
          font-weight: 600 !important;
          appearance: none !important;
          -webkit-appearance: none !important;
          -moz-appearance: none !important;
        }
        .grid-cols-3 {
          grid-template-cols: repeat(3, minmax(0, 1fr)) !important;
        }
      }
    `;
  };

  // Invoice Items state table rows
  interface InvoiceItemRow {
    id: string;
    itemId: string;
    name: string;
    sku: string;
    quantity: number;
    rate: number;
    taxPercent: number; // percentage value
    taxLabel: string;   // visual label
    amount: number;
    accountId?: string;
    accountName?: string;
  }

  const createEmptyRow = (): InvoiceItemRow => ({
    id: Math.random().toString(36).substring(7),
    itemId: '',
    name: '',
    sku: '',
    quantity: 1.00,
    rate: 0.00,
    taxPercent: 0,
    taxLabel: 'Select a Tax',
    amount: 0.00,
    accountId: '',
    accountName: ''
  });

  const [formRows, setFormRows] = React.useState<InvoiceItemRow[]>([createEmptyRow()]);

  const [isScannerOpen, setIsScannerOpen] = React.useState(false);
  const [scanSku, setScanSku] = React.useState('');
  const [scanError, setScanError] = React.useState('');
  const [isBulkActionOpen, setIsBulkActionOpen] = React.useState(false);
  const [rowSearchQueries, setRowSearchQueries] = React.useState<Record<string, string>>({});
  const [activeDropdownRowId, setActiveDropdownRowId] = React.useState<string | null>(null);

  const handleScanItem = () => {
    const item = items.find(it => it.sku.toLowerCase() === scanSku.trim().toLowerCase());
    if (item) {
      // Add or increment item
      const existingRowIndex = formRows.findIndex(row => row.itemId === item.id);
      if (existingRowIndex > -1) {
        setFormRows(prev => prev.map((row, idx) => {
          if (idx !== existingRowIndex) return row;
          const qty = row.quantity + 1;
          const amt = qty * row.rate * (1 + row.taxPercent / 100);
          return { ...row, quantity: qty, amount: amt };
        }));
      } else {
        setFormRows(prev => {
          const filteredPrev = prev.filter(r => r.itemId !== ''); // remove empty row if any
          return [
            ...filteredPrev,
            {
              id: Math.random().toString(36).substring(7),
              itemId: item.id,
              name: item.name,
              sku: item.sku,
              quantity: 1.00,
              rate: item.salesPrice,
              taxPercent: 0,
              taxLabel: 'Select a Tax',
              amount: item.salesPrice,
              accountId: item.incomeAccountId || 'acc_sales_revenue',
              accountName: accounts.find(a => a.id === (item.incomeAccountId || 'acc_sales_revenue'))?.name || 'Standard Product Sales Revenue',
            }
          ];
        });
      }
      setScanSku('');
      setScanError('');
      setIsScannerOpen(false);
    } else {
      setScanError('SKU not found. Try "ITEM-001" or other existing SKUs.');
    }
  };

  const handleBulkAction = (action: string) => {
    if (action === 'clear') {
      setFormRows([createEmptyRow()]);
    } else if (action === 'tax15') {
      setFormRows(prev => prev.map(row => {
        const amt = row.quantity * row.rate * 1.15;
        return { ...row, taxPercent: 15, taxLabel: 'VAT (15%)', amount: amt };
      }));
    } else if (action === 'tax5') {
      setFormRows(prev => prev.map(row => {
        const amt = row.quantity * row.rate * 1.05;
        return { ...row, taxPercent: 5, taxLabel: 'VAT (5%)', amount: amt };
      }));
    } else if (action === 'add3') {
      setFormRows(prev => [...prev, createEmptyRow(), createEmptyRow(), createEmptyRow()]);
    }
    setIsBulkActionOpen(false);
  };

  const handleAddItemsInBulk = () => {
    // Adds up to 3 standard items instantly from items collection to table rows
    const availableItemsToAdd = items.slice(0, 3);
    if (availableItemsToAdd.length > 0) {
      setFormRows(prev => {
        const filteredPrev = prev.filter(r => r.itemId !== ''); // remove empty row
        const newRows = availableItemsToAdd.map(it => ({
          id: Math.random().toString(36).substring(7),
          itemId: it.id,
          name: it.name,
          sku: it.sku,
          quantity: 1.00,
          rate: it.salesPrice,
          taxPercent: 0,
          taxLabel: 'Select a Tax',
          amount: it.salesPrice,
          accountId: it.incomeAccountId || 'acc_sales_revenue',
          accountName: accounts.find(a => a.id === (it.incomeAccountId || 'acc_sales_revenue'))?.name || 'Standard Product Sales Revenue',
        }));
        return [...filteredPrev, ...newRows];
      });
    } else {
      alert('No catalogue items found to add in bulk.');
    }
  };

  const handleRowChange = (id: string, updates: Partial<InvoiceItemRow>) => {
    setFormRows(prev => prev.map(row => {
      if (row.id !== id) return row;
      const updatedRow = { ...row, ...updates };
      const qty = Number(updatedRow.quantity) || 0;
      const rVal = Number(updatedRow.rate) || 0;
      const taxPercent = Number(updatedRow.taxPercent) || 0;
      updatedRow.amount = qty * rVal * (1 + taxPercent / 100);
      return updatedRow;
    }));
  };

  // Dynamically calculate subTotal from form item rows
  React.useEffect(() => {
    const totalAmount = formRows.reduce((sum, row) => sum + (row.amount || 0), 0);
    setInvoiceSubTotal(totalAmount);
  }, [formRows]);

  const calculatedDiscount = (invoiceSubTotal * (invoiceDiscountPercent || 0)) / 100;
  const grandTotal = invoiceSubTotal - calculatedDiscount + (invoiceShippingCharges || 0) + (invoiceAdjustment || 0);

  const { companyId } = useRBAC();

  React.useEffect(() => {
    const invoicesPath = 'invoices';
    const customersPath = 'customers';
    const itemsPath = 'items';
    const accountsPath = 'accounts';

    const qInvoices = query(
      collection(db, invoicesPath),
      where('companyId', '==', companyId),
      orderBy('createdAt', 'desc')
    );

    const qCustomers = query(
      collection(db, customersPath),
      where('companyId', '==', companyId)
    );

    const qItems = query(
      collection(db, itemsPath),
      where('companyId', '==', companyId)
    );

    const qAccounts = query(
      collection(db, accountsPath),
      where('companyId', '==', companyId)
    );

    const unsubInvoices = onSnapshot(qInvoices, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Invoice[];
      setInvoices(data);
      setIsLoading(false);
    }, (error) => {
      console.warn('Real-time invoices synchronization status (using local/fallback state):', error.message);
      setIsLoading(false);
    });

    const unsubCustomers = onSnapshot(qCustomers, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Customer[];
      setCustomers(data);
    }, (error) => {
      console.warn('Real-time customers synchronization status (using local/fallback state):', error.message);
    });

    const unsubItems = onSnapshot(qItems, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Item[];
      setItems(getMergedItems(data));
    }, (error) => {
      console.warn('Real-time items synchronization status (using local/fallback state):', error.message);
    });

    const unsubAccounts = onSnapshot(qAccounts, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Account[];
      setAccounts(getMergedAccounts(data));
    }, (error) => {
      console.warn('Real-time standard accounts synchronization status (using local/fallback state):', error.message);
    });

    return () => {
      unsubInvoices();
      unsubCustomers();
      unsubItems();
      unsubAccounts();
    };
  }, [companyId]);

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (editingInvoice && ((editingInvoice.status as string) === 'Posted' || editingInvoice.status === 'Sent' || editingInvoice.status === 'Paid' || (editingInvoice as any).isCreditNote)) {
      alert('Violation of audit-readiness: Posted, Sent, and Credit Note records are structurally locked and cannot be edited.');
      return;
    }
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    
    const customerId = formData.get('customerId') as string;
    const customer = customers.find(c => c.id === customerId);

    const finalStatus = saveStatus || editingInvoice?.status || 'Sent';

    if (finalStatus === 'Sent' && !customerId) {
      alert('Please select a customer to save and send this invoice.');
      setIsSaving(false);
      return;
    }

    const data = {
      number: formData.get('number') as string,
      customerId: customerId || '',
      customerName: customer?.name || 'Unassigned Customer',
      date: formData.get('date') as string,
      dueDate: formData.get('dueDate') as string,
      subTotal: invoiceSubTotal,
      discountPercent: invoiceDiscountPercent,
      shippingCharges: invoiceShippingCharges,
      adjustment: invoiceAdjustment,
      customerNotes: invoiceCustomerNotes,
      termsConditions: invoiceTermsConditions,
      total: grandTotal,
      currency: transactionCurrency,
      exchangeRate: transactionExchangeRate,
      amountInBaseCurrency: Number((grandTotal * transactionExchangeRate).toFixed(2)),
      status: finalStatus,
      companyId,
      branchId: invoiceBranchId,
      costCenterId: invoiceCostCenterId,
      updatedAt: serverTimestamp(),
      items: formRows.map(row => ({
        itemId: row.itemId,
        name: row.name,
        sku: row.sku,
        quantity: row.quantity,
        rate: row.rate,
        taxPercent: row.taxPercent,
        taxLabel: row.taxLabel,
        amount: row.amount,
        accountId: row.accountId || '',
        accountName: row.accountName || '',
        branchId: invoiceBranchId,
        costCenterId: invoiceCostCenterId
      })),
    };

    try {
      if (!navigator.onLine) {
        const { offlineDb } = await import('../utils/offlineDb');
        const isAr = document.documentElement.lang === 'ar';
        const offlineRecord = {
          ...data,
          id: editingInvoice?.id || `invoice-off-${Date.now()}`,
          isOfflineDraft: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        await offlineDb.saveRecord('offline_sales_invoices', offlineRecord);
        alert(
          isAr
            ? 'تم حفظ الفاتورة محلياً بأمان في صف الانتظار بسبب انقطاع الإنترنت. يرجى مزامنتها يدوياً من الأعلى عند عودة الاتصال.'
            : 'No internet connection detected. Invoice saved securely in local Offline Queue. Please sync manually from the top bar once connected.'
        );
        setIsModalOpen(false);
        setEditingInvoice(null);
        return;
      }

      let activeInvoiceId = '';
      if (editingInvoice) {
        await updateDoc(doc(db, 'invoices', editingInvoice.id), data);
        activeInvoiceId = editingInvoice.id;
      } else {
        const docRef = await addDoc(collection(db, 'invoices'), {
          ...data,
          createdAt: serverTimestamp(),
        });
        activeInvoiceId = docRef.id;
        await saveDraftAttachments(currentEntityId, docRef.id);
      }

      // Automatically generate database-synced balanced double-entry general ledger journal entries
      try {
        await postInvoiceJournal({
          id: activeInvoiceId,
          number: data.number,
          date: data.date,
          customerName: data.customerName,
          subTotal: Number((data.subTotal * transactionExchangeRate).toFixed(2)),
          total: Number((data.total * transactionExchangeRate).toFixed(2)),
          adjustment: Number(((data.adjustment || 0) * transactionExchangeRate).toFixed(2)),
          shippingCharges: Number(((data.shippingCharges || 0) * transactionExchangeRate).toFixed(2)),
          taxPercent: 5, // Default standard tax percent or invoice level percent
          branchId: invoiceBranchId,
          costCenterId: invoiceCostCenterId,
          items: data.items.map(it => ({
            amount: Number((it.amount * transactionExchangeRate).toFixed(2)),
            accountId: it.accountId || '',
            accountName: it.accountName || '',
            description: `Sales Revenue - SKU: ${it.sku} (${it.name})`
          }))
        }, companyId);
      } catch (jeErr) {
        console.warn("Auto double-entry posting engine warning:", jeErr);
      }
      setIsModalOpen(false);
      setEditingInvoice(null);
    } catch (error) {
      handleFirestoreError(error, editingInvoice ? OperationType.UPDATE : OperationType.CREATE, 'invoices');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePreviewJournalEntryClick = () => {
    const totalAmount = Number(grandTotal.toFixed(2));
    const subtotal = Number(invoiceSubTotal.toFixed(2));
    const shipping = Number((invoiceShippingCharges || 0).toFixed(2));
    const adjustment = Number((invoiceAdjustment || 0).toFixed(2));
    
    const freightAdjustmentTotal = Number((shipping + adjustment).toFixed(2));
    const taxAmount = Number((totalAmount - subtotal - freightAdjustmentTotal).toFixed(2));

    const selectedCustomer = customers.find(c => c.id === invoiceCustomerId);
    const customerName = selectedCustomer?.name || 'Unassigned Customer';
    
    const numberInput = document.querySelector('input[name="number"]') as HTMLInputElement;
    const dateInput = document.querySelector('input[name="date"]') as HTMLInputElement;
    const invoiceNumber = numberInput?.value || 'DRAFT-INV';
    const invoiceDate = dateInput?.value || new Date().toISOString().split('T')[0];

    const lines: any[] = [
      {
        accountId: 'acc_receivables',
        accountName: 'Trade Receivables (مدينو التجارة مبيعات)',
        accountCode: '120101',
        debit: totalAmount,
        credit: 0,
        ifrsMapping: 'CURRENT_ASSET',
        description: `Sales Invoice #${invoiceNumber} - Client: ${customerName}`,
      }
    ];

    if (formRows && formRows.length > 0) {
      let creditSum = 0;
      formRows.forEach((row, index) => {
        const itemAmt = Number((row.amount || 0).toFixed(2));
        if (itemAmt > 0) {
          creditSum += itemAmt;
          lines.push({
            accountId: row.accountId || 'acc_sales_revenue',
            accountName: row.accountName || 'Standard Product Sales Revenue',
            accountCode: row.accountId ? '410102' : '410101',
            debit: 0,
            credit: itemAmt,
            ifrsMapping: 'REVENUE',
            description: `Sales Invoice #${invoiceNumber} - SKU: ${row.sku || 'N/A'} (${row.name || 'Product'})`,
          });
        }
      });

      const mismatch = Number((totalAmount - taxAmount - creditSum).toFixed(2));
      if (Math.abs(mismatch) > 0.01) {
        lines.push({
          accountId: 'acc_sales_revenue',
          accountName: 'Standard Product Sales Revenue',
          accountCode: '410101',
          debit: mismatch < 0 ? Math.abs(mismatch) : 0,
          credit: mismatch > 0 ? mismatch : 0,
          ifrsMapping: 'REVENUE',
          description: `Invoice adjustments and shipping/allowance parameters`,
        });
      }
    } else {
      lines.push({
        accountId: 'acc_sales_revenue',
        accountName: 'Standard Product Sales Revenue',
        accountCode: '410101',
        debit: 0,
        credit: subtotal + freightAdjustmentTotal,
        ifrsMapping: 'REVENUE',
        description: `Invoice Subtotal & Shipping Adjustments`,
      });
    }

    if (taxAmount > 0) {
      lines.push({
        accountId: 'acc_vat_collect',
        accountName: 'VAT Output Tax (ضريبة القيمة المضافة لطلبات السلة وزد)',
        accountCode: '210202',
        debit: 0,
        credit: taxAmount,
        ifrsMapping: 'CURRENT_LIABILITY',
        description: `Sales Output VAT @ 15% for invoice #${invoiceNumber}`,
      });
    }

    setPendingLedgerTx({
      reference: `INV-${invoiceNumber}`,
      date: invoiceDate,
      description: `Automatic Journal Invoice Ledger [Invoice #${invoiceNumber}]`,
      lines
    });

    setIsPreviewModalOpen(true);
  };

  const handleConfirmPreviewPost = async () => {
    setIsPreviewModalOpen(false);
    setSaveStatus('Posted');
    
    const formEl = document.querySelector('form') as HTMLFormElement;
    if (formEl) {
      setTimeout(() => {
        if (typeof formEl.requestSubmit === 'function') {
          formEl.requestSubmit();
        } else {
          formEl.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
        }
      }, 50);
    }
  };

  const handleDelete = async (id: string) => {
    const inv = invoices.find(i => i.id === id);
    if (inv && ((inv.status as string) === 'Posted' || inv.status === 'Sent' || inv.status === 'Paid' || (inv as any).isCreditNote)) {
      alert('Violation of audit-readiness: Posted, Sent, and Credit Note records are structurally locked and cannot be deleted.');
      return;
    }
    if (!confirm('Are you sure you want to delete this invoice?')) return;
    try {
      await deleteDoc(doc(db, 'invoices', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'invoices');
    }
  };

  const handleRecordPaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentInvoice) return;
    setIsRecordingPayment(true);
    try {
      const payRef = paymentReference.trim() || `PAY-${paymentInvoice.number}-${Date.now()}`;
      
      const selectedAcc = accounts.find(a => a.id === paymentAccountId);
      const targetAccId = paymentAccountId || 'acc_bank_cash';
      const targetAccName = selectedAcc ? selectedAcc.name : paymentAccountName;
      const targetAccCode = selectedAcc?.code || '110101';

      const originalRate = Number((paymentInvoice as any).exchangeRate) || 1.0;
      const settlementRate = Number(paymentSettlementRate) || 1.0;

      // الحفاظ على سياقات الفروع ومراكز التكلفة من الفاتورة الأصلية لضمان تتبع التقارير بدقة
      const invoiceBranchId = (paymentInvoice as any).branchId || '';
      const invoiceCostCenterId = (paymentInvoice as any).costCenterId || '';

      // احتساب فوارق الصرف الرأسمالية المحققة من خلال محرك الفوارق
      const { correctionLine } = PostingEngine.computeRealizedForexDriftLines({
        transactionAmount: Number(paymentAmount),
        originalExchangeRate: originalRate,
        settlementExchangeRate: settlementRate,
        isVendorPayment: false,
        branchId: invoiceBranchId,
        costCenterId: invoiceCostCenterId
      });

      const lines: any[] = [
        {
          accountId: targetAccId,
          accountName: targetAccName,
          accountCode: targetAccCode,
          debit: Number(paymentAmount),
          credit: 0,
          description: `Debit Bank/Cash - Received Payment for Invoice #${paymentInvoice.number}`,
          exchangeRate: settlementRate,
          branchId: invoiceBranchId,
          costCenterId: invoiceCostCenterId
        },
        {
          accountId: 'acc_receivables',
          accountName: 'Trade Receivables (مدينو التجارة مبيعات)',
          accountCode: '120101',
          debit: 0,
          credit: Number(paymentAmount),
          description: `Credit Accounts Receivable - Receipt from client ${paymentInvoice.customerName}`,
          exchangeRate: originalRate,
          branchId: invoiceBranchId,
          costCenterId: invoiceCostCenterId
        }
      ];

      if (correctionLine) {
        lines.push(correctionLine);
      }

      const result = await postToLedger({
        date: paymentDate,
        reference: payRef,
        description: `Customer Receipt / Payment: Invoice #${paymentInvoice.number} - Client: ${paymentInvoice.customerName}`,
        totalDebit: Number(paymentAmount),
        totalCredit: Number(paymentAmount),
        companyId: companyId,
        lines: lines,
        status: 'Posted'
      });

      if (!result.success) {
        throw new Error(result.error || "Failed to post payment to balanced general ledger.");
      }

      await updateDoc(doc(db, 'invoices', paymentInvoice.id), {
        status: 'Paid',
        updatedAt: serverTimestamp()
      });

      setIsPaymentModalOpen(false);
      setPaymentInvoice(null);
      alert('SUCCESS: Balanced Payment Journal Entry recorded: Debit [Bank/Cash] and Credit [Accounts Receivable] with FOREX adjustments!');
    } catch (err: any) {
      console.error(err);
      alert(`Payment routing failed: ${err.message || err}`);
    } finally {
      setIsRecordingPayment(false);
    }
  };

  const handleCreateCreditNoteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!creditNoteInvoice) return;
    setIsCreatingCreditNote(true);
    try {
      const cnNumber = `CN-${creditNoteInvoice.number}-${Math.floor(Math.random() * 900 + 100)}`;
      
      const firstItem = creditNoteInvoice.items?.[0];
      const taxRate = firstItem?.taxPercent ?? creditNoteInvoice.taxPercent ?? 15;
      const reversedTotal = Number(creditNoteAmount);
      const reversedSubtotal = Number((reversedTotal / (1 + (taxRate / 100))).toFixed(2));
      const reversedVat = Number((reversedTotal - reversedSubtotal).toFixed(2));

      const ledgerLines = [
        {
          accountId: 'acc_sales_revenue',
          accountName: 'Standard Product Sales Revenue',
          accountCode: '410101',
          debit: reversedSubtotal,
          credit: 0,
          description: `Sales Return Revenue Reversing - Credit Note #${cnNumber} for Invoice #${creditNoteInvoice.number}`
        }
      ];

      if (reversedVat > 0) {
        ledgerLines.push({
          accountId: 'acc_vat_collect',
          accountName: 'VAT Output Tax (ضريبة القيمة المضافة لطلبات السلة وزد)',
          accountCode: '210202',
          debit: reversedVat,
          credit: 0,
          description: `VAT Return Reversing @ ${taxRate}% for Credit Note #${cnNumber}`
        });
      }

      ledgerLines.push({
        accountId: 'acc_receivables',
        accountName: 'Trade Receivables (مدينو التجارة مبيعات)',
        accountCode: '120101',
        debit: 0,
        credit: reversedTotal,
        description: `Credit Accounts Receivable Relief - Client return: ${creditNoteInvoice.customerName}`
      });

      const result = await postToLedger({
        date: creditNoteDate,
        reference: cnNumber,
        description: `Sales Return / Credit Note Reversal: CN #${cnNumber} for Invoice #${creditNoteInvoice.number}`,
        totalDebit: reversedTotal,
        totalCredit: reversedTotal,
        companyId: companyId,
        lines: ledgerLines,
        status: 'Posted'
      });

      if (!result.success) {
        throw new Error(result.error || "Failed to post credit note reversal to balanced ledger.");
      }

      await addDoc(collection(db, 'invoices'), {
        number: cnNumber,
        customerId: creditNoteInvoice.customerId,
        customerName: creditNoteInvoice.customerName,
        date: creditNoteDate,
        dueDate: creditNoteDate,
        total: reversedTotal,
        subTotal: reversedSubtotal,
        discountPercent: 0,
        shippingCharges: 0,
        adjustment: 0,
        customerNotes: `Sales Return / Reversal Credit Note for Invoice #${creditNoteInvoice.number}. Reason: ${creditNoteReason}`,
        termsConditions: 'Immutable Posted Credit Note Ledger',
        status: 'Posted',
        isCreditNote: true,
        originalInvoiceId: creditNoteInvoice.id,
        originalInvoiceNumber: creditNoteInvoice.number,
        companyId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        items: creditNoteInvoice.items || []
      });

      await updateDoc(doc(db, 'invoices', creditNoteInvoice.id), {
        status: 'Cancelled',
        updatedAt: serverTimestamp()
      });

      setIsCreditNoteModalOpen(false);
      setCreditNoteInvoice(null);
      alert(`SUCCESS: Immutable Credit Note issued & general ledger entries posted! Original invoice is now Cancelled.`);
    } catch (err: any) {
      console.error(err);
      alert(`Creating credit note failed: ${err.message || err}`);
    } finally {
      setIsCreatingCreditNote(false);
    }
  };

  const filteredInvoices = invoices.filter(inv => 
    inv.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inv.customerName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    outstanding: invoices.filter(inv => inv.status !== 'Paid').reduce((acc, inv) => acc + inv.total, 0),
    overdue: invoices.filter(inv => inv.status === 'Overdue').reduce((acc, inv) => acc + inv.total, 0),
    paid: invoices.filter(inv => inv.status === 'Paid').reduce((acc, inv) => acc + inv.total, 0),
    drafts: invoices.filter(inv => inv.status === 'Draft').reduce((acc, inv) => acc + inv.total, 0),
  };

  const columns: ColumnDef<Invoice>[] = [
    {
      header: 'Invoice #',
      accessorKey: 'number',
      cell: (info) => {
        const inv = info.row.original;
        if ((inv as any).isCreditNote) {
          return <span className="font-extrabold text-amber-700">CN-{info.getValue() as string}</span>;
        }
        return <span className="font-bold text-slate-900">{info.getValue() as string}</span>;
      },
    },
    {
      header: 'Customer',
      accessorKey: 'customerName',
      cell: (info) => <span className="font-medium text-slate-700">{info.getValue() as string}</span>,
    },
    {
      header: 'Date',
      accessorKey: 'date',
      cell: (info) => <span className="text-slate-500">{formatDate(info.getValue() as string)}</span>,
    },
    {
      header: 'Due Date',
      accessorKey: 'dueDate',
      cell: (info) => <span className="text-slate-500">{formatDate(info.getValue() as string)}</span>,
    },
    {
      header: 'Total',
      accessorKey: 'total',
      cell: (info) => {
        const inv = info.row.original;
        if ((inv as any).isCreditNote) {
          return <span className="font-extrabold text-amber-700">-{formatCurrency(info.getValue() as number)}</span>;
        }
        return <span className="font-bold text-slate-900">{formatCurrency(info.getValue() as number)}</span>;
      },
    },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: (info) => {
        const inv = info.row.original;
        if ((inv as any).isCreditNote) {
          return (
            <span className="px-2 py-1 rounded-full text-[10px] bg-amber-100 text-amber-800 border border-amber-300 font-extrabold tracking-wider uppercase">
              🔄 مردود مبيعات / Credit Note
            </span>
          );
        }
        const status = info.getValue() as string;
        const styles = {
          Draft: 'bg-slate-100 text-slate-600 border border-slate-200',
          Sent: 'bg-indigo-50 text-indigo-700 border border-indigo-200',
          'Partially Paid': 'bg-amber-100 text-amber-700 border border-amber-200',
          Paid: 'bg-emerald-100 text-emerald-700 border border-emerald-200',
          Overdue: 'bg-rose-100 text-rose-700 border border-rose-200',
          Cancelled: 'bg-slate-100 text-slate-400 border border-slate-200 line-through',
          Posted: 'bg-emerald-150 text-emerald-800 border border-emerald-300',
        };
        return (
          <span className={cn(
            "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
            styles[status as keyof typeof styles] || 'bg-slate-100 text-slate-600'
          )}>
            {status}
          </span>
        );
      },
    },
    {
      header: 'Attachments',
      id: 'attachments',
      cell: (info) => {
        const inv = info.row.original;
        return <InvoiceAttachmentsBadge invoiceId={inv.id} />;
      }
    },
    {
      header: 'Actions',
      id: 'actions',
      cell: (info) => {
        const inv = info.row.original;
        const isLocked = (inv.status as string) === 'Posted' || inv.status === 'Sent' || inv.status === 'Paid' || inv.status === 'Cancelled' || (inv as any).isCreditNote;

        if (isLocked) {
          return (
            <div className="flex items-center gap-2 flex-wrap">
              {!(inv as any).isCreditNote && inv.status !== 'Paid' && inv.status !== 'Cancelled' && (
                <button
                  onClick={() => {
                    setPaymentInvoice(inv);
                    setPaymentAmount(inv.total);
                    setPaymentDate(new Date().toISOString().split('T')[0]);
                    setPaymentReference('');
                    setPaymentSettlementRate((inv as any).exchangeRate || 1.0);
                    setIsPaymentModalOpen(true);
                  }}
                  className="px-2.5 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-md text-[11px] font-black transition-all shadow-xs cursor-pointer select-none"
                  title="Record Customer Payment Receipt"
                >
                  💵 تسجيل دفع
                </button>
              )}
              {!(inv as any).isCreditNote && inv.status !== 'Cancelled' && (
                <button
                  onClick={() => {
                    setCreditNoteInvoice(inv);
                    setCreditNoteAmount(inv.total);
                    setCreditNoteDate(new Date().toISOString().split('T')[0]);
                    setCreditNoteReason(`Sales Return / Reversal for Invoice #${inv.number}`);
                    setIsCreditNoteModalOpen(true);
                  }}
                  className="px-2.5 py-1.5 bg-amber-50 text-amber-750 hover:bg-amber-100 border border-amber-200 rounded-md text-[11px] font-black transition-all shadow-xs cursor-pointer select-none"
                  title="Issue Credit Note (Sales Return)"
                >
                  🔄 مردود مبيعات
                </button>
              )}
              <span className="flex items-center gap-1 text-[11px] text-slate-400 bg-slate-50 border border-slate-200 px-2 py-1.5 rounded-md font-bold select-none">
                🔒 Immutable
              </span>
            </div>
          );
        }

        return (
          <div className="flex items-center gap-2">
            <button 
              onClick={() => {
                setEditingInvoice(inv);
                setCurrentEntityId(inv.id);
                setInvoiceCustomerId(inv.customerId || '');
                setInvoiceSubTotal(inv.subTotal ?? inv.total ?? 0);
                setInvoiceDiscountPercent(inv.discountPercent ?? 0);
                setInvoiceShippingCharges(inv.shippingCharges ?? 0);
                setInvoiceAdjustment(inv.adjustment ?? 0);
                setInvoiceCustomerNotes(inv.customerNotes ?? 'Thanks for your business.');
                setInvoiceTermsConditions(inv.termsConditions ?? '');
                setInvoiceBranchId((inv as any).branchId || "Sana'a Main HQ branch");
                setInvoiceCostCenterId((inv as any).costCenterId || "Admin HQ Operations Center");
                setSaveStatus(null);
                setTransactionCurrency((inv as any).currency || settings?.currency || 'YER');
                setTransactionExchangeRate((inv as any).exchangeRate ?? 1.0);
                
                if (inv.items && Array.isArray(inv.items)) {
                  setFormRows(inv.items.map((it: any) => ({
                    id: Math.random().toString(36).substring(7),
                    itemId: it.itemId || '',
                    name: it.name || '',
                    sku: it.sku || '',
                    quantity: it.quantity ?? 1.00,
                    rate: it.rate ?? 0.00,
                    taxPercent: it.taxPercent ?? 0,
                    taxLabel: it.taxLabel ?? 'Select a Tax',
                    amount: it.amount ?? 0.00,
                    accountId: it.accountId || '',
                    accountName: it.accountName || '',
                  })));
                } else {
                  setFormRows([{
                    id: Math.random().toString(36).substring(7),
                    itemId: 'legacy-item',
                    name: 'Legacy Invoice Transaction',
                    sku: 'LEGACY',
                    quantity: 1.00,
                    rate: inv.subTotal ?? inv.total ?? 0.00,
                    taxPercent: 0,
                    taxLabel: 'Select a Tax',
                    amount: inv.subTotal ?? inv.total ?? 0.00,
                    accountId: 'acc_sales_revenue',
                    accountName: 'Standard Product Sales Revenue',
                  }]);
                }
                
                setIsModalOpen(true);
              }}
              className="p-1 text-slate-400 hover:text-indigo-600 transition-colors"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button 
              onClick={() => handleDelete(inv.id)}
              className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        );
      },
    }
  ];

  if (isCustomizerOpen) {
    return (
      <div className="space-y-6 animate-in fade-in duration-200">
        <style dangerouslySetInnerHTML={{ __html: compileCustomStyles() }} />
        
        {/* Customizer Sub-page Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-slate-200 pb-4 gap-4">
          <div>
            <div className="flex items-center gap-2 text-indigo-600 mb-1">
              <Palette className="w-5 h-5 text-indigo-600 animate-pulse" />
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">Invoice Design Studio</h1>
            </div>
            <p className="text-slate-500 text-sm font-medium">
              Tailor company branding, colors, typography, layout style, and active transaction parameters.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setIsCustomizerOpen(false)}
            className="px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-black hover:bg-indigo-700 transition shadow-sm cursor-pointer select-none"
          >
            ← Back to Invoices List
          </button>
        </div>

        {/* Workspace Panels Split */}
        <div className="flex flex-col xl:flex-row gap-8 items-start w-full">
          {/* Left Settings Controls */}
          <div className="w-full xl:w-[410px] shrink-0 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <TemplateCustomizer 
              settings={templateCustomizer}
              onChange={setTemplateCustomizer}
              onLogoUpload={handleLogoUpload}
            />
          </div>

          {/* Right Live Real-Time Preview Area */}
          <div className="flex-1 w-full space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider text-slate-400">
                Live Design Canvas
              </span>
              <span className="text-[10px] text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Live Preview (Using {invoices[0] ? 'Latest Invoice' : 'Demo Invoice Data'})
              </span>
            </div>
            <div className="p-6 md:p-8 border border-slate-200 bg-slate-50 rounded-3xl shadow-inner w-full flex items-center justify-center">
              <div className="w-full max-w-3xl">
                <InvoicePaperPreview 
                  invoice={invoices[0] || null} 
                  customers={customers} 
                  settings={templateCustomizer} 
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Sales Invoices</h1>
          <p className="text-slate-500 text-sm">Track your revenue and manage customer payments.</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-indigo-650 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            Import from Excel
          </button>

          <div className="relative">
            <button
              onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
              className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Export
            </button>
            {isExportDropdownOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setIsExportDropdownOpen(false)} />
                <div className="absolute right-0 mt-1.5 w-48 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 z-20">
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToExcel(
                        invoices,
                        ['number', 'customerName', 'date', 'dueDate', 'subTotal', 'discountPercent', 'shippingCharges', 'total', 'status'],
                        ['Invoice Number', 'Customer Name', 'Invoice Date', 'Due Date', 'Sub Total', 'Discount %', 'Shipping', 'Total Amount', 'Status'],
                        'System_Sales_Invoices'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    Export to Excel (.xlsx)
                  </button>
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToPDF(
                        invoices,
                        ['number', 'customerName', 'date', 'dueDate', 'subTotal', 'discountPercent', 'shippingCharges', 'total', 'status'],
                        ['Invoice Number', 'Customer Name', 'Invoice Date', 'Due Date', 'Sub Total', 'Discount %', 'Shipping', 'Total Amount', 'Status'],
                        'Advanced Accounting - Sales Invoices Registry',
                        'System_Sales_Invoices'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    Export to PDF (.pdf)
                  </button>
                </div>
              </>
            )}
          </div>

          <button 
            type="button"
            onClick={() => setIsCustomizerOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors text-sm font-semibold shadow-sm cursor-pointer select-none"
          >
            <Palette className="w-4 h-4 text-indigo-600" />
            Customize Template
          </button>
          <button 
            onClick={() => {
              setEditingInvoice(null);
              setInvoiceCustomerId('');
              setInvoiceSubTotal(0);
              setInvoiceDiscountPercent(0);
              setInvoiceShippingCharges(0);
              setInvoiceAdjustment(0);
              setInvoiceCustomerNotes('Thanks for your business.');
              setInvoiceTermsConditions('');
              setInvoiceBranchId("Sana'a Main HQ branch");
              setInvoiceCostCenterId("Admin HQ Operations Center");
              setFormRows([createEmptyRow()]);
              setSaveStatus(null);
              setTransactionCurrency(settings?.currency || 'YER');
              setTransactionExchangeRate(1.0);
              const tempId = 'temp_invoice_' + Math.random().toString(36).substring(2, 11);
              setCurrentEntityId(tempId);
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-semibold shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Create Invoice
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-2 bg-blue-50 rounded-lg text-blue-600">
            <Send className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Outstanding</p>
            <p className="text-lg font-bold text-slate-900">{formatCurrency(stats.outstanding)}</p>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-2 bg-rose-50 rounded-lg text-rose-600">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Overdue</p>
            <p className="text-lg font-bold text-slate-900">{formatCurrency(stats.overdue)}</p>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Paid (Total)</p>
            <p className="text-lg font-bold text-slate-900">{formatCurrency(stats.paid)}</p>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-2 bg-slate-50 rounded-lg text-slate-600">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Drafts</p>
            <p className="text-lg font-bold text-slate-900">{formatCurrency(stats.drafts)}</p>
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search by invoice number or customer name..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      ) : (
        <DataTable columns={columns} data={filteredInvoices} />
      )}

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => {
          setIsModalOpen(false);
          setEditingInvoice(null);
        }} 
        title={editingInvoice ? "Edit Invoice" : "Create New Invoice"} 
        size="xl"
      >
        <form onSubmit={handleSave} className="space-y-8 relative">
          <style dangerouslySetInnerHTML={{ __html: compileCustomStyles() }} />

          <div className="custom-font space-y-8">

              {/* Customized Branding Header */}
              <div 
                className={cn(
                  "p-6 rounded-2xl mb-6",
                  templateCustomizer.templateStyle === 'standard' && "bg-slate-50 border border-dashed border-slate-200 p-5",
                  templateCustomizer.templateStyle === 'professional' && "text-white shadow-md",
                  templateCustomizer.templateStyle === 'modern' && "bg-white border-b-2 pb-6 rounded-none px-0"
                )}
                style={
                  templateCustomizer.templateStyle === 'professional' 
                    ? { backgroundColor: templateCustomizer.primaryColor } 
                    : (templateCustomizer.templateStyle === 'modern' ? { borderBottomColor: templateCustomizer.primaryColor } : {})
                }
              >
                {/* Logo alignment and size render */}
                <div className={cn(
                  "flex mb-5 print:mb-2",
                  templateCustomizer.logoAlignment === 'left' && "justify-start",
                  templateCustomizer.logoAlignment === 'center' && "justify-center",
                  templateCustomizer.logoAlignment === 'right' && "justify-end",
                  !templateCustomizer.logoUrl && "print:hidden"
                )}>
                  {templateCustomizer.logoUrl ? (
                    <div className="relative group/logo">
                      <img 
                        src={templateCustomizer.logoUrl} 
                        alt="Company Logo" 
                        className={cn(
                          "object-contain",
                          templateCustomizer.logoSize === 'small' && "h-10",
                          templateCustomizer.logoSize === 'medium' && "h-16",
                          templateCustomizer.logoSize === 'large' && "h-24"
                        )}
                        referrerPolicy="no-referrer"
                      />
                      <button
                        type="button"
                        onClick={() => setTemplateCustomizer(prev => ({ ...prev, logoUrl: '' }))}
                        className="absolute -top-2 -right-2 bg-rose-600 text-white p-1 rounded-full text-[9px] shadow hover:bg-rose-700 opacity-0 group-hover/logo:opacity-100 transition-opacity print:hidden"
                        title="Remove logo"
                      >
                        ✕
                      </button>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center py-2 px-4 border border-dashed border-slate-300 rounded-xl hover:bg-slate-100/50 cursor-pointer text-slate-400 hover:text-slate-600 print:hidden select-none bg-white">
                      <span className="text-[10px] font-bold">Add Logo</span>
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleLogoUpload} 
                        className="hidden" 
                      />
                    </label>
                  )}
                </div>

                <div className={cn(
                  "flex flex-col sm:flex-row justify-between items-start gap-4",
                  templateCustomizer.templateStyle === 'professional' ? "text-white" : "text-slate-800"
                )}>
                  <div>
                    <h1 
                      className={cn(
                        "text-2xl font-black uppercase tracking-tight",
                        templateCustomizer.templateStyle === 'professional' ? "text-white" : "custom-primary-text"
                      )}
                    >
                      Sales Invoice
                    </h1>
                    <p className="text-xs opacity-75 mt-0.5 font-bold">
                      Status: <span className="uppercase tracking-wide font-extrabold">{editingInvoice?.status || 'Draft'}</span>
                    </p>
                  </div>
                  
                  <div className="sm:text-right text-left">
                    <h2 className="text-sm font-extrabold uppercase tracking-wide">Yemen Finance Systems</h2>
                    <p className="text-[11px] opacity-75 mt-0.5">Main Office, Sana'a</p>
                    <p className="text-[11px] opacity-75">VAT Reg: 120-993-211</p>
                  </div>
                </div>
              </div>

          <div className="grid grid-cols-3 gap-8">
            <div className="space-y-4">
              <h4 className="font-bold text-slate-900 border-b pb-2">Customer Details</h4>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Customer</label>
                <select 
                  name="customerId" 
                  value={invoiceCustomerId} 
                  onChange={(e) => setInvoiceCustomerId(e.target.value)} 
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm"
                >
                  <option value="">Select a customer</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Billing Address</label>
                <textarea 
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 h-24 bg-slate-50 text-slate-700 text-sm" 
                  readOnly 
                  value={
                    (() => {
                      const cust = customers.find(c => c.id === invoiceCustomerId);
                      if (!cust) return '';
                      const addressParts = [
                        cust.streetAddress,
                        cust.city,
                        cust.governorate,
                        cust.country
                      ].filter(Boolean);
                      return addressParts.join('\n') || 'No address provided for this customer.';
                    })()
                  }
                  placeholder="Address will auto-populate..."
                />
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-bold text-slate-900 border-b pb-2">Invoice Info</h4>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Invoice Number</label>
                <input name="number" defaultValue={editingInvoice?.number || `INV-${new Date().getFullYear()}-${String(invoices.length + 1).padStart(3, '0')}`} required type="text" className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Invoice Date</label>
                <input name="date" defaultValue={editingInvoice?.date || new Date().toISOString().split('T')[0]} required type="date" className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Currency</label>
                <select
                  value={transactionCurrency || 'YER'}
                  onChange={(e) => handleCurrencyChange(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm font-semibold"
                >
                  {GLOBAL_CURRENCIES.map(curr => (
                    <option key={curr.code} value={curr.code}>
                      {curr.flag} {curr.code} ({curr.name})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center justify-between">
                  <span>Exchange Rate</span>
                  {transactionCurrency !== settings?.currency && (
                    <span className="text-[10px] text-indigo-600 bg-indigo-50 px-2.2 py-0.5 rounded-full font-bold">
                      1 {transactionCurrency} = {transactionExchangeRate.toFixed(4)} {settings?.currency}
                    </span>
                  )}
                </label>
                <input
                  type="number"
                  step="any"
                  min="0.0001"
                  required
                  value={transactionExchangeRate}
                  onChange={(e) => setTransactionExchangeRate(Number(e.target.value) || 1.0)}
                  disabled={transactionCurrency === settings?.currency}
                  className={cn(
                    "w-full px-4 py-2 border rounded-lg outline-none text-sm font-mono font-bold",
                    transactionCurrency === settings?.currency
                      ? "bg-slate-50 border-slate-100 text-slate-400 cursor-not-allowed select-none"
                      : "bg-white border-slate-200 focus:ring-2 focus:ring-indigo-500 text-slate-950"
                  )}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  {document.documentElement.lang === 'ar' ? 'الفرع المستهدف' : 'Target Branch'}
                </label>
                <select
                  value={invoiceBranchId}
                  onChange={(e) => setInvoiceBranchId(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm font-semibold text-slate-950"
                >
                  <option value="Sana'a Main HQ branch">Sana'a Main HQ branch (فرع صنعاء الرئيسي)</option>
                  <option value="Aden Port Operations branch">Aden Port Operations branch (فرع عمليات ميناء عدن)</option>
                  <option value="Taiz Cold Store Branch">Taiz Cold Store Branch (فرع تعز للتبريد)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  {document.documentElement.lang === 'ar' ? 'مركز التكلفة' : 'Cost Center'}
                </label>
                <select
                  value={invoiceCostCenterId}
                  onChange={(e) => setInvoiceCostCenterId(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm font-semibold text-slate-950"
                >
                  <option value="Admin HQ Operations Center">Admin HQ Operations Center (عمليات الإدارة العامة)</option>
                  <option value="Sales Hub YER Ledger">Sales Hub YER Ledger (مركز مبيعات صنعاء)</option>
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-bold text-slate-900 border-b pb-2">Payment Terms</h4>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Due Date</label>
                <input name="dueDate" defaultValue={editingInvoice?.dueDate} required type="date" className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center justify-between">
                  <span>Sub Total</span>
                  <span className="text-xs text-indigo-600 font-normal font-sans">Calculated from items</span>
                </label>
                <input 
                  name="subTotal" 
                  value={invoiceSubTotal || '0.00'} 
                  readOnly 
                  placeholder="0.00" 
                  type="number" 
                  step="0.01" 
                  className="w-full px-4 py-2 border border-slate-100 bg-slate-50 text-slate-500 rounded-lg outline-none text-sm font-semibold select-none cursor-not-allowed" 
                />
              </div>
            </div>
          </div>

          {/* Item Table Section */}
          <div className="space-y-4 pt-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-2 border-slate-200">
              <h4 className="font-bold text-slate-800 text-base flex items-center gap-2">
                Item Table
              </h4>
              <div className="flex items-center gap-2 relative">
                {/* Scanner Popover or overlay */}
                {isScannerOpen && (
                  <div className="absolute right-0 bottom-full mb-2 bg-white border border-slate-200 rounded-xl p-4 shadow-xl z-[60] w-72 space-y-3">
                    <div className="flex items-center justify-between border-b pb-1">
                      <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                        <Barcode className="w-4 h-4 text-indigo-600" />
                        Scan Item Barcode
                      </span>
                      <button 
                        type="button" 
                        onClick={() => {
                          setIsScannerOpen(false);
                          setScanSku('');
                          setScanError('');
                        }}
                        className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase">Enter Item SKU</label>
                        <input 
                          type="text" 
                          placeholder="e.g. ITEM-001, ITEM-002"
                          value={scanSku}
                          onChange={(e) => setScanSku(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              e.stopPropagation();
                              handleScanItem();
                            }
                          }}
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-xs bg-slate-50"
                          autoFocus
                        />
                      </div>
                      {scanError && (
                        <p className="text-[10px] text-rose-600 font-medium">{scanError}</p>
                      )}
                      <button 
                        type="button"
                        onClick={handleScanItem}
                        className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-sm transition-colors"
                      >
                        Scan & Add
                      </button>
                    </div>
                  </div>
                )}

                {/* Bulk Actions Dropdown */}
                {isBulkActionOpen && (
                  <div className="absolute right-0 bottom-full mb-2 bg-white border border-slate-200 rounded-xl shadow-xl z-[60] w-52 py-1 overflow-hidden animate-in fade-in-50 duration-75">
                    <div className="px-3 py-1 border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      Actions
                    </div>
                    <button 
                      type="button" 
                      onClick={() => handleBulkAction('add3')}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-medium text-slate-700 transition"
                    >
                      + Add 3 Empty Rows
                    </button>
                    <button 
                      type="button" 
                      onClick={() => handleBulkAction('tax15')}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-medium text-slate-700 transition"
                    >
                      Apply VAT (15%) on all
                    </button>
                    <button 
                      type="button" 
                      onClick={() => handleBulkAction('tax5')}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-medium text-slate-700 transition"
                    >
                      Apply VAT (5%) on all
                    </button>
                    <div className="border-t border-slate-100 my-0.5" />
                    <button 
                      type="button" 
                      onClick={() => handleBulkAction('clear')}
                      className="w-full text-left px-4 py-2 hover:bg-rose-50 text-xs font-semibold text-rose-600 transition"
                    >
                      Clear All Rows
                    </button>
                  </div>
                )}

                <button 
                  type="button" 
                  onClick={() => {
                    setIsScannerOpen(!isScannerOpen);
                    setIsBulkActionOpen(false);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600 text-xs font-semibold shadow-sm transition-all"
                >
                  <Scan className="w-3.5 h-3.5 text-slate-500" />
                  Scan Item
                </button>
                <button 
                  type="button" 
                  onClick={() => {
                    setIsBulkActionOpen(!isBulkActionOpen);
                    setIsScannerOpen(false);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600 text-xs font-semibold shadow-sm transition-all"
                >
                  <Layers className="w-3.5 h-3.5 text-slate-500" />
                  Bulk Actions
                </button>
              </div>
            </div>

            {/* Item Rows Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-sm bg-white">
              <table className="w-full text-left border-collapse">
                <thead className={cn(
                  "text-[11px] uppercase tracking-wider font-extrabold border-b",
                  templateCustomizer.templateStyle === 'professional' ? "custom-primary-bg text-white border-transparent" : "bg-slate-50 text-slate-700 border-slate-200"
                )}>
                  <tr>
                    <th className="px-4 py-3 min-w-[320px]">Item Details</th>
                    <th className="px-4 py-3 min-w-[240px]">Revenue Account / الحساب المالي</th>
                    <th className="px-4 py-3 w-[120px] text-right">Quantity</th>
                    <th className="px-4 py-3 w-[150px] text-right">Rate</th>
                    {!templateCustomizer.hideTaxColumn && <th className="px-4 py-3 w-[180px]">Tax</th>}
                    <th className="px-4 py-3 w-[140px] text-right">Amount</th>
                    <th className="px-2 py-3 w-[45px] text-center print-hidden"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {formRows.map((row, index) => (
                    <tr key={row.id} className="hover:bg-slate-50/50 transition-colors">
                      {/* Searchable dropdown trigger */}
                      <td className="px-4 py-2.5 relative">
                        <div className="relative">
                          <input 
                            type="text"
                            placeholder="Type or click to select an item."
                            value={
                              activeDropdownRowId === row.id 
                                ? (rowSearchQueries[row.id] ?? '') 
                                : (row.name ? `${row.sku} - ${row.name}` : '')
                            }
                            onChange={(e) => {
                              setRowSearchQueries(prev => ({ ...prev, [row.id]: e.target.value }));
                              setActiveDropdownRowId(row.id);
                            }}
                            onFocus={() => {
                              setActiveDropdownRowId(row.id);
                              if (!rowSearchQueries[row.id]) {
                               setRowSearchQueries(prev => ({ ...prev, [row.id]: row.name || '' }));
                              }
                            }}
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-xs text-slate-800"
                          />
                          
                          {activeDropdownRowId === row.id && (
                            <>
                              <div 
                                className="fixed inset-0 z-40" 
                                onClick={() => setActiveDropdownRowId(null)}
                              />
                              <div className="absolute left-0 right-0 mt-1 max-h-60 overflow-y-auto bg-white border border-slate-200 rounded-xl shadow-2xl z-50 py-1.5">
                                {(() => {
                                  const queryText = (rowSearchQueries[row.id] ?? '').toLowerCase();
                                  const filtered = items.filter(it => 
                                    it.name.toLowerCase().includes(queryText) || 
                                    it.sku.toLowerCase().includes(queryText)
                                  );
                                  
                                  if (filtered.length === 0) {
                                    return (
                                      <div className="px-3 py-2 text-xs text-slate-400 text-center italic">
                                        No matching items found
                                      </div>
                                    );
                                  }
                                  
                                  return filtered.map(it => (
                                    <button
                                      key={it.id}
                                      type="button"
                                      onClick={() => {
                                        const mappingAccId = it.incomeAccountId || 'acc_sales_revenue';
                                        const mappingAccName = accounts.find(a => a.id === mappingAccId)?.name || 'Standard Product Sales Revenue';
                                        handleRowChange(row.id, {
                                          itemId: it.id,
                                          name: it.name,
                                          sku: it.sku,
                                          rate: it.salesPrice,
                                          accountId: mappingAccId,
                                          accountName: mappingAccName
                                        });
                                        setActiveDropdownRowId(null);
                                        setRowSearchQueries(prev => ({ ...prev, [row.id]: '' }));
                                      }}
                                      className="w-full text-left px-4 py-2 hover:bg-slate-50 flex flex-col gap-0.5 border-b border-slate-50 last:border-none"
                                    >
                                      <span className="font-bold text-slate-800 text-xs">{it.sku} - {it.name}</span>
                                      <span className="text-[10px] text-slate-400">Price: {formatCurrency(it.salesPrice, 'YER')} | Stock: {it.stockOnHand}</span>
                                    </button>
                                  ));
                                })()}
                              </div>
                            </>
                          )}
                        </div>
                      </td>

                      {/* Account Selector column */}
                      <td className="px-4 py-2.5 min-w-[240px]">
                        <AccountDropdownSelector
                          accountsList={accounts}
                          selectedAccountId={row.accountId || ''}
                          filterByType="Income"
                          placeholder="اختر الحساب المحاسبي للإيراد المربوط..."
                          className="w-full px-2.5 py-1.5 border border-slate-200 bg-white text-[11px] rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 font-semibold text-slate-700 select-none cursor-pointer"
                          onAccountChange={(newAccountId) => {
                            const acc = accounts.find(a => a.id === newAccountId);
                            handleRowChange(row.id, {
                              accountId: newAccountId,
                              accountName: acc?.name || ''
                            });
                          }}
                        />
                      </td>

                      {/* Quantity column */}
                      <td className="px-4 py-2.5">
                        <input 
                          type="number"
                          min="0.01"
                          step="0.01"
                          required
                          value={row.quantity}
                          onChange={(e) => handleRowChange(row.id, { quantity: Number(e.target.value) })}
                          placeholder="1.00"
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-xs text-slate-800 text-right font-semibold"
                        />
                      </td>

                      {/* Rate column */}
                      <td className="px-4 py-2.5">
                        <input 
                          type="number"
                          min="0"
                          step="0.01"
                          required
                          value={row.rate}
                          onChange={(e) => handleRowChange(row.id, { rate: Number(e.target.value) })}
                          placeholder="0.00"
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-xs text-slate-800 text-right font-semibold"
                        />
                      </td>

                      {/* Tax column */}
                      {!templateCustomizer.hideTaxColumn && (
                        <td className="px-4 py-2.5">
                          <select
                            value={row.taxPercent}
                            onChange={(e) => {
                              const val = Number(e.target.value);
                              let lbl = 'Select a Tax';
                              if (val === 15) lbl = 'VAT (15%)';
                              else if (val === 5) lbl = 'VAT (5%)';
                              else if (val === 0) lbl = 'Tax Exempt (0%)';
                              else lbl = `Custom VAT (${val}%)`;
                              handleRowChange(row.id, { taxPercent: val, taxLabel: lbl });
                            }}
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-xs text-slate-800 font-medium"
                          >
                            <option value="0" disabled={row.taxLabel === 'Select a Tax'}>Select a Tax</option>
                            <option value="0">Tax Exempt (0%)</option>
                            <option value="5">VAT (5%)</option>
                            <option value="15">VAT (15%)</option>
                            {settings && settings.vatPercentage !== 15 && settings.vatPercentage !== 5 && (
                              <option value={settings.vatPercentage}>Custom VAT ({settings.vatPercentage}%)</option>
                            )}
                          </select>
                        </td>
                      )}

                      {/* Amount read-only column */}
                      <td className="px-4 py-2.5 text-right">
                        <input 
                          type="text"
                          readOnly
                          value={formatCurrency(row.amount, transactionCurrency)}
                          className="w-full px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-xs font-extrabold text-slate-700 text-right cursor-not-allowed select-none"
                        />
                      </td>

                      {/* Bin/Trash column */}
                      <td className="px-2 py-2.5 text-center print-hidden">
                        <button
                          type="button"
                          onClick={() => {
                            if (formRows.length > 1) {
                              setFormRows(prev => prev.filter(r => r.id !== row.id));
                            } else {
                              setFormRows([createEmptyRow()]);
                            }
                          }}
                          className="p-1 px-1.5 text-slate-400 hover:text-rose-600 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Action buttons under table */}
            <div className="flex items-center gap-2 pt-1 pb-2">
              <div className="relative inline-flex group">
                <button 
                  type="button" 
                  onClick={() => setFormRows(prev => [...prev, createEmptyRow()])}
                  className="flex items-center justify-between gap-2 px-3.5 py-2 border border-slate-200 bg-slate-50 hover:bg-slate-100 rounded-lg text-slate-700 text-xs font-semibold transition-all shadow-sm"
                >
                  <span>+ Add New Row</span>
                  <ChevronDown className="w-3 h-3 text-slate-500 mt-0.5" />
                </button>
              </div>
              <button 
                type="button" 
                onClick={handleAddItemsInBulk}
                className="flex items-center gap-1.5 px-3.5 py-2 border border-indigo-100 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-indigo-700 text-xs font-semibold transition-all shadow-sm"
              >
                <PlusCircle className="w-3.5 h-3.5 text-indigo-600" />
                + Add Items in Bulk
              </button>
            </div>
          </div>

          {/* Horizontal Separator */}
          <div className="border-t border-slate-200 my-6" />

          {/* Bottom Section: Two Main Columns */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column: Notes & Conditions */}
            <div className="space-y-6">
              <div className={cn(templateCustomizer.hideCustomerNotes && "print:hidden")}>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-sm font-semibold text-slate-800">Customer Notes</label>
                  {templateCustomizer.hideCustomerNotes && (
                    <span className="text-[10px] text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full font-bold print:hidden">Hidden on Print</span>
                  )}
                </div>
                <textarea 
                  name="customerNotes"
                  value={invoiceCustomerNotes}
                  onChange={(e) => setInvoiceCustomerNotes(e.target.value)}
                  placeholder="Thanks for your business."
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 h-24 text-sm resize-none bg-white font-semibold"
                />
                <p className="text-[11px] text-slate-500 mt-1">Will be displayed on the invoice</p>
              </div>

              <div className={cn(templateCustomizer.hideTermsAndConditions && "print:hidden")}>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-sm font-semibold text-slate-800">Terms & Conditions</label>
                  {templateCustomizer.hideTermsAndConditions && (
                    <span className="text-[10px] text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full font-bold print:hidden">Hidden on Print</span>
                  )}
                </div>
                <textarea 
                  name="termsConditions"
                  value={invoiceTermsConditions}
                  onChange={(e) => setInvoiceTermsConditions(e.target.value)}
                  placeholder="Enter the terms and conditions of your business to be displayed in your transaction"
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 h-24 text-sm resize-none bg-white font-semibold"
                />
              </div>
            </div>

            {/* Right Column: Calculation Block */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4 shadow-sm hover:border-indigo-200 transition-all">
              <h4 className="font-bold text-sm text-slate-900 border-b pb-2 uppercase tracking-wide flex items-center gap-1.5">
                Calculation Summary
              </h4>

              {/* Sub Total Row */}
              <div className="flex items-center justify-between text-sm py-1 border-b border-dashed border-slate-200 pb-2">
                <span className="text-slate-600 font-medium">Sub Total</span>
                <span className="font-bold text-slate-900">{formatCurrency(invoiceSubTotal, transactionCurrency)}</span>
              </div>

              {/* Discount Row */}
              <div className="flex items-center justify-between gap-4 text-sm py-1">
                <div className="flex items-center gap-2 flex-1">
                  <span className="text-slate-600 font-medium">Discount</span>
                  <div className="relative inline-flex items-center">
                    <input 
                      type="number"
                      min="0"
                      max="100"
                      step="0.01"
                      placeholder="0"
                      value={invoiceDiscountPercent || ''}
                      onChange={(e) => setInvoiceDiscountPercent(Number(e.target.value))}
                      className="w-16 pl-2 pr-5 py-0.5 text-xs border border-slate-300 rounded outline-none text-right font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none bg-white"
                    />
                    <span className="absolute right-1 text-xs text-slate-400 font-bold">%</span>
                  </div>
                </div>
                <span className="font-bold text-rose-600">
                  -{formatCurrency(calculatedDiscount, transactionCurrency)}
                </span>
              </div>

              {/* Shipping Charges Row */}
              <div className={cn("flex items-center justify-between gap-4 text-sm py-1", templateCustomizer.hideShippingCharges && "print:hidden")}>
                <div className="flex items-center gap-1.5 flex-1">
                  <span className="text-slate-600 font-medium">Shipping Charges</span>
                  {templateCustomizer.hideShippingCharges && (
                    <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.2 rounded font-bold print:hidden">Hidden on Print</span>
                  )}
                  <div className="group relative print-hidden">
                    <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-pointer hover:text-indigo-600 select-none pb-0.5" />
                    <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-1 w-48 hidden group-hover:block bg-slate-900 text-white text-[10px] rounded p-2 shadow-lg z-50 text-center font-normal leading-normal">
                      Will be displayed on the invoice
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <input 
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    value={invoiceShippingCharges || ''}
                    onChange={(e) => setInvoiceShippingCharges(Number(e.target.value))}
                    className="w-24 px-2 py-0.5 text-xs text-right border border-slate-300 rounded font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 bg-white print-hidden"
                  />
                  <span className="font-bold text-slate-900 min-w-[80px] text-right">
                    {formatCurrency(invoiceShippingCharges || 0, transactionCurrency)}
                  </span>
                </div>
              </div>

              {/* Adjustment Row */}
              <div className="flex items-center justify-between gap-4 text-sm py-1 border-b border-dashed border-slate-200 pb-3">
                <div className="flex items-center gap-1.5 flex-1">
                  <span className="text-slate-600 font-medium">Adjustment</span>
                  <div className="group relative print-hidden">
                    <HelpCircle className="w-3.5 h-3.5 text-slate-400 cursor-pointer hover:text-indigo-600 select-none pb-0.5" />
                    <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-1 w-48 hidden group-hover:block bg-slate-900 text-white text-[10px] rounded p-2 shadow-lg z-50 text-center font-normal leading-normal">
                      Will be displayed in your transaction
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <input 
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={invoiceAdjustment || ''}
                    onChange={(e) => setInvoiceAdjustment(Number(e.target.value))}
                    className="w-24 px-2 py-0.5 text-xs text-right border border-slate-300 rounded font-semibold text-slate-800 focus:ring-2 focus:ring-indigo-500 bg-white print-hidden"
                  />
                  <span className={cn(
                    "font-bold min-w-[80px] text-right",
                    invoiceAdjustment < 0 ? "text-rose-600" : invoiceAdjustment > 0 ? "text-emerald-600" : "text-slate-900"
                  )}>
                    {invoiceAdjustment > 0 ? "+" : ""}{formatCurrency(invoiceAdjustment || 0, transactionCurrency)}
                  </span>
                </div>
              </div>

              {/* Grand Total Row */}
              <div className="flex items-center justify-between text-base py-2.5 font-extrabold text-indigo-700 bg-indigo-50 rounded-lg px-4 border border-indigo-100">
                <span>Total ({transactionCurrency})</span>
                <span className="text-lg">{formatCurrency(grandTotal, transactionCurrency)}</span>
              </div>

              {/* Base Currency Equivalent Display Block */}
              {transactionCurrency !== settings?.currency && (
                <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-xl text-xs flex justify-between items-center text-indigo-900 font-bold font-mono">
                  <span>Equivalent in Base ({settings?.currency}):</span>
                  <span>{formatCurrency(grandTotal * transactionExchangeRate, settings?.currency)}</span>
                </div>
              )}
            </div>

            {/* Bottom-right attachments layout box */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-inner mt-4 print-hidden">
              <h4 className="font-bold text-xs text-slate-700 mb-3 flex items-center gap-1.5 uppercase tracking-wide">
                <PaperclipIcon className="w-4 h-4 text-indigo-600 font-bold" />
                Linked Reference Attachments
              </h4>
              <FileAttachments entityId={currentEntityId} />
            </div>

          </div>
          </div>

          <div className="flex items-center justify-between pt-8 border-t print-hidden">
            <div className="flex items-center gap-2">
              <button 
                type="button" 
                onClick={() => setIsModalOpen(false)} 
                className="px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-semibold text-slate-600 text-sm"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="px-4 py-2 border border-indigo-100 text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-all font-semibold shadow-sm flex items-center gap-2 text-sm"
              >
                <Printer className="w-4 h-4" />
                Print Invoice
              </button>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="submit"
                onClick={() => setSaveStatus('Draft')}
                disabled={isSaving}
                className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors font-semibold text-sm"
              >
                Save as Draft
              </button>
              <button
                type="button"
                onClick={handlePreviewJournalEntryClick}
                className="px-4 py-2 bg-slate-100 ring-1 ring-slate-250 hover:bg-slate-200 text-slate-700 rounded-lg transition-all font-semibold text-sm flex items-center gap-1.5"
              >
                <Layers className="w-4 h-4 text-indigo-500 shrink-0" />
                <span>Preview Journal Entry</span>
              </button>
              <button
                type="submit"
                onClick={() => setSaveStatus('Posted')}
                disabled={isSaving}
                className="px-4 py-2 border border-emerald-200 text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors font-semibold text-sm"
              >
                Save and Post
              </button>
              <button 
                type="submit" 
                onClick={() => setSaveStatus('Sent')}
                disabled={isSaving}
                className="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-semibold shadow-sm flex items-center gap-2 text-sm"
              >
                {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
                {isSaving ? 'Saving...' : (editingInvoice ? 'Save & Publish' : 'Save and Send')}
              </button>
            </div>
          </div>
        </form>
      </Modal>

      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        moduleId="invoices"
        existingRecords={invoices}
        onImportSuccess={(cnt) => {
          setIsImportModalOpen(false);
        }}
      />

      {/* 💵 Record Payment Modal */}
      <Modal
        isOpen={isPaymentModalOpen}
        onClose={() => {
          setIsPaymentModalOpen(false);
          setPaymentInvoice(null);
        }}
        title={`Record Payment / تسجيل الدفع - INV #${paymentInvoice?.number}`}
        size="md"
      >
        <form onSubmit={handleRecordPaymentSubmit} className="space-y-5">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
              Customer Name / العميل
            </label>
            <input
              type="text"
              readOnly
              value={paymentInvoice?.customerName || ''}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
                Payment Date / تاريخ الدفع
              </label>
              <input
                type="date"
                required
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
                Amount Received / المبلغ ({paymentInvoice?.currency || settings?.currency || 'YER'})
              </label>
              <input
                type="number"
                required
                min="0.01"
                step="0.01"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
              />
            </div>
          </div>

          {/* محرك تسوية فروق أسعار الصرف التلقائي والتشغيلي */}
          {paymentInvoice && (paymentInvoice as any).currency !== settings?.currency && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
              <div>
                <label className="block text-xs font-black text-indigo-900 uppercase tracking-widest mb-2">
                  Settlement Rate / سعر التسوية
                </label>
                <input
                  type="number"
                  required
                  min="0.000001"
                  step="0.000001"
                  value={paymentSettlementRate}
                  onChange={(e) => setPaymentSettlementRate(parseFloat(e.target.value) || 1.0)}
                  className="w-full px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Original Invoice Rate: 1 {(paymentInvoice as any).currency} = {((paymentInvoice as any).exchangeRate || 1.0).toFixed(4)} {settings?.currency}
                </span>
              </div>
              <div className="flex flex-col justify-center">
                <span className="text-xs font-bold text-indigo-700 block">
                  ✨ FOREX Realized Drift / فارق الصرف:
                </span>
                {(() => {
                  const origRate = Number((paymentInvoice as any).exchangeRate) || 1.0;
                  const settRate = Number(paymentSettlementRate) || 1.0;
                  const baseValueOriginal = paymentAmount / origRate;
                  const baseValueSettlement = paymentAmount / settRate;
                  const correction = baseValueOriginal - baseValueSettlement;
                  return (
                    <span className="text-sm font-mono font-black mt-1 text-indigo-600">
                      {correction > 0 
                        ? `Realized Loss / خسارة فروق: +${correction.toFixed(2)} ${settings?.currency}`
                        : correction < 0 
                          ? `Realized Gain / أرباح فروق: ${correction.toFixed(2)} ${settings?.currency}`
                          : `Perfect Alignment / تطابق تام (0.00)`}
                    </span>
                  );
                })()}
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
              Payment Reference (e.g. Cheque #) / المرجع
            </label>
            <input
              type="text"
              placeholder="e.g. Bank Transfer Ref, Cash Receipt #, Cheque #"
              value={paymentReference}
              onChange={(e) => setPaymentReference(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 placeholder-slate-400 outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
              Payment Source / الحساب المالي (طريقة الدفع)
            </label>
            <AccountDropdownSelector
              accountsList={accounts}
              selectedAccountId={paymentAccountId}
              filterByType="Asset"
              placeholder="اختر الحساب المالي المدفوع له..."
              className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500 font-medium text-right"
              onAccountChange={(newAccountId) => {
                setPaymentAccountId(newAccountId);
                const acc = accounts.find(a => a.id === newAccountId);
                if (acc) {
                  setPaymentAccountName(acc.name);
                }
              }}
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">
              Balanced Double-Entry Audit Check / تفاصيل القيد المزدوج
            </label>
            <div className="bg-slate-50 border border-slate-100 p-3 rounded-lg text-[11px] space-y-1 text-slate-600 font-mono">
              <p className="text-emerald-700 font-bold">🟢 DEBIT: {paymentAccountName} : {formatCurrency(paymentAmount)}</p>
              <p className="text-rose-700 font-bold">🔴 CREDIT: Accounts Receivable [مدينو مبيعات - 120101] : {formatCurrency(paymentAmount)}</p>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => {
                setIsPaymentModalOpen(false);
                setPaymentInvoice(null);
              }}
              className="px-4 py-2 border border-slate-200 rounded-lg text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isRecordingPayment || paymentAmount <= 0}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-sm transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              {isRecordingPayment ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Recording...
                </>
              ) : (
                'Confirm Receipt / تأكيد الدفع'
              )}
            </button>
          </div>
        </form>
      </Modal>

      {/* 🔄 Issue Sales Return / Credit Note Modal */}
      <Modal
        isOpen={isCreditNoteModalOpen}
        onClose={() => {
          setIsCreditNoteModalOpen(false);
          setCreditNoteInvoice(null);
        }}
        title={`Issue Credit Note / إصدار مردود مبيعات - INV #${creditNoteInvoice?.number}`}
        size="md"
      >
        <form onSubmit={handleCreateCreditNoteSubmit} className="space-y-5">
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
              Customer Name / العميل
            </label>
            <input
              type="text"
              readOnly
              value={creditNoteInvoice?.customerName || ''}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
                Return Date / تاريخ المردود
              </label>
              <input
                type="date"
                required
                value={creditNoteDate}
                onChange={(e) => setCreditNoteDate(e.target.value)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
                Reversal / Return Amount (YER)
              </label>
              <input
                type="number"
                required
                min="0.01"
                step="0.01"
                max={creditNoteInvoice?.total || 99999999}
                value={creditNoteAmount}
                onChange={(e) => setCreditNoteAmount(parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">
              Reason for Return / سبب المردود
            </label>
            <textarea
              required
              rows={3}
              value={creditNoteReason}
              onChange={(e) => setCreditNoteReason(e.target.value)}
              className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="e.g. Faulty inventory, overbilled amounts, order cancellation"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">
              Balanced Reversal Double-Entry Audit Check
            </label>
            <div className="bg-slate-50 border border-slate-100 p-3 rounded-lg text-[11px] space-y-1 text-slate-605 font-mono">
              <p className="text-emerald-700 font-bold">🟢 DEBIT: Sales Revenue Reversed [ايرادات مبيعات - 410101] : {formatCurrency(creditNoteAmount)}</p>
              <p className="text-rose-700 font-bold">🔴 CREDIT: Accounts Receivable Relieved [مدينو مبيعات - 120101] : {formatCurrency(creditNoteAmount)}</p>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => {
                setIsCreditNoteModalOpen(false);
                setCreditNoteInvoice(null);
              }}
              className="px-4 py-2 border border-slate-200 rounded-lg text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isCreatingCreditNote || creditNoteAmount <= 0}
              className="px-5 py-2 font-bold rounded-lg text-sm transition-all shadow-md flex items-center gap-2 cursor-pointer border border-amber-300 bg-amber-200 text-amber-900 hover:bg-amber-300"
            >
              {isCreatingCreditNote ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Processing...
                </>
              ) : (
                'Post Credit Note / ترحيل المردود'
              )}
            </button>
          </div>
        </form>
      </Modal>

      <JournalPreviewModal
        isOpen={isPreviewModalOpen}
        onClose={() => setIsPreviewModalOpen(false)}
        onConfirmPost={handleConfirmPreviewPost}
        transactionData={pendingLedgerTx}
      />
    </div>
  );
}
