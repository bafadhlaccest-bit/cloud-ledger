import { DashboardOrchestrator } from './dashboard/DashboardOrchestrator';

export default DashboardOrchestrator;
