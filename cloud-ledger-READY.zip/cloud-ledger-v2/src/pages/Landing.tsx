import React from 'react';
import { Link } from 'react-router-dom';
import { FileText, BarChart3, ShieldCheck, Zap, Globe, Users, CheckCircle, ChevronLeft, Star, BookOpen, Sparkles, ArrowLeft } from 'lucide-react';

const FEATURES = [
  { icon: <BarChart3 className="w-6 h-6" />, title: 'تقارير مالية فورية', desc: 'ميزانية عمومية، قائمة دخل، ميزان مراجعة — محدّثة لحظياً' },
  { icon: <Sparkles className="w-6 h-6" />, title: 'محاسب ذكي بالذكاء الاصطناعي', desc: 'اكتب العملية بالعربية وسيسجلها المحاسب الذكي محاسبياً تلقائياً' },
  { icon: <ShieldCheck className="w-6 h-6" />, title: 'متوافق مع IFRS والضريبة', desc: 'مبني على معايير المحاسبة الدولية ومتوافق مع متطلبات ضريبة القيمة المضافة' },
  { icon: <Globe className="w-6 h-6" />, title: 'متعدد العملات', desc: 'فواتير وقيود بأي عملة مع أسعار صرف لحظية من صندوق النقد الدولي' },
  { icon: <Users className="w-6 h-6" />, title: 'صلاحيات متعددة', desc: 'أدوار مرنة: مدير، محاسب، مبيعات، مشتريات — بحدود واضحة' },
  { icon: <Zap className="w-6 h-6" />, title: 'ربط مع المتاجر الإلكترونية', desc: 'تكامل مع سلّة وزد — فواتير تُسجَّل محاسبياً تلقائياً' },
];

const PLANS = [
  {
    name: 'مجاني', price: '0', period: 'للأبد',
    features: ['شركة واحدة', '100 فاتورة/شهر', '2 مستخدم', 'تقارير أساسية'],
    cta: 'ابدأ مجاناً', highlight: false,
  },
  {
    name: 'الأعمال', price: '149', period: 'ريال/شهر',
    features: ['شركة واحدة', 'فواتير غير محدودة', '10 مستخدمين', 'جميع التقارير', 'المحاسب الذكي', 'دعم أولوية'],
    cta: 'جرّب 14 يوم مجاناً', highlight: true,
  },
  {
    name: 'المؤسسات', price: '399', period: 'ريال/شهر',
    features: ['شركات غير محدودة', 'مستخدمون غير محدودون', 'تقارير متقدمة', 'API كامل', 'مدير حساب مخصص', 'SLA 99.9%'],
    cta: 'تواصل معنا', highlight: false,
  },
];

const TESTIMONIALS = [
  { name: 'أحمد العمري', role: 'صاحب شركة تجارية، الرياض', text: 'وفّر عليّ ساعات أسبوعياً. التقارير جاهزة بنقرة واحدة والمحاسب الذكي يوفر وقت كبير.', stars: 5 },
  { name: 'فاطمة الزهراني', role: 'محاسبة، جدة', text: 'أفضل نظام جربته. واجهة عربية سلسة والتقارير وفق المعايير الدولية بالضبط.', stars: 5 },
  { name: 'خالد الدوسري', role: 'مدير مالي، الكويت', text: 'ربطناه مع سلّة وصارت الفواتير تُسجَّل تلقائياً. لا مقارنة بالنظام القديم.', stars: 5 },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-white" dir="rtl">
      {/* Navbar */}
      <nav className="sticky top-0 bg-white/90 backdrop-blur border-b border-slate-100 z-50">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
              <FileText className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-slate-900 text-lg">Cloud Ledger</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-slate-600">
            <a href="#features" className="hover:text-slate-900 transition-colors">المزايا</a>
            <a href="#pricing" className="hover:text-slate-900 transition-colors">الأسعار</a>
            <a href="#testimonials" className="hover:text-slate-900 transition-colors">آراء العملاء</a>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm text-slate-600 hover:text-slate-900 font-medium">دخول</Link>
            <Link to="/register" className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors">
              جرّب مجاناً
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="bg-gradient-to-b from-indigo-950 to-slate-900 text-white py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-sm px-4 py-1.5 rounded-full mb-6">
            <Sparkles className="w-3.5 h-3.5" />
            نظام محاسبة ذكي للمنشآت العربية
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-6">
            محاسبتك <span className="text-indigo-400">أبسط</span>،<br />أرباحك <span className="text-emerald-400">أوضح</span>
          </h1>
          <p className="text-lg text-slate-300 mb-10 max-w-2xl mx-auto leading-relaxed">
            نظام محاسبة سحابي متكامل مصمم للمنشآت الصغيرة والمتوسطة في السوق العربي. فواتير، تقارير مالية، محاسب ذكي بالعربية — كل شيء في مكان واحد.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register" className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-8 py-4 rounded-xl transition-colors text-lg flex items-center justify-center gap-2">
              ابدأ مجاناً — 14 يوم <ArrowLeft className="w-5 h-5" />
            </Link>
            <Link to="/login" className="border border-white/20 hover:border-white/40 text-white font-semibold px-8 py-4 rounded-xl transition-colors text-lg">
              تسجيل الدخول
            </Link>
          </div>
          <p className="text-slate-500 text-sm mt-4">لا يتطلب بطاقة ائتمان · إلغاء في أي وقت</p>
        </div>

        {/* Stats */}
        <div className="max-w-3xl mx-auto mt-16 grid grid-cols-3 gap-8 text-center border-t border-white/10 pt-12">
          {[
            { num: '+500', label: 'شركة تثق بنا' },
            { num: '99.9%', label: 'وقت تشغيل مضمون' },
            { num: 'IFRS', label: 'متوافق مع المعايير الدولية' },
          ].map(s => (
            <div key={s.label}>
              <div className="text-3xl font-extrabold text-white">{s.num}</div>
              <div className="text-slate-400 text-sm mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-slate-900 mb-3">كل ما تحتاجه في نظام واحد</h2>
            <p className="text-slate-500 max-w-xl mx-auto">مبني خصيصاً لمتطلبات السوق العربي والمعايير الدولية</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map(f => (
              <div key={f.title} className="p-6 rounded-2xl border border-slate-100 hover:border-indigo-200 hover:shadow-md transition-all group">
                <div className="w-12 h-12 bg-indigo-50 group-hover:bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center mb-4 transition-colors">
                  {f.icon}
                </div>
                <h3 className="font-bold text-slate-800 mb-2">{f.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI Feature highlight */}
      <section className="bg-gradient-to-l from-indigo-50 to-slate-50 py-20 px-6">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1">
            <div className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-700 text-sm px-3 py-1 rounded-full mb-4">
              <Sparkles className="w-3.5 h-3.5" /> مدعوم بـ Gemini AI
            </div>
            <h2 className="text-3xl font-bold text-slate-900 mb-4">اكتب بالعربية، وسيُسجَّل محاسبياً</h2>
            <p className="text-slate-600 leading-relaxed mb-6">
              بدل تعلّم القيد المزدوج، فقط اكتب:<br />
              <span className="text-indigo-700 font-medium">"بعت بضاعة بـ 5000 ريال نقداً وفيها ضريبة 15%"</span><br />
              وسيُنشئ المحاسب الذكي القيد المحاسبي الصحيح فوراً.
            </p>
            <ul className="space-y-2">
              {['يفهم العربية والإنجليزية', 'يقترح الحسابات المناسبة', 'يشرح كل قيد بالتفصيل', 'يتحقق من التوازن تلقائياً'].map(f => (
                <li key={f} className="flex items-center gap-2 text-sm text-slate-700">
                  <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" /> {f}
                </li>
              ))}
            </ul>
          </div>
          <div className="flex-1 bg-white rounded-2xl shadow-xl p-6 border border-slate-100">
            <div className="bg-slate-800 rounded-xl p-4 font-mono text-sm space-y-3">
              <div className="text-slate-400 text-xs mb-2">المحاسب الذكي</div>
              <div className="bg-indigo-900/50 text-indigo-200 p-3 rounded-lg text-right">
                "اشتريت بضاعة من المورد أحمد بـ 20,000 ريال آجل"
              </div>
              <div className="text-slate-400 text-xs">القيد المحاسبي المقترح ↓</div>
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-green-400">5000 — المشتريات</span>
                  <span className="text-blue-300">مدين: 17,391</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-green-400">2120 — ضريبة قيمة مضافة</span>
                  <span className="text-blue-300">مدين: 2,609</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-green-400">2110 — الموردون</span>
                  <span className="text-orange-300">دائن: 20,000</span>
                </div>
              </div>
              <div className="text-emerald-400 text-xs flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> القيد متوازن — جاهز للترحيل
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-slate-900 mb-3">أسعار شفافة، بدون مفاجآت</h2>
            <p className="text-slate-500">ابدأ مجاناً، وارتقِ حسب نمو شركتك</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {PLANS.map(p => (
              <div key={p.name} className={`p-6 rounded-2xl border-2 ${p.highlight ? 'border-indigo-600 shadow-xl shadow-indigo-100 relative' : 'border-slate-200'}`}>
                {p.highlight && (
                  <div className="absolute -top-3 right-1/2 translate-x-1/2 bg-indigo-600 text-white text-xs font-bold px-4 py-1 rounded-full">
                    الأكثر شيوعاً
                  </div>
                )}
                <div className="mb-5">
                  <div className="font-bold text-slate-700 mb-2">{p.name}</div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-extrabold text-slate-900">{p.price}</span>
                    <span className="text-slate-500 text-sm">{p.period}</span>
                  </div>
                </div>
                <ul className="space-y-2.5 mb-6">
                  {p.features.map(f => (
                    <li key={f} className="flex items-center gap-2 text-sm text-slate-600">
                      <CheckCircle className={`w-4 h-4 shrink-0 ${p.highlight ? 'text-indigo-600' : 'text-emerald-500'}`} /> {f}
                    </li>
                  ))}
                </ul>
                <Link to="/register"
                  className={`block text-center font-semibold py-3 rounded-xl transition-colors ${p.highlight ? 'bg-indigo-600 hover:bg-indigo-700 text-white' : 'border-2 border-slate-200 hover:border-indigo-300 text-slate-700'}`}>
                  {p.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="bg-slate-50 py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-slate-900 text-center mb-12">ماذا يقول عملاؤنا</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map(t => (
              <div key={t.name} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <div className="flex gap-0.5 mb-3">
                  {Array.from({ length: t.stars }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-slate-700 text-sm leading-relaxed mb-4">"{t.text}"</p>
                <div>
                  <div className="font-semibold text-slate-800 text-sm">{t.name}</div>
                  <div className="text-slate-500 text-xs mt-0.5">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-indigo-600 py-16 px-6 text-center text-white">
        <h2 className="text-3xl font-bold mb-4">جاهز تبدأ؟</h2>
        <p className="text-indigo-200 mb-8">14 يوم مجاناً — لا بطاقة ائتمان مطلوبة</p>
        <Link to="/register" className="bg-white text-indigo-700 font-bold px-8 py-4 rounded-xl hover:bg-indigo-50 transition-colors text-lg inline-flex items-center gap-2">
          أنشئ حسابك الآن <ArrowLeft className="w-5 h-5" />
        </Link>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-10 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-indigo-600 rounded flex items-center justify-center">
              <FileText className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-white font-semibold">Cloud Ledger</span>
          </div>
          <div className="flex gap-6 text-sm">
            <a href="#" className="hover:text-white transition-colors">شروط الاستخدام</a>
            <a href="#" className="hover:text-white transition-colors">الخصوصية</a>
            <a href="mailto:support@cloudledger.app" className="hover:text-white transition-colors">الدعم</a>
          </div>
          <div className="text-sm">© {new Date().getFullYear()} Cloud Ledger. جميع الحقوق محفوظة.</div>
        </div>
      </footer>
    </div>
  );
}
