import React from 'react';
import { ColumnDef } from '@tanstack/react-table';
import { DataTable } from '../components/DataTable';
import { Bill, Vendor, Item, Account } from '../types';
import { SEEDED_ITEMS, SEEDED_ACCOUNTS, getMergedItems, getMergedAccounts } from '../data/initialData';
import { formatCurrency, cn, formatDate } from '../lib/utils';
import { 
  Plus, 
  Search, 
  FileText, 
  Send, 
  CheckCircle, 
  Clock, 
  Loader2, 
  Trash2, 
  Edit2, 
  HelpCircle,
  Scan,
  Layers,
  PlusCircle,
  ChevronDown,
  Barcode,
  Printer,
  Palette
} from 'lucide-react';
import Modal from '../components/Modal';
import { useTranslation } from 'react-i18next';
import ImportModal from '../components/ImportModal';
import { exportToExcel, exportToPDF } from '../utils/exportImport';
import { Download, UploadCloud } from 'lucide-react';
import TemplateCustomizer from '../components/TemplateCustomizer';
import BillPaperPreview from '../components/BillPaperPreview';
import FileAttachments from '../components/FileAttachments';
import { saveDraftAttachments, getAttachments } from '../lib/attachmentStorage';
import { Paperclip as PaperclipIcon } from 'lucide-react';
import { useSettingsStore } from '../store/useSettingsStore';
import { useSettings } from '../context/SettingsContext';
import { CurrencyService, GLOBAL_CURRENCIES, custom_exchange_rates } from '../services/CurrencyService';
import GovernancePipeline from '../components/GovernancePipeline';
import { postToLedger } from '../utils/postingEngine';
import { PostingEngine } from '../services/PostingEngine';
import { AccountDropdown } from '../components/AccountDropdown';

import { safeStorage } from '../utils/safeStorage';

import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  serverTimestamp,
  orderBy,
  getDocs
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';
import { db, collection, addDoc, getDocs, updateDoc, deleteDoc, onSnapshot, query, where, orderBy, serverTimestamp, doc } from '../firebase';

// Dynamic Row Type inside the Bill Item Table
interface BillItemRow {
  id: string;
  itemId: string;
  name: string;
  sku: string;
  quantity: number;
  rate: number;
  taxPercent: number; // percentage value
  taxLabel: string;   // visual label
  amount: number;
  accountId: string;    // Debit Expense/Asset Account ID
  accountName: string;  // Debit Expense/Asset Account Name
}

function BillAttachmentsBadge({ billId }: { billId: string }) {
  const [count, setCount] = React.useState(0);
  const [isOpen, setIsOpen] = React.useState(false);

  React.useEffect(() => {
    let active = true;
    getAttachments(billId).then(list => {
      if (active) setCount(list.length);
    });
    // check periodically
    const interval = setInterval(() => {
      getAttachments(billId).then(list => {
        if (active) setCount(list.length);
      });
    }, 4000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [billId]);

  return (
    <>
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        className={cn(
          "flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[11px] font-bold shadow-xs hover:bg-slate-50 transition cursor-pointer select-none",
          count > 0 
            ? "bg-indigo-50 border-indigo-200 text-indigo-700 font-extrabold" 
            : "bg-white border-slate-200 text-slate-500"
        )}
      >
        <PaperclipIcon className="w-3.5 h-3.5" />
        <span>{count > 0 ? `${count} files` : 'Attach'}</span>
      </button>

      {isOpen && (
        <Modal
          isOpen={isOpen}
          onClose={() => setIsOpen(false)}
          title="Manage Bill Attachments"
          size="md"
        >
          <div className="space-y-4 p-1">
            <p className="text-xs text-slate-500 font-medium">
              View and manage attached reference documents and receipts for this bill directly.
            </p>
            <FileAttachments 
              entityId={billId} 
              onAttachmentsChange={(list) => setCount(list.length)} 
            />
            <div className="flex justify-end pt-4 border-t">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 font-bold rounded-lg text-xs shadow-sm transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}


export default function Purchases() {
  const { t } = useTranslation();
  const { settings } = useSettings();
  const enableServiceModule = useSettingsStore((state) => state.enableServiceModule);

  const [transactionCurrency, setTransactionCurrency] = React.useState<string>('YER');
  const [transactionExchangeRate, setTransactionExchangeRate] = React.useState<number>(1.0);
  const [officialRates, setOfficialRates] = React.useState<Record<string, number>>({});

  // Fetch official rates calibrated relative to System Base currency
  React.useEffect(() => {
    if (settings && settings.currency) {
      CurrencyService.fetchIMFRates(settings.currency)
        .then(rates => setOfficialRates(rates))
        .catch(err => {
          console.warn("Failed to fetch official rates, fallback to simplified system:", err);
          const simpleFallbacks: Record<string, number> = {
            'USD': 1.0, 'EUR': 0.92, 'SAR': 3.75, 'YER': 250.0, 'AED': 3.67, 'EGP': 47.0
          };
          const baseRateInUSD = simpleFallbacks[settings.currency] || 1.0;
          const calibrated: Record<string, number> = {};
          Object.keys(simpleFallbacks).forEach((k) => {
            calibrated[k] = simpleFallbacks[k] / baseRateInUSD;
          });
          calibrated[settings.currency] = 1.0;
          setOfficialRates(calibrated);
        });
    }
  }, [settings?.currency]);

  // Helper code to grab prioritised rate (custom override inside setting map first, then IMF official rate inverted as base per target)
  const getCurrencyExchangeRate = React.useCallback((currCode: string) => {
    if (!currCode) return 1.0;
    if (settings && currCode === settings.currency) return 1.0;

    // 1. Check custom override from settings
    const savedCustom = (window as any).custom_exchange_rates?.[currCode] || custom_exchange_rates?.[currCode];
    if (savedCustom && typeof savedCustom === 'number' && savedCustom > 0) {
      return savedCustom;
    }

    // 2. Fallback to official IMF rate (inverted to Base per Target)
    const officialRate = officialRates[currCode];
    if (officialRate && officialRate > 0) {
      return 1 / officialRate;
    }

    // 3. Simple static fallback
    const simpleFallbacks: Record<string, number> = {
      'USD': 1.0, 'EUR': 0.92, 'SAR': 3.75, 'YER': 250.0, 'AED': 3.67, 'EGP': 47.0
    };
    const targetInUSD = simpleFallbacks[currCode] || 1.0;
    const baseInUSD = simpleFallbacks[settings?.currency || 'YER'] || 1.0;
    return baseInUSD / targetInUSD;
  }, [settings, officialRates]);

  const handleCurrencyChange = (newCurrency: string) => {
    setTransactionCurrency(newCurrency);
    const rate = getCurrencyExchangeRate(newCurrency);
    setTransactionExchangeRate(rate);
  };

  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = React.useState(false);
  const [isExportDropdownOpen, setIsExportDropdownOpen] = React.useState(false);
  const [bills, setBills] = React.useState<Bill[]>([]);
  const [vendors, setVendors] = React.useState<Vendor[]>([]);
  const [items, setItems] = React.useState<Item[]>(SEEDED_ITEMS);
  const [accounts, setAccounts] = React.useState<Account[]>(SEEDED_ACCOUNTS);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSaving, setIsSaving] = React.useState(false);
  const [editingBill, setEditingBill] = React.useState<Bill | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');

  // States for Recording Vendor Payment (Payout)
  const [isPaymentModalOpen, setIsPaymentModalOpen] = React.useState(false);
  const [paymentBill, setPaymentBill] = React.useState<Bill | null>(null);
  const [paymentAmount, setPaymentAmount] = React.useState<number>(0);
  const [paymentDate, setPaymentDate] = React.useState<string>(new Date().toISOString().split('T')[0]);
  const [paymentReference, setPaymentReference] = React.useState<string>('');
  const [paymentSettlementRate, setPaymentSettlementRate] = React.useState<number>(1.0);
  const [isRecordingPayment, setIsRecordingPayment] = React.useState(false);

  // States for Debit Note / Purchase Return (مردود مشتريات)
  const [isDebitNoteModalOpen, setIsDebitNoteModalOpen] = React.useState(false);
  const [debitNoteBill, setDebitNoteBill] = React.useState<Bill | null>(null);
  const [debitNoteAmount, setDebitNoteAmount] = React.useState<number>(0);
  const [debitNoteDate, setDebitNoteDate] = React.useState<string>(new Date().toISOString().split('T')[0]);
  const [debitNoteReason, setDebitNoteReason] = React.useState<string>('Return of defective items');
  const [isCreatingDebitNote, setIsCreatingDebitNote] = React.useState(false);

  // States for Bill Builder Form
  const [billVendorId, setBillVendorId] = React.useState('');
  const [billSubTotal, setBillSubTotal] = React.useState<number>(0);
  const [billDiscountPercent, setBillDiscountPercent] = React.useState<number>(0);
  const [billShippingCharges, setBillShippingCharges] = React.useState<number>(0);
  const [billAdjustment, setBillAdjustment] = React.useState<number>(0);
  const [billVendorNotes, setBillVendorNotes] = React.useState('Items received in perfect condition.');
  const [billTermsConditions, setBillTermsConditions] = React.useState('');
  const [billBranchId, setBillBranchId] = React.useState<string>("Sana'a Main HQ branch");
  const [billCostCenterId, setBillCostCenterId] = React.useState<string>("Admin HQ Operations Center");
  const [saveStatus, setSaveStatus] = React.useState<'Draft' | 'Unpaid' | null>(null);
  const [currentEntityId, setCurrentEntityId] = React.useState<string>('');

  // Service & Maintenance Bill specific states
  const [isServiceModalOpen, setIsServiceModalOpen] = React.useState(false);
  const [serviceBillVendorId, setServiceBillVendorId] = React.useState('');
  const [serviceJobDescription, setServiceJobDescription] = React.useState('');
  const [serviceJobStatus, setServiceJobStatus] = React.useState<'Draft' | 'Received' | 'In Progress' | 'Ready for Delivery' | 'Delivered'>('Draft');
  const [serviceReceivingDate, setServiceReceivingDate] = React.useState(new Date().toISOString().split('T')[0]);
  const [serviceEstimatedDeliveryDate, setServiceEstimatedDeliveryDate] = React.useState('');
  const [serviceBillNumber, setServiceBillNumber] = React.useState('');

  interface ServiceExpenseRow {
    id: string;
    description: string;
    amount: number;
    accountId: string;
    accountName: string;
  }

  interface ConsumedItemRow {
    id: string;
    itemId: string;
    name: string;
    sku: string;
    quantity: number;
    rate: number;
    amount: number;
  }

  const [serviceExpenses, setServiceExpenses] = React.useState<ServiceExpenseRow[]>([]);
  const [consumedItems, setConsumedItems] = React.useState<ConsumedItemRow[]>([]);


  // Layout customization states (mirrors Invoice styling)
  const [templateCustomizer, setTemplateCustomizer] = React.useState<{
    templateStyle: 'standard' | 'professional' | 'modern';
    logoUrl: string;
    logoAlignment: 'left' | 'center' | 'right';
    logoSize: 'small' | 'medium' | 'large';
    primaryColor: string;
    secondaryColor: string;
    fontFamily: 'Inter' | 'Arial' | 'Roboto' | 'Tajawal' | 'Courier New';
    hideTaxColumn: boolean;
    hideShippingCharges: boolean;
    hideTermsAndConditions: boolean;
    hideCustomerNotes: boolean;
  }>(() => {
    try {
      const saved = safeStorage.getItem('bill_template_customizer');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn("Could not load template customizer from safeStorage", e);
    }
    return {
      templateStyle: 'standard',
      logoUrl: '',
      logoAlignment: 'left',
      logoSize: 'medium',
      primaryColor: '#0f172a', // Slatier default for procurement
      secondaryColor: '#475569',
      fontFamily: 'Inter',
      hideTaxColumn: false,
      hideShippingCharges: false,
      hideTermsAndConditions: false,
      hideCustomerNotes: false,
    };
  });

  const [isCustomizerOpen, setIsCustomizerOpen] = React.useState(false);

  // Keep saved to localStorage safely
  React.useEffect(() => {
    try {
      safeStorage.setItem('bill_template_customizer', JSON.stringify(templateCustomizer));
    } catch {}
  }, [templateCustomizer]);

  // Handle Logo file uploaded convert to base64
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setTemplateCustomizer(prev => ({
          ...prev,
          logoUrl: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const compileCustomStyles = () => {
    const {
      primaryColor,
      secondaryColor,
      fontFamily,
    } = templateCustomizer;

    let fontCSS = '';
    if (fontFamily === 'Tajawal') {
      fontCSS = `font-family: 'Tajawal', sans-serif !important;`;
    } else if (fontFamily === 'Roboto') {
      fontCSS = `font-family: 'Roboto', sans-serif !important;`;
    } else if (fontFamily === 'Arial') {
      fontCSS = `font-family: Arial, sans-serif !important;`;
    } else if (fontFamily === 'Courier New') {
      fontCSS = `font-family: 'Courier New', Courier, monospace !important;`;
    } else {
      fontCSS = `font-family: 'Inter', sans-serif !important;`;
    }

    return `
      .custom-font, .custom-font * {
        ${fontCSS}
      }
      .custom-primary-bg {
        background-color: ${primaryColor} !important;
      }
      .custom-primary-text {
        color: ${primaryColor} !important;
      }
      .custom-secondary-text {
        color: ${secondaryColor} !important;
      }
      .custom-primary-border {
        border-color: ${primaryColor} !important;
      }
      .custom-secondary-border {
        border-color: ${secondaryColor} !important;
      }
      /* Custom selection rings overrides */
      .focus\\:ring-indigo-500:focus,
      .focus\\:ring-2:focus {
        --tw-ring-color: ${primaryColor} !important;
        border-color: ${primaryColor} !important;
      }
      /* Media Print Styles (overrides) */
      @media print {
        .custom-font, .custom-font * {
          ${fontCSS}
        }
        body > div:not(.fixed),
        #root > div:not(.fixed) {
          display: none !important;
          height: 0 !important;
          overflow: hidden !important;
        }
        .fixed.inset-0.z-50 {
          position: static !important;
          display: block !important;
          padding: 0 !important;
          margin: 0 !important;
          width: 100% !important;
          height: auto !important;
          overflow: visible !important;
          padding: 0 !important;
        }
        .bg-slate-900\\/60,
        .backdrop-blur-sm,
        .border-b.shrink-0 {
          display: none !important;
        }
        .relative.w-full.bg-white {
          box-shadow: none !important;
          border: none !important;
          border-radius: 0 !important;
          max-height: none !important;
          height: auto !important;
          overflow: visible !important;
          padding: 0 !important;
        }
        .p-6.overflow-y-auto {
          padding: 0 !important;
          overflow: visible !important;
        }
        .print-hidden,
        button,
        .print\\:hidden,
        .flex.items-center.gap-2.pt-1,
        .pt-8.border-t,
        .trash-column,
        td:last-child,
        th:last-child {
          display: none !important;
        }
        input, select, textarea {
          border: none !important;
          background: transparent !important;
          box-shadow: none !important;
          padding: 0 !important;
          color: #000 !important;
          font-weight: 600 !important;
          appearance: none !important;
          -webkit-appearance: none !important;
          -moz-appearance: none !important;
        }
        .grid-cols-3 {
          grid-template-cols: repeat(3, minmax(0, 1fr)) !important;
        }
      }
    `;
  };

  const createEmptyRow = (): BillItemRow => {
    // Default to a typical Cost of Goods Sold or Expense account if possible, or keep blank to force selection
    return {
      id: Math.random().toString(36).substring(7),
      itemId: '',
      name: '',
      sku: '',
      quantity: 1.00,
      rate: 0.00,
      taxPercent: 0,
      taxLabel: 'Select a Tax',
      amount: 0.00,
      accountId: '',
      accountName: ''
    };
  };

  const [formRows, setFormRows] = React.useState<BillItemRow[]>([createEmptyRow()]);

  const [isScannerOpen, setIsScannerOpen] = React.useState(false);
  const [scanSku, setScanSku] = React.useState('');
  const [scanError, setScanError] = React.useState('');
  const [isBulkActionOpen, setIsBulkActionOpen] = React.useState(false);
  const [rowSearchQueries, setRowSearchQueries] = React.useState<Record<string, string>>({});
  const [activeDropdownRowId, setActiveDropdownRowId] = React.useState<string | null>(null);

  // Filter accounts of type 'Expense' or 'Asset' as requested
  const expenseAndAssetAccounts = React.useMemo(() => {
    return accounts.filter(acc => acc.type === 'Expense' || acc.type === 'Asset');
  }, [accounts]);

  // State and Memos for Today's Deliveries engine & Service dashboard
  const [filterTodayOnly, setFilterTodayOnly] = React.useState(false);

  const todayStr = React.useMemo(() => {
    try {
      return new Date().toLocaleDateString('en-CA');
    } catch (e) {
      return new Date().toISOString().split('T')[0];
    }
  }, []);

  const serviceBills = React.useMemo(() => {
    return bills.filter(b => b.isServiceBill === true);
  }, [bills]);

  const todayServiceBills = React.useMemo(() => {
    if (!enableServiceModule) return [];
    return serviceBills.filter(b => b.estimatedDeliveryDate === todayStr);
  }, [serviceBills, todayStr, enableServiceModule]);

  const filteredServiceBills = React.useMemo(() => {
    return serviceBills.filter(b => {
      const matchesSearch = b.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            b.vendorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            (b.jobDescription || '').toLowerCase().includes(searchTerm.toLowerCase());
      const matchesToday = filterTodayOnly ? b.estimatedDeliveryDate === todayStr : true;
      return matchesSearch && matchesToday;
    });
  }, [serviceBills, searchTerm, filterTodayOnly, todayStr]);

  const handleScanItem = () => {
    const item = items.find(it => it.sku.toLowerCase() === scanSku.trim().toLowerCase());
    if (item) {
      // Find a default expense account for pre-filling if possible
      const defaultAcc = expenseAndAssetAccounts.find(a => a.name.toLowerCase().includes('cost of goods') || a.type === 'Expense') || expenseAndAssetAccounts[0];
      
      const existingRowIndex = formRows.findIndex(row => row.itemId === item.id);
      if (existingRowIndex > -1) {
        setFormRows(prev => prev.map((row, idx) => {
          if (idx !== existingRowIndex) return row;
          const qty = row.quantity + 1;
          const amt = qty * row.rate * (1 + row.taxPercent / 100);
          return { ...row, quantity: qty, amount: amt };
        }));
      } else {
        setFormRows(prev => {
          const filteredPrev = prev.filter(r => r.itemId !== ''); // remove empty row if any
          return [
            ...filteredPrev,
            {
              id: Math.random().toString(36).substring(7),
              itemId: item.id,
              name: item.name,
              sku: item.sku,
              quantity: 1.00,
              rate: item.purchasePrice || item.salesPrice || 0,
              taxPercent: 0,
              taxLabel: 'Select a Tax',
              amount: item.purchasePrice || item.salesPrice || 0,
              accountId: defaultAcc?.id || '',
              accountName: defaultAcc?.name || ''
            }
          ];
        });
      }
      setScanSku('');
      setScanError('');
      setIsScannerOpen(false);
    } else {
      setScanError('SKU not found. Try "ITEM-001" or other existing SKUs.');
    }
  };

  const handleBulkAction = (action: string) => {
    if (action === 'clear') {
      setFormRows([createEmptyRow()]);
    } else if (action === 'tax15') {
      setFormRows(prev => prev.map(row => {
        const amt = row.quantity * row.rate * 1.15;
        return { ...row, taxPercent: 15, taxLabel: 'VAT (15%)', amount: amt };
      }));
    } else if (action === 'tax5') {
      setFormRows(prev => prev.map(row => {
        const amt = row.quantity * row.rate * 1.05;
        return { ...row, taxPercent: 5, taxLabel: 'VAT (5%)', amount: amt };
      }));
    } else if (action === 'add3') {
      setFormRows(prev => [...prev, createEmptyRow(), createEmptyRow(), createEmptyRow()]);
    }
    setIsBulkActionOpen(false);
  };

  const handleAddItemsInBulk = () => {
    const availableItemsToAdd = items.slice(0, 3);
    const defaultAcc = expenseAndAssetAccounts.find(a => a.name.toLowerCase().includes('cost of goods') || a.type === 'Expense') || expenseAndAssetAccounts[0];
    
    if (availableItemsToAdd.length > 0) {
      setFormRows(prev => {
        const filteredPrev = prev.filter(r => r.itemId !== ''); // remove empty row
        const newRows = availableItemsToAdd.map(it => ({
          id: Math.random().toString(36).substring(7),
          itemId: it.id,
          name: it.name,
          sku: it.sku,
          quantity: 1.00,
          rate: it.purchasePrice || it.salesPrice || 0,
          taxPercent: 0,
          taxLabel: 'Select a Tax',
          amount: it.purchasePrice || it.salesPrice || 0,
          accountId: defaultAcc?.id || '',
          accountName: defaultAcc?.name || ''
        }));
        return [...filteredPrev, ...newRows];
      });
    } else {
      alert('No catalogue items found to add in bulk.');
    }
  };

  const handleRowChange = (id: string, updates: Partial<BillItemRow>) => {
    setFormRows(prev => prev.map(row => {
      if (row.id !== id) return row;
      const updatedRow = { ...row, ...updates };
      const qty = Number(updatedRow.quantity) || 0;
      const rVal = Number(updatedRow.rate) || 0;
      const taxPercent = Number(updatedRow.taxPercent) || 0;
      updatedRow.amount = qty * rVal * (1 + taxPercent / 100);
      return updatedRow;
    }));
  };

  // Dynamically calculate subTotal from form item rows
  React.useEffect(() => {
    const totalAmount = formRows.reduce((sum, row) => sum + (row.amount || 0), 0);
    setBillSubTotal(totalAmount);
  }, [formRows]);

  const calculatedDiscount = (billSubTotal * (billDiscountPercent || 0)) / 100;
  const grandTotal = billSubTotal - calculatedDiscount + (billShippingCharges || 0) + (billAdjustment || 0);

  const { companyId } = useRBAC();

  React.useEffect(() => {
    const billsPath = 'bills';
    const vendorsPath = 'vendors';
    const itemsPath = 'items';
    const accountsPath = 'accounts';

    const qBills = query(
      collection(db, billsPath),
      where('companyId', '==', companyId),
      orderBy('createdAt', 'desc')
    );

    const qVendors = query(
      collection(db, vendorsPath),
      where('companyId', '==', companyId)
    );

    const qItems = query(
      collection(db, itemsPath),
      where('companyId', '==', companyId)
    );

    const qAccounts = query(
      collection(db, accountsPath),
      where('companyId', '==', companyId)
    );

    const unsubBills = onSnapshot(qBills, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Bill[];
      setBills(data);
      setIsLoading(false);
    }, (error) => {
      console.warn('Real-time bills synchronization status (using local/fallback state):', error.message);
      setIsLoading(false);
    });

    const unsubVendors = onSnapshot(qVendors, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Vendor[];
      setVendors(data);
    }, (error) => {
      console.warn('Real-time vendors synchronization status (using local/fallback state):', error.message);
    });

    const unsubItems = onSnapshot(qItems, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Item[];
      setItems(getMergedItems(data));
    }, (error) => {
      console.warn('Real-time items synchronization status (using local/fallback state):', error.message);
    });

    const unsubAccounts = onSnapshot(qAccounts, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Account[];
      setAccounts(getMergedAccounts(data));
    }, (error) => {
      console.warn('Real-time standard accounts synchronization status (using local/fallback state):', error.message);
    });

    return () => {
      unsubBills();
      unsubVendors();
      unsubItems();
      unsubAccounts();
    };
  }, [companyId]);

  const handleSaveServiceBill = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    if (!serviceBillVendorId) {
      alert('Please select a service provider / sub-contractor.');
      setIsSaving(false);
      return;
    }

    if (!serviceJobDescription.trim()) {
      alert('Please provide a main Job Order / Service description.');
      setIsSaving(false);
      return;
    }

    if (!serviceEstimatedDeliveryDate) {
      alert(t('serviceBill.est_delivery_required'));
      setIsSaving(false);
      return;
    }

    // Verify all Table A rows have description, account, and amount values
    const invalidExpenses = serviceExpenses.filter(r => !r.description.trim() || !r.accountId || Number(r.amount || 0) <= 0);
    if (serviceExpenses.length > 0 && invalidExpenses.length > 0) {
      alert('Please ensure all service labor rows have a valid description, mapped account, and non-zero amount value.');
      setIsSaving(false);
      return;
    }

    // Verify all Table B rows have item, non-zero quantity
    const invalidItemsList = consumedItems.filter(r => !r.itemId || Number(r.quantity || 0) <= 0);
    if (consumedItems.length > 0 && invalidItemsList.length > 0) {
      alert('Please ensure all consumed inventory rows have selected materials and set a valid quantity.');
      setIsSaving(false);
      return;
    }

    const billNumber = serviceBillNumber || (editingBill ? editingBill.number : `SRV-${Math.floor(100000 + Math.random() * 900000)}`);
    const oldBillNumber = editingBill?.number;
    const vendor = vendors.find(v => v.id === serviceBillVendorId);

    const totalExpenses = serviceExpenses.reduce((sum, row) => sum + Number(row.amount || 0), 0);
    const totalItems = consumedItems.reduce((sum, row) => sum + (Number(row.quantity || 0) * Number(row.rate || 0)), 0);
    const srvTotal = totalExpenses + totalItems;

    const billsPath = 'bills';
    const data = {
      number: billNumber,
      vendorId: serviceBillVendorId,
      vendorName: vendor?.name || 'Unassigned Service Vendor',
      date: serviceReceivingDate,
      dueDate: serviceEstimatedDeliveryDate, // Set Estimated Delivery Date as system due date
      subTotal: srvTotal,
      discountPercent: 0,
      shippingCharges: 0,
      adjustment: 0,
      customerNotes: serviceJobDescription,
      termsConditions: 'Specialized Service & Job Order Bill',
      total: srvTotal,
      status: 'Unpaid' as const, // service bills can default to Unpaid
      companyId,
      updatedAt: serverTimestamp(),
      isServiceBill: true,
      jobDescription: serviceJobDescription,
      serviceStatus: serviceJobStatus,
      receivingDate: serviceReceivingDate,
      estimatedDeliveryDate: serviceEstimatedDeliveryDate,
      serviceExpenses: serviceExpenses.map(r => ({
        id: r.id,
        description: r.description,
        amount: Number(r.amount || 0),
        accountId: r.accountId,
        accountName: r.accountName
      })),
      consumedItems: consumedItems.map(r => ({
        id: r.id,
        itemId: r.itemId,
        name: r.name,
        sku: r.sku,
        quantity: Number(r.quantity || 0),
        rate: Number(r.rate || 0),
        amount: Number(r.quantity || 0) * Number(r.rate || 0)
      })),
      items: [
        ...serviceExpenses.map(r => ({
          itemId: 'service-expense',
          name: r.description,
          sku: 'SRV-EXP',
          quantity: 1,
          rate: Number(r.amount || 0),
          taxPercent: 0,
          taxLabel: 'No Tax',
          amount: Number(r.amount || 0),
          accountId: r.accountId,
          accountName: r.accountName
        })),
        ...consumedItems.map(r => ({
          itemId: r.itemId,
          name: r.name,
          sku: r.sku,
          quantity: Number(r.quantity || 0),
          rate: Number(r.rate || 0),
          taxPercent: 0,
          taxLabel: 'No Tax',
          amount: Number(r.quantity || 0) * Number(r.rate || 0)
        }))
      ]
    };

    try {
      if (!navigator.onLine) {
        const { offlineDb } = await import('../utils/offlineDb');
        const isAr = document.documentElement.lang === 'ar';
        const offlineRecord = {
          ...data,
          id: editingBill?.id || `bill-off-${Date.now()}`,
          isOfflineDraft: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        await offlineDb.saveRecord('offline_purchase_bills', offlineRecord);
        alert(
          isAr
            ? 'تم حفظ فاتورة الخدمة محلياً بأمان بسبب انقطاع الإنترنت. يرجى المزامنة يدوياً من الأعلى عند عودة الاتصال.'
            : 'No internet connection detected. Service bill saved securely in local Offline Queue. Please sync manually from the top bar once connected.'
        );
        setIsModalOpen(false);
        setEditingBill(null);
        return;
      }

      // 1. Save or Update service bill in Firestore
      if (editingBill) {
        await updateDoc(doc(db, 'bills', editingBill.id), data);
      } else {
        await addDoc(collection(db, 'bills'), {
          ...data,
          createdAt: serverTimestamp()
        });
      }

      // 2. Automated Inventory Stock Reduction Asset movement
      for (const item of consumedItems) {
        const actualItem = items.find(it => it.id === item.itemId);
        if (actualItem) {
          const itemDocRef = doc(db, 'items', item.itemId);
          const newStock = Math.max(0, (actualItem.stockOnHand || 0) - Number(item.quantity || 0));
          await updateDoc(itemDocRef, {
            stockOnHand: newStock
          });
        }
      }

      // 3. Double-entry ledger routing to journalEntries (debit expense/asset, credit accounts payable)
      const accountsPayableAccount = accounts.find(a => a.type === 'Liability' && a.name.toLowerCase().includes('payable'))
        || accounts.find(a => a.type === 'Liability' && a.code.startsWith('2'))
        || accounts.find(a => a.type === 'Liability')
        || accounts.find(a => a.code === '2000');

      if (accountsPayableAccount && srvTotal > 0) {
        const accountsPayableCode = accountsPayableAccount.code || '210101';
        const journalLines: any[] = [
          {
            accountId: accountsPayableAccount.id,
            accountName: accountsPayableAccount.name,
            accountCode: accountsPayableCode,
            debit: 0,
            credit: srvTotal,
            description: `Accounts Payable Credit recorded for Job Order ${billNumber}`
          }
        ];

        serviceExpenses.forEach(row => {
          if (row.amount > 0 && row.accountId) {
            const accObj = accounts.find(a => a.id === row.accountId);
            const accCode = accObj ? accObj.code : '510102';
            journalLines.push({
              accountId: row.accountId,
              accountName: row.accountName,
              accountCode: accCode,
              debit: Number(row.amount),
              credit: 0,
              description: `Service Labor Expense Debit: ${row.description}`
            });
          }
        });

        consumedItems.forEach(row => {
          const itemObj = items.find(it => it.id === row.itemId);
          const itemExpenseAccountId = itemObj?.expenseAccountId
            || accounts.find(a => a.name.toLowerCase().includes('cost of goods') || a.type === 'Expense')?.id
            || accounts.find(a => a.type === 'Expense')?.id
            || 'fallback-item-expense';

          const itemExpenseAccountObj = accounts.find(a => a.id === itemExpenseAccountId);
          const itemExpenseAccountName = itemExpenseAccountObj?.name || 'Cost of Goods Sold';
          const itemExpenseAccountCode = itemExpenseAccountObj?.code || '510101';

          const rowTotal = Number(row.quantity || 0) * Number(row.rate || 0);
          if (rowTotal > 0 && itemExpenseAccountId) {
            journalLines.push({
              accountId: itemExpenseAccountId,
              accountName: itemExpenseAccountName,
              accountCode: itemExpenseAccountCode,
              debit: rowTotal,
              credit: 0,
              description: `Material Consumption Debit for Job Order SKU: ${row.sku} - ${row.name}`
            });
          }
        });

        const totalDebit = journalLines.reduce((sum, l) => sum + l.debit, 0);
        const totalCredit = journalLines.reduce((sum, l) => sum + l.credit, 0);

        const qJE = query(
          collection(db, 'journalEntries'),
          where('reference', '==', oldBillNumber || billNumber),
          where('companyId', '==', companyId)
        );
        const jeSnap = await getDocs(qJE);

        const jePayload = {
          date: serviceReceivingDate,
          reference: billNumber,
          description: `Automated Service Job Entry for Bill ${billNumber} - ${data.vendorName}`,
          totalDebit,
          totalCredit,
          amount: srvTotal,
          status: 'Posted' as const,
          companyId,
          updatedAt: serverTimestamp(),
          lines: journalLines
        };

        if (!jeSnap.empty) {
          const existingJeId = jeSnap.docs[0].id;
          await updateDoc(doc(db, 'journalEntries', existingJeId), jePayload);
        } else {
          await addDoc(collection(db, 'journalEntries'), {
            ...jePayload,
            createdAt: serverTimestamp()
          });
        }
      }

      setIsServiceModalOpen(false);
      setEditingBill(null);
    } catch (error) {
      handleFirestoreError(error, editingBill ? OperationType.UPDATE : OperationType.CREATE, billsPath);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (editingBill && ((editingBill.status as string) === 'Posted' || editingBill.status === 'Unpaid' || editingBill.status === 'Paid' || (editingBill as any).isDebitNote)) {
      alert('Violation of audit-readiness: Posted, Unpaid, Paid, and Debit Note records are structurally locked and cannot be edited.');
      return;
    }
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    
    const vendorId = billVendorId;
    const vendor = vendors.find(v => v.id === vendorId);

    const finalStatus = saveStatus || editingBill?.status || 'Unpaid';

    if (!vendorId) {
      alert('Please select a vendor to record this bill.');
      setIsSaving(false);
      return;
    }

    // Verify all rows have an assigned account
    const unmappedRows = formRows.filter(r => !r.accountId);
    if (unmappedRows.length > 0 && formRows.some(r => r.itemId)) {
      alert('Please mapping expense/asset account for all items in the Table.');
      setIsSaving(false);
      return;
    }

    const billNumber = formData.get('number') as string;
    const oldBillNumber = editingBill?.number;

    const data = {
      number: billNumber,
      vendorId: vendorId,
      vendorName: vendor?.name || 'Unassigned Vendor',
      date: formData.get('date') as string,
      dueDate: formData.get('dueDate') as string,
      subTotal: billSubTotal,
      discountPercent: billDiscountPercent,
      shippingCharges: billShippingCharges,
      adjustment: billAdjustment,
      customerNotes: billVendorNotes,
      termsConditions: billTermsConditions,
      total: grandTotal,
      currency: transactionCurrency,
      exchangeRate: transactionExchangeRate,
      amountInBaseCurrency: Number((grandTotal * transactionExchangeRate).toFixed(2)),
      status: finalStatus,
      companyId,
      branchId: billBranchId,
      costCenterId: billCostCenterId,
      updatedAt: serverTimestamp(),
      items: formRows.map(row => ({
        itemId: row.itemId,
        name: row.name,
        sku: row.sku,
        quantity: row.quantity,
        rate: row.rate,
        taxPercent: row.taxPercent,
        taxLabel: row.taxLabel,
        amount: row.amount,
        accountId: row.accountId,
        accountName: row.accountName,
        branchId: billBranchId,
        costCenterId: billCostCenterId
      })),
    };

    try {
      if (!navigator.onLine) {
        const { offlineDb } = await import('../utils/offlineDb');
        const isAr = document.documentElement.lang === 'ar';
        const offlineRecord = {
          ...data,
          id: editingBill?.id || `bill-off-${Date.now()}`,
          isOfflineDraft: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        await offlineDb.saveRecord('offline_purchase_bills', offlineRecord);
        alert(
          isAr
            ? 'تم حفظ الفاتورة محلياً بأمان بسبب انقطاع الإنترنت. يرجى المزامنة يدوياً من الأعلى عند عودة الاتصال.'
            : 'No internet connection detected. Purchase bill saved securely in local Offline Queue. Please sync manually from the top bar once connected.'
        );
        setIsModalOpen(false);
        setEditingBill(null);
        return;
      }

      if (editingBill) {
        await updateDoc(doc(db, 'bills', editingBill.id), data);
      } else {
        const docRef = await addDoc(collection(db, 'bills'), {
          ...data,
          createdAt: serverTimestamp(),
        });
        await saveDraftAttachments(currentEntityId, docRef.id);
      }

      // ----------------------------------------------------
      // AUTOMATED DOUBLE-ENTRY JOURNAL ROUTING ON SAVING
      // ----------------------------------------------------
      // Accounts Receivable is debited for Revenue on Sales
      // For bills, we Credit Accounts Payable, and Debit Expense/Asset per line.
      // ----------------------------------------------------
      const accountsPayableAccount = accounts.find(a => a.type === 'Liability' && a.name.toLowerCase().includes('payable'))
        || accounts.find(a => a.type === 'Liability' && a.code.startsWith('2'))
        || accounts.find(a => a.type === 'Liability')
        || accounts.find(a => a.code === '2000');

      if (accountsPayableAccount && grandTotal > 0) {
        const accountsPayableCode = accountsPayableAccount.code || '210101';
        // Create custom lines:
        // A. Credit entry for Accounts Payable (for total in Base currency)
        const journalLines: any[] = [
          {
            accountId: accountsPayableAccount.id,
            accountName: accountsPayableAccount.name,
            accountCode: accountsPayableCode,
            debit: 0,
            credit: Number((grandTotal * transactionExchangeRate).toFixed(2)),
            description: `Accounts Payable Credit recorded for Bill ${billNumber}`,
            branchId: billBranchId,
            costCenterId: billCostCenterId
          }
        ];

        // B. Debit entry for each line item account (for separate item bounds in Base currency)
        formRows.forEach(row => {
          if (row.amount > 0 && row.accountId) {
            const rowAcc = accounts.find(a => a.id === row.accountId);
            const rowAccCode = rowAcc ? rowAcc.code : '510101';
            journalLines.push({
              accountId: row.accountId,
              accountName: row.accountName,
              accountCode: rowAccCode,
              debit: Number((row.amount * transactionExchangeRate).toFixed(2)),
              credit: 0,
              description: `Expense/Asset Debit for item SKU: ${row.sku || 'N/A'} - ${row.name || 'Equipment'}`,
              branchId: billBranchId,
              costCenterId: billCostCenterId
            });
          }
        });

        const totalDebit = Number(journalLines.reduce((sum, l) => sum + l.debit, 0).toFixed(2));
        const totalCredit = Number(journalLines.reduce((sum, l) => sum + l.credit, 0).toFixed(2));

        try {
          // Check if an existing journal entry exists for this reference
          const qJE = query(
            collection(db, 'journalEntries'),
            where('reference', '==', oldBillNumber || billNumber),
            where('companyId', '==', companyId)
          );
          const jeSnap = await getDocs(qJE);

          const jePayload = {
            date: data.date,
            reference: billNumber,
            description: `Automated Entry for Bill ${billNumber} - ${data.vendorName}`,
            totalDebit,
            totalCredit,
            amount: Number((grandTotal * transactionExchangeRate).toFixed(2)),
            status: 'Posted',
            companyId,
            branchId: billBranchId,
            costCenterId: billCostCenterId,
            branch: billBranchId,
            updatedAt: serverTimestamp(),
            lines: journalLines
          };

          if (!jeSnap.empty) {
            // Update old journal document
            const existingJeId = jeSnap.docs[0].id;
            await updateDoc(doc(db, 'journalEntries', existingJeId), jePayload);
          } else {
            // Add new journal document
            await addDoc(collection(db, 'journalEntries'), {
              ...jePayload,
              createdAt: serverTimestamp()
            });
          }
        } catch (jeErr) {
          console.error("Failed to post double entry accounting journal:", jeErr);
        }
      }

      setIsModalOpen(false);
      setEditingBill(null);
    } catch (error) {
      handleFirestoreError(error, editingBill ? OperationType.UPDATE : OperationType.CREATE, 'bills');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string, billNum: string) => {
    const b = bills.find(x => x.id === id);
    if (b && ((b.status as string) === 'Posted' || b.status === 'Unpaid' || b.status === 'Paid' || b.status === 'Cancelled' || (b as any).isDebitNote)) {
      alert('Violation of audit-readiness: Posted, Unpaid, Paid, and Debit Note records are structurally locked and cannot be deleted.');
      return;
    }
    if (!confirm('Are you sure you want to delete this bill?')) return;
    try {
      await deleteDoc(doc(db, 'bills', id));

      // Attempt to delete correlated double entry journal in journalEntries
      try {
        const qJE = query(
          collection(db, 'journalEntries'),
          where('reference', '==', billNum),
          where('companyId', '==', companyId)
        );
        const jeSnap = await getDocs(qJE);
        for (const jeDoc of jeSnap.docs) {
          await deleteDoc(doc(db, 'journalEntries', jeDoc.id));
        }
      } catch (err) {
        console.error("Failed to delete matching journal entries", err);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'bills');
    }
  };

  const handleRecordPaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentBill) return;
    setIsRecordingPayment(true);
    try {
      const payRef = paymentReference.trim() || `PAY-VENDOR-${paymentBill.number}-${Date.now()}`;

      const originalRate = Number((paymentBill as any).exchangeRate) || 1.0;
      const settlementRate = Number(paymentSettlementRate) || 1.0;

      // الحفاظ على سياقات الفروع ومراكز التكلفة لضمان تجسيد دقيق للتقارير الختامية
      const billBranchId = (paymentBill as any).branchId || '';
      const billCostCenterId = (paymentBill as any).costCenterId || '';

      // احتساب فوارق الصرف الرأسمالية المحققة من خلال محرك الفوارق
      const { correctionLine } = PostingEngine.computeRealizedForexDriftLines({
        transactionAmount: Number(paymentAmount),
        originalExchangeRate: originalRate,
        settlementExchangeRate: settlementRate,
        isVendorPayment: true,
        branchId: billBranchId,
        costCenterId: billCostCenterId
      });

      const lines: any[] = [
        {
          accountId: 'acc_supplier_creditors',
          accountName: 'Tadhamon Bank Supplier Creditors',
          accountCode: '210101',
          debit: Number(paymentAmount),
          credit: 0,
          description: `Debit Accounts Payable - Settling Liability for Bill #${paymentBill.number}`,
          exchangeRate: originalRate,
          branchId: billBranchId,
          costCenterId: billCostCenterId
        },
        {
          accountId: 'acc_kuraimi',
          accountName: 'Al-Kuraimi Cash YER (صندوق المركز رئيسي)',
          accountCode: '110101',
          debit: 0,
          credit: Number(paymentAmount),
          description: `Credit Bank/Cash - Fund Outflow for vendor payout`,
          exchangeRate: settlementRate,
          branchId: billBranchId,
          costCenterId: billCostCenterId
        }
      ];

      if (correctionLine) {
        lines.push(correctionLine);
      }

      const result = await postToLedger({
        date: paymentDate,
        reference: payRef,
        description: `Vendor Payout: Bill #${paymentBill.number} - Vendor Name: ${paymentBill.vendorName}`,
        totalDebit: Number(paymentAmount),
        totalCredit: Number(paymentAmount),
        companyId: companyId,
        lines: lines,
        status: 'Posted'
      });

      if (!result.success) {
        throw new Error(result.error || "Failed to post vendor payout to balanced general ledger.");
      }

      await updateDoc(doc(db, 'bills', paymentBill.id), {
        status: 'Paid',
        updatedAt: serverTimestamp()
      });

      setIsPaymentModalOpen(false);
      setPaymentBill(null);
      alert('SUCCESS: Balanced Vendor Payout Entry recorded: Debit [Accounts Payable] and Credit [Bank/Cash] with FOREX adjustments!');
    } catch (err: any) {
      console.error(err);
      alert(`Payout processing failed: ${err.message || err}`);
    } finally {
      setIsRecordingPayment(false);
    }
  };

  const handleCreateDebitNoteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!debitNoteBill) return;
    setIsCreatingDebitNote(true);
    try {
      const dnNumber = `DN-${debitNoteBill.number}-${Math.floor(Math.random() * 900 + 100)}`;
      
      const reversedTotal = Number(debitNoteAmount);
      const ledgerLines = [
        {
          accountId: 'acc_supplier_creditors',
          accountName: 'Tadhamon Bank Supplier Creditors',
          accountCode: '210101',
          debit: reversedTotal,
          credit: 0,
          description: `Debit Accounts Payable - Purchase Return Reference: Debit Note #${dnNumber} for Bill #${debitNoteBill.number}`
        }
      ];

      if (debitNoteBill.items && debitNoteBill.items.length > 0) {
        const firstItem = debitNoteBill.items[0];
        const originalAccount = firstItem.accountId || 'acc_cogs';
        const originalAccountName = firstItem.accountName || 'Cost of Goods Sold (تكلفة المبيعات)';
        const originalAccountCode = firstItem.accountId ? '510102' : '510101';
        
        ledgerLines.push({
          accountId: originalAccount,
          accountName: originalAccountName,
          accountCode: originalAccountCode,
          debit: 0,
          credit: reversedTotal,
          description: `Credit Asset/Expense Account Relief - Purchase Return: ${debitNoteBill.vendorName}`
        });
      } else {
        ledgerLines.push({
          accountId: 'acc_cogs',
          accountName: 'Cost of Goods Sold (تكلفة المبيعات)',
          accountCode: '510101',
          debit: 0,
          credit: reversedTotal,
          description: `Credit Asset/Expense Account Relief - Purchase Return: ${debitNoteBill.vendorName}`
        });
      }

      const result = await postToLedger({
        date: debitNoteDate,
        reference: dnNumber,
        description: `Purchase Return / Debit Note Reversal: DN #${dnNumber} for Bill #${debitNoteBill.number}`,
        totalDebit: reversedTotal,
        totalCredit: reversedTotal,
        companyId: companyId,
        lines: ledgerLines,
        status: 'Posted'
      });

      if (!result.success) {
        throw new Error(result.error || "Failed to post debit note reversal to balanced ledger.");
      }

      await addDoc(collection(db, 'bills'), {
        number: dnNumber,
        vendorId: debitNoteBill.vendorId,
        vendorName: debitNoteBill.vendorName,
        date: debitNoteDate,
        dueDate: debitNoteDate,
        total: reversedTotal,
        subTotal: reversedTotal,
        discountPercent: 0,
        shippingCharges: 0,
        adjustment: 0,
        customerNotes: `Debit Note Reversal for Bill #${debitNoteBill.number}. Reason: ${debitNoteReason}`,
        termsConditions: 'Immutable Posted Debit Note Ledger',
        status: 'Posted',
        isDebitNote: true,
        originalBillId: debitNoteBill.id,
        originalBillNumber: debitNoteBill.number,
        companyId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        items: debitNoteBill.items || []
      });

      await updateDoc(doc(db, 'bills', debitNoteBill.id), {
        status: 'Cancelled',
        updatedAt: serverTimestamp()
      });

      setIsDebitNoteModalOpen(false);
      setDebitNoteBill(null);
      alert(`SUCCESS: Immutable Debit Note issued & general ledger entries posted! Original bill is now Cancelled.`);
    } catch (err: any) {
      console.error(err);
      alert(`Creating debit note failed: ${err.message || err}`);
    } finally {
      setIsCreatingDebitNote(false);
    }
  };

  const filteredBills = bills.filter(bill => 
    bill.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bill.vendorName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    unpaid: bills.filter(b => b.status === 'Unpaid').reduce((acc, b) => acc + b.total, 0),
    overdue: bills.filter(b => b.status === 'Overdue').reduce((acc, b) => acc + b.total, 0),
    paid: bills.filter(b => b.status === 'Paid').reduce((acc, b) => acc + b.total, 0),
    drafts: bills.filter(b => (b.status as any) === 'Draft').reduce((acc, b) => acc + b.total, 0),
  };

  const columns: ColumnDef<Bill>[] = [
    {
      header: 'Bill #',
      accessorKey: 'number',
      cell: (info) => {
        const b = info.row.original;
        if ((b as any).isDebitNote) {
          return <span className="font-extrabold text-amber-700">DN-{info.getValue() as string}</span>;
        }
        return <span className="font-bold text-slate-900">{info.getValue() as string}</span>;
      },
    },
    {
      header: 'Vendor',
      accessorKey: 'vendorName',
      cell: (info) => <span className="font-medium text-slate-700">{info.getValue() as string}</span>,
    },
    {
      header: 'Bill Date',
      accessorKey: 'date',
      cell: (info) => <span className="text-slate-500">{formatDate(info.getValue() as string)}</span>,
    },
    {
      header: 'Due Date',
      accessorKey: 'dueDate',
      cell: (info) => <span className="text-slate-500">{formatDate(info.getValue() as string)}</span>,
    },
    {
      header: 'Total',
      accessorKey: 'total',
      cell: (info) => {
        const b = info.row.original;
        if ((b as any).isDebitNote) {
          return <span className="font-extrabold text-amber-700">-{formatCurrency(info.getValue() as number)}</span>;
        }
        return <span className="font-bold text-slate-900">{formatCurrency(info.getValue() as number)}</span>;
      },
    },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: (info) => {
        const b = info.row.original;
        if ((b as any).isDebitNote) {
          return (
            <span className="px-2 py-1 rounded-full text-[10px] bg-amber-100 text-amber-800 border border-amber-300 font-extrabold tracking-wider uppercase">
              🔄 مردود مشتريات / Debit Note
            </span>
          );
        }
        const status = info.getValue() as string;
        const styles = {
          Draft: 'bg-slate-100 text-slate-600 border border-slate-200',
          Unpaid: 'bg-amber-100 text-amber-700 border border-amber-200',
          'Partially Paid': 'bg-blue-100 text-blue-700 border border-blue-200',
          Paid: 'bg-emerald-100 text-emerald-700 border border-emerald-200',
          Overdue: 'bg-rose-100 text-rose-700 border border-rose-200',
          Cancelled: 'bg-slate-100 text-slate-400 border border-slate-200 line-through',
          Posted: 'bg-emerald-150 text-emerald-800 border border-emerald-300',
        };
        return (
          <span className={cn(
            "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
            styles[status as keyof typeof styles] || 'bg-slate-100 text-slate-600'
          )}>
            {status}
          </span>
        );
      },
    },
    {
      header: 'Attachments',
      id: 'attachments',
      cell: (info) => {
        const b = info.row.original;
        return <BillAttachmentsBadge billId={b.id} />;
      }
    },
    {
      header: 'Actions',
      id: 'actions',
      cell: (info) => {
        const b = info.row.original;
        const isLocked = b.status === 'Posted' || b.status === 'Unpaid' || b.status === 'Paid' || b.status === 'Cancelled' || (b as any).isDebitNote;

        if (isLocked) {
          return (
            <div className="flex items-center gap-2 flex-wrap">
              {!(b as any).isDebitNote && b.status !== 'Paid' && b.status !== 'Cancelled' && (
                <button
                  onClick={() => {
                    setPaymentBill(b);
                    setPaymentAmount(b.total);
                    setPaymentDate(new Date().toISOString().split('T')[0]);
                    setPaymentReference('');
                    setPaymentSettlementRate((b as any).exchangeRate || 1.0);
                    setIsPaymentModalOpen(true);
                  }}
                  className="px-2.5 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-md text-[11px] font-black transition-all shadow-xs cursor-pointer select-none"
                  title="Pay Bill / تسديد الفاتورة"
                >
                  💵 سداد الفاتورة
                </button>
              )}
              {!(b as any).isDebitNote && b.status !== 'Cancelled' && (
                <button
                  onClick={() => {
                    setDebitNoteBill(b);
                    setDebitNoteAmount(b.total);
                    setDebitNoteDate(new Date().toISOString().split('T')[0]);
                    setDebitNoteReason(`Purchase Return for Bill #${b.number}`);
                    setIsDebitNoteModalOpen(true);
                  }}
                  className="px-2.5 py-1.5 bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100 rounded-md text-[11px] font-black transition-all shadow-xs cursor-pointer select-none"
                  title="Issue Purchase Debit Note"
                >
                  🔄 مردود مشتريات
                </button>
              )}
              <span className="flex items-center gap-1 text-[11px] text-slate-400 bg-slate-50 border border-slate-200 px-2 py-1.5 rounded-md font-bold select-none">
                🔒 Immutable
              </span>
            </div>
          );
        }

        return (
          <div className="flex items-center gap-2">
             <button 
              onClick={() => {
                const b = info.row.original;
                if (b.isServiceBill) {
                  setEditingBill(b);
                  setCurrentEntityId(b.id);
                  setServiceBillVendorId(b.vendorId || '');
                  setServiceJobDescription(b.jobDescription || '');
                  setServiceJobStatus(b.serviceStatus || 'Draft');
                  setServiceReceivingDate(b.receivingDate || '');
                  setServiceEstimatedDeliveryDate(b.estimatedDeliveryDate || '');
                  setServiceExpenses(b.serviceExpenses || []);
                  setConsumedItems(b.consumedItems || []);
                  setServiceBillNumber(b.number || '');
                  setIsServiceModalOpen(true);
                } else {
                  setEditingBill(b);
                  setCurrentEntityId(b.id);
                  setBillVendorId(b.vendorId || '');
                  setBillSubTotal(b.subTotal ?? b.total ?? 0);
                  setBillDiscountPercent(b.discountPercent ?? 0);
                  setBillShippingCharges(b.shippingCharges ?? 0);
                  setBillAdjustment(b.adjustment ?? 0);
                  setBillVendorNotes(b.customerNotes ?? 'Items received in perfect condition.');
                  setBillTermsConditions(b.termsConditions ?? '');
                  setBillBranchId((b as any).branchId || "Sana'a Main HQ branch");
                  setBillCostCenterId((b as any).costCenterId || "Admin HQ Operations Center");
                  setSaveStatus(null);
                  setTransactionCurrency((b as any).currency || settings?.currency || 'YER');
                  setTransactionExchangeRate((b as any).exchangeRate ?? 1.0);
                  
                  if (b.items && Array.isArray(b.items)) {
                    setFormRows(b.items.map((it: any) => ({
                      id: Math.random().toString(36).substring(7),
                      itemId: it.itemId || '',
                      name: it.name || '',
                      sku: it.sku || '',
                      quantity: it.quantity ?? 1.00,
                      rate: it.rate ?? 0.00,
                      taxPercent: it.taxPercent ?? 0,
                      taxLabel: it.taxLabel ?? 'Select a Tax',
                      amount: it.amount ?? 0.00,
                      accountId: it.accountId || '',
                      accountName: it.accountName || ''
                    })));
                  } else {
                    setFormRows([{
                      id: Math.random().toString(36).substring(7),
                      itemId: 'legacy-item',
                      name: 'Legacy Bill Transaction',
                      sku: 'LEGACY',
                      quantity: 1.00,
                      rate: b.total ?? 0.00,
                      taxPercent: 0,
                      taxLabel: 'Select a Tax',
                      amount: b.total ?? 0.00,
                      accountId: '',
                      accountName: ''
                    }]);
                  }
                  
                  setIsModalOpen(true);
                }
              }}
              className="p-1 text-slate-400 hover:text-indigo-600 transition-colors cursor-pointer"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button 
              onClick={() => handleDelete(b.id, b.number)}
              className="p-1 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        );
      },
    }
  ];

  if (isCustomizerOpen) {
    return (
      <div className="space-y-6 animate-in fade-in duration-200">
        <style dangerouslySetInnerHTML={{ __html: compileCustomStyles() }} />
        
        {/* Sub-page Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-slate-200 pb-4 gap-4">
          <div>
            <div className="flex items-center gap-2 text-indigo-600 mb-1">
              <Palette className="w-5 h-5 text-indigo-600 animate-pulse" />
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">Purchase Bill Design Studio</h1>
            </div>
            <p className="text-slate-500 text-sm font-medium">
              Tailor company branding, colors, typography, layout style, and active transaction parameters.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setIsCustomizerOpen(false)}
            className="px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-black hover:bg-slate-700 transition shadow-sm cursor-pointer select-none"
          >
            ← Back to Bills List
          </button>
        </div>

        {/* Workspace Panels Split */}
        <div className="flex flex-col xl:flex-row gap-8 items-start w-full">
          {/* Left Controls */}
          <div className="w-full xl:w-[410px] shrink-0 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <TemplateCustomizer 
              settings={templateCustomizer}
              onChange={setTemplateCustomizer}
              onLogoUpload={handleLogoUpload}
            />
          </div>

          {/* Right Preview */}
          <div className="flex-1 w-full space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider text-slate-400">
                Live Design Canvas
              </span>
              <span className="text-[10px] text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Live Preview (Using {bills[0] ? 'Latest Bill' : 'Demo Bill Data'})
              </span>
            </div>
            <div className="p-6 md:p-8 border border-slate-200 bg-slate-50 rounded-3xl shadow-inner w-full flex items-center justify-center">
              <div className="w-full max-w-3xl">
                <BillPaperPreview 
                  bill={bills[0] || null} 
                  vendors={vendors} 
                  settings={templateCustomizer} 
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Today's Delivery Notifications Engine */}
      {enableServiceModule && (todayServiceBills.length === 0 ? (
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-100 rounded-full text-slate-500 shadow-inner">
              <CheckCircle className="w-4 h-4 text-slate-500" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-800">{t('services.due_today')}</h4>
              <p className="text-xs text-slate-500 font-medium">
                {t('services.all_clear')}
              </p>
            </div>
          </div>
          {filterTodayOnly && (
            <button
              onClick={() => setFilterTodayOnly(false)}
              className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold transition-all"
            >
              Show All Orders
            </button>
          )}
        </div>
      ) : (
        <div 
          onClick={() => setFilterTodayOnly(true)}
          className={cn(
            "border rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md cursor-pointer transition-all duration-300",
            filterTodayOnly 
              ? "bg-indigo-50 border-indigo-200 ring-2 ring-indigo-500/20"
              : "bg-amber-50 border-amber-200 hover:bg-amber-100"
          )}
        >
          <div className="flex items-center gap-3">
            <div className={cn(
              "p-2.5 rounded-full shadow-inner text-white",
              filterTodayOnly ? "bg-indigo-600" : "bg-amber-500"
            )}>
              <Clock className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-800">{t('services.due_today')}</h4>
              <p className="text-xs text-slate-600 font-bold mt-0.5">
                {t('services.count_alert', { count: todayServiceBills.length })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto">
            {filterTodayOnly ? (
              <span className="px-3 py-1 bg-indigo-200/50 text-indigo-800 rounded-lg text-xs font-bold border border-indigo-200/60">
                Filter Active / الفلتر نشط
              </span>
            ) : (
              <span className="px-3 py-1 bg-amber-500 text-white rounded-lg text-xs font-bold shadow-sm animate-bounce-subtle">
                Click to Filter Grid
              </span>
            )}
            {filterTodayOnly && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFilterTodayOnly(false);
                }}
                className="px-3 py-1 bg-white hover:bg-slate-50 text-slate-705 rounded-lg text-xs font-semibold border border-slate-205 shadow-sm transition-all"
              >
                Reset Filter
              </button>
            )}
          </div>
        </div>
      ))}

      {/* Enterprise Governance Architecture & Performance QA Suite */}
      <GovernancePipeline />

      <div className="flex items-center justify-between animate-fade-in-delayed">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Purchase Bills</h1>
          <p className="text-slate-500 text-sm">Track your dynamic business expenses and supplier bills.</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-indigo-650 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            Import from Excel
          </button>

          <div className="relative">
            <button
              onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
              className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Export
            </button>
            {isExportDropdownOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setIsExportDropdownOpen(false)} />
                <div className="absolute right-0 mt-1.5 w-48 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 z-20">
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToExcel(
                        bills,
                        ['number', 'vendorName', 'date', 'dueDate', 'subTotal', 'discountPercent', 'shippingCharges', 'total', 'status'],
                        ['Bill Number', 'Vendor Name', 'Bill Date', 'Due Date', 'Sub Total', 'Discount %', 'Shipping', 'Total Amount', 'Status'],
                        'System_Purchase_Bills'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    Export to Excel (.xlsx)
                  </button>
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToPDF(
                        bills,
                        ['number', 'vendorName', 'date', 'dueDate', 'subTotal', 'discountPercent', 'shippingCharges', 'total', 'status'],
                        ['Bill Number', 'Vendor Name', 'Bill Date', 'Due Date', 'Sub Total', 'Discount %', 'Shipping', 'Total Amount', 'Status'],
                        'Advanced Accounting - Purchase Bills Registry',
                        'System_Purchase_Bills'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    Export to PDF (.pdf)
                  </button>
                </div>
              </>
            )}
          </div>

          <button 
            type="button"
            onClick={() => setIsCustomizerOpen(true)}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors text-sm font-semibold shadow-sm cursor-pointer select-none"
          >
            <Palette className="w-4 h-4 text-indigo-600" />
            Customize Template
          </button>
          <button 
            onClick={() => {
              setEditingBill(null);
              setBillVendorId('');
              setBillSubTotal(0);
              setBillDiscountPercent(0);
              setBillShippingCharges(0);
              setBillAdjustment(0);
              setBillVendorNotes('Items received in perfect condition.');
              setBillTermsConditions('');
              setBillBranchId("Sana'a Main HQ branch");
              setBillCostCenterId("Admin HQ Operations Center");
              setFormRows([createEmptyRow()]);
              setSaveStatus(null);
              setTransactionCurrency(settings?.currency || 'YER');
              setTransactionExchangeRate(1.0);
              const tempId = 'temp_bill_' + Math.random().toString(36).substring(2, 11);
              setCurrentEntityId(tempId);
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-semibold shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Record Bill
          </button>

          {enableServiceModule && (
            <button 
              onClick={() => {
                setEditingBill(null);
                setServiceBillVendorId('');
                setServiceJobDescription('');
                setServiceJobStatus('Draft');
                setServiceReceivingDate(new Date().toISOString().split('T')[0]);
                setServiceEstimatedDeliveryDate('');
                setServiceBillNumber(`SRV-${Math.floor(100000 + Math.random() * 900000)}`);
                setServiceExpenses([{
                  id: Math.random().toString(36).substring(7),
                  description: 'Technical labor fees',
                  amount: 0,
                  accountId: '',
                  accountName: ''
                }]);
                setConsumedItems([]);
                setIsServiceModalOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors text-sm font-semibold shadow-sm cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              {t('serviceBill.new_service_bill')}
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-2 bg-amber-50 rounded-lg text-amber-600">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Unpaid Bills</p>
            <p className="text-lg font-bold text-slate-900">{formatCurrency(stats.unpaid)}</p>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-2 bg-rose-50 rounded-lg text-rose-600">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Overdue</p>
            <p className="text-lg font-bold text-slate-900">{formatCurrency(stats.overdue)}</p>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Paid (Total)</p>
            <p className="text-lg font-bold text-slate-900">{formatCurrency(stats.paid)}</p>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-2 bg-slate-50 rounded-lg text-slate-600">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Drafts</p>
            <p className="text-lg font-bold text-slate-900">{formatCurrency(stats.drafts)}</p>
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search by bill number or vendor name..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      ) : (
        <DataTable columns={columns} data={filteredBills} />
      )}

      {/* Service & Job Orders Tracking Operational Dashboard */}
      {enableServiceModule && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mt-8">
          <div className="bg-slate-50 border-b border-slate-200 px-6 py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-600" />
                <h2 className="text-lg font-bold text-slate-900">
                  {t('services.tracking_title')}
                </h2>
              </div>
              <p className="text-slate-505 text-xs mt-1">
                Operational tracking of technical labor, material consumed, and real-time maintenance lifecycle status.
              </p>
            </div>
            <div className="flex items-center gap-2">
              {filterTodayOnly && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200 text-amber-800 rounded-lg text-xs font-bold">
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                  {t('services.due_today')}
                </span>
              )}
              <button
                onClick={() => {
                  setEditingBill(null);
                  setServiceBillVendorId('');
                  setServiceJobDescription('');
                  setServiceJobStatus('Draft');
                  setServiceReceivingDate(new Date().toISOString().split('T')[0]);
                  setServiceEstimatedDeliveryDate('');
                  setServiceBillNumber(`SRV-${Math.floor(100000 + Math.random() * 900000)}`);
                  setServiceExpenses([{
                    id: Math.random().toString(36).substring(7),
                    description: 'Technical labor fees',
                    amount: 0,
                    accountId: '',
                    accountName: ''
                  }]);
                  setConsumedItems([]);
                  setIsServiceModalOpen(true);
                }}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer shadow-sm flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                {t('serviceBill.new_service_bill')}
              </button>
            </div>
          </div>

          {filteredServiceBills.length === 0 ? (
            <div className="p-12 text-center text-slate-400 text-sm font-medium">
              No service or job orders found matching the filter criteria.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="px-6 py-3.5 text-xs font-bold text-slate-500 uppercase tracking-wider">{t('services.order_id')}</th>
                    <th className="px-6 py-3.5 text-xs font-bold text-slate-500 uppercase tracking-wider">{t('services.vendor')}</th>
                    <th className="px-6 py-3.5 text-xs font-bold text-slate-500 uppercase tracking-wider">{t('services.job_desc_summary')}</th>
                    <th className="px-6 py-3.5 text-xs font-bold text-slate-500 uppercase tracking-wider">{t('services.receiving_date')}</th>
                    <th className="px-6 py-3.5 text-xs font-bold text-slate-500 uppercase tracking-wider">{t('services.delivery_date')}</th>
                    <th className="px-6 py-3.5 text-xs font-bold text-slate-500 uppercase tracking-wider">{t('services.status')}</th>
                    <th className="px-6 py-3.5 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredServiceBills.map(b => {
                    const status = b.serviceStatus || 'Draft';
                    let statusBadge = (
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-600 border border-slate-200">
                        {status}
                      </span>
                    );
                    if (status === 'Draft' || status === 'Received') {
                      statusBadge = (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-50 text-rose-700 border border-rose-105">
                          {status === 'Draft' ? t('serviceBill.draft') : t('serviceBill.received')}
                        </span>
                      );
                    } else if (status === 'In Progress') {
                      statusBadge = (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-50 text-amber-700 border border-amber-105">
                          {t('services.status_in_progress')}
                        </span>
                      );
                    } else if (status === 'Ready for Delivery') {
                      statusBadge = (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-105">
                          {t('serviceBill.ready')}
                        </span>
                      );
                    } else if (status === 'Delivered') {
                      statusBadge = (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-105">
                          {t('serviceBill.delivered')}
                        </span>
                      );
                    }

                    return (
                      <tr key={b.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4 text-xs font-bold text-slate-900">{b.number}</td>
                        <td className="px-6 py-4 text-xs font-semibold text-slate-700">{b.vendorName}</td>
                        <td className="px-6 py-4 text-xs text-slate-500 max-w-xs truncate" title={b.jobDescription || b.customerNotes}>
                          {b.jobDescription || b.customerNotes || "N/A"}
                        </td>
                        <td className="px-6 py-4 text-xs text-slate-505 font-mono">{b.receivingDate || b.date}</td>
                        <td className="px-6 py-4 text-xs text-slate-700 font-bold font-mono">{b.estimatedDeliveryDate || b.dueDate}</td>
                        <td className="px-6 py-4 text-xs">{statusBadge}</td>
                        <td className="px-6 py-4 text-xs text-right">
                          <button
                            onClick={() => {
                              setEditingBill(b);
                              setCurrentEntityId(b.id);
                              setServiceBillVendorId(b.vendorId || '');
                              setServiceJobDescription(b.jobDescription || '');
                              setServiceJobStatus(b.serviceStatus || 'Draft');
                              setServiceReceivingDate(b.receivingDate || '');
                              setServiceEstimatedDeliveryDate(b.estimatedDeliveryDate || '');
                              setServiceExpenses(b.serviceExpenses || []);
                              setConsumedItems(b.consumedItems || []);
                              setServiceBillNumber(b.number || '');
                              setIsServiceModalOpen(true);
                            }}
                            className="px-2.5 py-1 bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 text-slate-600 hover:text-indigo-650 rounded-md font-semibold transition-all shadow-sm cursor-pointer"
                          >
                            Edit
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => {
          setIsModalOpen(false);
          setEditingBill(null);
        }} 
        title={editingBill ? "Edit Bill Details" : "Record New Purchase Bill"} 
        size="xl"
      >
        <form onSubmit={handleSave} className="space-y-8 relative">
          <style dangerouslySetInnerHTML={{ __html: compileCustomStyles() }} />

          <div className="custom-font space-y-8">

              {/* Customized Branding Header */}
              <div 
                className={cn(
                  "p-6 rounded-2xl mb-6 text-left",
                  templateCustomizer.templateStyle === 'standard' && "bg-slate-50 border border-dashed border-slate-200 p-5",
                  templateCustomizer.templateStyle === 'professional' && "text-white shadow-md",
                  templateCustomizer.templateStyle === 'modern' && "bg-white border-b-2 pb-6 rounded-none px-0"
                )}
                style={
                  templateCustomizer.templateStyle === 'professional' 
                    ? { backgroundColor: templateCustomizer.primaryColor } 
                    : (templateCustomizer.templateStyle === 'modern' ? { borderBottomColor: templateCustomizer.primaryColor } : {})
                }
              >
                {/* Logo alignment and size */}
                <div className={cn(
                  "flex mb-5 print:mb-2",
                  templateCustomizer.logoAlignment === 'left' && "justify-start",
                  templateCustomizer.logoAlignment === 'center' && "justify-center",
                  templateCustomizer.logoAlignment === 'right' && "justify-end",
                  !templateCustomizer.logoUrl && "print:hidden"
                )}>
                  {templateCustomizer.logoUrl ? (
                    <div className="relative group/logo">
                      <img 
                        src={templateCustomizer.logoUrl} 
                        alt="Company Logo" 
                        className={cn(
                          "object-contain",
                          templateCustomizer.logoSize === 'small' && "h-10",
                          templateCustomizer.logoSize === 'medium' && "h-16",
                          templateCustomizer.logoSize === 'large' && "h-24"
                        )}
                        referrerPolicy="no-referrer"
                      />
                      <button
                        type="button"
                        onClick={() => setTemplateCustomizer(prev => ({ ...prev, logoUrl: '' }))}
                        className="absolute -top-2 -right-2 bg-rose-600 text-white p-1 rounded-full text-[9px] shadow hover:bg-rose-700 opacity-0 group-hover/logo:opacity-100 transition-opacity print:hidden"
                        title="Remove logo"
                      >
                        ✕
                      </button>
                    </div>
                  ) : (
                    <label className="flex flex-col items-center justify-center py-2 px-4 border border-dashed border-slate-300 rounded-xl hover:bg-slate-100/50 cursor-pointer text-slate-400 hover:text-slate-600 print:hidden select-none bg-white">
                      <span className="text-[10px] font-bold">Add Logo</span>
                      <input 
                        type="file" 
                        accept="image/*" 
                        onChange={handleLogoUpload} 
                        className="hidden" 
                      />
                    </label>
                  )}
                </div>

                <div className={cn(
                  "flex flex-col sm:flex-row justify-between items-start gap-4",
                  templateCustomizer.templateStyle === 'professional' ? "text-white" : "text-slate-800"
                )}>
                  <div>
                    <h1 
                      className={cn(
                        "text-2xl font-black uppercase tracking-tight",
                        templateCustomizer.templateStyle === 'professional' ? "text-white" : "custom-primary-text"
                      )}
                    >
                      Purchase Bill
                    </h1>
                    <p className="text-xs opacity-75 mt-0.5 font-bold">
                      Status: <span className="uppercase tracking-wide font-extrabold">{editingBill?.status || 'Draft'}</span>
                    </p>
                  </div>
                  
                  <div className="sm:text-right text-left text-xs font-semibold leading-relaxed">
                    <h2 className="text-sm font-extrabold uppercase tracking-wide">Yemen Finance Systems</h2>
                    <p className="opacity-75 mt-0.5">Main Office, Sana'a</p>
                    <p className="opacity-75">VAT Reg: 120-993-211</p>
                  </div>
                </div>
              </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <div className="space-y-4">
              <h4 className="font-bold text-slate-900 border-b pb-2">Vendor Details</h4>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Vendor</label>
                <select 
                  name="vendorId" 
                  value={billVendorId} 
                  required
                  onChange={(e) => setBillVendorId(e.target.value)} 
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm"
                >
                  <option value="">Select a vendor</option>
                  {vendors.map(v => (
                    <option key={v.id} value={v.id}>{v.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Billing Address</label>
                <textarea 
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 h-24 bg-slate-50 text-slate-700 text-sm resize-none" 
                  readOnly 
                  value={
                    (() => {
                      const v = vendors.find(vend => vend.id === billVendorId);
                      if (!v) return '';
                      const addressParts = [
                        v.streetAddress,
                        v.city,
                        v.governorate,
                        v.country
                      ].filter(Boolean);
                      return addressParts.join('\n') || 'No address provided for this vendor.';
                    })()
                  }
                  placeholder="Address will auto-populate..."
                />
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-bold text-slate-900 border-b pb-2">Bill Info</h4>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Bill Number</label>
                <input name="number" defaultValue={editingBill?.number || `BILL-${new Date().getFullYear()}-${String(bills.length + 1).padStart(3, '0')}`} required type="text" className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Bill Date</label>
                <input name="date" defaultValue={editingBill?.date || new Date().toISOString().split('T')[0]} required type="date" className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Currency</label>
                <select
                  value={transactionCurrency || 'YER'}
                  onChange={(e) => handleCurrencyChange(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm font-semibold animate-none"
                >
                  {GLOBAL_CURRENCIES.map(curr => (
                    <option key={curr.code} value={curr.code}>
                      {curr.flag} {curr.code} ({curr.name})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center justify-between">
                  <span>Exchange Rate</span>
                  {transactionCurrency !== settings?.currency && (
                    <span className="text-[10px] text-indigo-600 bg-indigo-50 px-2.2 py-0.5 rounded-full font-bold">
                      1 {transactionCurrency} = {transactionExchangeRate.toFixed(4)} {settings?.currency}
                    </span>
                  )}
                </label>
                <input
                  type="number"
                  step="any"
                  min="0.0001"
                  required
                  value={transactionExchangeRate}
                  onChange={(e) => setTransactionExchangeRate(Number(e.target.value) || 1.0)}
                  disabled={transactionCurrency === settings?.currency}
                  className={cn(
                    "w-full px-4 py-2 border rounded-lg outline-none text-sm font-mono font-bold",
                    transactionCurrency === settings?.currency
                      ? "bg-slate-50 border-slate-100 text-slate-400 cursor-not-allowed select-none"
                      : "bg-white border-slate-200 focus:ring-2 focus:ring-indigo-500 text-slate-1000"
                  )}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  {document.documentElement.lang === 'ar' ? 'الفرع المستهدف' : 'Target Branch'}
                </label>
                <select
                  value={billBranchId}
                  onChange={(e) => setBillBranchId(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm font-semibold text-slate-950"
                >
                  <option value="Sana'a Main HQ branch">Sana'a Main HQ branch (فرع صنعاء الرئيسي)</option>
                  <option value="Aden Port Operations branch">Aden Port Operations branch (فرع عمليات ميناء عدن)</option>
                  <option value="Taiz Cold Store Branch">Taiz Cold Store Branch (فرع تعز للتبريد)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  {document.documentElement.lang === 'ar' ? 'مركز التكلفة' : 'Cost Center'}
                </label>
                <select
                  value={billCostCenterId}
                  onChange={(e) => setBillCostCenterId(e.target.value)}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-sm font-semibold text-slate-950"
                >
                  <option value="Admin HQ Operations Center">Admin HQ Operations Center (عمليات الإدارة العامة)</option>
                  <option value="Sales Hub YER Ledger">Sales Hub YER Ledger (مركز مبيعات صنعاء)</option>
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="font-bold text-slate-900 border-b pb-2">Payment Terms</h4>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Due Date</label>
                <input name="dueDate" defaultValue={editingBill?.dueDate || new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]} required type="date" className="w-full px-4 py-2 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center justify-between">
                  <span>Sub Total</span>
                  <span className="text-xs text-indigo-600 font-normal font-sans">Calculated from items</span>
                </label>
                <input 
                  name="subTotal" 
                  value={billSubTotal || '0.00'} 
                  readOnly 
                  placeholder="0.00" 
                  type="number" 
                  step="0.01" 
                  className="w-full px-4 py-2 border border-slate-100 bg-slate-50 text-slate-500 rounded-lg outline-none text-sm font-semibold select-none cursor-not-allowed text-right" 
                />
              </div>
            </div>
          </div>

          {/* Item Table Section */}
          <div className="space-y-4 pt-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-2 border-slate-200 text-left">
              <h4 className="font-bold text-slate-800 text-base flex items-center gap-2">
                Item Table
              </h4>
              <div className="flex items-center gap-2 relative">
                {/* Scanner Popover */}
                {isScannerOpen && (
                  <div className="absolute right-0 bottom-full mb-2 bg-white border border-slate-200 rounded-xl p-4 shadow-xl z-[60] w-72 space-y-3">
                    <div className="flex items-center justify-between border-b pb-1">
                      <span className="text-xs font-bold text-slate-800 flex items-center gap-1">
                        <Barcode className="w-4 h-4 text-indigo-600" />
                        Scan Item Barcode
                      </span>
                      <button 
                        type="button" 
                        onClick={() => {
                          setIsScannerOpen(false);
                          setScanSku('');
                          setScanError('');
                        }}
                        className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                      >
                        ✕
                      </button>
                    </div>
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase">Enter Item SKU</label>
                        <input 
                          type="text" 
                          placeholder="e.g. ITEM-001, ITEM-002"
                          value={scanSku}
                          onChange={(e) => setScanSku(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              e.stopPropagation();
                              handleScanItem();
                            }
                          }}
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-xs bg-slate-50"
                          autoFocus
                        />
                      </div>
                      {scanError && (
                        <p className="text-[10px] text-rose-600 font-medium">{scanError}</p>
                      )}
                      <button 
                        type="button"
                        onClick={handleScanItem}
                        className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-sm transition-colors"
                      >
                        Scan & Add
                      </button>
                    </div>
                  </div>
                )}

                {/* Bulk Actions Dropdown */}
                {isBulkActionOpen && (
                  <div className="absolute right-0 bottom-full mb-2 bg-white border border-slate-200 rounded-xl shadow-xl z-[60] w-52 py-1 overflow-hidden animate-in fade-in-50 duration-75">
                    <div className="px-3 py-1 border-b border-slate-100 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                      Actions
                    </div>
                    <button 
                      type="button" 
                      onClick={() => handleBulkAction('add3')}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-medium text-slate-700 transition"
                    >
                      + Add 3 Empty Rows
                    </button>
                    <button 
                      type="button" 
                      onClick={() => handleBulkAction('tax15')}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-medium text-slate-700 transition"
                    >
                      Apply VAT (15%) on all
                    </button>
                    <button 
                      type="button" 
                      onClick={() => handleBulkAction('tax5')}
                      className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-medium text-slate-700 transition"
                    >
                      Apply VAT (5%) on all
                    </button>
                    <div className="border-t border-slate-100 my-0.5" />
                    <button 
                      type="button" 
                      onClick={() => handleBulkAction('clear')}
                      className="w-full text-left px-4 py-2 hover:bg-rose-50 text-xs font-semibold text-rose-600 transition"
                    >
                      Clear All Rows
                    </button>
                  </div>
                )}

                <button 
                  type="button" 
                  onClick={() => {
                    setIsScannerOpen(!isScannerOpen);
                    setIsBulkActionOpen(false);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600 text-xs font-semibold shadow-sm transition-all"
                >
                  <Scan className="w-3.5 h-3.5 text-slate-500" />
                  Scan Item
                </button>
                <button 
                  type="button" 
                  onClick={() => {
                    setIsBulkActionOpen(!isBulkActionOpen);
                    setIsScannerOpen(false);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-600 text-xs font-semibold shadow-sm transition-all"
                >
                  <Layers className="w-3.5 h-3.5 text-slate-500" />
                  Bulk Actions
                </button>
              </div>
            </div>

            {/* Item Rows Table with ACCOUNT Mapping */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-sm bg-white">
              <table className="w-full text-left border-collapse">
                <thead className={cn(
                  "text-[11px] uppercase tracking-wider font-extrabold border-b",
                  templateCustomizer.templateStyle === 'professional' ? "custom-primary-bg text-white border-transparent" : "bg-slate-50 text-slate-700 border-slate-200"
                )}>
                  <tr>
                    <th className="px-4 py-3 min-w-[240px]">Item Details</th>
                    <th className="px-4 py-3 min-w-[200px]">ACCOUNT</th>
                    <th className="px-4 py-3 w-[100px] text-right">Quantity</th>
                    <th className="px-4 py-3 w-[130px] text-right">Rate</th>
                    {!templateCustomizer.hideTaxColumn && <th className="px-4 py-3 w-[140px]">Tax</th>}
                    <th className="px-4 py-3 w-[130px] text-right">Amount</th>
                    <th className="px-2 py-3 w-[45px] text-center print-hidden"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {formRows.map((row) => (
                    <tr key={row.id} className="hover:bg-slate-50/50 transition-colors">
                      {/* Item details autocomplete search field */}
                      <td className="px-4 py-2.5 relative">
                        <div className="relative">
                          <input 
                            type="text"
                            placeholder="Type or select warehouse item..."
                            value={
                              activeDropdownRowId === row.id 
                                ? (rowSearchQueries[row.id] ?? '') 
                                : (row.name ? `${row.sku} - ${row.name}` : '')
                            }
                            onChange={(e) => {
                              setRowSearchQueries(prev => ({ ...prev, [row.id]: e.target.value }));
                              setActiveDropdownRowId(row.id);
                            }}
                            onFocus={() => {
                              setActiveDropdownRowId(row.id);
                              if (!rowSearchQueries[row.id]) {
                               setRowSearchQueries(prev => ({ ...prev, [row.id]: row.name || '' }));
                              }
                            }}
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-xs text-slate-800"
                          />
                          
                          {activeDropdownRowId === row.id && (
                            <>
                              <div 
                                className="fixed inset-0 z-40" 
                                onClick={() => setActiveDropdownRowId(null)}
                              />
                              <div className="absolute left-0 right-0 mt-1 max-h-60 overflow-y-auto bg-white border border-slate-200 rounded-xl shadow-2xl z-50 py-1.5">
                                {(() => {
                                  const queryText = (rowSearchQueries[row.id] ?? '').toLowerCase();
                                  const filtered = items.filter(it => 
                                    it.name.toLowerCase().includes(queryText) || 
                                    it.sku.toLowerCase().includes(queryText)
                                  );
                                  
                                  if (filtered.length === 0) {
                                    return (
                                      <div className="px-3 py-2 text-xs text-slate-400 text-center italic">
                                        No matching catalog items
                                      </div>
                                    );
                                  }
                                  
                                  return filtered.map(it => (
                                    <button
                                      key={it.id}
                                      type="button"
                                      onClick={() => {
                                        // Pick matching default account if select empty
                                        const fallbackAcc = expenseAndAssetAccounts.find(a => a.name.toLowerCase().includes('cost of goods') || a.type === 'Expense') || expenseAndAssetAccounts[0];
                                        handleRowChange(row.id, {
                                          itemId: it.id,
                                          name: it.name,
                                          sku: it.sku,
                                          rate: it.purchasePrice || it.salesPrice || 0,
                                          accountId: row.accountId || fallbackAcc?.id || '',
                                          accountName: row.accountName || fallbackAcc?.name || ''
                                        });
                                        setActiveDropdownRowId(null);
                                        setRowSearchQueries(prev => ({ ...prev, [row.id]: '' }));
                                      }}
                                      className="w-full text-left px-4 py-2 hover:bg-slate-50 flex flex-col gap-0.5 border-b border-slate-50 last:border-none"
                                    >
                                      <span className="font-bold text-slate-800 text-xs">{it.sku} - {it.name}</span>
                                      <span className="text-[10px] text-slate-400">Cost Rate: {formatCurrency(it.purchasePrice || 0, 'YER')} | Qty: {it.stockOnHand}</span>
                                    </button>
                                  ));
                                })()}
                              </div>
                            </>
                          )}
                        </div>
                      </td>

                      {/* ACCOUNT selection Column */}
                      <td className="px-4 py-2.5">
                        <AccountDropdown
                          accounts={accounts}
                          selectedAccountId={row.accountId || ''}
                          onAccountChange={(accId) => {
                            const accObj = accounts.find(a => a.id === accId);
                            handleRowChange(row.id, { 
                              accountId: accId, 
                              accountName: accObj ? accObj.name : '' 
                            });
                          }}
                          accountTypeFilter={['Expense', 'Asset']}
                          placeholder="Select Account"
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-xs text-slate-800 font-semibold text-right"
                        />
                      </td>

                      {/* Quantity */}
                      <td className="px-4 py-2.5">
                        <input 
                          type="number"
                          min="0.01"
                          step="0.01"
                          required
                          value={row.quantity}
                          onChange={(e) => handleRowChange(row.id, { quantity: Number(e.target.value) })}
                          placeholder="1.00"
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-xs text-slate-800 text-right font-semibold"
                        />
                      </td>

                      {/* Rate */}
                      <td className="px-4 py-2.5">
                        <input 
                          type="number"
                          min="0"
                          step="0.01"
                          required
                          value={row.rate}
                          onChange={(e) => handleRowChange(row.id, { rate: Number(e.target.value) })}
                          placeholder="0.00"
                          className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-xs text-slate-800 text-right font-semibold"
                        />
                      </td>

                      {/* Tax selection */}
                      {!templateCustomizer.hideTaxColumn && (
                        <td className="px-4 py-2.5">
                          <select
                            value={row.taxPercent}
                            onChange={(e) => {
                              const val = Number(e.target.value);
                              let lbl = 'Select a Tax';
                              if (val === 15) lbl = 'VAT (15%)';
                              else if (val === 5) lbl = 'VAT (5%)';
                              else if (val === 0) lbl = 'Tax Exempt (0%)';
                              handleRowChange(row.id, { taxPercent: val, taxLabel: lbl });
                            }}
                            className="w-full px-3 py-1.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white text-xs text-slate-800 font-medium"
                          >
                            <option value="0" disabled={row.taxLabel === 'Select a Tax'}>Select a Tax</option>
                            <option value="0">Tax Exempt (0%)</option>
                            <option value="5">VAT (5%)</option>
                            <option value="15">VAT (15%)</option>
                          </select>
                        </td>
                      )}

                      {/* Amount read-only */}
                      <td className="px-4 py-2.5 text-right">
                        <input 
                          type="text"
                          readOnly
                          value={formatCurrency(row.amount, transactionCurrency)}
                          className="w-full px-3 py-1.5 bg-slate-50 border border-slate-100 rounded-lg text-xs font-extrabold text-slate-700 text-right cursor-not-allowed select-none"
                        />
                      </td>

                      {/* Bin/Trash action */}
                      <td className="px-2 py-2.5 text-center print-hidden">
                        <button
                          type="button"
                          onClick={() => {
                            if (formRows.length > 1) {
                              setFormRows(prev => prev.filter(r => r.id !== row.id));
                            } else {
                              setFormRows([createEmptyRow()]);
                            }
                          }}
                          className="p-1 px-1.5 text-slate-400 hover:text-rose-600 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Addition tools under table */}
            <div className="flex items-center gap-2 pt-1 pb-2">
              <button 
                type="button" 
                onClick={() => setFormRows(prev => [...prev, createEmptyRow()])}
                className="flex items-center gap-2 px-3.5 py-2 border border-slate-200 bg-slate-50 hover:bg-slate-100 rounded-lg text-slate-700 text-xs font-semibold transition-all shadow-sm"
              >
                <span>+ Add New Row</span>
              </button>
              <button 
                type="button" 
                onClick={handleAddItemsInBulk}
                className="flex items-center gap-1.5 px-3.5 py-2 border border-indigo-100 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-indigo-700 text-xs font-semibold transition-all shadow-sm"
              >
                <PlusCircle className="w-3.5 h-3.5 text-indigo-600" />
                + Add Items in Bulk
              </button>
            </div>
          </div>

          <div className="border-t border-slate-200 my-6" />

          {/* Bottom Summary Alignments */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6 text-left">
              <div className={cn(templateCustomizer.hideCustomerNotes && "print:hidden")}>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-sm font-semibold text-slate-800">Vendor Notes</label>
                  {templateCustomizer.hideCustomerNotes && (
                    <span className="text-[10px] text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full font-bold print:hidden">Hidden on Print</span>
                  )}
                </div>
                <textarea 
                  name="customerNotes"
                  value={billVendorNotes}
                  onChange={(e) => setBillVendorNotes(e.target.value)}
                  placeholder="Items received in perfect condition."
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 h-24 text-sm resize-none bg-white font-semibold"
                />
                <p className="text-[11px] text-slate-500 mt-1">Will be displayed on the printed Bill</p>
              </div>

              <div className={cn(templateCustomizer.hideTermsAndConditions && "print:hidden")}>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-sm font-semibold text-slate-800">Terms & Conditions</label>
                  {templateCustomizer.hideTermsAndConditions && (
                    <span className="text-[10px] text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full font-bold print:hidden">Hidden on Print</span>
                  )}
                </div>
                <textarea 
                  name="termsConditions"
                  value={billTermsConditions}
                  onChange={(e) => setBillTermsConditions(e.target.value)}
                  placeholder="Enter specific vendor contractual terms here..."
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 h-24 text-sm resize-none bg-white font-semibold"
                />
              </div>
            </div>

            {/* Calculations block (matches Sales Invoice side perfectly) */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4 shadow-sm hover:border-indigo-200 transition-all text-left">
              <h4 className="font-bold text-sm text-slate-900 border-b pb-2 uppercase tracking-wide flex items-center gap-1.5">
                Calculation Summary
              </h4>

              {/* Sub Total */}
              <div className="flex items-center justify-between text-sm py-1 border-b border-dashed border-slate-200 pb-2">
                <span className="text-slate-600 font-medium">Sub Total</span>
                <span className="font-bold text-slate-900">{formatCurrency(billSubTotal, transactionCurrency)}</span>
              </div>

              {/* Discount Row */}
              <div className="flex items-center justify-between gap-4 text-sm py-1">
                <div className="flex items-center gap-2 flex-1">
                  <span className="text-slate-600 font-medium">Discount</span>
                  <div className="relative inline-flex items-center">
                    <input 
                      type="number"
                      min="0"
                      max="100"
                      step="0.01"
                      placeholder="0"
                      value={billDiscountPercent || ''}
                      onChange={(e) => setBillDiscountPercent(Number(e.target.value))}
                      className="w-16 pl-2 pr-5 py-0.5 text-xs text-slate-800 border border-slate-300 rounded outline-none text-right font-semibold focus:ring-2 focus:ring-indigo-500 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none bg-white"
                    />
                    <span className="absolute right-1 text-xs text-slate-400 font-bold">%</span>
                  </div>
                </div>
                <span className="font-bold text-rose-600">
                  -{formatCurrency(calculatedDiscount, transactionCurrency)}
                </span>
              </div>

              {/* Shipping Charges Row */}
              <div className={cn("flex items-center justify-between gap-4 text-sm py-1", templateCustomizer.hideShippingCharges && "print:hidden")}>
                <div className="flex items-center gap-1.5 flex-1">
                  <span className="text-slate-600 font-medium">Freight & Shipping Charges</span>
                  {templateCustomizer.hideShippingCharges && (
                    <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.2 rounded font-bold print:hidden font-sans">Hidden</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <input 
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    value={billShippingCharges || ''}
                    onChange={(e) => setBillShippingCharges(Number(e.target.value))}
                    className="w-24 px-2 py-0.5 text-xs text-right text-slate-800 border border-slate-300 rounded font-semibold focus:ring-2 focus:ring-indigo-500 bg-white print-hidden"
                  />
                  <span className="font-bold text-slate-900 min-w-[80px] text-right">
                    {formatCurrency(billShippingCharges || 0, transactionCurrency)}
                  </span>
                </div>
              </div>

              {/* Adjustment Row */}
              <div className="flex items-center justify-between gap-4 text-sm py-1 border-b border-dashed border-slate-200 pb-3">
                <span className="text-slate-600 font-medium flex-1">Adjustment</span>
                <div className="flex items-center gap-2">
                  <input 
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={billAdjustment || ''}
                    onChange={(e) => setBillAdjustment(Number(e.target.value))}
                    className="w-24 px-2 py-0.5 text-xs text-right text-slate-800 border border-slate-300 rounded font-semibold focus:ring-2 focus:ring-indigo-500 bg-white print-hidden"
                  />
                  <span className={cn(
                    "font-bold min-w-[80px] text-right",
                    billAdjustment < 0 ? "text-rose-600" : billAdjustment > 0 ? "text-emerald-600" : "text-slate-900"
                  )}>
                    {billAdjustment > 0 ? "+" : ""}{formatCurrency(billAdjustment || 0, transactionCurrency)}
                  </span>
                </div>
              </div>

              {/* Grand Total Row */}
              <div className="flex items-center justify-between text-base py-2.5 font-extrabold text-indigo-700 bg-indigo-50 rounded-lg px-4 border border-indigo-100">
                <span>Grand Total ({transactionCurrency})</span>
                <span className="text-lg">{formatCurrency(grandTotal, transactionCurrency)}</span>
              </div>

              {/* Base Currency Equivalent Display Block */}
              {transactionCurrency !== settings?.currency && (
                <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-xl text-xs flex justify-between items-center text-indigo-900 font-bold font-mono">
                  <span>Equivalent in Base ({settings?.currency}):</span>
                  <span>{formatCurrency(grandTotal * transactionExchangeRate, settings?.currency)}</span>
                </div>
              )}
            </div>

            {/* Bottom-right attachments layout box */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-inner mt-4 print-hidden">
              <h4 className="font-bold text-xs text-slate-700 mb-3 flex items-center gap-1.5 uppercase tracking-wide">
                <PaperclipIcon className="w-4 h-4 text-indigo-600 font-bold" />
                Linked Reference Attachments
              </h4>
              <FileAttachments entityId={currentEntityId} />
            </div>

          </div>
          </div>

          <div className="flex items-center justify-between pt-8 border-t print-hidden">
            <div className="flex items-center gap-2">
              <button 
                type="button" 
                onClick={() => setIsModalOpen(false)} 
                className="px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-semibold text-slate-600 text-sm"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="px-4 py-2 border border-indigo-100 text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-all font-semibold shadow-sm flex items-center gap-2 text-sm"
              >
                <Printer className="w-4 h-4" />
                Print Bill
              </button>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="submit"
                onClick={() => setSaveStatus('Draft')}
                disabled={isSaving}
                className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors font-semibold text-sm"
              >
                Save as Draft
              </button>
              <button 
                type="submit" 
                onClick={() => setSaveStatus('Unpaid')}
                disabled={isSaving}
                className="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-semibold shadow-sm flex items-center gap-2 text-sm"
              >
                {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
                {isSaving ? 'Processing...' : (editingBill ? 'Save & Approve' : 'Save Bill')}
              </button>
            </div>
          </div>
        </form>
      </Modal>

      <Modal
        isOpen={isServiceModalOpen}
        onClose={() => {
          setIsServiceModalOpen(false);
          setEditingBill(null);
        }}
        title={editingBill ? t('serviceBill.modal_title_edit') : t('serviceBill.modal_title')}
        size="xl"
      >
        <form onSubmit={handleSaveServiceBill} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-50 p-6 rounded-2xl border border-dashed border-slate-200">
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1.5">{t('table.invoice_no')}</label>
              <input 
                type="text"
                value={serviceBillNumber}
                onChange={(e) => setServiceBillNumber(e.target.value)}
                className="w-full px-4 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm font-medium shadow-sm"
                placeholder="e.g. SRV-2026-001"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1.5">{t('serviceBill.vendor')}</label>
              <select
                value={serviceBillVendorId}
                onChange={(e) => setServiceBillVendorId(e.target.value)}
                className="w-full px-4 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm font-medium shadow-sm transition-shadow"
              >
                <option value="">Select Service Provider</option>
                {vendors.map(v => (
                  <option key={v.id} value={v.id}>{v.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1.5">{t('serviceBill.status')}</label>
              <select
                value={serviceJobStatus}
                onChange={(e) => setServiceJobStatus(e.target.value as any)}
                className="w-full px-4 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm font-medium shadow-sm transition-shadow"
              >
                <option value="Draft">{t('serviceBill.draft')}</option>
                <option value="Received">{t('serviceBill.received')}</option>
                <option value="In Progress">{t('serviceBill.in_progress')}</option>
                <option value="Ready for Delivery">{t('serviceBill.ready')}</option>
                <option value="Delivered">{t('serviceBill.delivered')}</option>
              </select>
            </div>

            <div className="col-span-1 md:col-span-3">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1.5">{t('serviceBill.job_desc')}</label>
              <textarea
                value={serviceJobDescription}
                onChange={(e) => setServiceJobDescription(e.target.value)}
                className="w-full h-20 px-4 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm font-medium shadow-sm resize-none"
                placeholder={t('serviceBill.job_desc_placeholder')}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 col-span-1 md:col-span-3">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1.5">{t('serviceBill.receiving_date')}</label>
                <input 
                  type="date"
                  value={serviceReceivingDate}
                  onChange={(e) => setServiceReceivingDate(e.target.value)}
                  className="w-full px-4 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm font-medium shadow-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1.5">
                  {t('serviceBill.est_delivery_date')} <span className="text-rose-500">*</span>
                </label>
                <input 
                  type="date"
                  value={serviceEstimatedDeliveryDate}
                  onChange={(e) => setServiceEstimatedDeliveryDate(e.target.value)}
                  required
                  className="w-full px-4 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-sm font-medium shadow-sm"
                />
              </div>
            </div>
          </div>

          {/* Table A: Service Expenses */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm bg-white">
            <div className="bg-slate-50 border-b border-slate-200 px-6 py-4 flex justify-between items-center">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t('serviceBill.table_a_title')}</h3>
              <button
                type="button"
                onClick={() => {
                  setServiceExpenses(prev => [
                    ...prev,
                    {
                      id: Math.random().toString(36).substring(7),
                      description: '',
                      amount: 0,
                      accountId: '',
                      accountName: ''
                    }
                  ]);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg text-xs font-semibold transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                {t('serviceBill.add_expense_row')}
              </button>
            </div>

            {serviceExpenses.length === 0 ? (
              <div className="p-6 text-center text-slate-400 text-xs font-medium bg-slate-50/50"> No services or labor lines added yet.</div>
            ) : (
              <div className="p-4 space-y-3">
                {serviceExpenses.map((row, idx) => (
                  <div key={row.id} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center bg-slate-50/75 p-3 rounded-xl border border-slate-100">
                    <div className="md:col-span-5">
                      <label className="block md:hidden text-[10px] text-slate-400 mb-1">Description</label>
                      <input 
                        type="text"
                        value={row.description}
                        onChange={(e) => {
                          const val = e.target.value;
                          setServiceExpenses(p => p.map(r => r.id === row.id ? { ...r, description: val } : r));
                        }}
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 text-slate-800 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500"
                        placeholder="Labor / Technician Fees"
                      />
                    </div>
                    <div className="md:col-span-4">
                      <label className="block md:hidden text-[10px] text-slate-400 mb-1">Debit Account</label>
                      <AccountDropdown
                        accounts={accounts}
                        selectedAccountId={row.accountId}
                        onAccountChange={(accId) => {
                          const accName = accounts.find(a => a.id === accId)?.name || '';
                          setServiceExpenses(p => p.map(r => r.id === row.id ? { ...r, accountId: accId, accountName: accName } : r));
                        }}
                        accountTypeFilter={['Expense', 'Asset']}
                        placeholder="Select Expense Account"
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 text-slate-800 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500 text-right"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block md:hidden text-[10px] text-slate-400 mb-1">Amount</label>
                      <input 
                        type="number"
                        min="0"
                        value={row.amount || ''}
                        onChange={(e) => {
                          const amt = Number(e.target.value);
                          setServiceExpenses(p => p.map(r => r.id === row.id ? { ...r, amount: amt } : r));
                        }}
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 text-slate-800 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500"
                        placeholder="Cost"
                      />
                    </div>
                    <div className="md:col-span-1 text-center">
                      <button
                        type="button"
                        onClick={() => setServiceExpenses(prev => prev.filter(r => r.id !== row.id))}
                        className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Table B: Consumed Inventory Items */}
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm bg-white">
            <div className="bg-slate-50 border-b border-slate-200 px-6 py-4 flex justify-between items-center">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">{t('serviceBill.table_b_title')}</h3>
              <button
                type="button"
                onClick={() => {
                  setConsumedItems(prev => [
                    ...prev,
                    {
                      id: Math.random().toString(36).substring(7),
                      itemId: '',
                      name: '',
                      sku: '',
                      quantity: 1,
                      rate: 0,
                      amount: 0
                    }
                  ]);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg text-xs font-semibold transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                {t('serviceBill.add_item_row')}
              </button>
            </div>

            {consumedItems.length === 0 ? (
              <div className="p-6 text-center text-slate-400 text-xs font-medium bg-slate-50/50"> No parts or stock materials consumed yet.</div>
            ) : (
              <div className="p-4 space-y-3">
                {consumedItems.map((row, idx) => {
                  const mappedItem = items.find(it => it.id === row.itemId);
                  const maxStock = mappedItem?.stockOnHand ?? 0;
                  return (
                    <div key={row.id} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center bg-slate-50/75 p-3 rounded-xl border border-slate-100">
                      <div className="md:col-span-4">
                        <label className="block md:hidden text-[10px] text-slate-400 mb-1">Inventory Item</label>
                        <select
                          value={row.itemId}
                          onChange={(e) => {
                            const itemId = e.target.value;
                            const itemObj = items.find(it => it.id === itemId);
                            setConsumedItems(p => p.map(r => {
                              if (r.id !== row.id) return r;
                              return {
                                ...r,
                                itemId,
                                name: itemObj?.name || '',
                                sku: itemObj?.sku || '',
                                rate: itemObj?.purchasePrice || 0,
                                amount: (itemObj?.purchasePrice || 0) * (r.quantity ?? 1)
                              };
                            }));
                          }}
                          className="w-full px-3 py-1.5 bg-white border border-slate-200 text-slate-800 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500"
                        >
                          <option value="">Select Item</option>
                          {items.filter(it => it.type === 'Product').map(it => (
                            <option key={it.id} value={it.id}>({it.sku}) {it.name}</option>
                          ))}
                        </select>
                        {mappedItem && (
                          <span className={cn(
                            "text-[10px] font-semibold mt-1 block px-1.5 py-0.5 rounded-sm w-fit",
                            maxStock <= 0 ? "bg-rose-50 text-rose-600" : "bg-emerald-50 text-emerald-700"
                          )}>
                            Stock Level: {maxStock} units
                          </span>
                        )}
                      </div>
                      <div className="md:col-span-2">
                        <label className="block md:hidden text-[10px] text-slate-400 mb-1">Quantity</label>
                        <input 
                          type="number"
                          min="1"
                          max={maxStock > 0 ? maxStock : undefined}
                          value={row.quantity || ''}
                          onChange={(e) => {
                            const qty = Math.max(1, Number(e.target.value));
                            setConsumedItems(p => p.map(r => r.id === row.id ? { ...r, quantity: qty, amount: r.rate * qty } : r));
                          }}
                          className="w-full px-3 py-1.5 bg-white border border-slate-200 text-slate-800 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500"
                          placeholder="Qty"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="block md:hidden text-[10px] text-slate-400 mb-1">Cost Rate</label>
                        <input 
                          type="number"
                          min="0"
                          value={row.rate || ''}
                          onChange={(e) => {
                            const rate = Number(e.target.value);
                            setConsumedItems(p => p.map(r => r.id === row.id ? { ...r, rate, amount: rate * r.quantity } : r));
                          }}
                          className="w-full px-3 py-1.5 bg-white border border-slate-200 text-slate-800 rounded-lg text-xs focus:ring-1 focus:ring-indigo-500"
                        />
                      </div>
                      <div className="md:col-span-3 text-right pr-4 font-semibold text-slate-700 text-xs">
                        <label className="block md:hidden text-[10px] text-slate-400 text-left mb-1">Total</label>
                        {formatCurrency(row.amount || 0)}
                      </div>
                      <div className="md:col-span-1 text-center">
                        <button
                          type="button"
                          onClick={() => setConsumedItems(prev => prev.filter(r => r.id !== row.id))}
                          className="p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Aggregates Cards Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-5 rounded-2xl border border-slate-100">
            <div className="p-4 bg-white rounded-xl border border-slate-100 shadow-sm">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-1">Technical Labor Subtotal</span>
              <span className="text-sm font-bold text-slate-800">
                {formatCurrency(serviceExpenses.reduce((sum, r) => sum + Number(r.amount || 0), 0))}
              </span>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-100 shadow-sm">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest block mb-1">Inventory Material Subtotal</span>
              <span className="text-sm font-bold text-slate-800">
                {formatCurrency(consumedItems.reduce((sum, r) => sum + Number(row => r.amount || 0), 0) || consumedItems.reduce((sum, r) => sum + (r.quantity * r.rate), 0))}
              </span>
            </div>
            <div className="p-4 bg-indigo-600 rounded-xl shadow-md text-white">
              <span className="text-[10px] text-indigo-200 font-bold uppercase tracking-widest block mb-1">Grand Unified Total</span>
              <span className="text-lg font-black">
                {formatCurrency(
                  serviceExpenses.reduce((sum, r) => sum + Number(r.amount || 0), 0) +
                  consumedItems.reduce((sum, r) => sum + (r.quantity * r.rate), 0)
                )}
              </span>
            </div>
          </div>

          {/* Save panel footer triggers */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => {
                setIsServiceModalOpen(false);
                setEditingBill(null);
              }}
              className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors font-semibold text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors font-semibold shadow-sm flex items-center gap-2 text-xs cursor-pointer"
            >
              {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
              {isSaving ? 'Processing...' : t('serviceBill.save_confirm')}
            </button>
          </div>
        </form>
      </Modal>

      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        moduleId="bills"
        existingRecords={bills}
        onImportSuccess={(cnt) => {
          setIsImportModalOpen(false);
        }}
      />

      {/* RECORD VENDOR PAYMENT MODAL */}
      <Modal
        isOpen={isPaymentModalOpen}
        onClose={() => {
          setIsPaymentModalOpen(false);
          setPaymentBill(null);
        }}
        title="Record Vendor Payment / تسجيل عملية السداد للكل"
      >
        <form onSubmit={handleRecordPaymentSubmit} className="space-y-4">
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl">
            <p className="text-xs text-emerald-800 font-bold leading-relaxed">
              عملية سداد المورد (Pay Bill Action Gateway):
            </p>
            <p className="text-xs text-slate-700 mt-1">
              Executing this will validate the liability and post an unalterable payment journal entry in the General Ledger: <strong>Debit [Accounts Payable]</strong> and <strong>Credit [Bank/Cash Account]</strong>.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Bill Reference / مرجع الفاتورة
            </label>
            <input
              type="text"
              value={paymentBill ? `#${paymentBill.number} - Vendor: ${paymentBill.vendorName}` : ''}
              disabled
              className="w-full px-3 py-2 bg-slate-100 border border-slate-200 text-slate-600 rounded-lg text-sm font-medium"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Payment Amount / مبلغ السداد ({paymentBill?.currency || settings?.currency || 'YER'})
              </label>
              <input
                type="number"
                step="0.01"
                required
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(Number(e.target.value))}
                className="w-full px-3 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg text-sm focus:ring-1 focus:ring-emerald-500 font-semibold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Payment Date / تاريخ الدفع
              </label>
              <input
                type="date"
                required
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg text-sm focus:ring-1 focus:ring-emerald-500 font-semibold"
              />
            </div>
          </div>

          {/* محرك تسوية فروق أسعار الصرف التلقائي والتشغيلي للمشتريات */}
          {paymentBill && (paymentBill as any).currency !== settings?.currency && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
              <div>
                <label className="block text-xs font-black text-indigo-900 uppercase tracking-widest mb-1">
                  Settlement Rate / سعر التسوية
                </label>
                <input
                  type="number"
                  required
                  min="0.000001"
                  step="0.000001"
                  value={paymentSettlementRate}
                  onChange={(e) => setPaymentSettlementRate(parseFloat(e.target.value) || 1.0)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-800 outline-none focus:ring-1 focus:ring-emerald-500 font-bold"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  Original Bill Rate: 1 {(paymentBill as any).currency} = {((paymentBill as any).exchangeRate || 1.0).toFixed(4)} {settings?.currency}
                </span>
              </div>
              <div className="flex flex-col justify-center">
                <span className="text-xs font-bold text-indigo-700 block">
                  ✨ FOREX Realized Drift / فارق الصرف:
                </span>
                {(() => {
                  const origRate = Number((paymentBill as any).exchangeRate) || 1.0;
                  const settRate = Number(paymentSettlementRate) || 1.0;
                  const baseValueOriginal = paymentAmount / origRate;
                  const baseValueSettlement = paymentAmount / settRate;
                  // For AP Vendor payments: settlement < original is an Exchange Gain (credit/negative).
                  // settlement > original is an Exchange Loss (debit/positive).
                  const correction = baseValueSettlement - baseValueOriginal;
                  return (
                    <span className="text-sm font-mono font-black mt-1 text-indigo-600">
                      {correction > 0 
                        ? `Realized Loss / خسارة فروق: +${correction.toFixed(2)} ${settings?.currency}`
                        : correction < 0 
                          ? `Realized Gain / أرباح فروق: ${correction.toFixed(2)} ${settings?.currency}`
                          : `Perfect Alignment / تطابق تام (0.00)`}
                    </span>
                  );
                })()}
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Reference Code/Check # / مرجع المعاملة
            </label>
            <input
              type="text"
              placeholder="e.g. Check #1042-Kuraimi, bank draft, etc."
              value={paymentReference}
              onChange={(e) => setPaymentReference(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg text-sm focus:ring-1 focus:ring-emerald-500 font-medium"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => {
                setIsPaymentModalOpen(false);
                setPaymentBill(null);
              }}
              className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-bold transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isRecordingPayment}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm transition-all flex items-center gap-2 cursor-pointer"
            >
              {isRecordingPayment && <Loader2 className="w-4 h-4 animate-spin" />}
              {isRecordingPayment ? 'Posting Pay entry...' : 'Confirm Vendor Payout (اعتماد السداد)'}
            </button>
          </div>
        </form>
      </Modal>

      {/* CREATE PURCHASE RETURN / DEBIT NOTE MODAL */}
      <Modal
        isOpen={isDebitNoteModalOpen}
        onClose={() => {
          setIsDebitNoteModalOpen(false);
          setDebitNoteBill(null);
        }}
        title="Issue Purchase Return & Debit Note / مردود مشتريات"
      >
        <form onSubmit={handleCreateDebitNoteSubmit} className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl">
            <p className="text-xs text-amber-900 font-extrabold leading-relaxed">
              إدخال مردود المبيعات وعكس حركة المخازن/المصاريف (Purchase Return Module):
            </p>
            <p className="text-xs text-slate-700 mt-1">
              Submitting this will issue an <strong>unalterable Debit Note</strong> and automatically generate a balanced reversal transaction in the General Ledger: <strong>Debit [Accounts Payable]</strong> and <strong>Credit [Expense/COGS Account]</strong>.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Original Bill Reference / فاتورة الشراء الأصلية
            </label>
            <input
              type="text"
              value={debitNoteBill ? `#${debitNoteBill.number} - Vendor: ${debitNoteBill.vendorName} - Total: $${debitNoteBill.total}` : ''}
              disabled
              className="w-full px-3 py-2 bg-slate-100 border border-slate-200 text-slate-600 rounded-lg text-sm font-medium"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Return Amount / قيمة المردود المالي ($)
              </label>
              <input
                type="number"
                step="0.01"
                required
                max={debitNoteBill?.total}
                value={debitNoteAmount}
                onChange={(e) => setDebitNoteAmount(Number(e.target.value))}
                className="w-full px-3 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg text-sm focus:ring-1 focus:ring-amber-500 font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Return Date / تاريخ المردود
              </label>
              <input
                type="date"
                required
                value={debitNoteDate}
                onChange={(e) => setDebitNoteDate(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg text-sm focus:ring-1 focus:ring-amber-500 font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Reason for Return / سبب مردود المشتريات
            </label>
            <textarea
              required
              rows={3}
              value={debitNoteReason}
              onChange={(e) => setDebitNoteReason(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-200 text-slate-800 rounded-lg text-xs focus:ring-1 focus:ring-amber-500 font-medium"
              placeholder="Specify the reason (e.g., defective items, price correction)..."
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={() => {
                setIsDebitNoteModalOpen(false);
                setDebitNoteBill(null);
              }}
              className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-bold transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isCreatingDebitNote}
              className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-extrabold shadow-sm transition-all flex items-center gap-2 cursor-pointer"
            >
              {isCreatingDebitNote && <Loader2 className="w-4 h-4 animate-spin" />}
              {isCreatingDebitNote ? 'Posting Return...' : 'Post Immutable Debit Note (اعتماد المردود)'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
