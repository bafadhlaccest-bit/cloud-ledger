/**
 * Expenses — المصروفات اليومية
 * موجود في زوهو/زيرو: تسجيل سريع للمصروفات مع إيصالات
 */
import React, { useState, useEffect } from 'react';
import { Plus, Receipt, Search, RefreshCw, X, Upload, Camera } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useRBAC } from '../hooks/useRBAC';

const CATEGORIES = [
  'إيجار', 'كهرباء ومياه', 'اتصالات وإنترنت', 'رواتب',
  'مواصلات', 'أدوات مكتبية', 'صيانة', 'تسويق وإعلان',
  'تأمين', 'ضرائب ورسوم', 'وجبات واستضافة', 'أخرى',
];

const PAYMENT_METHODS = ['نقداً', 'بطاقة ائتمان', 'تحويل بنكي', 'شيك'];

export default function Expenses() {
  const { companyId } = useRBAC();
  const [expenses, setExpenses] = useState<any[]>([]);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10), category: 'أخرى',
    description: '', amount: '', tax_amount: '0',
    payment_method: 'نقداً', account_id: '', reference: '', notes: '',
  });

  useEffect(() => { if (companyId) load(); }, [companyId]);

  async function load() {
    setIsLoading(true);
    const [{ data: e }, { data: a }] = await Promise.all([
      supabase.from('expenses').select('*').eq('company_id', companyId).order('date', { ascending: false }),
      supabase.from('accounts').select('id,code,name').eq('company_id', companyId).in('type', ['ASSET', 'Asset']).limit(50),
    ]);
    setExpenses(e || []);
    setAccounts(a || []);
    setIsLoading(false);
  }

  const handleSubmit = async () => {
    if (!form.description || !form.amount) return;
    setIsSubmitting(true);
    await supabase.from('expenses').insert({
      company_id: companyId,
      date: form.date, category: form.category,
      description: form.description,
      amount: parseFloat(form.amount),
      tax_amount: parseFloat(form.tax_amount) || 0,
      total: parseFloat(form.amount) + parseFloat(form.tax_amount || '0'),
      payment_method: form.payment_method,
      account_id: form.account_id || null,
      reference: form.reference, notes: form.notes,
      status: 'Approved',
    });
    setShowForm(false);
    setForm({ date: new Date().toISOString().slice(0, 10), category: 'أخرى', description: '', amount: '', tax_amount: '0', payment_method: 'نقداً', account_id: '', reference: '', notes: '' });
    load();
    setIsSubmitting(false);
  };

  const totalThisMonth = expenses
    .filter(e => e.date?.startsWith(new Date().toISOString().slice(0, 7)))
    .reduce((s, e) => s + Number(e.total || 0), 0);

  const fmt = (n: number) => n.toLocaleString('ar-SA', { minimumFractionDigits: 2 });

  const filtered = expenses.filter(e =>
    !search || e.description?.includes(search) || e.category?.includes(search)
  );

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-rose-600 rounded-xl flex items-center justify-center">
            <Receipt className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">المصروفات</h1>
            <p className="text-slate-500 text-sm">هذا الشهر: {fmt(totalThisMonth)} ريال</p>
          </div>
        </div>
        <button onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-colors">
          <Plus className="w-4 h-4" /> مصروف جديد
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'هذا الشهر', value: fmt(totalThisMonth), color: 'rose' },
          { label: 'إجمالي المصروفات', value: fmt(expenses.reduce((s, e) => s + Number(e.total || 0), 0)), color: 'slate' },
          { label: 'عدد السجلات', value: String(expenses.length), color: 'indigo' },
        ].map(c => (
          <div key={c.label} className={`p-4 bg-white rounded-2xl border border-slate-200 shadow-sm`}>
            <div className="text-xs text-slate-500 mb-1">{c.label}</div>
            <div className={`text-xl font-bold text-${c.color}-600`}>{c.value}</div>
          </div>
        ))}
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث في المصروفات..."
          className="w-full pr-10 pl-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-rose-500 text-sm" />
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {['التاريخ', 'الوصف', 'الفئة', 'طريقة الدفع', 'المبلغ', 'الضريبة', 'الإجمالي'].map(h => (
                <th key={h} className="text-right px-4 py-3 text-xs font-bold text-slate-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {isLoading ? (
              <tr><td colSpan={7} className="text-center py-12"><RefreshCw className="w-5 h-5 animate-spin mx-auto text-slate-400" /></td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-12 text-slate-400">لا توجد مصروفات مسجلة</td></tr>
            ) : filtered.map(e => (
              <tr key={e.id} className="hover:bg-slate-50">
                <td className="px-4 py-2.5 text-slate-500 font-mono text-xs">{e.date}</td>
                <td className="px-4 py-2.5 font-medium text-slate-800">{e.description}</td>
                <td className="px-4 py-2.5">
                  <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">{e.category}</span>
                </td>
                <td className="px-4 py-2.5 text-slate-500 text-xs">{e.payment_method}</td>
                <td className="px-4 py-2.5 text-slate-700">{fmt(Number(e.amount))}</td>
                <td className="px-4 py-2.5 text-amber-600 text-xs">{fmt(Number(e.tax_amount || 0))}</td>
                <td className="px-4 py-2.5 font-bold text-rose-600">{fmt(Number(e.total))}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg">
            <div className="flex items-center justify-between px-6 py-4 border-b">
              <h2 className="font-bold">مصروف جديد</h2>
              <button onClick={() => setShowForm(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">التاريخ</label>
                  <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-rose-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">الفئة</label>
                  <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-rose-500 bg-white">
                    {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">الوصف *</label>
                <input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  placeholder="مثال: فاتورة الكهرباء — يناير 2025"
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-rose-500" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">المبلغ *</label>
                  <input type="number" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
                    placeholder="0.00"
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-rose-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">ضريبة القيمة المضافة</label>
                  <input type="number" value={form.tax_amount} onChange={e => setForm(f => ({ ...f, tax_amount: e.target.value }))}
                    placeholder="0.00"
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-rose-500" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">طريقة الدفع</label>
                  <select value={form.payment_method} onChange={e => setForm(f => ({ ...f, payment_method: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-rose-500 bg-white">
                    {PAYMENT_METHODS.map(m => <option key={m}>{m}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">الحساب البنكي</label>
                  <select value={form.account_id} onChange={e => setForm(f => ({ ...f, account_id: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-rose-500 bg-white">
                    <option value="">اختر الحساب</option>
                    {accounts.map(a => <option key={a.id} value={a.id}>{a.code} — {a.name}</option>)}
                  </select>
                </div>
              </div>
              <div className="bg-rose-50 rounded-xl p-3 flex justify-between text-sm font-bold">
                <span className="text-slate-600">الإجمالي</span>
                <span className="text-rose-600">
                  {((parseFloat(form.amount) || 0) + (parseFloat(form.tax_amount) || 0)).toLocaleString('ar-SA', { minimumFractionDigits: 2 })} ريال
                </span>
              </div>
            </div>
            <div className="flex gap-3 px-6 py-4 border-t">
              <button onClick={() => setShowForm(false)} className="flex-1 border border-slate-200 rounded-xl py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-50">إلغاء</button>
              <button onClick={handleSubmit} disabled={isSubmitting || !form.description || !form.amount}
                className="flex-1 bg-rose-600 text-white rounded-xl py-2.5 text-sm font-semibold disabled:opacity-60 hover:bg-rose-700">
                {isSubmitting ? 'حفظ...' : 'تسجيل المصروف'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
