/**
 * VATReport — تقرير ضريبة القيمة المضافة
 * موجود في زوهو/زيرو: مهم جداً للسوق السعودي والخليجي
 */
import React, { useState } from 'react';
import { RefreshCw, Download, CheckCircle2, AlertCircle, FileSpreadsheet } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useRBAC } from '../hooks/useRBAC';
import * as XLSX from 'xlsx';

interface VATData {
  // Output VAT (from sales)
  salesBase: number; salesVAT: number;
  creditNotesBase: number; creditNotesVAT: number;
  netSalesBase: number; netOutputVAT: number;
  // Input VAT (from purchases)
  purchasesBase: number; purchasesVAT: number;
  expensesBase: number; expensesVAT: number;
  netPurchasesBase: number; netInputVAT: number;
  // Net VAT
  vatPayable: number;
  vatRefundable: number;
}

const PERIODS = [
  { label: 'هذا الشهر', value: 'this_month' },
  { label: 'الشهر الماضي', value: 'last_month' },
  { label: 'هذا الربع', value: 'this_quarter' },
  { label: 'الربع الماضي', value: 'last_quarter' },
  { label: 'هذه السنة', value: 'this_year' },
  { label: 'فترة مخصصة', value: 'custom' },
];

function getPeriodDates(period: string): { from: string; to: string } {
  const now = new Date();
  const y = now.getFullYear(), m = now.getMonth();
  switch (period) {
    case 'this_month':   return { from: new Date(y, m, 1).toISOString().slice(0,10), to: now.toISOString().slice(0,10) };
    case 'last_month':   return { from: new Date(y, m-1, 1).toISOString().slice(0,10), to: new Date(y, m, 0).toISOString().slice(0,10) };
    case 'this_quarter': { const q = Math.floor(m/3); return { from: new Date(y, q*3, 1).toISOString().slice(0,10), to: now.toISOString().slice(0,10) }; }
    case 'last_quarter': { const q = Math.floor(m/3)-1; const qy = q < 0 ? y-1 : y; const qi = ((q+4)%4); return { from: new Date(qy, qi*3, 1).toISOString().slice(0,10), to: new Date(qy, qi*3+3, 0).toISOString().slice(0,10) }; }
    case 'this_year':    return { from: `${y}-01-01`, to: now.toISOString().slice(0,10) };
    default:             return { from: new Date(y, m, 1).toISOString().slice(0,10), to: now.toISOString().slice(0,10) };
  }
}

export default function VATReport() {
  const { companyId } = useRBAC();
  const [period, setPeriod] = useState('this_quarter');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState<VATData | null>(null);
  const [error, setError] = useState('');

  const dates = period === 'custom'
    ? { from: customFrom, to: customTo }
    : getPeriodDates(period);

  const loadReport = async () => {
    if (!dates.from || !dates.to) return;
    setIsLoading(true); setError('');
    try {
      const [{ data: invoices }, { data: bills }, { data: expenses }] = await Promise.all([
        supabase.from('invoices').select('subtotal,tax_total,status,date')
          .eq('company_id', companyId)
          .gte('date', dates.from).lte('date', dates.to)
          .in('status', ['Paid', 'Sent', 'Posted']),
        supabase.from('bills').select('subtotal,tax_total,status,date')
          .eq('company_id', companyId)
          .gte('date', dates.from).lte('date', dates.to)
          .neq('status', 'Cancelled'),
        supabase.from('expenses').select('amount,tax_amount,date')
          .eq('company_id', companyId)
          .gte('date', dates.from).lte('date', dates.to),
      ]);

      const inv = invoices || [], bl = bills || [], exp = expenses || [];

      const salesBase = inv.reduce((s, i) => s + Number(i.subtotal||0), 0);
      const salesVAT  = inv.reduce((s, i) => s + Number(i.tax_total||0), 0);
      const purchasesBase = bl.reduce((s, b) => s + Number(b.subtotal||0), 0);
      const purchasesVAT  = bl.reduce((s, b) => s + Number(b.tax_total||0), 0);
      const expensesBase  = exp.reduce((s, e) => s + Number(e.amount||0), 0);
      const expensesVAT   = exp.reduce((s, e) => s + Number(e.tax_amount||0), 0);

      const netOutputVAT = salesVAT;
      const netInputVAT  = purchasesVAT + expensesVAT;
      const netVAT       = netOutputVAT - netInputVAT;

      setData({
        salesBase, salesVAT,
        creditNotesBase: 0, creditNotesVAT: 0,
        netSalesBase: salesBase, netOutputVAT,
        purchasesBase, purchasesVAT,
        expensesBase, expensesVAT,
        netPurchasesBase: purchasesBase + expensesBase, netInputVAT,
        vatPayable: Math.max(0, netVAT),
        vatRefundable: Math.max(0, -netVAT),
      });
    } catch (err: any) { setError(err.message); }
    setIsLoading(false);
  };

  const exportExcel = () => {
    if (!data) return;
    const fmt = (n: number) => n.toFixed(2);
    const rows = [
      { البيان: '=== ضريبة المخرجات (المبيعات) ===', الوعاء: '', الضريبة: '' },
      { البيان: 'إيرادات المبيعات', الوعاء: fmt(data.salesBase), الضريبة: fmt(data.salesVAT) },
      { البيان: 'إجمالي ضريبة المخرجات', الوعاء: fmt(data.netSalesBase), الضريبة: fmt(data.netOutputVAT) },
      { البيان: '', الوعاء: '', الضريبة: '' },
      { البيان: '=== ضريبة المدخلات (المشتريات) ===', الوعاء: '', الضريبة: '' },
      { البيان: 'المشتريات', الوعاء: fmt(data.purchasesBase), الضريبة: fmt(data.purchasesVAT) },
      { البيان: 'المصروفات', الوعاء: fmt(data.expensesBase), الضريبة: fmt(data.expensesVAT) },
      { البيان: 'إجمالي ضريبة المدخلات', الوعاء: fmt(data.netPurchasesBase), الضريبة: fmt(data.netInputVAT) },
      { البيان: '', الوعاء: '', الضريبة: '' },
      { البيان: 'صافي الضريبة المستحقة', الوعاء: '', الضريبة: fmt(data.vatPayable) },
      { البيان: 'ضريبة قابلة للاسترداد', الوعاء: '', الضريبة: fmt(data.vatRefundable) },
    ];
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'تقرير ضريبة القيمة المضافة');
    XLSX.writeFile(wb, `VAT_Report_${dates.from}_${dates.to}.xlsx`);
  };

  const fmt = (n: number) => n.toLocaleString('ar-SA', { minimumFractionDigits: 2 });

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-teal-600 rounded-xl flex items-center justify-center">
            <FileSpreadsheet className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">تقرير ضريبة القيمة المضافة</h1>
            <p className="text-slate-500 text-sm">متوافق مع متطلبات هيئة الزكاة والضريبة والجمارك</p>
          </div>
        </div>
        {data && (
          <button onClick={exportExcel}
            className="flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-colors">
            <Download className="w-4 h-4" /> تصدير Excel
          </button>
        )}
      </div>

      {/* Period Selector */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
        <div className="flex flex-wrap gap-2 mb-4">
          {PERIODS.map(p => (
            <button key={p.value} onClick={() => setPeriod(p.value)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${period === p.value ? 'bg-teal-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
              {p.label}
            </button>
          ))}
        </div>
        {period === 'custom' && (
          <div className="flex items-center gap-3 mb-4">
            <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-teal-500" />
            <span className="text-slate-400">إلى</span>
            <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-teal-500" />
          </div>
        )}
        <div className="flex items-center gap-3">
          <span className="text-sm text-slate-500">{dates.from} — {dates.to}</span>
          <button onClick={loadReport} disabled={isLoading}
            className="flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors disabled:opacity-60">
            {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            إنشاء التقرير
          </button>
        </div>
      </div>

      {error && <div className="p-3 bg-red-50 text-red-600 rounded-xl text-sm flex items-center gap-2"><AlertCircle className="w-4 h-4" />{error}</div>}

      {data && (
        <div className="space-y-4">
          {/* Net VAT Banner */}
          <div className={`p-5 rounded-2xl text-white ${data.vatPayable > 0 ? 'bg-orange-600' : 'bg-emerald-600'}`}>
            <div className="text-sm opacity-80 mb-1">
              {data.vatPayable > 0 ? '⚠️ ضريبة مستحقة للدفع' : '✅ ضريبة قابلة للاسترداد'}
            </div>
            <div className="text-3xl font-extrabold">
              {fmt(data.vatPayable > 0 ? data.vatPayable : data.vatRefundable)} ريال
            </div>
            <div className="text-sm opacity-70 mt-1">
              ضريبة المخرجات: {fmt(data.netOutputVAT)} — ضريبة المدخلات: {fmt(data.netInputVAT)}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Output VAT */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="bg-blue-600 text-white px-4 py-3 font-bold text-sm">ضريبة المخرجات (المبيعات)</div>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="text-right px-4 py-2 text-xs text-slate-500">البيان</th>
                    <th className="text-right px-4 py-2 text-xs text-slate-500">الوعاء الضريبي</th>
                    <th className="text-right px-4 py-2 text-xs text-slate-500">الضريبة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 text-slate-700">المبيعات الخاضعة للضريبة</td>
                    <td className="px-4 py-3 text-right font-mono">{fmt(data.salesBase)}</td>
                    <td className="px-4 py-3 text-right font-mono text-blue-700">{fmt(data.salesVAT)}</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 text-slate-700">مردودات وإشعارات دائنة</td>
                    <td className="px-4 py-3 text-right font-mono text-red-500">({fmt(data.creditNotesBase)})</td>
                    <td className="px-4 py-3 text-right font-mono text-red-500">({fmt(data.creditNotesVAT)})</td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr className="bg-blue-50 font-bold">
                    <td className="px-4 py-3 text-blue-800">الإجمالي</td>
                    <td className="px-4 py-3 text-right font-mono text-blue-800">{fmt(data.netSalesBase)}</td>
                    <td className="px-4 py-3 text-right font-mono text-blue-800">{fmt(data.netOutputVAT)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Input VAT */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="bg-emerald-600 text-white px-4 py-3 font-bold text-sm">ضريبة المدخلات (المشتريات)</div>
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200">
                    <th className="text-right px-4 py-2 text-xs text-slate-500">البيان</th>
                    <th className="text-right px-4 py-2 text-xs text-slate-500">الوعاء الضريبي</th>
                    <th className="text-right px-4 py-2 text-xs text-slate-500">الضريبة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 text-slate-700">المشتريات الخاضعة للضريبة</td>
                    <td className="px-4 py-3 text-right font-mono">{fmt(data.purchasesBase)}</td>
                    <td className="px-4 py-3 text-right font-mono text-emerald-700">{fmt(data.purchasesVAT)}</td>
                  </tr>
                  <tr className="hover:bg-slate-50">
                    <td className="px-4 py-3 text-slate-700">المصروفات الخاضعة للضريبة</td>
                    <td className="px-4 py-3 text-right font-mono">{fmt(data.expensesBase)}</td>
                    <td className="px-4 py-3 text-right font-mono text-emerald-700">{fmt(data.expensesVAT)}</td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr className="bg-emerald-50 font-bold">
                    <td className="px-4 py-3 text-emerald-800">الإجمالي</td>
                    <td className="px-4 py-3 text-right font-mono text-emerald-800">{fmt(data.netPurchasesBase)}</td>
                    <td className="px-4 py-3 text-right font-mono text-emerald-800">{fmt(data.netInputVAT)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
