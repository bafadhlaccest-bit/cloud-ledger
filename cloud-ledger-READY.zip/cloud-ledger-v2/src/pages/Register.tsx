import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { FileText, Loader2, CheckCircle2, Building2, Globe, DollarSign } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/useAuthStore';

const CURRENCIES = [
  { code: 'SAR', name: 'ريال سعودي' }, { code: 'AED', name: 'درهم إماراتي' },
  { code: 'USD', name: 'دولار أمريكي' }, { code: 'EGP', name: 'جنيه مصري' },
  { code: 'KWD', name: 'دينار كويتي' }, { code: 'QAR', name: 'ريال قطري' },
  { code: 'BHD', name: 'دينار بحريني' }, { code: 'OMR', name: 'ريال عُماني' },
  { code: 'YER', name: 'ريال يمني' }, { code: 'JOD', name: 'دينار أردني' },
];

export default function Register() {
  const navigate = useNavigate();
  const login = useAuthStore(s => s.login);
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const [form, setForm] = useState({
    companyName: '', industry: '', email: '',
    password: '', confirmPassword: '',
    currency: 'SAR', fiscalYearStart: new Date().getFullYear() + '-01-01',
    vatNumber: '', phone: '',
  });

  const set = (k: string, v: string) => setForm(p => ({ ...p, [k]: v }));

  const handleStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) { setError('كلمة المرور غير متطابقة'); return; }
    if (form.password.length < 8) { setError('كلمة المرور يجب أن تكون 8 أحرف على الأقل'); return; }
    setError(''); setStep(2);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true); setError('');
    try {
      // Register via server API
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: form.email, password: form.password,
          companyName: form.companyName, currency: form.currency,
          fiscalYearStart: form.fiscalYearStart,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل التسجيل');

      // Sign in immediately
      const { data: authData, error: signInErr } = await supabase.auth.signInWithPassword({
        email: form.email, password: form.password,
      });
      if (signInErr) throw signInErr;

      login(
        { id: authData.user!.id, name: form.companyName, email: form.email, role: 'admin' },
        authData.session!.access_token
      );
      navigate('/onboarding');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-lg">
        {/* Logo */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <span className="text-white text-xl font-bold">Cloud Ledger</span>
        </div>

        <div className="bg-white rounded-2xl shadow-2xl p-8">
          {/* Steps indicator */}
          <div className="flex items-center gap-2 mb-6">
            {[1, 2].map(s => (
              <React.Fragment key={s}>
                <div className={`flex items-center justify-center w-8 h-8 rounded-full text-sm font-bold ${step >= s ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-400'}`}>
                  {step > s ? <CheckCircle2 className="w-4 h-4" /> : s}
                </div>
                {s < 2 && <div className={`flex-1 h-1 rounded ${step > s ? 'bg-indigo-600' : 'bg-slate-100'}`} />}
              </React.Fragment>
            ))}
          </div>

          {error && <div className="mb-4 p-3 bg-red-50 border border-red-100 text-red-600 text-sm rounded-lg">{error}</div>}

          {step === 1 && (
            <form onSubmit={handleStep1} className="space-y-4">
              <div>
                <h2 className="text-xl font-bold text-slate-800">إنشاء حساب جديد</h2>
                <p className="text-slate-500 text-sm mt-1">ابدأ تجربتك المجانية لمدة 14 يوم</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">اسم الشركة / المنشأة <span className="text-red-500">*</span></label>
                <div className="relative">
                  <Building2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input required value={form.companyName} onChange={e => set('companyName', e.target.value)}
                    className="w-full pr-10 pl-3 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-right"
                    placeholder="شركة النجاح للتجارة" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">البريد الإلكتروني <span className="text-red-500">*</span></label>
                <input required type="email" value={form.email} onChange={e => set('email', e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-right"
                  placeholder="info@company.com" dir="ltr" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">كلمة المرور <span className="text-red-500">*</span></label>
                  <input required type="password" value={form.password} onChange={e => set('password', e.target.value)}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="••••••••" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">تأكيد المرور <span className="text-red-500">*</span></label>
                  <input required type="password" value={form.confirmPassword} onChange={e => set('confirmPassword', e.target.value)}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
                    placeholder="••••••••" />
                </div>
              </div>

              <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 rounded-lg transition-colors">
                التالي ←
              </button>

              <p className="text-center text-sm text-slate-500">
                لديك حساب؟ <Link to="/login" className="text-indigo-600 font-medium hover:underline">تسجيل الدخول</Link>
              </p>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <h2 className="text-xl font-bold text-slate-800">إعداد المنشأة</h2>
                <p className="text-slate-500 text-sm mt-1">سيتم ضبط النظام وفق هذه الإعدادات</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    <DollarSign className="inline w-3.5 h-3.5 ml-1 text-slate-400" />
                    العملة الرئيسية
                  </label>
                  <select value={form.currency} onChange={e => set('currency', e.target.value)}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white">
                    {CURRENCIES.map(c => <option key={c.code} value={c.code}>{c.code} — {c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">بداية السنة المالية</label>
                  <input type="date" value={form.fiscalYearStart} onChange={e => set('fiscalYearStart', e.target.value)}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  <Globe className="inline w-3.5 h-3.5 ml-1 text-slate-400" />
                  القطاع / النشاط التجاري
                </label>
                <select value={form.industry} onChange={e => set('industry', e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 bg-white">
                  <option value="">اختر القطاع</option>
                  <option value="trade">تجارة عامة</option>
                  <option value="retail">تجزئة</option>
                  <option value="services">خدمات</option>
                  <option value="construction">مقاولات وإنشاءات</option>
                  <option value="manufacturing">تصنيع</option>
                  <option value="food">مطاعم وأغذية</option>
                  <option value="healthcare">رعاية صحية</option>
                  <option value="education">تعليم</option>
                  <option value="real_estate">عقارات</option>
                  <option value="other">أخرى</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">رقم ضريبي / سجل تجاري (اختياري)</label>
                <input value={form.vatNumber} onChange={e => set('vatNumber', e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500 text-right"
                  placeholder="300000000000003" dir="ltr" />
              </div>

              {/* Terms */}
              <p className="text-xs text-slate-400 text-center">
                بالتسجيل، أنت توافق على <a href="#" className="text-indigo-600 hover:underline">شروط الاستخدام</a> و<a href="#" className="text-indigo-600 hover:underline">سياسة الخصوصية</a>
              </p>

              <div className="flex gap-3">
                <button type="button" onClick={() => setStep(1)} className="flex-1 border border-slate-200 text-slate-600 font-semibold py-3 rounded-lg hover:bg-slate-50 transition-colors">
                  → رجوع
                </button>
                <button type="submit" disabled={isLoading} className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-70">
                  {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                  إنشاء الحساب
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Trust indicators */}
        <div className="flex items-center justify-center gap-6 mt-6 text-slate-400 text-xs">
          <span>🔒 بيانات مشفرة SSL</span>
          <span>🇸🇦 خوادم الشرق الأوسط</span>
          <span>✅ متوافق مع IFRS</span>
        </div>
      </div>
    </div>
  );
}
