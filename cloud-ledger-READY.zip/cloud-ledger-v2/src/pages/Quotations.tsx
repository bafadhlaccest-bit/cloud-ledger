/**
 * Quotations — عروض الأسعار
 * موجود في زوهو/زيرو، ناقص من النظام
 * يمكن تحويل عرض السعر لفاتورة بنقرة واحدة
 */
import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, FileText, Send, CheckCircle2, X, Search, Download, RefreshCw, ArrowRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useRBAC } from '../hooks/useRBAC';
import { useNavigate } from 'react-router-dom';

interface Quotation {
  id: string;
  number: string;
  customer_id: string;
  customer_name?: string;
  date: string;
  expiry_date: string;
  status: 'Draft' | 'Sent' | 'Accepted' | 'Rejected' | 'Expired' | 'Converted';
  subtotal: number;
  tax_total: number;
  total: number;
  notes?: string;
  currency: string;
  lines: QuotationLine[];
}

interface QuotationLine {
  id: string;
  item_id?: string;
  description: string;
  quantity: number;
  rate: number;
  tax_rate: number;
  amount: number;
}

const STATUS_STYLE: Record<string, string> = {
  Draft:     'bg-slate-100 text-slate-600',
  Sent:      'bg-blue-100 text-blue-700',
  Accepted:  'bg-emerald-100 text-emerald-700',
  Rejected:  'bg-red-100 text-red-600',
  Expired:   'bg-orange-100 text-orange-700',
  Converted: 'bg-purple-100 text-purple-700',
};

const STATUS_AR: Record<string, string> = {
  Draft: 'مسودة', Sent: 'مُرسَل', Accepted: 'مقبول',
  Rejected: 'مرفوض', Expired: 'منتهي', Converted: 'محوَّل لفاتورة',
};

export default function Quotations() {
  const { i18n } = useTranslation();
  const isRtl = i18n.language === 'ar';
  const { companyId } = useRBAC();
  const navigate = useNavigate();

  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [form, setForm] = useState({
    customer_id: '', date: new Date().toISOString().slice(0, 10),
    expiry_date: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10),
    notes: '', currency: 'SAR',
    lines: [{ description: '', quantity: 1, rate: 0, tax_rate: 15, amount: 0 }] as any[],
  });

  useEffect(() => {
    if (!companyId) return;
    load();
  }, [companyId]);

  async function load() {
    setIsLoading(true);
    const [{ data: q }, { data: c }, { data: it }] = await Promise.all([
      supabase.from('quotations').select('*').eq('company_id', companyId).order('date', { ascending: false }),
      supabase.from('customers').select('id,name').eq('company_id', companyId),
      supabase.from('items').select('id,name,sale_price,tax_rate').eq('company_id', companyId),
    ]);
    setQuotations((q || []) as Quotation[]);
    setCustomers(c || []);
    setItems(it || []);
    setIsLoading(false);
  }

  const calcLine = (line: any) => {
    const amount = line.quantity * line.rate;
    return { ...line, amount };
  };

  const subtotal = form.lines.reduce((s, l) => s + l.amount, 0);
  const taxTotal = form.lines.reduce((s, l) => s + (l.amount * (l.tax_rate || 0) / 100), 0);
  const total    = subtotal + taxTotal;

  const handleSubmit = async () => {
    if (!form.customer_id) return;
    setIsSubmitting(true);
    const cust = customers.find(c => c.id === form.customer_id);
    const num  = `QUO-${Date.now().toString().slice(-6)}`;
    const { error } = await supabase.from('quotations').insert({
      company_id: companyId, number: num,
      customer_id: form.customer_id,
      customer_name: cust?.name || '',
      date: form.date, expiry_date: form.expiry_date,
      status: 'Draft', subtotal, tax_total: taxTotal, total,
      notes: form.notes, currency: form.currency,
      lines: form.lines,
    });
    if (!error) { setShowForm(false); load(); }
    setIsSubmitting(false);
  };

  // Convert quotation → invoice
  const convertToInvoice = async (q: Quotation) => {
    if (q.status === 'Converted') return;
    const invNum = `INV-${Date.now().toString().slice(-6)}`;
    const { error } = await supabase.from('invoices').insert({
      company_id: companyId, number: invNum,
      customer_id: q.customer_id, date: new Date().toISOString().slice(0, 10),
      status: 'Draft', subtotal: q.subtotal, tax_total: q.tax_total, total: q.total,
      notes: `محوَّل من عرض سعر ${q.number}`, currency: q.currency,
      lines: q.lines,
    });
    if (!error) {
      await supabase.from('quotations').update({ status: 'Converted' }).eq('id', q.id);
      load();
    }
  };

  const filtered = quotations.filter(q =>
    !search || q.number.includes(search) || (q.customer_name || '').includes(search)
  );

  const fmt = (n: number) => n.toLocaleString('ar-SA', { minimumFractionDigits: 2 });

  return (
    <div className="space-y-6" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">عروض الأسعار</h1>
            <p className="text-slate-500 text-sm">{quotations.length} عرض سعر</p>
          </div>
        </div>
        <button onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-colors">
          <Plus className="w-4 h-4" /> عرض سعر جديد
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input value={search} onChange={e => setSearch(e.target.value)}
          placeholder="بحث برقم عرض السعر أو العميل..."
          className="w-full pr-10 pl-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-sm" />
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="text-right px-4 py-3 text-xs font-bold text-slate-500">رقم العرض</th>
              <th className="text-right px-4 py-3 text-xs font-bold text-slate-500">العميل</th>
              <th className="text-right px-4 py-3 text-xs font-bold text-slate-500">التاريخ</th>
              <th className="text-right px-4 py-3 text-xs font-bold text-slate-500">الانتهاء</th>
              <th className="text-right px-4 py-3 text-xs font-bold text-slate-500">الإجمالي</th>
              <th className="text-right px-4 py-3 text-xs font-bold text-slate-500">الحالة</th>
              <th className="text-right px-4 py-3 text-xs font-bold text-slate-500">إجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {isLoading ? (
              <tr><td colSpan={7} className="text-center py-12"><RefreshCw className="w-5 h-5 animate-spin text-slate-400 mx-auto" /></td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-12 text-slate-400">لا توجد عروض أسعار</td></tr>
            ) : filtered.map(q => (
              <tr key={q.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-3 font-mono font-medium text-indigo-600">{q.number}</td>
                <td className="px-4 py-3 font-medium text-slate-800">{q.customer_name}</td>
                <td className="px-4 py-3 text-slate-500">{q.date}</td>
                <td className="px-4 py-3 text-slate-500">{q.expiry_date}</td>
                <td className="px-4 py-3 font-bold text-slate-800">{fmt(q.total)} {q.currency}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${STATUS_STYLE[q.status]}`}>
                    {STATUS_AR[q.status]}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    {q.status !== 'Converted' && q.status !== 'Rejected' && (
                      <button onClick={() => convertToInvoice(q)} title="تحويل لفاتورة"
                        className="flex items-center gap-1 text-xs px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg transition-colors font-medium">
                        <ArrowRight className="w-3 h-3" /> فاتورة
                      </button>
                    )}
                    {q.status === 'Draft' && (
                      <button onClick={async () => {
                        await supabase.from('quotations').update({ status: 'Sent' }).eq('id', q.id);
                        load();
                      }} title="إرسال" className="p-1.5 text-blue-500 hover:bg-blue-50 rounded-lg">
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <h2 className="font-bold text-slate-900">عرض سعر جديد</h2>
              <button onClick={() => setShowForm(false)} className="p-2 hover:bg-slate-100 rounded-lg">
                <X className="w-4 h-4 text-slate-500" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">العميل *</label>
                  <select value={form.customer_id} onChange={e => setForm(f => ({ ...f, customer_id: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 bg-white">
                    <option value="">اختر العميل</option>
                    {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">العملة</label>
                  <select value={form.currency} onChange={e => setForm(f => ({ ...f, currency: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 bg-white">
                    {['SAR','AED','USD','KWD','QAR','BHD','OMR','EGP','YER'].map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">تاريخ العرض</label>
                  <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">تاريخ الانتهاء</label>
                  <input type="date" value={form.expiry_date} onChange={e => setForm(f => ({ ...f, expiry_date: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>

              {/* Lines */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold text-slate-600">البنود</label>
                  <button onClick={() => setForm(f => ({ ...f, lines: [...f.lines, { description: '', quantity: 1, rate: 0, tax_rate: 15, amount: 0 }] }))}
                    className="text-xs text-indigo-600 font-medium hover:underline flex items-center gap-1">
                    <Plus className="w-3 h-3" /> إضافة بند
                  </button>
                </div>
                <div className="space-y-2">
                  {form.lines.map((line, i) => (
                    <div key={i} className="grid grid-cols-12 gap-2 items-center">
                      <input value={line.description} onChange={e => {
                        const lines = [...form.lines]; lines[i] = calcLine({ ...lines[i], description: e.target.value }); setForm(f => ({ ...f, lines }));
                      }} placeholder="وصف البند" className="col-span-5 px-2.5 py-2 border border-slate-200 rounded-lg text-xs outline-none focus:ring-1 focus:ring-indigo-400" />
                      <input type="number" value={line.quantity} onChange={e => {
                        const lines = [...form.lines]; lines[i] = calcLine({ ...lines[i], quantity: Number(e.target.value) }); setForm(f => ({ ...f, lines }));
                      }} placeholder="الكمية" className="col-span-2 px-2.5 py-2 border border-slate-200 rounded-lg text-xs outline-none focus:ring-1 focus:ring-indigo-400" />
                      <input type="number" value={line.rate} onChange={e => {
                        const lines = [...form.lines]; lines[i] = calcLine({ ...lines[i], rate: Number(e.target.value) }); setForm(f => ({ ...f, lines }));
                      }} placeholder="السعر" className="col-span-2 px-2.5 py-2 border border-slate-200 rounded-lg text-xs outline-none focus:ring-1 focus:ring-indigo-400" />
                      <input type="number" value={line.tax_rate} onChange={e => {
                        const lines = [...form.lines]; lines[i] = calcLine({ ...lines[i], tax_rate: Number(e.target.value) }); setForm(f => ({ ...f, lines }));
                      }} placeholder="ض%" className="col-span-2 px-2.5 py-2 border border-slate-200 rounded-lg text-xs outline-none focus:ring-1 focus:ring-indigo-400" />
                      <button onClick={() => setForm(f => ({ ...f, lines: f.lines.filter((_, j) => j !== i) }))}
                        className="col-span-1 p-1.5 text-red-400 hover:bg-red-50 rounded-lg flex items-center justify-center">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals */}
              <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-slate-500">المجموع قبل الضريبة</span><span className="font-medium">{fmt(subtotal)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">ضريبة القيمة المضافة</span><span className="font-medium">{fmt(taxTotal)}</span></div>
                <div className="flex justify-between text-base font-bold border-t border-slate-200 pt-2"><span>الإجمالي</span><span className="text-indigo-600">{fmt(total)} {form.currency}</span></div>
              </div>

              <textarea value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                placeholder="ملاحظات للعميل..." rows={2}
                className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500 resize-none" />
            </div>

            <div className="flex gap-3 px-6 py-4 border-t border-slate-200">
              <button onClick={() => setShowForm(false)} className="flex-1 border border-slate-200 text-slate-600 font-semibold py-2.5 rounded-xl hover:bg-slate-50">
                إلغاء
              </button>
              <button onClick={handleSubmit} disabled={isSubmitting || !form.customer_id}
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 rounded-xl transition-colors disabled:opacity-60">
                {isSubmitting ? 'جارٍ الحفظ...' : 'حفظ العرض'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
