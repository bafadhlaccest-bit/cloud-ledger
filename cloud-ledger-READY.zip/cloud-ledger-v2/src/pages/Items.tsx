import React from 'react';
import { ColumnDef } from '@tanstack/react-table';
import { DataTable } from '../components/DataTable';
import { Item, Invoice, Bill, Account } from '../types';
import { useRBAC } from '../hooks/useRBAC';
import { SEEDED_ITEMS, SEEDED_ACCOUNTS, getMergedItems, getMergedAccounts } from '../data/initialData';
import { formatCurrency, cn, getLocalizedName } from '../lib/utils';
import { useTranslation } from 'react-i18next';
import { 
  Plus, 
  Search, 
  Package, 
  Box, 
  Tag, 
  Loader2, 
  Edit2, 
  Trash2,
  TrendingUp,
  Activity,
  Bell,
  Scale,
  Layers,
  Clock,
  HelpCircle,
  HelpCircle as InfoIcon
} from 'lucide-react';
import Modal from '../components/Modal';
import ImportModal from '../components/ImportModal';
import { exportToExcel, exportToPDF } from '../utils/exportImport';
import { Download, UploadCloud } from 'lucide-react';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  serverTimestamp 
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';
import { db, collection, addDoc, updateDoc, deleteDoc, onSnapshot, query, where, serverTimestamp, doc } from '../firebase';

export default function Items() {
  const { t } = useTranslation();
  const { canPerform, validateRowSecurity, companyId } = useRBAC();
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = React.useState(false);
  const [isExportDropdownOpen, setIsExportDropdownOpen] = React.useState(false);
  const [items, setItems] = React.useState<Item[]>(SEEDED_ITEMS);
  const [invoices, setInvoices] = React.useState<Invoice[]>([]);
  const [bills, setBills] = React.useState<Bill[]>([]);
  const [accounts, setAccounts] = React.useState<Account[]>(SEEDED_ACCOUNTS);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSaving, setIsSaving] = React.useState(false);
  const [editingItem, setEditingItem] = React.useState<Item | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');
  
  // Custom Form tab selection
  const [formTab, setFormTab] = React.useState<'general' | 'inventory' | 'accounting'>('general');

  // Form states matching standard ERP specifications
  const [productType, setProductType] = React.useState<'Consumable' | 'Service' | 'Storable'>('Storable');
  const [invoicingPolicy, setInvoicingPolicy] = React.useState<'Ordered' | 'Delivered'>('Ordered');
  const [routesBuy, setRoutesBuy] = React.useState<boolean>(true);
  const [routesMTO, setRoutesMTO] = React.useState<boolean>(false);
  const [traceability, setTraceability] = React.useState<'Serial' | 'Lots' | 'None'>('None');
  const [weight, setWeight] = React.useState<number>(0);
  const [volume, setVolume] = React.useState<number>(0);
  const [customerLeadTime, setCustomerLeadTime] = React.useState<number>(0);
  const [incomeAccountId, setIncomeAccountId] = React.useState<string>('');
  const [expenseAccountId, setExpenseAccountId] = React.useState<string>('');
  const [priceDiffAccountId, setPriceDiffAccountId] = React.useState<string>('');

  // Reordering rules (Safety stock)
  const [minReorderingQty, setMinReorderingQty] = React.useState<number>(0);
  const [maxReorderingQty, setMaxReorderingQty] = React.useState<number>(0);
  const [reorderingEnabled, setReorderingEnabled] = React.useState<boolean>(false);

  // Sub-modal states within the form
  const [isReorderingModalOpen, setIsReorderingModalOpen] = React.useState(false);
  const [isMovesModalOpen, setIsMovesModalOpen] = React.useState(false);

  // Active company bounds

  // Subscriptions to Items, Invoices, Bills and Accounts standard collections
  React.useEffect(() => {
    const qItems = query(
      collection(db, 'items'),
      where('companyId', '==', companyId)
    );
    const qInvoices = query(
      collection(db, 'invoices'),
      where('companyId', '==', companyId)
    );
    const qBills = query(
      collection(db, 'bills'),
      where('companyId', '==', companyId)
    );
    const qAccounts = query(
      collection(db, 'accounts'),
      where('companyId', '==', companyId)
    );

    const unsubItems = onSnapshot(qItems, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Item[];
      setItems(getMergedItems(data));
      setIsLoading(false);
    }, (error) => {
      console.warn('Real-time items synchronization status (using local/fallback state):', error.message);
      setIsLoading(false);
    });

    const unsubInvoices = onSnapshot(qInvoices, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Invoice[];
      setInvoices(data);
    }, (error) => {
      console.warn('Real-time invoices synchronization status (using local/fallback state):', error.message);
    });

    const unsubBills = onSnapshot(qBills, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Bill[];
      setBills(data);
    }, (error) => {
      console.warn('Real-time bills synchronization status (using local/fallback state):', error.message);
    });

    const unsubAccounts = onSnapshot(qAccounts, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Account[];
      setAccounts(getMergedAccounts(data));
    }, (error) => {
      console.warn('Real-time standard accounts synchronization status (using local/fallback state):', error.message);
    });

    return () => {
      unsubItems();
      unsubInvoices();
      unsubBills();
      unsubAccounts();
    };
  }, [companyId]);

  // Dynamic Warehouse Stats Calculator
  const getItemInventoryData = (itemId: string, baseStockOnHand: number) => {
    if (!itemId) {
      return {
        onHand: baseStockOnHand || 0,
        incoming: 0,
        outgoing: 0,
        forecasted: baseStockOnHand || 0,
        moves: [],
      };
    }

    let totalReceived = 0;
    let totalShipped = 0;
    let pendingIncoming = 0;
    let pendingOutgoing = 0;

    const moves: {
      id: string;
      date: string;
      ref: string;
      type: 'In' | 'Out';
      partyName: string;
      quantity: number;
      rate: number;
      status: string;
    }[] = [];

    // Parse Bills (Inward Moves)
    bills.forEach((bill) => {
      if (!bill.items) return;
      const itemMatch = bill.items.find((it) => it.itemId === itemId);
      if (itemMatch) {
        const isPaidOrPartial = bill.status === 'Paid' || bill.status === 'Partially Paid';
        const qty = Number(itemMatch.quantity) || 0;
        
        if (isPaidOrPartial) {
          totalReceived += qty;
        } else {
          pendingIncoming += qty;
        }

        moves.push({
          id: `${bill.id}_${itemMatch.itemId}`,
          date: bill.date || '',
          ref: bill.number || `Bill (ID: ${bill.id.slice(0, 5)})`,
          type: 'In',
          partyName: bill.vendorName || 'Supplier',
          quantity: qty,
          rate: Number(itemMatch.rate) || 0,
          status: bill.status,
        });
      }
    });

    // Parse Invoices (Outward Moves)
    invoices.forEach((invoice) => {
      if (!invoice.items) return;
      const itemMatch = invoice.items.find((it) => it.itemId === itemId);
      if (itemMatch) {
        const isPaidOrPartial = invoice.status === 'Paid' || invoice.status === 'Partially Paid';
        const qty = Number(itemMatch.quantity) || 0;

        if (isPaidOrPartial) {
          totalShipped += qty;
        } else {
          pendingOutgoing += qty;
        }

        moves.push({
          id: `${invoice.id}_${itemMatch.itemId}`,
          date: invoice.date || '',
          ref: invoice.number || `Invoice (ID: ${invoice.id.slice(0, 5)})`,
          type: 'Out',
          partyName: invoice.customerName || 'Customer',
          quantity: qty,
          rate: Number(itemMatch.rate) || 0,
          status: invoice.status,
        });
      }
    });

    // Sort moves by date descending
    moves.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const onHand = (baseStockOnHand || 0) + totalReceived - totalShipped;
    const forecasted = onHand + pendingIncoming - pendingOutgoing;

    return {
      onHand,
      incoming: pendingIncoming,
      outgoing: pendingOutgoing,
      forecasted,
      moves,
    };
  };

  const populateFields = (item: Item | null) => {
    setFormTab('general');
    if (item) {
      setProductType(item.productType || (item.type === 'Service' ? 'Service' : 'Storable'));
      setInvoicingPolicy(item.invoicingPolicy || 'Ordered');
      setRoutesBuy(item.routesBuy !== false);
      setRoutesMTO(!!item.routesMTO);
      setTraceability(item.traceability || 'None');
      setWeight(item.weight || 0);
      setVolume(item.volume || 0);
      setCustomerLeadTime(item.customerLeadTime || 0);
      setIncomeAccountId(item.incomeAccountId || '');
      setExpenseAccountId(item.expenseAccountId || '');
      setPriceDiffAccountId(item.priceDiffAccountId || '');
      setMinReorderingQty(item.minReorderingQty || 0);
      setMaxReorderingQty(item.maxReorderingQty || 0);
      setReorderingEnabled(!!item.reorderingEnabled);
    } else {
      setProductType('Storable');
      setInvoicingPolicy('Ordered');
      setRoutesBuy(true);
      setRoutesMTO(false);
      setTraceability('None');
      setWeight(0);
      setVolume(0);
      setCustomerLeadTime(0);
      setIncomeAccountId('');
      setExpenseAccountId('');
      setPriceDiffAccountId('');
      setMinReorderingQty(0);
      setMaxReorderingQty(0);
      setReorderingEnabled(false);
    }
  };

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    
    const baseStockVal = Number(formData.get('stockOnHand') || 0);

    const data = {
      name: formData.get('name') as string,
      sku: formData.get('sku') as string,
      type: productType === 'Service' ? 'Service' : 'Product',
      unit: formData.get('unit') as string,
      salesPrice: Number(formData.get('salesPrice')),
      purchasePrice: Number(formData.get('purchasePrice')),
      stockOnHand: baseStockVal,
      productType,
      invoicingPolicy,
      routesBuy,
      routesMTO,
      traceability,
      weight: Number(weight),
      volume: Number(volume),
      customerLeadTime: Number(customerLeadTime),
      incomeAccountId,
      expenseAccountId,
      priceDiffAccountId,
      minReorderingQty: Number(minReorderingQty),
      maxReorderingQty: Number(maxReorderingQty),
      reorderingEnabled,
      companyId,
      updatedAt: serverTimestamp(),
    };

    try {
      if (editingItem) {
        await updateDoc(doc(db, 'items', editingItem.id), data);
      } else {
        await addDoc(collection(db, 'items'), {
          ...data,
          createdAt: serverTimestamp(),
        });
      }
      setIsModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, 'items');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string, itemData?: Item) => {
    if (!canPerform('delete')) {
      alert("🚨 صلاحيات محدودة: لا تملك صلاحية حذف الأصناف.");
      return;
    }

    const data = itemData || items.find(i => i.id === id);
    if (!data) return;

    const secureRow = (data as any).companyId ? data : { ...data, companyId };
    if (!validateRowSecurity(secureRow)) {
      alert("🚨 خرق أمني: لا يمكن حذف أصناف تابعة لشركات أخرى.");
      return;
    }

    if (!window.confirm("هل أنت متأكد من حذف هذا الصنف؟")) return;

    try {
      await deleteDoc(doc(db, 'items', id));
      // Fix screen rendering/freezing by removing the deleted product immediately
      setItems(prev => prev.filter(i => i.id !== id));
      console.log("✅ Product successfully deleted and state updated smoothly.");
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `items/${id}`);
      alert("حدث خطأ غير متوقع أثناء الحذف بالسيرفر، يرجى مراجعة Console المطور.");
    }
  };

  const filteredItems = items.filter(i => 
    i.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    i.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    totalProducts: items.filter(i => i.type === 'Product' || i.productType === 'Storable' || i.productType === 'Consumable').length,
    totalServices: items.filter(i => i.type === 'Service' || i.productType === 'Service').length,
    lowStock: items.filter(i => {
      const liveData = getItemInventoryData(i.id, i.stockOnHand);
      return (i.type === 'Product' || i.productType === 'Storable') && liveData.onHand < (i.minReorderingQty || 10);
    }).length,
  };

  const columns: ColumnDef<Item>[] = [
    {
      header: t('sidebar.items') || 'Product Details',
      accessorKey: 'name',
      cell: (info) => {
        const it = info.row.original;
        return (
          <div className="flex flex-col">
            <span className="font-bold text-slate-900">{getLocalizedName(it)}</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-xs font-mono text-slate-400 bg-slate-50 px-1 border border-slate-100 rounded">{it.sku}</span>
              {it.productType && (
                <span className="text-[10px] font-bold text-slate-400">
                  • {it.productType}
                </span>
              )}
            </div>
          </div>
        );
      },
    },
    {
      header: 'Logistics Type',
      accessorKey: 'productType',
      cell: (info) => {
        const val = info.row.original.productType || (info.row.original.type === 'Service' ? 'Service' : 'Storable');
        return (
          <span className={cn(
            "px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider",
            val === 'Storable' ? "bg-blue-50 text-blue-700 border border-blue-100" :
            val === 'Service' ? "bg-amber-50 text-amber-700 border border-amber-100" :
            "bg-purple-50 text-purple-700 border border-purple-100"
          )}>
            {val === 'Storable' ? 'Storable Product' : val === 'Service' ? 'Service' : 'Consumable'}
          </span>
        );
      },
    },
    {
      header: 'Sales Price',
      accessorKey: 'salesPrice',
      cell: (info) => <span className="font-bold text-slate-950">{formatCurrency(info.getValue() as number, 'YER')}</span>,
    },
    {
      header: 'Stock On-Hand',
      accessorKey: 'stockOnHand',
      cell: (info) => {
        const item = info.row.original;
        const state = getItemInventoryData(item.id, item.stockOnHand);
        const displayStock = (item.type === 'Product' || item.productType === 'Storable') ? state.onHand : 'N/A';
        const isLowStock = (item.type === 'Product' || item.productType === 'Storable') && state.onHand < (item.minReorderingQty || 10);
        return (
          <div className="flex items-center gap-2">
            <span className={cn(
              "font-extrabold text-sm",
              isLowStock ? "text-rose-600" : "text-slate-700"
            )}>
              {displayStock}
            </span>
            {(item.type === 'Product' || item.productType === 'Storable') && isLowStock && (
              <span className="text-[9px] font-bold text-rose-600 bg-rose-50 border border-rose-100 rounded-md px-1.5 py-0.5 uppercase tracking-wide">
                Low Stock
              </span>
            )}
          </div>
        );
      },
    },
    {
      header: 'Actions',
      id: 'actions',
      cell: (info) => (
        <div className="flex items-center gap-2">
          <button 
            type="button"
            onClick={() => {
              const item = info.row.original;
              setEditingItem(item);
              populateFields(item);
              setIsModalOpen(true);
            }}
            className="p-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 shadow-xs transition-colors flex items-center gap-1 text-xs font-semibold cursor-pointer"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>Config</span>
          </button>
          <button 
            type="button"
            onClick={() => handleDelete(info.row.original.id, info.row.original)}
            className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-rose-50 text-slate-400 hover:text-rose-600 shadow-xs transition-colors cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      ),
    }
  ];

  // Pick appropriate active Item's inventory data
  const currentInvData = getItemInventoryData(editingItem?.id || '', editingItem?.stockOnHand || 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Items & Product Catalog</h1>
          <p className="text-slate-500 text-sm">Advanced Inventory integration, safety stock thresholds, and logistics routes tracking.</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-indigo-650 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            Import from Excel
          </button>

          <div className="relative">
            <button
              onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
              className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Export
            </button>
            {isExportDropdownOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setIsExportDropdownOpen(false)} />
                <div className="absolute right-0 mt-1.5 w-48 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 z-20">
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToExcel(
                        items,
                        ['sku', 'name', 'type', 'salesPrice', 'purchasePrice', 'stockOnHand', 'reorderPoint', 'status'],
                        ['SKU Code', 'Item Name', 'Type', 'Sales Price', 'Purchase Price', 'Stock On Hand', 'Reorder Point', 'Status'],
                        'System_Items_Catalog'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    Export to Excel (.xlsx)
                  </button>
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToPDF(
                        items,
                        ['sku', 'name', 'type', 'salesPrice', 'purchasePrice', 'stockOnHand', 'reorderPoint', 'status'],
                        ['SKU Code', 'Item Name', 'Type', 'Sales Price', 'Purchase Price', 'Stock On Hand', 'Reorder Point', 'Status'],
                        'Advanced Accounting - Items & Product Inventory Catalog',
                        'System_Items_Catalog'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    Export to PDF (.pdf)
                  </button>
                </div>
              </>
            )}
          </div>

          <button 
            onClick={() => {
              setEditingItem(null);
              populateFields(null);
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-semibold shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            New Product / Service
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium font-sans">Total Products</p>
            <p className="text-2xl font-bold text-slate-900">{stats.totalProducts}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-50 rounded-xl text-amber-600">
            <Tag className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium font-sans">Total Services</p>
            <p className="text-2xl font-bold text-slate-900">{stats.totalServices}</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-rose-50 rounded-xl text-rose-600">
            <Box className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-slate-500 font-medium font-sans">Low Stock Items</p>
            <p className="text-2xl font-bold text-slate-900">{stats.lowStock}</p>
          </div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search by SKU, product name, or classification..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      ) : (
        <DataTable columns={columns} data={filteredItems} />
      )}

      {/* Detailed Product Form Sheet Modal */}
      <Modal 
        isOpen={isModalOpen} 
        onClose={() => {
          setIsModalOpen(false);
          setEditingItem(null);
        }} 
        title={editingItem ? "Edit Product Form" : "Create Product Form"} 
        size="xl"
      >
        <form onSubmit={handleSave} className="space-y-6">
          {/* Smart Buttons & Header section */}
          <div className="flex flex-col md:flex-row justify-between items-start gap-4 border-b border-slate-200 pb-5">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-slate-100 px-2 py-0.5 rounded-md">
                  Product Form
                </span>
                <span className={cn(
                  "text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border",
                  productType === 'Storable' ? "bg-blue-50 text-blue-700 border-blue-200" :
                  productType === 'Service' ? "bg-amber-50 text-amber-700 border-amber-200" :
                  "bg-purple-50 text-purple-700 border-purple-200"
                )}>
                  {productType === 'Storable' ? 'Storable Product' : productType === 'Service' ? 'Service' : 'Consumable'}
                </span>
              </div>
              <h3 className="text-lg font-extrabold text-slate-900 truncate max-w-sm" title={editingItem?.name}>
                {editingItem ? editingItem.name : "New Inventory Item"}
              </h3>
            </div>

            {/* Smart Buttons Cards */}
            <div className="flex flex-wrap gap-2 justify-end w-full md:w-auto shrink-0">
              <button
                type="button"
                onClick={() => {
                  alert(`On Hand physical count: ${currentInvData.onHand} units.\nCalculated from: Base Stock setup (${editingItem?.stockOnHand || 0}) + Received Bills Qty (${currentInvData.onHand - (editingItem?.stockOnHand || 0)})`);
                }}
                className="flex items-center gap-2 px-3 py-1 bg-white border border-slate-200 hover:border-indigo-400 rounded-lg shadow-xs hover:bg-slate-50 transition text-left select-none text-slate-700 min-w-[95px] h-11 cursor-pointer"
              >
                <Box className="w-4 h-4 text-indigo-500 shrink-0" />
                <div className="min-w-0">
                  <span className="block text-[8px] font-semibold text-slate-400 uppercase tracking-wider leading-none">On Hand</span>
                  <span className="block text-xs font-extrabold text-slate-800 leading-normal mt-0.5">{currentInvData.onHand} Units</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => {
                  alert(`Forecasted Stock Calculation:\nPhysical On Hand: ${currentInvData.onHand} Units\n+ Pending Incoming: ${currentInvData.incoming} Units\n- Pending Outgoing: ${currentInvData.outgoing} Units\n= Predicted Forecasted Stock: ${currentInvData.forecasted} Units`);
                }}
                className="flex items-center gap-2 px-3 py-1 bg-white border border-slate-200 hover:border-indigo-400 rounded-lg shadow-xs hover:bg-slate-50 transition text-left select-none text-slate-700 min-w-[100px] h-11 cursor-pointer"
              >
                <TrendingUp className="w-4 h-4 text-emerald-500 shrink-0" />
                <div className="min-w-0">
                  <span className="block text-[8px] font-semibold text-slate-400 uppercase tracking-wider leading-none">Forecasted</span>
                  <span className="block text-xs font-extrabold text-emerald-600 leading-normal mt-0.5">{currentInvData.forecasted} Units</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setIsMovesModalOpen(true)}
                className="flex items-center gap-2 px-3 py-1 bg-white border border-slate-200 hover:border-indigo-400 rounded-lg shadow-xs hover:bg-indigo-50 transition text-left select-none text-slate-700 min-w-[95px] h-11 cursor-pointer"
              >
                <Activity className="w-4 h-4 text-indigo-600 shrink-0" />
                <div className="min-w-0">
                  <span className="block text-[8px] font-semibold text-slate-400 uppercase tracking-wider leading-none">In/Out Moves</span>
                  <span className="block text-xs font-extrabold text-slate-800 leading-normal mt-0.5">{currentInvData.moves.length} Moves</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setIsReorderingModalOpen(true)}
                className={cn(
                  "flex items-center gap-2 px-3 py-1 border hover:border-indigo-400 rounded-lg shadow-xs transition text-left select-none min-w-[110px] h-11 cursor-pointer",
                  reorderingEnabled 
                    ? "bg-indigo-50/50 border-indigo-200 text-indigo-700 hover:bg-indigo-50" 
                    : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                )}
              >
                <Bell className={cn("w-4 h-4 shrink-0", reorderingEnabled ? "text-indigo-600" : "text-slate-400")} />
                <div className="min-w-0">
                  <span className="block text-[8px] font-semibold text-slate-400 uppercase tracking-wider leading-none">Reordering Rules</span>
                  <span className="block text-[10px] font-extrabold leading-normal mt-0.5 truncate">
                    {reorderingEnabled ? `Min ${minReorderingQty} / Max ${maxReorderingQty}` : 'Inactive'}
                  </span>
                </div>
              </button>
            </div>
          </div>

          {/* Product Name Inputs & General Information section */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4 shadow-2xs hover:border-indigo-200 transition">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Product Name <span className="text-rose-500">*</span>
                </label>
                <input 
                  name="name" 
                  defaultValue={editingItem?.name} 
                  required 
                  type="text" 
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 font-semibold" 
                  placeholder="e.g. Dell Latitude 5420 Laptop" 
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  SKU Reference <span className="text-rose-500">*</span>
                </label>
                <input 
                  name="sku" 
                  defaultValue={editingItem?.sku} 
                  required 
                  type="text" 
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 font-mono" 
                  placeholder="e.g. SKU-ST-1002" 
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-slate-200 pt-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Product Type
                </label>
                <select 
                  value={productType}
                  onChange={(e) => {
                    const val = e.target.value as 'Consumable' | 'Service' | 'Storable';
                    setProductType(val);
                  }}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                >
                  <option value="Storable">Storable Product (منتج مخزني)</option>
                  <option value="Consumable">Consumable (استهلاكي)</option>
                  <option value="Service">Service (خدمة)</option>
                </select>
                <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                  {productType === 'Storable' ? 'Tracks quantities and triggers stock moves.' : 
                   productType === 'Service' ? 'Intangible items sold as time-bound service.' :
                   'Physical items always available, no quantities tracked.'}
                </p>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Invoicing Policy
                </label>
                <div className="flex flex-col gap-2 bg-white p-2.5 border border-slate-300 rounded">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-600 font-medium">
                    <input 
                      type="radio" 
                      name="invoicingPolicyRaw" 
                      checked={invoicingPolicy === 'Ordered'} 
                      onChange={() => setInvoicingPolicy('Ordered')} 
                      className="text-indigo-600 focus:ring-indigo-500" 
                    />
                    <span>Ordered quantities</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-600 font-medium">
                    <input 
                      type="radio" 
                      name="invoicingPolicyRaw" 
                      checked={invoicingPolicy === 'Delivered'} 
                      onChange={() => setInvoicingPolicy('Delivered')} 
                      className="text-indigo-600 focus:ring-indigo-500" 
                    />
                    <span>Delivered quantities</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  UoM (Unit of Measure)
                </label>
                <select name="unit" defaultValue={editingItem?.unit || 'Unit'} className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500">
                  <option value="Unit">Units / Pieces</option>
                  <option value="Hour">Hours / Time</option>
                  <option value="Month">Months</option>
                  <option value="Box">Boxes</option>
                </select>
              </div>
            </div>
          </div>

          {/* Sub-tabs selection bar */}
          <div className="flex border-b border-slate-200">
            <button
              type="button"
              onClick={() => setFormTab('general')}
              className={cn(
                "px-5 py-2.5 text-xs font-bold border-b-2 uppercase tracking-wide transition-colors",
                formTab === 'general' 
                  ? "border-indigo-600 text-indigo-600 font-extrabold" 
                  : "border-transparent text-slate-500 hover:text-slate-800"
              )}
            >
              General Information
            </button>
            <button
              type="button"
              onClick={() => setFormTab('inventory')}
              className={cn(
                "px-5 py-2.5 text-xs font-bold border-b-2 uppercase tracking-wide transition-colors",
                formTab === 'inventory' 
                  ? "border-indigo-600 text-indigo-600 font-extrabold" 
                  : "border-transparent text-slate-500 hover:text-slate-800"
              )}
            >
              Inventory (المخزون)
            </button>
            <button
              type="button"
              onClick={() => setFormTab('accounting')}
              className={cn(
                "px-5 py-2.5 text-xs font-bold border-b-2 uppercase tracking-wide transition-colors",
                formTab === 'accounting' 
                  ? "border-indigo-600 text-indigo-600 font-extrabold" 
                  : "border-transparent text-slate-500 hover:text-slate-800"
              )}
            >
              Accounting (المحاسبة)
            </button>
          </div>

          {/* Tab 1 Content: Pricing & Initial Stock configurations */}
          {formTab === 'general' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-1 animate-fade-in">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Sales Price (YER)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">YER</span>
                  <input 
                    name="salesPrice" 
                    defaultValue={editingItem?.salesPrice || 0} 
                    type="number" 
                    step="0.01" 
                    className="w-full pl-11 pr-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-800" 
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">Default public retail price of this product.</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Cost / Purchase Price (YER)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">YER</span>
                  <input 
                    name="purchasePrice" 
                    defaultValue={editingItem?.purchasePrice || 0} 
                    type="number" 
                    step="0.01" 
                    className="w-full pl-11 pr-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-800" 
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">Acquisition rate or supplier procurement cost.</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Base Starting Stock (On Hand)
                </label>
                <input 
                  name="stockOnHand" 
                  defaultValue={editingItem?.stockOnHand || 0} 
                  type="number" 
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 font-bold" 
                />
                <p className="text-[10px] text-slate-400 mt-1">Baseline warehouse inventory count manually configured.</p>
              </div>
            </div>
          )}

          {/* Tab 2 Content: Inventory Routes, Tracking & Logistics */}
          {formTab === 'inventory' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-1 animate-fade-in">
              {/* Replenishment Routes section */}
              <div className="space-y-3 bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
                <h5 className="font-bold text-xs text-slate-900 border-b pb-1.5 flex items-center gap-1.5 uppercase tracking-wide">
                  <Layers className="w-4 h-4 text-indigo-500" />
                  Routes (مسارات الإمداد)
                </h5>
                <div className="space-y-3 pt-1">
                  <label className="flex items-start gap-2.5 cursor-pointer select-none text-xs text-slate-600 font-medium">
                    <input 
                      type="checkbox" 
                      checked={routesBuy} 
                      onChange={(e) => setRoutesBuy(e.target.checked)}
                      className="text-indigo-600 focus:ring-indigo-500 mt-0.5 rounded" 
                    />
                    <div className="min-w-0">
                      <span className="block font-bold text-slate-800">Buy (شراء)</span>
                      <span className="block text-[10px] text-slate-400 mt-0.5 leading-normal">Creates a draft RFQ automatically for minimum safety alert drops.</span>
                    </div>
                  </label>

                  <label className="flex items-start gap-2.5 cursor-pointer select-none text-xs text-slate-600 font-medium border-t border-slate-100 pt-3">
                    <input 
                      type="checkbox" 
                      checked={routesMTO} 
                      onChange={(e) => setRoutesMTO(e.target.checked)}
                      className="text-indigo-600 focus:ring-indigo-500 mt-0.5 rounded" 
                    />
                    <div className="min-w-0">
                      <span className="block font-bold text-slate-800">Replenish on Order (MTO)</span>
                      <span className="block text-[10px] text-slate-400 mt-0.5 leading-normal">Procures or manufactures items immediately upon Sales Invoice request.</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* Traceability Warehouse configuration */}
              <div className="space-y-3 bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
                <h5 className="font-bold text-xs text-slate-900 border-b pb-1.5 flex items-center gap-1.5 uppercase tracking-wide">
                  <Activity className="w-4 h-4 text-indigo-500" />
                  Traceability (التتبع)
                </h5>
                <div className="space-y-2 pt-1 flex flex-col">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-600 font-medium py-1">
                    <input 
                      type="radio" 
                      name="traceabilityRaw" 
                      checked={traceability === 'Serial'} 
                      onChange={() => setTraceability('Serial')} 
                      className="text-indigo-600 focus:ring-indigo-500" 
                    />
                    <span>By Unique Serial Number (رقم تسلسلي)</span>
                  </label>
                  
                  <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-600 font-medium py-1">
                    <input 
                      type="radio" 
                      name="traceabilityRaw" 
                      checked={traceability === 'Lots'} 
                      onChange={() => setTraceability('Lots')} 
                      className="text-indigo-600 focus:ring-indigo-500" 
                    />
                    <span>By Lots (رقم التشغيلة)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-600 font-medium py-1">
                    <input 
                      type="radio" 
                      name="traceabilityRaw" 
                      checked={traceability === 'None'} 
                      onChange={() => setTraceability('None')} 
                      className="text-indigo-600 focus:ring-indigo-500" 
                    />
                    <span>No Tracking (بدون تتبع)</span>
                  </label>
                </div>
              </div>

              {/* Physical Logistics Fields */}
              <div className="space-y-3 bg-white border border-slate-200 rounded-xl p-4 shadow-2xs">
                <h5 className="font-bold text-xs text-slate-900 border-b pb-1.5 flex items-center gap-1.5 uppercase tracking-wide">
                  <Scale className="w-4 h-4 text-indigo-500" />
                  Logistics & Dimensions
                </h5>
                <div className="space-y-2 pt-1 text-xs">
                  <div>
                    <label className="block text-slate-500 font-medium mb-1">Weight (kg)</label>
                    <input 
                      type="number" 
                      step="0.01" 
                      value={weight}
                      onChange={(e) => setWeight(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded outline-none focus:bg-white focus:ring-1 focus:ring-indigo-500" 
                      placeholder="0.00" 
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 font-medium mb-1">Volume (m³)</label>
                    <input 
                      type="number" 
                      step="0.001" 
                      value={volume}
                      onChange={(e) => setVolume(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded outline-none focus:bg-white focus:ring-1 focus:ring-indigo-500" 
                      placeholder="0.000" 
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 font-medium mb-1">Customer Lead Time (Days)</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        value={customerLeadTime}
                        onChange={(e) => setCustomerLeadTime(Number(e.target.value))}
                        className="w-full pl-2.5 pr-14 py-1.5 bg-slate-50 border border-slate-200 rounded outline-none focus:bg-white focus:ring-1 focus:ring-indigo-500" 
                        placeholder="0" 
                      />
                      <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold uppercase">Days</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3 Content: Automatic Real-time COGS Account Mapping */}
          {formTab === 'accounting' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-1 animate-fade-in">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Income Account
                </label>
                <select 
                  value={incomeAccountId} 
                  onChange={(e) => setIncomeAccountId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">-- Choose Sales/Income Account --</option>
                  {accounts.filter(a => a.type === 'Income' && a.code !== '4000').map(a => (
                    <option key={a.id} value={a.id}>{a.code} - {a.name}</option>
                  ))}
                  {/* Backup defaults fallback */}
                  <option value="default_income_4000">4000 - Sales Revenue (Default)</option>
                  <option value="default_income_4100">4100 - Service Revenue</option>
                </select>
                <p className="text-[10px] text-slate-400 leading-normal mt-1">Automatic account destination to credit when generating customer invoices for this product.</p>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Expense Account
                </label>
                <select 
                  value={expenseAccountId} 
                  onChange={(e) => setExpenseAccountId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">-- Choose Cost/Procurement Account --</option>
                  {accounts.filter(a => a.type === 'Expense' && a.code !== '5000').map(a => (
                    <option key={a.id} value={a.id}>{a.code} - {a.name}</option>
                  ))}
                  {/* Backup defaults fallback */}
                  <option value="default_expense_5000">5000 - Cost of Goods Sold (Default)</option>
                  <option value="default_expense_6000">6000 - Office Supplies / procurement</option>
                </select>
                <p className="text-[10px] text-slate-400 leading-normal mt-1">Automatic account destination to debit when recording supplier purchase bills.</p>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Price Difference Account
                </label>
                <select 
                  value={priceDiffAccountId} 
                  onChange={(e) => setPriceDiffAccountId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">-- Choose Valuation Variance Account --</option>
                  {accounts.filter(a => (a.type === 'Expense' || a.type === 'Asset') && !['1000', '5000'].includes(a.code)).map(a => (
                    <option key={a.id} value={a.id}>{a.code} - {a.name}</option>
                  ))}
                  {/* Backup defaults fallback */}
                  <option value="default_diff_5100">5100 - Price Difference/Variance Account</option>
                  <option value="default_diff_1400">1400 - Inventory Valuation Gaps</option>
                </select>
                <p className="text-[10px] text-slate-400 leading-normal mt-1">Directly records procurement gaps between invoice price and standard catalog purchase price.</p>
              </div>
            </div>
          )}

          {/* Buttons footer bar */}
          <div className="flex items-center gap-4 pt-6 border-t border-slate-200">
            <button 
              type="button" 
              onClick={() => {
                setIsModalOpen(false);
                setEditingItem(null);
              }} 
              className="flex-1 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-semibold text-slate-600 text-sm cursor-pointer"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              disabled={isSaving}
              className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-bold shadow-xs flex items-center justify-center gap-2 text-sm cursor-pointer"
            >
              {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
              {isSaving ? 'Saving Form...' : (editingItem ? 'Update Product' : 'Create Product')}
            </button>
          </div>
        </form>
      </Modal>

      {/* Embedded Sub-Modal: Real-time In/Out Moves history list */}
      {isMovesModalOpen && (
        <Modal
          isOpen={isMovesModalOpen}
          onClose={() => setIsMovesModalOpen(false)}
          title={`${editingItem ? editingItem.name : 'Product'} - Historical Inventory Stock Moves`}
          size="lg"
        >
          <div className="space-y-4 p-1">
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs leading-relaxed text-slate-500">
              This lists all warehouse transfers, stock movements, purchase bill additions, and customer invoice deductions recorded for this specific storable inventory item.
            </div>

            {currentInvData.moves.length === 0 ? (
              <div className="text-center py-10 bg-white border border-dashed rounded-xl border-slate-200">
                <Package className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <h3 className="font-bold text-slate-700 text-sm">No Stock Movements</h3>
                <p className="text-xs text-slate-400 mt-1">This product has not been involved in any sales or purchase transactions yet.</p>
              </div>
            ) : (
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs bg-white">
                <div className="max-h-96 overflow-y-auto">
                  <table className="w-full text-left text-xs text-slate-600">
                    <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-bold border-b border-slate-200">
                      <tr>
                        <th className="px-4 py-3">Date</th>
                        <th className="px-4 py-3">Ref Document</th>
                        <th className="px-4 py-3">Type</th>
                        <th className="px-4 py-3">Partner Name</th>
                        <th className="px-4 py-3 text-right">Quantity</th>
                        <th className="px-4 py-3 text-right">Rate</th>
                        <th className="px-4 py-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {currentInvData.moves.map((move: any) => (
                        <tr key={move.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="px-4 py-3 font-medium text-slate-400">{move.date}</td>
                          <td className="px-4 py-3 font-semibold text-indigo-600">{move.ref}</td>
                          <td className="px-4 py-3">
                            <span className={cn(
                              "px-2 py-0.5 rounded-full font-semibold text-[10px]",
                              move.type === 'In' ? "bg-green-50 text-green-700" : "bg-rose-50 text-rose-700"
                            )}>
                              {move.type === 'In' ? "Inward (Purchase)" : "Outward (Sale)"}
                            </span>
                          </td>
                          <td className="px-4 py-3 font-medium text-slate-700">{move.partyName}</td>
                          <td className={cn(
                            "px-4 py-3 text-right font-extrabold text-sm",
                            move.type === 'In' ? "text-green-600" : "text-rose-600"
                          )}>
                            {move.type === 'In' ? `+${move.quantity}` : `-${move.quantity}`}
                          </td>
                          <td className="px-4 py-3 text-right font-mono text-slate-500">{formatCurrency(move.rate, 'YER')}</td>
                          <td className="px-4 py-3">
                            <span className="capitalize text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 font-bold">
                              {move.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="flex justify-end pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIsMovesModalOpen(false)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-bold text-xs shadow-xs transition cursor-pointer"
              >
                Close History
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Embedded Sub-Modal: safety stock configuration popup */}
      {isReorderingModalOpen && (
        <Modal
          isOpen={isReorderingModalOpen}
          onClose={() => setIsReorderingModalOpen(false)}
          title={`Configure Reordering Safety Stock Rules`}
          size="md"
        >
          <div className="space-y-4 p-1">
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs leading-relaxed text-slate-500 flex gap-2">
              <Bell className="w-5 h-5 text-indigo-500 shrink-0 mt-0.5" />
              <span>
                Define minimum safety quantity limits for automated procurement. If physical stock drops below the minimum safety stock value, replenishment recommendations will be computed.
              </span>
            </div>

            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between p-3.5 bg-indigo-50/50 border border-indigo-100 rounded-xl">
                <div className="space-y-0.5">
                  <h5 className="font-extrabold text-xs text-slate-800">Activate Safety Stock Rules</h5>
                  <p className="text-[10px] text-slate-400">Trigger low-stock alerts and buy/MTO workflows.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    checked={reorderingEnabled} 
                    onChange={(e) => setReorderingEnabled(e.target.checked)}
                    className="sr-only peer" 
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                </label>
              </div>

              <div className={cn("grid grid-cols-2 gap-4 transition-all duration-300", reorderingEnabled ? "opacity-100" : "opacity-40 pointer-events-none")}>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Minimum Quantity (Safety)
                  </label>
                  <input 
                    type="number" 
                    value={minReorderingQty}
                    onChange={(e) => setMinReorderingQty(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                    placeholder="e.g. 5"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Maximum Quantity (Target Capacity)
                  </label>
                  <input 
                    type="number" 
                    value={maxReorderingQty}
                    onChange={(e) => setMaxReorderingQty(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 font-bold"
                    placeholder="e.g. 50"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-200 gap-3">
              <button
                type="button"
                onClick={() => setIsReorderingModalOpen(false)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-bold text-xs shadow-xs transition cursor-pointer"
              >
                Confirm Setup
              </button>
            </div>
          </div>
        </Modal>
      )}

      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        moduleId="items"
        existingRecords={items}
        onImportSuccess={(cnt) => {
          setIsImportModalOpen(false);
        }}
      />
    </div>
  );
}
