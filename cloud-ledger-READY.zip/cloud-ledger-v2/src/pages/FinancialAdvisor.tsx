import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Sparkles, Send, RefreshCw, AlertTriangle, AlertCircle,
  Info, TrendingUp, TrendingDown, Activity, DollarSign,
  Trash2, ChevronDown, ChevronUp, Zap, Shield, BarChart2
} from 'lucide-react';
import { useFinancialAdvisor, AccountingAlert, FinancialSnapshot } from '../hooks/useFinancialAdvisor';

// ── Quick prompts ──────────────────────────────────────────────────
const QUICK_PROMPTS = [
  { icon: '🔍', label: 'تشخيص شامل', prompt: 'قم بتشخيص مالي شامل للشركة مع توصيات استراتيجية للأشهر الثلاثة القادمة' },
  { icon: '💰', label: 'التدفق النقدي', prompt: 'كيف وضع التدفق النقدي للشركة؟ هل هناك خطر نقص السيولة؟' },
  { icon: '📊', label: 'هامش الربح', prompt: 'حلّل هامش الربح واقترح كيفية تحسينه' },
  { icon: '⚠️', label: 'المخاطر المالية', prompt: 'ما هي أكبر المخاطر المالية التي تواجهها الشركة الآن؟' },
  { icon: '🏦', label: 'نسب السيولة', prompt: 'هل نسب السيولة جيدة؟ قارنها بالمعايير الدولية' },
  { icon: '📅', label: 'توقعات الربع', prompt: 'بناءً على الأداء الحالي، توقع أداء الربع القادم' },
];

// ── Alert badge ────────────────────────────────────────────────────
function AlertBadge({ alert }: { alert: AccountingAlert }) {
  const colors = {
    critical: 'bg-red-50 border-red-200 text-red-700',
    warning:  'bg-amber-50 border-amber-200 text-amber-700',
    info:     'bg-blue-50 border-blue-200 text-blue-700',
  };
  const icons = {
    critical: <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />,
    warning:  <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />,
    info:     <Info className="w-4 h-4 text-blue-500 shrink-0" />,
  };
  return (
    <div className={`flex items-start gap-3 p-3 rounded-xl border ${colors[alert.severity]} text-sm`}>
      {icons[alert.severity]}
      <div>
        <div className="font-bold">{alert.title}</div>
        <div className="text-xs opacity-80 mt-0.5">{alert.detail}</div>
        <div className="text-xs mt-1 font-medium">💡 {alert.recommendation}</div>
      </div>
    </div>
  );
}

// ── Snapshot card ──────────────────────────────────────────────────
function SnapshotPanel({ snap }: { snap: FinancialSnapshot }) {
  const [open, setOpen] = useState(false);
  const fmt = (n: number) =>
    n >= 1_000_000 ? `${(n / 1_000_000).toFixed(1)}م`
    : n >= 1_000 ? `${(n / 1_000).toFixed(1)}ك`
    : n.toLocaleString('ar-SA', { maximumFractionDigits: 0 });

  const isProfit = snap.netIncome >= 0;

  return (
    <div className="border border-slate-200 rounded-2xl overflow-hidden mb-4">
      <button onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-4 py-3 bg-slate-50 hover:bg-slate-100 transition-colors text-sm font-semibold text-slate-700">
        <span className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-indigo-500" />
          البيانات المالية المُحمَّلة للمستشار
        </span>
        <div className="flex items-center gap-3">
          <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${snap.isBalanced ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
            {snap.isBalanced ? '✓ متوازن' : '✗ غير متوازن'}
          </span>
          {open ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </div>
      </button>

      {open && (
        <div className="p-4 grid grid-cols-2 gap-3 bg-white">
          {[
            { label: 'الإيرادات', value: fmt(snap.totalRevenue), icon: TrendingUp, color: 'emerald' },
            { label: 'المصروفات', value: fmt(snap.totalExpenses), icon: TrendingDown, color: 'rose' },
            { label: 'صافي الربح', value: `${fmt(snap.netIncome)} (${snap.netMargin.toFixed(1)}%)`, icon: DollarSign, color: isProfit ? 'emerald' : 'red' },
            { label: 'النقد والبنك', value: fmt(snap.cashBalance), icon: DollarSign, color: 'blue' },
            { label: 'ذمم مدينة', value: fmt(snap.totalReceivables), icon: BarChart2, color: 'amber' },
            { label: 'ذمم دائنة', value: fmt(snap.totalPayables), icon: BarChart2, color: 'orange' },
            { label: 'نسبة السيولة', value: snap.currentRatio > 0 ? snap.currentRatio.toFixed(2) : 'N/A', icon: Shield, color: snap.currentRatio >= 1.5 ? 'emerald' : 'red' },
            { label: 'فواتير متأخرة', value: `${snap.overdueInvoices} (${fmt(snap.overdueAmount)})`, icon: AlertCircle, color: snap.overdueInvoices > 0 ? 'red' : 'emerald' },
          ].map(item => (
            <div key={item.label} className={`flex items-center gap-2 p-2.5 rounded-xl bg-${item.color}-50 border border-${item.color}-100`}>
              <item.icon className={`w-3.5 h-3.5 text-${item.color}-600 shrink-0`} />
              <div>
                <div className="text-xs text-slate-500">{item.label}</div>
                <div className={`text-sm font-bold text-${item.color}-700`}>{item.value} {snap.currency}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Message bubble ─────────────────────────────────────────────────
function MessageBubble({ msg }: { msg: any }) {
  const isUser = msg.role === 'user';

  return (
    <div className={`flex ${isUser ? 'justify-start' : 'justify-end'} mb-4`}>
      {!isUser && (
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shrink-0 ml-2 mt-1">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
      )}

      <div className={`max-w-[85%] ${isUser ? 'order-2' : 'order-1'}`}>
        <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
          isUser
            ? 'bg-slate-800 text-white rounded-tr-sm'
            : 'bg-white border border-slate-200 text-slate-800 rounded-tl-sm shadow-sm'
        }`}>
          {msg.content}
        </div>

        {/* Critical alerts inline */}
        {msg.alerts && msg.alerts.length > 0 && (
          <div className="mt-2 space-y-2">
            {msg.alerts.map((a: AccountingAlert) => <AlertBadge key={a.code} alert={a} />)}
          </div>
        )}

        <div className="text-xs text-slate-400 mt-1 px-1">
          {msg.timestamp.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>

      {isUser && (
        <div className="w-8 h-8 rounded-xl bg-slate-700 flex items-center justify-center shrink-0 mr-2 mt-1">
          <span className="text-white text-xs font-bold">أنت</span>
        </div>
      )}
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────
export default function FinancialAdvisor() {
  const { i18n } = useTranslation();
  const isRtl = i18n.language === 'ar';
  const [input, setInput] = useState('');
  const [showAlerts, setShowAlerts] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { messages, isLoading, snapshot, alerts, sendMessage, runFullDiagnosis, clearChat } = useFinancialAdvisor();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const text = input;
    setInput('');
    await sendMessage(text);
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)]" dir="rtl">
      {/* Header */}
      <div className="shrink-0 px-6 py-4 bg-white border-b border-slate-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-slate-900 text-base">المستشار المالي الذكي</h1>
              <p className="text-xs text-slate-500">يقرأ جميع بيانات شركتك ويجيب كمستشار مالي خبير</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={runFullDiagnosis} disabled={isLoading}
              className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50">
              <Zap className="w-3.5 h-3.5" />
              تشخيص شامل
            </button>
            <button onClick={clearChat}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar — Alerts + Snapshot */}
        <div className="w-72 shrink-0 border-l border-slate-200 bg-slate-50 overflow-y-auto p-4 space-y-4">
          {/* Alerts */}
          {alerts.length > 0 && (
            <div>
              <button onClick={() => setShowAlerts(o => !o)}
                className="w-full flex items-center justify-between text-xs font-bold text-slate-600 mb-2 hover:text-slate-900">
                <span className="flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                  تنبيهات محاسبية ({alerts.length})
                </span>
                {showAlerts ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
              {showAlerts && (
                <div className="space-y-2">
                  {alerts.map(a => <AlertBadge key={a.code} alert={a} />)}
                </div>
              )}
            </div>
          )}

          {/* Financial Snapshot */}
          {snapshot && <SnapshotPanel snap={snapshot} />}

          {/* Quick prompts */}
          <div>
            <div className="text-xs font-bold text-slate-500 mb-2">أسئلة سريعة</div>
            <div className="space-y-1.5">
              {QUICK_PROMPTS.map(q => (
                <button key={q.label} onClick={() => { setInput(q.prompt); textareaRef.current?.focus(); }}
                  className="w-full text-right text-xs px-3 py-2 rounded-lg bg-white border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50 transition-all text-slate-700 flex items-center gap-2">
                  <span>{q.icon}</span>
                  <span>{q.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Chat area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto px-6 py-4">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-100 to-purple-100 flex items-center justify-center mb-4">
                  <Sparkles className="w-8 h-8 text-indigo-500" />
                </div>
                <h2 className="text-xl font-bold text-slate-800 mb-2">مستشارك المالي الذكي</h2>
                <p className="text-slate-500 text-sm max-w-sm mb-6">
                  أسألني أي سؤال مالي أو محاسبي — سأقرأ جميع بيانات شركتك أولاً ثم أجيبك كخبير مالي متخصص
                </p>
                <div className="flex flex-wrap gap-2 justify-center max-w-md">
                  {QUICK_PROMPTS.slice(0, 3).map(q => (
                    <button key={q.label} onClick={() => sendMessage(q.prompt)}
                      className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm text-slate-700 hover:border-indigo-300 hover:bg-indigo-50 transition-all shadow-sm">
                      {q.icon} {q.label}
                    </button>
                  ))}
                </div>
                <button onClick={runFullDiagnosis} disabled={isLoading}
                  className="mt-4 flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50">
                  <Zap className="w-4 h-4" />
                  ابدأ بتشخيص مالي شامل
                </button>
              </div>
            ) : (
              <>
                {messages.map(msg => <MessageBubble key={msg.id} msg={msg} />)}
                {isLoading && (
                  <div className="flex justify-end mb-4">
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shrink-0 ml-2">
                      <Sparkles className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-5 py-3 shadow-sm">
                      <div className="flex items-center gap-2 text-slate-500 text-sm">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        يقرأ بيانات الشركة ويحلّلها...
                      </div>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </>
            )}
          </div>

          {/* Input */}
          <div className="shrink-0 border-t border-slate-200 bg-white px-4 py-3">
            <div className="flex gap-3 items-end">
              <div className="flex-1 relative">
                <textarea
                  ref={textareaRef}
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={handleKey}
                  placeholder="اسأل عن وضع السيولة، هامش الربح، المخاطر المالية، أي شيء..."
                  className="w-full resize-none rounded-xl border border-slate-200 px-4 py-3 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-400 outline-none transition-all min-h-[48px] max-h-32 text-right"
                  rows={1}
                />
              </div>
              <button onClick={handleSend} disabled={isLoading || !input.trim()}
                className="w-11 h-11 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl flex items-center justify-center transition-colors disabled:opacity-40 disabled:cursor-not-allowed shrink-0">
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </div>
            <div className="text-xs text-slate-400 mt-1.5 text-center">
              يقرأ المستشار جميع بيانات شركتك (فواتير، حسابات، قيود) قبل كل إجابة
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
