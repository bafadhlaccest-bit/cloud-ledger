import React, { useState, useEffect, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { 
  FileText, 
  BarChart3, 
  PieChart, 
  Table as TableIcon, 
  ChevronRight, 
  ChevronDown,
  Download,
  Printer,
  Plus,
  Search,
  Trash2,
  Settings,
  Play,
  Database,
  Layers,
  GitCommit,
  FileSpreadsheet,
  Maximize2,
  Save,
  Undo,
  Eye,
  Share2,
  RefreshCw,
  Sliders,
  Calendar,
  Code,
  User,
  Folder,
  Boxes,
  CheckCircle2,
  ArrowRight,
  Info,
  SlidersHorizontal,
  X,
  Sparkles,
  QrCode,
  Hash,
  AlertCircle,
  Bell,
  Clock,
  RotateCcw,
  Sliders as SlidersIcon,
  HelpCircle,
  ListFilter
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart as RechartPie,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';
import { cn } from '../lib/utils';
import { useTranslation } from 'react-i18next';

// Redux Toolkit integration
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { 
  setSelectedTemplateId, 
  updateFilters, 
  addSchedule, 
  toggleSchedule, 
  removeSchedule,
  addHistoryLog
} from '../store/reportsSlice';

// TanStack React Query integration
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

// Material-UI components
import { 
  Tabs, 
  Tab, 
  Box, 
  Dialog, 
  Drawer, 
  Switch, 
  FormControlLabel, 
  Slider as MuiSlider, 
  Chip,
  Tooltip as MuiTooltip,
  CircularProgress
} from '@mui/material';

import { 
  DBTable, 
  DBField, 
  TableJoin, 
  ReportElement, 
  ReportBand, 
  ReportLayout, 
  ReportAuditLog,
  ElementType,
  FormattingSettings
} from '../types/reports';
import { ERP_TABLES } from '../lib/reportDS';
import { CORE_TEMPLATES } from '../lib/reportTemplates';
import BalanceSheetTab from '../components/reports/BalanceSheetTab';
import ProfitLossTab from '../components/reports/ProfitLossTab';
import TrialBalanceTab from '../components/reports/TrialBalanceTab';
import GeneralLedgerTab from '../components/reports/GeneralLedgerTab';
import AccountLedgerStatement from '../components/reports/AccountLedgerStatement';

const labelTranslations: Record<string, { ar: string; en: string }> = {
  "Debit": { ar: "مدين", en: "Debit" },
  "Credit": { ar: "دائن", en: "Credit" },
  "Balance": { ar: "الرصيد", en: "Balance" },
  "Account Name": { ar: "اسم الحساب", en: "Account Name" },
  "Code": { ar: "الكود", en: "Code" },
  "Type": { ar: "النوع", en: "Type" },
  "Status": { ar: "الحالة", en: "Status" },
  "Date": { ar: "التاريخ", en: "Date" },
  "Particulars": { ar: "البيان / التفاصيل", en: "Particulars" },
  "Stock Qty": { ar: "الكمية بالمخزن", en: "Stock Qty" },
  "SKU": { ar: "الرمز SKU", en: "SKU" },
  "Description": { ar: "الوصف", en: "Description" },
  "Total Balance": { ar: "إجمالي الرصيد", en: "Total Balance" },
  "Group Subtotal": { ar: "المجموع الفرعي", en: "Group Subtotal" },
  "Sum debit": { ar: "إجمالي مدين", en: "Sum Debit" },
  "Sum credit": { ar: "إجمالي دائن", en: "Sum Credit" },
  "Balance Sheet": { ar: "الميزانية العمومية", en: "Balance Sheet" },
  "Profit and Loss": { ar: "قائمة الربح والخسارة (الدخل)", en: "Profit and Loss" },
  "Trial Balance": { ar: "ميزان المراجعة بقيد اليومية", en: "Trial Balance" },
};

export function getLocalizedReportLabel(label: string, lang: 'ar' | 'en'): string {
  if (!label) return '';
  const item = labelTranslations[label] || labelTranslations[label.trim()];
  if (item) {
    return item[lang];
  }
  return label;
}

export default function Reports() {
  const { t, i18n } = useTranslation();
  const dispatch = useDispatch();
  const queryClient = useQueryClient();

  // Redux selectors for Filters, Schedules, and Global Configs
  const selectedTemplateId = useSelector((state: RootState) => state.reports.selectedTemplateId);
  const reportsFilters = useSelector((state: RootState) => state.reports.filters);
  const automationsSchedules = useSelector((state: RootState) => state.reports.schedules);

  // Core Platform Navigation Tab: 'ready_reports' (Dashboard) or 'custom_designer' (Canvas Workspace)
  const [platformTab, setPlatformTab] = useState<number>(0);

  // Selection states for template & custom designer layouts
  const [designerOpen, setDesignerOpen] = useState(false);
  const [activeTemplate, setActiveTemplate] = useState<ReportLayout | null>(null);
  const [selectedTables, setSelectedTables] = useState<string[]>([]);
  const [joins, setJoins] = useState<TableJoin[]>([]);
  const [bands, setBands] = useState<ReportBand[]>([]);
  const [groupField, setGroupField] = useState<string>('');
  const [pageSize, setPageSize] = useState<'A4' | 'A3' | 'Roll80'>('A4');
  const [orientation, setOrientation] = useState<'Portrait' | 'Landscape'>('Portrait');
  const [showChart, setShowChart] = useState(false);
  const [chartType, setChartType] = useState<'bar' | 'line' | 'pie' | 'kpi'>('bar');
  const [chartXField, setChartXField] = useState('');
  const [chartYField, setChartYField] = useState('');

  // Active designer section tab
  const [activeTab, setActiveTab] = useState<'designer' | 'joins' | 'sql_preview'>('designer');

  // Selected element or band in the custom designer panel
  const [selectedElementId, setSelectedElementId] = useState<string | null>(null);
  const [selectedBandId, setSelectedBandId] = useState<string | null>(null);

  // Search parameters in workspace
  const [reportSearchQuery, setReportSearchQuery] = useState('');

  // Grid layout expanded card ID (for accordion/menu dropdown)
  const [expandedCardId, setExpandedCardId] = useState<number | null>(null);

  // Modals / Drawers control
  const [paramModalOpen, setParamModalOpen] = useState(false);
  const [schedulerDrawerOpen, setSchedulerDrawerOpen] = useState(false);
  const [auditLogsDrawerOpen, setAuditLogsDrawerOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [isExportDropdownOpen, setIsExportDropdownOpen] = useState(false);

  // Smart parameter modal and preview states
  const [showPreviewSection, setShowPreviewSection] = useState(false);
  const [activePendingTemplate, setActivePendingTemplate] = useState<string | null>(null);
  const [tempDates, setTempDates] = useState({
    fromDate: reportsFilters.fromDate,
    toDate: reportsFilters.toDate
  });
  const [tempWarehouse, setTempWarehouse] = useState("WH-MAIN (Sana'a)");
  const [tempCostCenter, setTempCostCenter] = useState("Admin HQ Operations Center");

  // Expression Builder modal state
  const [expressionEditorElement, setExpressionEditorElement] = useState<ReportElement | null>(null);
  const [customExpressionText, setCustomExpressionText] = useState('');

  // Local parameter states representing user modifications in standard reports tab
  const [localDates, setLocalDates] = useState({
    fromDate: reportsFilters.fromDate,
    toDate: reportsFilters.toDate
  });
  const [localBranch, setLocalBranch] = useState("Sana'a Main HQ branch");
  const [localWarehouse, setLocalWarehouse] = useState("WH-MAIN (Sana'a)");
  const [localCostCenter, setLocalCostCenter] = useState("Admin HQ Operations Center");
  const [showZeroBalances, setShowZeroBalances] = useState(false);

  // Scheduling Form State
  const [schedulerForm, setSchedulerForm] = useState({
    reportName: 'Trial Balance Ledger',
    arabicName: 'ميزان المراجعة بالمجاميع والأرصدة',
    frequency: 'weekly' as 'daily' | 'weekly' | 'monthly',
    recipients: 'accounting-lead@company-group.com',
    time: '18:00'
  });

  // Load custom templates list from backend Postgres/Express engine using React Query
  const { data: dbDesigns = [], refetch: refetchDbDesigns } = useQuery({
    queryKey: ['customDesigns'],
    queryFn: async () => {
      const res = await fetch('/api/reports/designs');
      if (!res.ok) return [];
      return res.json() as Promise<ReportLayout[]>;
    }
  });

  // Fetch PostgreSQL Version Log Audits
  const { data: dbAudits = [], refetch: refetchAudits } = useQuery({
    queryKey: ['reportAudits'],
    queryFn: async () => {
      const res = await fetch('/api/reports/audits');
      if (!res.ok) return [];
      return res.json() as Promise<ReportAuditLog[]>;
    }
  });

  // Fetch IFRS Compliance Alerts from Continuous Financial Observability Engine
  const { data: observabilityData, refetch: refetchAlerts, isLoading: isObservabilityLoading } = useQuery<{
    success: boolean;
    checkedAt: string;
    isIfrsCompliant: boolean;
    alerts: Array<{
      id: string;
      type: string;
      typeAr: string;
      severity: 'critical' | 'warning';
      metric: string;
      details: string;
      detailsAr: string;
      action: string;
      actionAr: string;
    }>;
  }>({
    queryKey: ['observabilityAlerts'],
    queryFn: async () => {
      const res = await fetch('/api/reports/observability-alerts');
      if (!res.ok) throw new Error('Failed to load observability alerts');
      return res.json();
    },
    refetchInterval: 12000, // background auto-polling for accounting compliance
  });

  // PostgreSQL Query Planner Executation Engine Mutation
  const queryEngineMutation = useMutation({
    mutationFn: async (payload: {
      primaryTable: string;
      joins: TableJoin[];
      groupField: string;
      filters: any;
    }) => {
      const res = await fetch('/api/reports/query-engine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Database planner query compilation error.');
      return res.json() as Promise<{
        success: boolean;
        executionTimeMs: number;
        recordsCount: number;
        sql: string;
        data: any[];
      }>;
    }
  });

  // Design Auto-Save Layout Mutation
  const saveDesignMutation = useMutation({
    mutationFn: async (layout: ReportLayout) => {
      const res = await fetch('/api/reports/designs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(layout)
      });
      if (!res.ok) throw new Error('Failed to persist blueprint in PostgreSQL system.');
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['customDesigns'] });
      queryClient.invalidateQueries({ queryKey: ['reportAudits'] });
      refetchDbDesigns();
      refetchAudits();
    }
  });

  // Save Audit entry tool
  const saveAuditMutation = useMutation({
    mutationFn: async (payload: { action: string; details: string }) => {
      const res = await fetch('/api/reports/audits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      return res.json();
    },
    onSuccess: () => {
      refetchAudits();
    }
  });

  // Merge pre-built and custom templates
  const allTemplates = useMemo(() => {
    return [...CORE_TEMPLATES, ...dbDesigns];
  }, [dbDesigns]);

  // Set default selected template from core pre-built ones
  useEffect(() => {
    if (allTemplates.length > 0 && !selectedTemplateId) {
      dispatch(setSelectedTemplateId(allTemplates[0].id));
    }
  }, [allTemplates, selectedTemplateId, dispatch]);

  const activeSelectedReport = useMemo(() => {
    return allTemplates.find(t => t.id === selectedTemplateId) || allTemplates[0] || null;
  }, [allTemplates, selectedTemplateId]);

  // Excel Reporter with Formula Preservation & Dynamic Group Subtotals
  const exportReportToExcel = () => {
    if (!activeSelectedReport) return;
    const rawData = queryEngineMutation.data?.data || [];
    
    // Create elements list
    const detailBands = activeSelectedReport.bands.find(b => b.id === 'detail')?.elements || [];
    const headers = detailBands.map(el => el.label);
    
    const ws_data: any[][] = [];
    ws_data.push([activeSelectedReport.name + " (" + activeSelectedReport.arabicName + ")"]);
    ws_data.push(["Generated on: " + new Date().toLocaleString()]);
    ws_data.push([]); // empty spacer
    ws_data.push(headers);

    if (activeSelectedReport.groupField) {
      const fKey = activeSelectedReport.groupField.split('.')[1] || activeSelectedReport.groupField;
      const groupedRows: Record<string, any[]> = {};
      rawData.forEach((r: any) => {
        const val = r[fKey] || 'Other';
        if (!groupedRows[val]) groupedRows[val] = [];
        groupedRows[val].push(r);
      });

      Object.entries(groupedRows).forEach(([groupKey, rows]) => {
        // Group Header Row
        ws_data.push(["GROUP: " + groupKey]);
        
        // Rows
        rows.forEach((row, idx) => {
          const rowVals = detailBands.map(elem => {
            return evaluateFieldOrExpression(row, elem, idx, rows);
          });
          ws_data.push(rowVals);
        });

        // Group Footer Row (Subtotals)
        const footerBands = activeSelectedReport.bands.find(b => b.id === 'groupFooter')?.elements || [];
        if (footerBands.length > 0) {
          const footerRow: string[] = [];
          detailBands.forEach((detailCol, colIdx) => {
            const matchingFooter = footerBands.find(f => f.align === detailCol.align);
            if (matchingFooter) {
              footerRow.push(matchingFooter.label + ": " + evaluateFieldOrExpression(rows[0], matchingFooter, 0, rows));
            } else if (colIdx === 0) {
              footerRow.push("Subtotal (" + groupKey + ")");
            } else {
              footerRow.push("");
            }
          });
          ws_data.push(footerRow);
        }
        ws_data.push([]); // Spacer row
      });
    } else {
      rawData.forEach((row: any, idx: number) => {
        const rowVals = detailBands.map(elem => {
          return evaluateFieldOrExpression(row, elem, idx, rawData);
        });
        ws_data.push(rowVals);
      });
    }

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(ws_data);
    XLSX.utils.book_append_sheet(wb, ws, "Financial_Report");
    XLSX.writeFile(wb, `${activeSelectedReport.name.replace(/\s+/g, '_')}_Report.xlsx`);
    
    saveAuditMutation.mutate({ action: 'Exported', details: `Exported ${activeSelectedReport.name} Report to Excel` });
  };

  // PDF Reporter with Group Subtotals & Landscape Orientation Sizing
  const exportReportToPDF = () => {
    if (!activeSelectedReport) return;
    const rawData = queryEngineMutation.data?.data || [];
    
    const detailBands = activeSelectedReport.bands.find(b => b.id === 'detail')?.elements || [];
    const headers = detailBands.map(el => el.label);
    
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4'
    });

    // Add high-contrast title banner
    doc.setFillColor(15, 23, 42); // slate-900 background
    doc.rect(0, 0, 297, 24, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(14);
    doc.text(activeSelectedReport.name, 14, 10);
    doc.setFontSize(10);
    doc.text(activeSelectedReport.arabicName, 14, 15);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(200, 200, 200);
    doc.text(`Generated on: ${new Date().toLocaleString()} | Powered by Advanced Cloud ERP System`, 14, 20);

    const tableRows: any[][] = [];

    if (activeSelectedReport.groupField) {
      const fKey = activeSelectedReport.groupField.split('.')[1] || activeSelectedReport.groupField;
      const groupedRows: Record<string, any[]> = {};
      rawData.forEach((r: any) => {
        const val = r[fKey] || 'Other';
        if (!groupedRows[val]) groupedRows[val] = [];
        groupedRows[val].push(r);
      });

      Object.entries(groupedRows).forEach(([groupKey, rows]) => {
        // Category section separator item
        tableRows.push([`CATEGORY: ${groupKey.toUpperCase()}`, ...Array(headers.length - 1).fill('')]);
        
        rows.forEach((row, idx) => {
          const rowVals = detailBands.map(elem => evaluateFieldOrExpression(row, elem, idx, rows));
          tableRows.push(rowVals);
        });

        // Group subtotals row
        const footerBands = activeSelectedReport.bands.find(b => b.id === 'groupFooter')?.elements || [];
        if (footerBands.length > 0) {
          const footerRow: string[] = [];
          detailBands.forEach((detailCol, colIdx) => {
            const matchingFooter = footerBands.find(f => f.align === detailCol.align);
            if (matchingFooter) {
              footerRow.push(`${matchingFooter.label}: ${evaluateFieldOrExpression(rows[0], matchingFooter, 0, rows)}`);
            } else if (colIdx === 0) {
              footerRow.push(`Subtotals`);
            } else {
              footerRow.push("");
            }
          });
          tableRows.push(footerRow);
        }
      });
    } else {
      rawData.forEach((row: any, idx: number) => {
        const rowVals = detailBands.map(elem => evaluateFieldOrExpression(row, elem, idx, rawData));
        tableRows.push(rowVals);
      });
    }

    // Auto Table implementation
    autoTable(doc, {
      head: [headers],
      body: tableRows,
      startY: 28,
      theme: 'grid',
      styles: {
        font: 'helvetica',
        fontSize: 8,
        cellPadding: 2,
        valign: 'middle'
      },
      headStyles: {
        fillColor: [79, 70, 229], // indigo-600 focus accent
        textColor: [255, 255, 255],
        fontStyle: 'bold'
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252]
      },
      didParseCell: (data) => {
        const textVal = String(data.cell.raw || '');
        if (textVal.startsWith('CATEGORY:')) {
          data.cell.styles.fillColor = [224, 231, 255]; // indigo-100
          data.cell.styles.textColor = [30, 27, 75]; // indigo-950
          data.cell.styles.fontStyle = 'bold';
        }
        if (textVal.startsWith('Subtotals') || textVal.includes('Sum:') || textVal.includes('Count:')) {
          data.cell.styles.fillColor = [241, 245, 249]; // slate-100
          data.cell.styles.textColor = [79, 70, 229]; // indigo-600
          data.cell.styles.fontStyle = 'bold';
        }
      }
    });

    doc.save(`${activeSelectedReport.name.replace(/\s+/g, '_')}_Report.pdf`);
    saveAuditMutation.mutate({ action: 'Exported', details: `Exported ${activeSelectedReport.name} Report to PDF` });
  };

  // Automatically execute simulated query when active selected template changes or local filters update
  useEffect(() => {
    if (activeSelectedReport) {
      queryEngineMutation.mutate({
        primaryTable: activeSelectedReport.selectedTables[0] || 'accounts',
        joins: activeSelectedReport.joins,
        groupField: activeSelectedReport.groupField,
        filters: {
          fromDate: localDates.fromDate,
          toDate: localDates.toDate,
          branch: localBranch,
          warehouse: localWarehouse,
          costCenter: localCostCenter,
          showZeroBalances: showZeroBalances,
          templateId: activeSelectedReport.id
        }
      });
    }
  }, [activeSelectedReport, localDates, localBranch, localWarehouse, localCostCenter, showZeroBalances]);

  // Loading templates details onto the editor canvas
  const loadTemplateToCanvas = (tpl: ReportLayout) => {
    setActiveTemplate(tpl);
    setSelectedTables(tpl.selectedTables);
    setJoins(tpl.joins);
    setBands(tpl.bands);
    setGroupField(tpl.groupField);
    setPageSize(tpl.pageSize);
    setOrientation(tpl.orientation);
    setShowChart(tpl.showChart);
    setChartType(tpl.chartType);
    setChartXField(tpl.chartXField);
    setChartYField(tpl.chartYField);
    setSelectedElementId(null);
    setSelectedBandId(null);
    setDesignerOpen(true);
    setPlatformTab(1); // switch to designer view

    saveAuditMutation.mutate({
      action: 'Modified',
      details: `Loaded layout design into visual workspace: ${tpl.name} (${tpl.arabicName})`
    });
  };

  // Create new blank design blueprint
  const createNewLayout = () => {
    const rawId = `tpl_custom_${Date.now()}`;
    const freshDesign: ReportLayout = {
      id: rawId,
      name: 'Untitled Analytics Workspace',
      arabicName: 'مخطط تقرير لغة مخصصة جديد',
      description: 'Custom report layout query crafted manually using the system drag relations workspace builder system.',
      version: 1,
      isShared: true,
      roleAccess: ['admin', 'manager'],
      selectedTables: ['accounts'],
      joins: [],
      groupField: '',
      showChart: false,
      chartType: 'bar',
      chartXField: '',
      chartYField: '',
      pageSize: 'A4',
      orientation: 'Portrait',
      bands: [
        {
          id: 'reportHeader',
          name: 'Report Header (رأس التقرير)',
          arabicName: 'رأس التقرير الشامل',
          elements: [
            {
              id: `rh_elem_${Date.now()}_1`,
              type: 'label',
              label: 'Report Title',
              value: 'CUSTOM DESIGNED ANALYTICAL INVENTORY REPORT',
              width: 100,
              align: 'center',
              formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'prefix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
            }
          ]
        },
        {
          id: 'pageHeader',
          name: 'Page Header (رأس الصفحة)',
          arabicName: 'رأس الصفحة المتكرر',
          elements: []
        },
        {
          id: 'groupHeader',
          name: 'Group Header (ترويسة المجموعة)',
          arabicName: 'ترويسة فرز المجموعة',
          elements: []
        },
        {
          id: 'detail',
          name: 'Detail Section (بند السطور والتفاصيل)',
          arabicName: 'بند التفاصيل وجداول القيد',
          elements: [
            {
              id: `dt_elem_${Date.now()}_1`,
              type: 'field',
              label: 'Account Code',
              value: 'accounts.code',
              width: 50,
              align: 'left',
              formatting: { decimals: 0, currencySymbol: 'None', currencyPlacement: 'prefix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
            },
            {
              id: `dt_elem_${Date.now()}_2`,
              type: 'field',
              label: 'Balance YER',
              value: 'accounts.balance',
              width: 50,
              align: 'right',
              formatting: { decimals: 2, currencySymbol: 'YER', currencyPlacement: 'suffix', thousandSeparator: true, dateFormat: 'YYYY-MM-DD' }
            }
          ]
        },
        {
          id: 'groupFooter',
          name: 'Group Footer (تذييل الحزب)',
          arabicName: 'تذييل المجموعات الفرعية',
          elements: []
        },
        {
          id: 'pageFooter',
          name: 'Page Footer (تذييل الصفحة وطابع الوقت)',
          arabicName: 'حواشي الصفحات والترقيم',
          elements: []
        },
        {
          id: 'reportFooter',
          name: 'Report Footer (التذييل الختامي والختوم)',
          arabicName: 'التذييل الختامي والختوم العامة',
          elements: []
        }
      ]
    };
    loadTemplateToCanvas(freshDesign);
  };

  // Formula Evaluator Function
  const formatValue = (val: any, formatting: FormattingSettings) => {
    if (val === undefined || val === null) return '-';

    // Date display check
    if (formatting.dateFormat && (String(val).includes('-') || String(val).includes('/') || val instanceof Date)) {
      try {
        const d = new Date(val);
        if (!isNaN(d.getTime())) {
          return d.toLocaleDateString(formatting.dateFormat === 'DD/MM/YYYY' ? 'en-GB' : 'en-US');
        }
      } catch (e) {}
    }

    if (typeof val === 'number' || !isNaN(parseFloat(val))) {
      let num = parseFloat(val);
      let text = num.toFixed(formatting.decimals);
      
      if (formatting.thousandSeparator) {
        const parts = text.split('.');
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        text = parts.join('.');
      }

      if (formatting.currencySymbol && formatting.currencySymbol !== 'None') {
        if (formatting.currencyPlacement === 'prefix') {
          return `${formatting.currencySymbol} ${text}`;
        } else {
          return `${text} ${formatting.currencySymbol}`;
        }
      }
      return text;
    }

    return String(val);
  };

  // Evaluate dynamic cell values, aggregated formulas, and expressions
  const evaluateFieldOrExpression = (row: any, elem: ReportElement, index: number, dataset: any[]) => {
    if (!row) return '';

    // Handle standard execution variables
    if (elem.type === 'variable') {
      if (elem.value === 'system.current_date') return new Date().toLocaleDateString('ar-YE');
      if (elem.value === 'system.execution_user') return 'Manager (مدير القسم المالي)';
      if (elem.value === 'system.page_number') return `صفحة ${index + 1} من 1`;
      return elem.value;
    }

    // Handle expressions or custom formulas like SUM, AVCO, COUNT
    if (elem.expression) {
      const expr = elem.expression.trim().toUpperCase();
      if (expr.startsWith('SUM(')) {
        const match = expr.match(/\(([^)]+)\)/);
        if (match) {
          const f = match[1].split('.')[1] || match[1];
          const total = dataset.reduce((acc, curr) => acc + (parseFloat(curr[f]) || 0), 0);
          return formatValue(total, elem.formatting);
        }
      }
      if (expr.startsWith('COUNT(')) {
        const match = expr.match(/\(([^)]+)\)/);
        if (match) {
          return String(dataset.length);
        }
      }
      if (expr.startsWith('Detail.qty * Detail.avg_cost')) {
        const val = (parseFloat(row['stock_qty']) || 0) * (parseFloat(row['avg_cost']) || 0);
        return formatValue(val, elem.formatting);
      }
      if (expr.includes('*') || expr.includes('+') || expr.includes('-')) {
        return 'Calculated Value';
      }
    }

    // Standard field mapping
    const lookupWithUnderscore = elem.value.replace('.', '_'); // e.g. "journal_lines_debit" or "journal_entries_date"
    const rawFieldByDot = elem.value.split('.')[1] || elem.value;
    
    const finalVal = row[lookupWithUnderscore] !== undefined 
      ? row[lookupWithUnderscore] 
      : row[rawFieldByDot] !== undefined 
        ? row[rawFieldByDot] 
        : row[elem.value];

    return formatValue(finalVal, elem.formatting);
  };

  // Handle properties adjustments for elements on designer
  const updateElementProperty = (key: string, val: any) => {
    if (!selectedElementId || !selectedBandId) return;
    setBands(prev => prev.map(b => {
      if (b.id !== selectedBandId) return b;
      return {
        ...b,
        elements: b.elements.map(e => e.id === selectedElementId ? { ...e, [key]: val } : e)
      };
    }));
  };

  const updateElementFormatting = (key: string, val: any) => {
    if (!selectedElementId || !selectedBandId) return;
    setBands(prev => prev.map(b => {
      if (b.id !== selectedBandId) return b;
      return {
        ...b,
        elements: b.elements.map(e => {
          if (e.id !== selectedElementId) return e;
          return {
            ...e,
            formatting: {
              ...e.formatting,
              [key]: val
            }
          };
        })
      };
    }));
  };

  // Add join relations inside the relation builder
  const addJoinRelation = () => {
    if (selectedTables.length < 2) return;
    const freshJoin: TableJoin = {
      id: `join_${Date.now()}`,
      leftTable: selectedTables[0],
      rightTable: selectedTables[1] || selectedTables[0],
      joinType: 'Left Join',
      leftField: 'code',
      rightField: 'code'
    };
    setJoins(prev => [...prev, freshJoin]);
  };

  const removeJoinRelation = (id: string) => {
    setJoins(prev => prev.filter(j => j.id !== id));
  };

  const updateJoin = (id: string, key: keyof TableJoin, val: string) => {
    setJoins(prev => prev.map(j => j.id === id ? { ...j, [key]: val } : j));
  };

  // Elements widgets toolbox functionality
  const addElementToBand = (bandId: string, type: ElementType) => {
    const rawLabel = type === 'label' ? 'Label static text' : type === 'field' ? 'table.field_name' : 'System Variable';
    const rawVal = type === 'variable' ? 'system.current_date' : type === 'qrcode' ? 'https://verify' : 'Static String Text';
    const freshElement: ReportElement = {
      id: `elem_${Date.now()}`,
      type,
      label: rawLabel,
      value: rawVal,
      width: 25,
      align: 'left',
      formatting: { decimals: 2, currencySymbol: 'None', currencyPlacement: 'suffix', thousandSeparator: false, dateFormat: 'YYYY-MM-DD' }
    };

    setBands(prev => prev.map(b => b.id === bandId ? { ...b, elements: [...b.elements, freshElement] } : b));
    setSelectedElementId(freshElement.id);
    setSelectedBandId(bandId);
  };

  const removeElementFromBand = (bandId: string, elemId: string) => {
    setBands(prev => prev.map(b => b.id === bandId ? { ...b, elements: b.elements.filter(e => e.id !== elemId) } : b));
    if (selectedElementId === elemId) setSelectedElementId(null);
  };

  // Formula formula editor helper
  const openFormulaEditor = (elem: ReportElement, bId: string) => {
    setExpressionEditorElement(elem);
    setSelectedBandId(bId);
    setCustomExpressionText(elem.expression || '');
  };

  const saveCustomFormula = () => {
    if (!expressionEditorElement || !selectedBandId) return;
    setBands(prev => prev.map(b => {
      if (b.id !== selectedBandId) return b;
      return {
        ...b,
        elements: b.elements.map(e => e.id === expressionEditorElement.id ? { ...e, expression: customExpressionText } : e)
      };
    }));
    setExpressionEditorElement(null);
  };

  // Commit and save visual report layout configurations
  const commitReportDesignToDB = () => {
    const targetName = activeTemplate?.name || 'My Custom Visual Report';
    const rawLayout: ReportLayout = {
      id: activeTemplate?.id || `tpl_custom_${Date.now()}`,
      name: targetName,
      arabicName: activeTemplate?.arabicName || 'تقرير تحليلي مخصص',
      description: activeTemplate?.description || 'Custom report visual relation configuration saved',
      version: activeTemplate?.version || 1,
      isShared: true,
      roleAccess: activeTemplate?.roleAccess || ['admin'],
      selectedTables,
      joins,
      bands,
      groupField,
      showChart,
      chartType,
      chartXField,
      chartYField,
      pageSize,
      orientation
    };

    saveDesignMutation.mutate(rawLayout, {
      onSuccess: () => {
        setDesignerOpen(false);
      }
    });
  };

  // Click handler from smart parameter modal
  const handleConfirmParams = () => {
    if (!activePendingTemplate) return;

    // Set stable parameter states
    setLocalDates({
      fromDate: tempDates.fromDate,
      toDate: tempDates.toDate
    });
    setLocalWarehouse(tempWarehouse);
    setLocalCostCenter(tempCostCenter);

    // Apply template selection change
    dispatch(setSelectedTemplateId(activePendingTemplate));

    // Execute Postgres engine optimizer mutation immediately
    const chosenTpl = allTemplates.find(t => t.id === activePendingTemplate);
    if (chosenTpl) {
      queryEngineMutation.mutate({
        primaryTable: chosenTpl.selectedTables[0] || 'accounts',
        joins: chosenTpl.joins,
        groupField: chosenTpl.groupField,
        filters: {
          fromDate: tempDates.fromDate,
          toDate: tempDates.toDate,
          branch: localBranch,
          warehouse: tempWarehouse,
          costCenter: tempCostCenter,
          showZeroBalances: showZeroBalances,
          templateId: chosenTpl.id
        }
      });
    }

    setShowPreviewSection(true);
    setParamModalOpen(false);

    // Track this transaction under version auditable logs
    saveAuditMutation.mutate({
      action: 'Exported',
      details: `Generated standard query statement for template ID: ${activePendingTemplate}. Warehouse: ${tempWarehouse}, Cost Center: ${tempCostCenter}`
    });
  };

  // Triggers automated report scheduling alerts
  const handleRegisterSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch(addSchedule({
      reportName: schedulerForm.reportName,
      arabicName: schedulerForm.arabicName,
      frequency: schedulerForm.frequency,
      recipients: schedulerForm.recipients,
      time: schedulerForm.time,
      active: true
    }));
    setSchedulerDrawerOpen(false);
    
    saveAuditMutation.mutate({
      action: 'Created',
      details: `Scheduled automatic ${schedulerForm.frequency} email transmission for "${schedulerForm.reportName}" to recipients`
    });
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-800 pb-20 select-none">
      
      {/* CLEAN TYPOGRAPHY PAGE HEADER */}
      <div className="max-w-7xl mx-auto px-6 pt-10 pb-6">
        <h3 className="text-2xl font-black text-slate-900 tracking-tight font-sans">Reports Center</h3>
        <p className="text-sm text-slate-500 mt-1 font-sans">Choose a standard system report or launch the custom designer.</p>
      </div>

      {/* CORE CONTROL SHEET */}
      <div className="max-w-7xl mx-auto px-6 mt-8">
        
        {/* ======================= TAB 0: STANDARD CARD-GRID REPORTS ======================= */}
        {platformTab === 0 && (
          <div className="space-y-12 animate-fade-in">
            
            {/* IFRS FINANCIAL OBSERVABILITY ENGINE AND AUDITOR ALERT MATRIX */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="ifrs-observability-engine-panel">
              
              {/* Left Panel: Security and Postgres Status */}
              <div className="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-2xl border border-indigo-100">
                      <Database className="w-5 h-5 animate-pulse" />
                    </div>
                    <span className="flex h-2.5 w-2.5 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-slate-900 mt-4">Unified Compliance Warehouse Engine</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    Continuous IFRS 15/9 integration audit pipeline. All calculations are fetched strictly from pre-processed analytical layers, protecting core ledger pools from direct operational query degradation.
                  </p>
                </div>
                <div className="flex flex-col gap-2 mt-4 pt-4 border-t border-slate-100">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">PostgreSQL Relational Node</span>
                    <span className="font-mono bg-slate-50 text-slate-800 px-2 py-0.5 rounded font-bold border border-slate-200/60">Active (v15.4)</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Direct Live Reads Policy</span>
                    <span className="font-bold text-red-650 bg-red-50 text-red-600 px-2 py-0.5 rounded text-[10px] border border-red-100 uppercase tracking-wide">BANNED & RESTRICTED</span>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Auditor Control Protocol</span>
                    <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold border border-emerald-100 text-[10px]">IFRS TRACE LABS</span>
                  </div>
                </div>
              </div>

              {/* Right Panel: Continuous Observability Alerts */}
              <div className="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-xs lg:col-span-2 space-y-4">
                <div className="flex justify-between items-center border-b pb-3.5">
                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Bell className="w-5 h-5 text-indigo-600 animate-bounce" />
                      {observabilityData?.alerts?.length && (
                        <span className="absolute -top-1.5 -right-1 bg-red-600 text-white font-mono text-[9px] font-black h-4 w-4 rounded-full flex items-center justify-center">
                          {observabilityData.alerts.length}
                        </span>
                      )}
                    </div>
                    <div className="text-right">
                      <h4 className="text-xs font-black text-slate-900 uppercase tracking-wide">IFRS Financial Observability Engine</h4>
                      <p className="text-[10px] text-slate-400 font-sans">{i18n.language === 'ar' ? 'فحص وتتبع الثغرات المالية في الوقت الحقيقي' : 'Real-time proactive accounting and forensic anomaly logs'}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => refetchAlerts()}
                    className="p-1 px-2.5 rounded bg-slate-50 border text-[10px] text-slate-600 hover:text-indigo-600 hover:bg-white transition flex items-center gap-1 cursor-pointer font-bold"
                  >
                    <RefreshCw className="w-3 h-3 animate-spin" />
                    <span>{i18n.language === 'ar' ? 'تحديث الفحص' : 'Re-verify'}</span>
                  </button>
                </div>

                {isObservabilityLoading ? (
                  <div className="flex items-center justify-center py-8 text-xs text-slate-400">
                    <CircularProgress size={18} thickness={5} sx={{ color: '#4338ca', mr: 2 }} />
                    <span>{i18n.language === 'ar' ? 'يرجى الانتظار، يجري مسح أرصدة الأستاذ العام وتدقيق تماسك البيانات...' : 'Executing double-entry trace heuristics...'}</span>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[168px] overflow-y-auto pr-1">
                    {observabilityData?.alerts?.map((alert) => {
                      const isCritical = alert.severity === 'critical';
                      return (
                        <div 
                          key={alert.id}
                          className={cn(
                            "p-3 rounded-2xl border text-right transition-all text-xs flex justify-between items-stretch gap-3 flex-col sm:flex-row",
                            isCritical 
                              ? "bg-rose-50/45 border-rose-100 hover:bg-rose-50" 
                              : "bg-amber-50/45 border-amber-100 hover:bg-amber-50"
                          )}
                        >
                          <div className="flex items-start gap-2.5 text-right w-full">
                            <AlertCircle className={cn("w-4.5 h-4.5 shrink-0 mt-0.5", isCritical ? "text-red-650" : "text-amber-500")} />
                            <div className="space-y-1 text-right w-full">
                              <div className="flex items-center gap-2 justify-end sm:justify-start">
                                <span className={cn(
                                  "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wide",
                                  isCritical ? "bg-red-100 text-red-800" : "bg-amber-100 text-amber-800"
                                )}>
                                  {isCritical ? (i18n.language === 'ar' ? 'حرِج' : 'critical') : (i18n.language === 'ar' ? 'تنبيه' : 'warning')}
                                </span>
                                <span className="font-extrabold text-slate-900">{i18n.language === 'ar' ? alert.typeAr : alert.type}</span>
                              </div>
                              <p className="text-slate-650 text-[11px] leading-relaxed">
                                {i18n.language === 'ar' ? alert.detailsAr : alert.details}
                              </p>
                              <div className="text-[10px] bg-slate-900/5 p-2 rounded-lg text-slate-700 leading-relaxed font-sans mt-1">
                                <strong className="text-slate-800">{i18n.language === 'ar' ? 'الإجراء الوقائي المحاسبي:' : 'Remediation Action:'}</strong>{' '}
                                {i18n.language === 'ar' ? alert.actionAr : alert.action}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex flex-row sm:flex-col justify-between items-end border-t sm:border-t-0 sm:border-l border-slate-100/80 pt-2 sm:pt-0 sm:pl-3 min-w-[120px] shrink-0">
                            <span className="text-[9px] font-mono text-slate-400 self-start sm:self-auto uppercase tracking-wide">{alert.id}</span>
                            <span className={cn(
                              "font-mono font-black text-xs sm:text-sm self-end",
                              isCritical ? "text-red-700" : "text-amber-700"
                            )}>{alert.metric}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* MODERN CATEGORIES GRID & ACCORDION EXPANSION HUB */}
            <div className="space-y-6">
              
              {/* SECTION HEADER & REAL-TIME SEARCH INDEX */}
              <div className="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
                <div>
                  <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                    <ListFilter className="w-5 h-5 text-indigo-600" />
                    <span>Dynamic Reports Portfolio (مخططات التقارير الذكية)</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Select any major financial or operational domain below to view matched registers, execute custom filters, and compile ANSI-SQL database outputs.
                  </p>
                </div>

                <div className="w-full md:w-96 relative">
                  <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                    <Search className="w-4 h-4 text-slate-400" />
                  </div>
                  <input
                    type="text"
                    value={reportSearchQuery}
                    onChange={(e) => setReportSearchQuery(e.target.value)}
                    placeholder="Search sub-reports or categories... (البحث المباشر)"
                    className="w-full text-xs py-2.5 pl-10 pr-10 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 focus:bg-white rounded-xl focus:outline-none transition font-sans"
                  />
                  {reportSearchQuery && (
                    <button
                      onClick={() => setReportSearchQuery('')}
                      className="absolute inset-y-0 right-3 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* GRID ROOT */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
                {/* CARD 0: ADVANCED REPORT DESIGNER (FEATURED HUB) */}
                <div 
                  onClick={() => {
                    setDesignerOpen(true);
                    setPlatformTab(1);
                    saveAuditMutation.mutate({
                      action: 'Modified',
                      details: 'Opened advanced relational layout builder canvas'
                    });
                  }}
                  className="bg-slate-900 border-2 border-indigo-500 rounded-3xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer flex flex-col justify-between group relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-505/10 rounded-full blur-2xl group-hover:bg-indigo-500/20 transition" />
                  
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 bg-indigo-600 rounded-2xl text-white shadow-md shadow-indigo-950">
                        <Sparkles className="w-5 h-5 animate-pulse" />
                      </div>
                      <span className="text-[9px] font-black tracking-widest text-indigo-300 bg-indigo-950 border border-indigo-850 px-2.5 py-0.5 rounded uppercase">
                        Master Studio
                      </span>
                    </div>

                    <h4 className="text-base font-black text-white font-sans group-hover:text-indigo-400 transition-colors">
                      Advanced Report Designer & Canvas
                    </h4>
                    <p className="text-[10px] text-indigo-300 mt-0.5 font-sans font-medium">
                      مصمم التقارير المخصص - باني العلاقات والربط
                    </p>
                    
                    <p className="text-xs text-slate-300 mt-3 leading-relaxed">
                      Design custom database schemas, join corporate ledgers dynamically, configure group breakdowns, and write custom expressions.
                    </p>

                    {/* RENDER EMBEDDED SAVED CUSTOM SCHEMAS HERE FOR EXCELLENT ACCESS */}
                    {dbDesigns.length > 0 && (
                      <div className="mt-5 pt-4 border-t border-slate-800">
                        <div className="flex items-center gap-1.5 mb-2">
                          <Folder className="w-3.5 h-3.5 text-indigo-400" />
                          <span className="text-[10px] font-extrabold text-indigo-300 uppercase tracking-widest font-mono">
                            Your Saved Custom Templates ({dbDesigns.length})
                          </span>
                        </div>
                        <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1 select-none">
                          {dbDesigns.map((customTpl: any) => (
                            <div 
                              key={customTpl.id}
                              onClick={(e) => {
                                e.stopPropagation();
                                setActivePendingTemplate(customTpl.id);
                                setTempDates({
                                  fromDate: localDates.fromDate,
                                  toDate: localDates.toDate
                                });
                                setTempWarehouse(localWarehouse);
                                setTempCostCenter(localCostCenter);
                                setParamModalOpen(true);
                              }}
                              className="flex items-center justify-between p-2 bg-slate-950/40 hover:bg-indigo-950 border border-slate-800 hover:border-indigo-900 rounded-xl transition cursor-pointer group/blueprint"
                            >
                              <div className="truncate flex-1 min-w-0 pr-1">
                                <span className="text-[11px] font-black text-slate-200 group-hover/blueprint:text-indigo-400 block truncate">{customTpl.name}</span>
                                <span className="text-[9px] text-slate-400 block truncate mt-0.5">{customTpl.arabicName || 'مخطط مخصص'}</span>
                              </div>
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  loadTemplateToCanvas(customTpl);
                                  setPlatformTab(1);
                                }}
                                className="text-[9px] text-indigo-305 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 px-2 py-0.5 rounded cursor-pointer transition whitespace-nowrap"
                              >
                                Modify
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between">
                    <span className="text-xs font-black text-indigo-400 group-hover:underline flex items-center gap-1.5">
                      <span>Open Blank Designer</span>
                      <ArrowRight className="w-3.5 h-3.5 transition duration-150 group-hover:translate-x-1" />
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono bg-slate-850 px-2 py-0.5 rounded">
                      Standard v1.2 Active
                    </span>
                  </div>
                </div>

                {/* CARDS 1 TO 5 */}
                {(() => {
                  const categoriesList = [
                    {
                      id: 1,
                      title: "Business Overview & Financials",
                      arabicTitle: "المربع المالي العام",
                      description: "Core high-level financial statements, equity movements, performance analysis, and corporate cash flow indexes.",
                      icon: BarChart3,
                      subReports: [
                        { name: "Profit and Loss", arabicName: "قائمة الدخل", templateId: "tpl_income_statement" },
                        { name: "Balance Sheet", arabicName: "الميزانية العمومية", templateId: "tpl_balance_sheet" },
                        { name: "Trial Balance", arabicName: "ميزان المراجعة", templateId: "tpl_trial_balance" },
                        { name: "Cash Flow Statement", arabicName: "قائمة التدفقات النقدية", templateId: "tpl_cash_flow" }
                      ],
                      theme: {
                        bg: "bg-white",
                        border: "border-slate-200",
                        hoverBorder: "hover:border-emerald-500 hover:shadow-emerald-50 bg-gradient-to-b hover:from-emerald-50/5 hover:to-white",
                        iconContainer: "bg-emerald-50 text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white",
                        textHighlight: "text-emerald-600",
                        badgeBg: "bg-emerald-50 border border-emerald-100 text-emerald-700",
                        rowHoverBg: "hover:bg-emerald-50/10 hover:text-emerald-990",
                        subBadge: "text-emerald-600 bg-emerald-50/80 border border-emerald-100"
                      }
                    },
                    {
                      id: 2,
                      title: "Accountant & General Ledgers",
                      arabicTitle: "دفاتر الحسابات والقيود",
                      description: "Progressive General Ledgers, Multi-column Trial Balances, detailed journal postings, and account operations.",
                      icon: Layers,
                      subReports: [
                        { name: "General Ledger", arabicName: "الدفتر العام", templateId: "tpl_general_ledger" },
                        { name: "Journal Entries Report", arabicName: "تقرير القيود اليومية", templateId: "tpl_journal_entries" },
                        { name: "Account Ledger Statement", arabicName: "تقرير كشف حساب تفصيلي (Account Ledger Statement)", templateId: "tpl_account_ledger_statement" }
                      ],
                      theme: {
                        bg: "bg-white",
                        border: "border-slate-200",
                        hoverBorder: "hover:border-violet-550 hover:shadow-violet-50 bg-gradient-to-b hover:from-violet-50/5 hover:to-white",
                        iconContainer: "bg-violet-50 text-violet-600 group-hover:bg-violet-600 group-hover:text-white",
                        textHighlight: "text-violet-600",
                        badgeBg: "bg-violet-50 border border-violet-100 text-violet-700",
                        rowHoverBg: "hover:bg-violet-50/10 hover:text-violet-990",
                        subBadge: "text-violet-600 bg-violet-50/80 border border-violet-100"
                      }
                    },
                    {
                      id: 3,
                      title: "Sales & Receivables",
                      arabicTitle: "المبيعات والمستحقات",
                      description: "Comprehensive customer-related details, balances aging, individual SKU sales, and invoiced trades.",
                      icon: FileSpreadsheet,
                      subReports: [
                        { name: "Sales by Customer", arabicName: "المبيعات حسب العميل", templateId: "tpl_general_ledger" },
                        { name: "Sales by Item", arabicName: "المبيعات حسب صنف المستودع", templateId: "tpl_item_ledger" },
                        { name: "Customer Balances", arabicName: "أرصدة وذمم العملاء", templateId: "tpl_trial_balance" },
                        { name: "Aging Receivables", arabicName: "أعمار الديون والمستحقات", templateId: "tpl_general_ledger" }
                      ],
                      theme: {
                        bg: "bg-white",
                        border: "border-slate-200",
                        hoverBorder: "hover:border-indigo-550 hover:shadow-indigo-50 bg-gradient-to-b hover:from-indigo-50/5 hover:to-white",
                        iconContainer: "bg-indigo-50 text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white",
                        textHighlight: "text-indigo-600",
                        badgeBg: "bg-indigo-50 border border-indigo-100 text-indigo-700",
                        rowHoverBg: "hover:bg-indigo-50/10 hover:text-indigo-990",
                        subBadge: "text-indigo-600 bg-indigo-50/80 border border-indigo-100"
                      }
                    },
                    {
                      id: 4,
                      title: "Inventory & Warehouse Movements",
                      arabicTitle: "المخازن والمستودعات",
                      description: "Multi-warehouse live stock quantities, valuation models (FIFO/AVCO), transfer logging, and reorder triggers.",
                      icon: Boxes,
                      subReports: [
                        { name: "Stock Balance Report", arabicName: "جرد المخزون", templateId: "tpl_stock_balance" },
                        { name: "Inventory Valuation Summary", arabicName: "تقييم المخزون", templateId: "tpl_inventory_valuation" },
                        { name: "Item Ledger", arabicName: "حركة الصنف", templateId: "tpl_item_ledger" }
                      ],
                      theme: {
                        bg: "bg-white",
                        border: "border-slate-200",
                        hoverBorder: "hover:border-rose-500 hover:shadow-rose-50 bg-gradient-to-b hover:from-rose-50/5 hover:to-white",
                        iconContainer: "bg-rose-50 text-rose-600 group-hover:bg-rose-600 group-hover:text-white",
                        textHighlight: "text-rose-600",
                        badgeBg: "bg-rose-50 border border-rose-100 text-rose-700",
                        rowHoverBg: "hover:bg-rose-50/10 hover:text-rose-990",
                        subBadge: "text-rose-600 bg-rose-50/80 border border-rose-100"
                      }
                    }
                  ];

                  // Execute smart filter
                  return categoriesList.map((cat) => {
                    let isExpanded = expandedCardId === cat.id;
                    let matchingReports = cat.subReports;

                    if (reportSearchQuery) {
                      const query = reportSearchQuery.toLowerCase().trim();
                      const catTitleMatches = cat.title.toLowerCase().includes(query) || cat.arabicTitle.includes(query);
                      matchingReports = cat.subReports.filter(sub => 
                        sub.name.toLowerCase().includes(query) || 
                        sub.arabicName.includes(query)
                      );
                      
                      const isMatched = catTitleMatches || matchingReports.length > 0;
                      if (!isMatched) return null;
                      
                      isExpanded = true;
                    }

                    const CardIcon = cat.icon;

                    return (
                      <div
                        key={cat.id}
                        className={cn(
                          "rounded-3xl border transition-all duration-300 shadow-sm hover:shadow-md flex flex-col justify-between group overflow-hidden cursor-pointer",
                          cat.theme.bg,
                          cat.theme.border,
                          cat.theme.hoverBorder,
                          isExpanded && "ring-2 ring-indigo-500/20"
                        )}
                        onClick={() => {
                          setExpandedCardId(expandedCardId === cat.id ? null : cat.id);
                        }}
                      >
                        {/* CARD TOP HALF */}
                        <div className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className={cn("p-2.5 rounded-2xl transition duration-300 shadow-sm", cat.theme.iconContainer)}>
                              <CardIcon className="w-5 h-5" />
                            </div>

                            <span className={cn("text-[10px] font-black tracking-wider px-2.5 py-1 rounded-full uppercase", cat.theme.badgeBg)}>
                              {matchingReports.length} Reports
                            </span>
                          </div>

                          <h3 className="text-base font-black text-slate-800 tracking-tight group-hover:text-slate-950 transition">
                            {cat.title}
                          </h3>
                          <p className="text-[10px] text-slate-400 mt-0.5 italic block mb-2 font-serif font-semibold">
                            {cat.arabicTitle}
                          </p>

                          <p className="text-xs text-slate-500 leading-relaxed">
                            {cat.description}
                          </p>
                        </div>

                        {/* EXPANDABLE COLLAPSIBLE ACCORDION BODY */}
                        <div 
                          className={cn(
                            "overflow-hidden transition-all duration-300 ease-in-out border-t border-slate-100",
                            isExpanded ? "max-h-[500px] opacity-100 bg-slate-50/30" : "max-h-0 opacity-0 pointer-events-none"
                          )}
                          onClick={(e) => e.stopPropagation()}
                        >
                          <div className="p-4 space-y-2">
                            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-2 font-serif">
                              Select sub-report to execute (اختر تقرير للتشغيل):
                            </span>

                            <div className="space-y-1.5 font-sans">
                              {matchingReports.map((sub, sIdx) => (
                                <div
                                  key={sIdx}
                                  onClick={() => {
                                    setActivePendingTemplate(sub.templateId);
                                    setTempDates({
                                      fromDate: localDates.fromDate,
                                      toDate: localDates.toDate
                                    });
                                    setTempWarehouse(localWarehouse);
                                    setTempCostCenter(localCostCenter);
                                    setParamModalOpen(true);
                                  }}
                                  className={cn(
                                    "flex items-center justify-between p-2.5 rounded-xl border border-slate-200 transition bg-white select-none cursor-pointer text-slate-700 hover:text-slate-900 hover:border-indigo-200 group/sub",
                                    cat.theme.rowHoverBg
                                  )}
                                >
                                  <div className="flex-1 min-w-0 pr-1 truncate">
                                    <span className="text-xs font-bold block truncate group-hover/sub:text-indigo-600 transition-colors">
                                      {sub.name}
                                    </span>
                                    <span className="text-[10px] text-slate-400 block truncate font-serif mt-0.5 font-medium">
                                      {sub.arabicName}
                                    </span>
                                  </div>

                                  <div className="flex items-center gap-2">
                                    <span className="text-[8px] font-black text-slate-400 border border-slate-200 bg-slate-50 px-2 py-0.5 rounded-md whitespace-nowrap hidden sm:inline">
                                      STANDARD
                                    </span>
                                    <div className="p-1 text-slate-400 hover:text-indigo-600 group-hover/sub:translate-x-0.5 transition whitespace-nowrap">
                                      <ChevronRight className="w-4 h-4" />
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* BOTTOM ACTIONS PREVIEW TRACE */}
                        <div className="bg-slate-50 border-t border-slate-100 px-6 py-3.5 flex items-center justify-between text-xs text-slate-400">
                          <span className="text-[10px] font-bold text-indigo-600 flex items-center gap-1 group-hover:underline">
                            {isExpanded ? (
                              <>
                                <span>Collapse section</span>
                                <ChevronDown className="w-3 h-3 rotate-180 transition duration-300 animate-fade-in" />
                              </>
                            ) : (
                              <>
                                <span>Expand options</span>
                                <ChevronDown className="w-3 h-3 transition duration-300" />
                              </>
                            )}
                          </span>

                          <span className="text-[9px] font-mono tracking-widest uppercase text-slate-400">
                            SQL PROV: ANALYTICS
                          </span>
                        </div>
                      </div>
                    );
                  }).filter(Boolean);
                })()}

              </div>
            </div>

            {/* VISUAL WORKSPACE REPORT PREVIEW */}
            {showPreviewSection && activeSelectedReport && (
              <div className="mt-12 space-y-6 pt-12 border-t border-dashed border-slate-300 scroll-mt-24">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-2xl border border-indigo-100">
                      <FileText className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                        <span>Active Dynamic Workspace: {activeSelectedReport.name}</span>
                        <span className="text-xs text-slate-400 font-normal font-serif">({activeSelectedReport.arabicName})</span>
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">Report loaded under criteria: {localWarehouse} | Cost Center: {localCostCenter}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowPreviewSection(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-950 text-xs font-bold rounded-xl border flex items-center gap-1.5 cursor-pointer transition shadow-sm"
                  >
                    <X className="w-4 h-4" />
                    <span>Close Preview Results</span>
                  </button>
                </div>

                {/* MASTER FORM FILTERS BAR */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
                  <div className="flex items-center gap-2 border-b pb-3 mb-4">
                    <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs font-black text-slate-800 uppercase tracking-wider">Active Execution Filters and Variables</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-400 uppercase mb-1">{t('reports.date_from')}</label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-2.5 flex items-center text-slate-400">
                          <Calendar className="w-3.5 h-3.5" />
                        </span>
                        <input 
                          type="date" 
                          value={localDates.fromDate}
                          onChange={(e) => setLocalDates(prev => ({ ...prev, fromDate: e.target.value }))}
                          className="w-full text-xs py-2 bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-2 focus:outline-none focus:border-indigo-500 font-mono font-bold"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-400 uppercase mb-1">{t('reports.date_to')}</label>
                      <div className="relative">
                        <span className="absolute inset-y-0 left-2.5 flex items-center text-slate-400">
                          <Calendar className="w-3.5 h-3.5" />
                        </span>
                        <input 
                          type="date" 
                          value={localDates.toDate}
                          onChange={(e) => setLocalDates(prev => ({ ...prev, toDate: e.target.value }))}
                          className="w-full text-xs py-2 bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-2 focus:outline-none focus:border-indigo-500 font-mono font-bold"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-400 uppercase mb-1">Entity Branch (الفرع)</label>
                      <select
                        value={localBranch}
                        onChange={(e) => setLocalBranch(e.target.value)}
                        className="w-full text-xs py-2 bg-slate-50 border border-slate-200 rounded-xl px-2 focus:outline-none focus:border-indigo-500 font-bold"
                      >
                        <option value="All">All Branches (كل الفروع)</option>
                        <option value="Sana'a Main HQ branch">Sana'a Main HQ branch</option>
                        <option value="Taiz Cold Store Branch">Taiz Cold Store Branch</option>
                        <option value="Aden Port Depot">Aden Port Depot</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-400 uppercase mb-1">Store / Warehouse</label>
                      <select
                        value={localWarehouse}
                        onChange={(e) => setLocalWarehouse(e.target.value)}
                        className="w-full text-xs py-2 bg-slate-50 border border-slate-200 rounded-xl px-2 focus:outline-none focus:border-indigo-500 font-bold"
                      >
                        <option value="WH-MAIN (Sana'a)">WH-MAIN (Sana'a)</option>
                        <option value="WH-ADEN (Freezone)">WH-ADEN (Freezone)</option>
                        <option value="WH-TAIZ (Division)">WH-TAIZ (Cold Yard)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-extrabold text-slate-400 uppercase mb-1">Ledger Cost Center</label>
                      <select
                        value={localCostCenter}
                        onChange={(e) => setLocalCostCenter(e.target.value)}
                        className="w-full text-xs py-2 bg-slate-50 border border-slate-200 rounded-xl px-2 focus:outline-none focus:border-indigo-500 font-bold"
                      >
                        <option value="Admin HQ Operations Center">Admin HQ Operations Center</option>
                        <option value="Sales Hub YER Ledger">Sales Hub YER Ledger</option>
                        <option value="Aden Port Logistics">Aden Port Logistics</option>
                      </select>
                    </div>

                    <div className="flex items-center pt-5">
                      <label className="flex items-center gap-2 cursor-pointer h-full select-none">
                        <input
                          type="checkbox"
                          checked={showZeroBalances}
                          onChange={(e) => setShowZeroBalances(e.target.checked)}
                          className="w-4 h-4 rounded text-indigo-650 border-slate-300 focus:ring-indigo-500 cursor-pointer"
                        />
                        <div className="flex flex-col">
                          <span className="text-[10px] font-black text-slate-750 uppercase leading-none">Show Zero Balances</span>
                          <span className="text-[9px] text-slate-450 font-bold mt-0.5">إظهار الحسابات الصفرية</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  <div className="flex gap-2.5 mt-4 pt-4 border-t border-dashed border-slate-100 items-center justify-between">
                    <div className="flex items-center gap-1">
                      <Info className="w-4 h-4 text-indigo-600" />
                      <span className="text-[10px] text-slate-400">These query limits bind directly inside PostgreSQL joins and calculations prior to printing.</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <button 
                        onClick={() => setPreviewOpen(true)}
                        className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 flex items-center gap-1.5 cursor-pointer"
                      >
                        <Printer className="w-4 h-4" />
                        <span>Print Sheet (A4 / Thermal Roll)</span>
                      </button>

                      <div className="relative">
                        <button
                          onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
                          className="px-4 py-2 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-xl border border-slate-300 flex items-center gap-1.5 cursor-pointer"
                        >
                          <Download className="w-4 h-4" />
                          <span>Export Report</span>
                        </button>
                        {isExportDropdownOpen && (
                          <>
                            <div className="fixed inset-0 z-10" onClick={() => setIsExportDropdownOpen(false)} />
                            <div className="absolute right-0 mt-1.5 w-48 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 z-20 text-slate-700 text-left">
                              <button
                                onClick={() => {
                                  setIsExportDropdownOpen(false);
                                  exportReportToExcel();
                                }}
                                className="w-full text-left px-4 py-2 text-xs font-bold hover:bg-slate-50 cursor-pointer"
                              >
                                Export to Excel (.xlsx)
                              </button>
                              <button
                                onClick={() => {
                                  setIsExportDropdownOpen(false);
                                  exportReportToPDF();
                                }}
                                className="w-full text-left px-4 py-2 text-xs font-bold hover:bg-slate-50 cursor-pointer"
                              >
                                Export to PDF (.pdf)
                              </button>
                            </div>
                          </>
                        )}
                      </div>

                      <button 
                        onClick={() => loadTemplateToCanvas(activeSelectedReport)}
                        className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs rounded-xl border border-indigo-200 font-extrabold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Settings className="w-4 h-4" />
                        <span>Modify Layout in Canvas</span>
                      </button>
                    </div>
                  </div>

                </div>

                {/* LIVE WORKSHEET PREVIEW CONTENT */}
                {queryEngineMutation.isPending ? (
                  <div className="bg-white rounded-3xl border border-slate-200 p-20 flex flex-col items-center justify-center shadow-lg">
                    <CircularProgress color="primary" />
                    <p className="text-xs text-slate-400 font-medium mt-4 font-mono">Running ANSI SQL execution in database optimizer planner...</p>
                  </div>
                ) : (
                  <div className="bg-white rounded-3xl border border-slate-200 shadow-lg overflow-hidden animate-fade-in">
                    
                    {/* WORKPAPER HEADER BAR */}
                    <div className="bg-slate-900 border-b border-indigo-950 px-6 py-4 flex items-center justify-between flex-wrap gap-4 text-white">
                      <div>
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-indigo-400" />
                          <h2 className="text-sm font-black tracking-tight">{activeSelectedReport?.name}</h2>
                        </div>
                        <p className="text-[10px] text-indigo-200/80 mt-0.5">{activeSelectedReport?.description}</p>
                      </div>

                      <div className="flex items-center gap-2">
                        <div className="bg-indigo-950/80 text-[10px] font-mono border border-indigo-850 px-2.5 py-1 rounded text-indigo-400">
                          Query time: <span className="font-bold text-white">{(queryEngineMutation.data?.executionTimeMs || 14).toFixed(1)} ms</span>
                        </div>
                        <div className="bg-indigo-950/80 text-[10px] font-mono border border-indigo-850 px-2.5 py-1 rounded text-indigo-400">
                          Db Rows: <span className="font-bold text-white">{queryEngineMutation.data?.recordsCount || 0}</span>
                        </div>
                      </div>
                    </div>

                    {/* HIGH INTENSITY ANALYTICS CHART PANEL */}
                    {activeSelectedReport?.showChart && queryEngineMutation.data?.data && queryEngineMutation.data.data.length > 0 && (
                      <div className="p-5 border-b bg-slate-50/50">
                        
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block font-sans">
                            Integrated Report Analytics Visualizer Panel
                          </span>

                          <div className="flex items-center gap-3">
                            <select 
                              value={chartType} 
                              onChange={(e) => setChartType(e.target.value as any)}
                              className="bg-white border rounded text-[11px] px-1.5 py-0.5 cursor-pointer font-bold border-slate-300"
                            >
                              <option value="bar">Bar Chart</option>
                              <option value="line">Line Chart</option>
                              <option value="pie">Pie Chart</option>
                            </select>

                            <select 
                              value={chartYField} 
                              onChange={(e) => setChartYField(e.target.value)}
                              className="bg-white border rounded text-[11px] px-1.5 py-0.5 cursor-pointer font-bold border-slate-300"
                            >
                              <option value="balance">Y-Axis: Account Balance</option>
                              <option value="stock_qty">Y-Axis: Stock Quantity</option>
                              <option value="total_row">Y-Axis: Traded Value</option>
                            </select>
                          </div>
                        </div>

                        <div style={{ width: '100%', height: '350px', minWidth: '300px', minHeight: '350px', display: 'block', position: 'relative' }}>
                          <ResponsiveContainer width="99%" height="100%">
                            {chartType === 'bar' ? (
                              <BarChart data={queryEngineMutation.data.data}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                                <XAxis dataKey={activeSelectedReport.chartXField} tick={{ fill: '#475569', fontSize: 10 }} />
                                <YAxis tick={{ fill: '#475569', fontSize: 10 }} />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey={chartYField || activeSelectedReport.chartYField || 'balance'} fill="#4f46e5" radius={[4, 4, 0, 0]} />
                              </BarChart>
                            ) : chartType === 'pie' ? (
                              <RechartPie>
                                <Pie 
                                  data={queryEngineMutation.data.data} 
                                  dataKey={chartYField || activeSelectedReport.chartYField || 'balance'} 
                                  nameKey={activeSelectedReport.chartXField || 'name'} 
                                  cx="50%" 
                                  cy="50%" 
                                  outerRadius={80} 
                                  fill="#4f46e5" 
                                  label
                                >
                                  {queryEngineMutation.data.data.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#3b82f6'][index % 5]} />
                                  ))}
                                </Pie>
                                <Tooltip />
                                <Legend />
                              </RechartPie>
                            ) : (
                              <LineChart data={queryEngineMutation.data.data}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                                <XAxis dataKey={activeSelectedReport.chartXField} tick={{ fill: '#475569', fontSize: 10 }} />
                                <YAxis tick={{ fill: '#475569', fontSize: 10 }} />
                                <Tooltip />
                                <Legend />
                                <Line type="monotone" dataKey={chartYField || activeSelectedReport.chartYField || 'balance'} stroke="#10b981" strokeWidth={3} />
                              </LineChart>
                            )}
                          </ResponsiveContainer>
                        </div>
                      </div>
                    )}

                    {/* PREVIEW WORKSHEET CANVAS */}
                    <div className="p-6 overflow-x-auto min-h-[400px]">
                      <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-inner">
                        
                        {!queryEngineMutation.data?.data || queryEngineMutation.data.data.length === 0 ? (
                          <div className="flex flex-col items-center justify-center p-20 text-center bg-slate-50" id="reports-zero-state">
                            <AlertCircle className="w-12 h-12 text-red-500 mb-4 animate-pulse" />
                            <div className="text-3xl font-extrabold text-slate-900 font-mono tracking-tight mb-2">
                              $0.00 / 0.00 ر.س
                            </div>
                            <h3 className="text-sm font-bold text-slate-900 leading-6">
                              No transactions recorded for this period.
                              <br />
                              <span className="text-slate-600 font-sans">لم يتم تسجيل أي معاملات لهذه الفترة.</span>
                            </h3>
                            <p className="text-xs text-slate-400 mt-2 font-sans max-w-sm">
                              All fallback/mock metrics are deactivated. If the query returns zero rows from the live database, this uncompromised zero-state screen is rendered.
                            </p>
                          </div>
                        ) : activeSelectedReport?.id === 'tpl_balance_sheet' ? (
                          <div className="p-4 bg-slate-50/50">
                            <BalanceSheetTab
                              data={queryEngineMutation.data?.data || []}
                              isLoading={queryEngineMutation.isPending}
                              isRtl={i18n.language === 'ar'}
                              dateFrom={localDates.fromDate}
                              dateTo={localDates.toDate}
                            />
                          </div>
                        ) : activeSelectedReport?.id === 'tpl_income_statement' ? (
                          <div className="p-4 bg-slate-50/50">
                            <ProfitLossTab
                              data={queryEngineMutation.data?.data || []}
                              isLoading={queryEngineMutation.isPending}
                              isRtl={i18n.language === 'ar'}
                              dateFrom={localDates.fromDate}
                              dateTo={localDates.toDate}
                            />
                          </div>
                        ) : activeSelectedReport?.id === 'tpl_trial_balance' ? (
                          <div className="p-4 bg-slate-50/50">
                            <TrialBalanceTab
                              data={queryEngineMutation.data?.data || []}
                              isLoading={queryEngineMutation.isPending}
                              isRtl={i18n.language === 'ar'}
                              dateFrom={localDates.fromDate}
                              dateTo={localDates.toDate}
                            />
                          </div>
                        ) : activeSelectedReport?.id === 'tpl_general_ledger' ? (
                          <div className="p-4 bg-slate-50/50">
                            <GeneralLedgerTab
                              data={queryEngineMutation.data?.data || []}
                              isLoading={queryEngineMutation.isPending}
                              isRtl={i18n.language === 'ar'}
                              dateFrom={localDates.fromDate}
                              dateTo={localDates.toDate}
                            />
                          </div>
                        ) : activeSelectedReport?.id === 'tpl_account_ledger_statement' ? (
                          <div className="p-4 bg-slate-50/50">
                            <AccountLedgerStatement
                              data={queryEngineMutation.data?.data || []}
                              isLoading={queryEngineMutation.isPending}
                              isRtl={i18n.language === 'ar'}
                            />
                          </div>
                        ) : activeSelectedReport?.groupField ? (
                          (() => {
                            const fKey = activeSelectedReport.groupField.split('.')[1] || activeSelectedReport.groupField;
                            const groupedRows: Record<string, any[]> = {};
                            const rawData = queryEngineMutation.data?.data || [];
                            
                            rawData.forEach((r: any) => {
                              const val = r[fKey] || 'Other Assets';
                              if (!groupedRows[val]) groupedRows[val] = [];
                              groupedRows[val].push(r);
                            });

                            return Object.entries(groupedRows).map(([groupKey, rows]) => (
                              <div key={groupKey} className="mb-6 last:mb-0">
                                
                                <div className="bg-slate-50 border-b border-t border-slate-150 px-4 py-2 flex items-center justify-between text-xs text-slate-500">
                                  <span className="font-extrabold text-slate-800">
                                    Category (المجموعة): <span className="text-indigo-600 font-sans font-black">{groupKey}</span>
                                  </span>
                                  <span className="text-[10px] font-mono italic">({rows.length} rows matched in db)</span>
                                </div>

                                <table className="w-full text-xs text-slate-700">
                                  <thead className="bg-[#f8fafc] text-slate-500 font-extrabold uppercase text-[10px] border-b border-slate-200">
                                    <tr>
                                      {activeSelectedReport.bands.find(b => b.id === 'detail')?.elements.map((el) => (
                                        <th key={el.id} className={cn("py-2.5 px-4 text-slate-800", el.align === 'center' && "text-center", el.align === 'right' && "text-right")}>
                                          {getLocalizedReportLabel(el.label, i18n.language === 'ar' ? 'ar' : 'en')}
                                        </th>
                                      ))}
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-100 font-sans">
                                    {rows.map((row, rIdx) => (
                                      <tr key={rIdx} className="hover:bg-slate-50/40">
                                        {activeSelectedReport.bands.find(b => b.id === 'detail')?.elements.map((elem) => {
                                          const value = evaluateFieldOrExpression(row, elem, rIdx, rows);
                                          let needsAlertStyle = false;
                                          if (elem.value.includes('stock_qty') && parseInt(row['stock_qty']) < 500) {
                                            needsAlertStyle = true;
                                          }

                                          return (
                                            <td 
                                              key={elem.id} 
                                              className={cn(
                                                "py-3 px-4 truncate font-sans", 
                                                elem.align === 'center' && "text-center", 
                                                elem.align === 'right' && "text-right font-medium font-mono",
                                                needsAlertStyle && "bg-rose-50 text-rose-600 font-extrabold border-l-2 border-rose-500"
                                              )}
                                            >
                                              {value}
                                            </td>
                                          );
                                        })}
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>

                                <div className="bg-indigo-50/15 p-3 flex justify-between items-center text-xs border-b">
                                  {activeSelectedReport.bands.find(b => b.id === 'groupFooter')?.elements.map((el) => (
                                    <div key={el.id} className={cn("w-1/2 flex items-center gap-1.5", el.align === 'right' && "justify-end text-right")}>
                                      <span className="font-bold text-slate-400">{getLocalizedReportLabel(el.label, i18n.language === 'ar' ? 'ar' : 'en')}:</span>
                                      <span className="font-extrabold text-slate-900 font-mono">
                                        {rows.length > 0 ? evaluateFieldOrExpression(rows[0], el, 0, rows) : '-'}
                                      </span>
                                    </div>
                                  ))}
                                </div>

                              </div>
                            ));
                          })()
                        ) : (
                          <table className="w-full text-xs text-slate-700">
                            <thead className="bg-[#f8fafc] text-slate-500 font-extrabold uppercase text-[10px] border-b border-slate-200">
                              <tr>
                                {activeSelectedReport?.bands.find(b => b.id === 'detail')?.elements.map((el) => (
                                  <th key={el.id} className={cn("py-2.5 px-4 text-slate-800", el.align === 'center' && "text-center", el.align === 'right' && "text-right")}>
                                    {getLocalizedReportLabel(el.label, i18n.language === 'ar' ? 'ar' : 'en')}
                                  </th>
                                ))}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 font-sans">
                              {(queryEngineMutation.data?.data || []).map((row, rIdx) => (
                                <tr key={rIdx} className="hover:bg-slate-50/40">
                                  {activeSelectedReport?.bands.find(b => b.id === 'detail')?.elements.map((elem) => (
                                    <td key={elem.id} className={cn("py-3 px-4 truncate font-sans", elem.align === 'center' && "text-center", elem.align === 'right' && "text-right font-medium font-mono")}>
                                      {evaluateFieldOrExpression(row, elem, rIdx, queryEngineMutation.data?.data || [])}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        )}

                      </div>
                    </div>

                    {/* BOTTOM RECONCILED POSTGRES TRACE */}
                    <div className="bg-slate-900 border-t border-indigo-950 p-4 font-mono text-[11px] text-indigo-300">
                      <div className="flex justify-between items-center mb-2">
                        <div className="flex items-center gap-1.5">
                          <Code className="w-4 h-4 text-indigo-400" />
                          <span className="text-white font-extrabold">ANSI-SQL Compilation Trace Log (PostgreSQL Plan)</span>
                        </div>
                        <span className="text-emerald-400 tracking-wider font-extrabold">STATUS: COMPILED</span>
                      </div>
                      <pre className="bg-slate-950/80 p-3 rounded-lg border border-slate-850 overflow-x-auto text-emerald-400">
                        {queryEngineMutation.data?.sql || '-- Engine initial compilation --'}
                      </pre>
                    </div>

                  </div>
                )}

              </div>
            )}

          </div>
        )}

        {/* ======================= TAB 1: VISUAL CUSTOM REPORT DESIGNER ======================= */}
        {platformTab === 1 && (
          <div className="space-y-6">
            
            {/* BUILD CONTROLS BAR */}
            <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-sm flex flex-wrap gap-4 items-center justify-between">
              
              <button
                onClick={() => {
                  setDesignerOpen(false);
                  setPlatformTab(0);
                }}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 hover:text-slate-950 font-bold text-xs rounded-xl border border-slate-200 flex items-center gap-2 cursor-pointer transition mr-2"
              >
                <ArrowRight className="w-4 h-4 rotate-180" />
                <span>Back to Hub Dashboard</span>
              </button>

              <div className="flex items-center gap-4">
                <div>
                  <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block mb-0.5">Primary Schema Master</span>
                  <select
                    value={selectedTables[0] || 'accounts'}
                    onChange={(e) => {
                      const nt = e.target.value;
                      setSelectedTables([nt]);
                      setJoins([]);
                      saveAuditMutation.mutate({ action: 'Modified', details: `Reselected core database source table to: ${nt}` });
                    }}
                    className="bg-slate-50 border border-slate-300 font-bold text-xs rounded-xl px-3 py-1.5 focus:outline-none focus:border-indigo-500"
                  >
                    {ERP_TABLES.map(t => (
                      <option key={t.id} value={t.id}>{t.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block mb-0.5">Partition grouping (Group Field)</span>
                  <select
                    value={groupField}
                    onChange={(e) => setGroupField(e.target.value)}
                    className="bg-slate-50 border border-slate-300 font-bold text-xs rounded-xl px-3 py-1.5 focus:outline-none focus:border-indigo-500 font-mono"
                  >
                    <option value="">No Partitioning / Raw listing</option>
                    {selectedTables.flatMap(tId => {
                      const tbl = ERP_TABLES.find(t => t.id === tId);
                      return tbl?.fields.map(f => (
                        <option key={`${tId}.${f.name}`} value={`${tId}.${f.name}`}>{tId}.{f.name}</option>
                      )) || [];
                    })}
                  </select>
                </div>

                <div>
                  <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block mb-0.5">Integrate chart analytics</span>
                  <div className="flex items-center gap-2 mt-1">
                    <Switch checked={showChart} onChange={(e) => setShowChart(e.target.checked)} />
                    <span className="text-xs font-bold text-slate-600">{showChart ? 'Enabled' : 'Disabled'}</span>
                  </div>
                </div>

                {showChart && (
                  <div className="flex items-center gap-3">
                    <div>
                      <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block mb-0.5">Label Axis (X)</span>
                      <select 
                        value={chartXField} 
                        onChange={(e) => setChartXField(e.target.value)}
                        className="bg-slate-50 border border-slate-300 text-xs rounded-xl px-2 py-1 focus:outline-none"
                      >
                        {selectedTables.flatMap(tId => ERP_TABLES.find(t => t.id === tId)?.fields.map(f => (
                          <option key={f.name} value={f.name}>{f.label}</option>
                        )) || [])}
                      </select>
                    </div>

                    <div>
                      <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block mb-0.5">Quantities (Y)</span>
                      <select 
                        value={chartYField} 
                        onChange={(e) => setChartYField(e.target.value)}
                        className="bg-slate-50 border border-slate-300 text-xs rounded-xl px-2 py-1 focus:outline-none"
                      >
                        {selectedTables.flatMap(tId => ERP_TABLES.find(t => t.id === tId)?.fields.map(f => (
                          <option key={f.name} value={f.name}>{f.label}</option>
                        )) || [])}
                      </select>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={commitReportDesignToDB}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition duration-150 font-bold text-xs flex items-center gap-2 cursor-pointer shadow-md shadow-indigo-200"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Layout Metadata</span>
                </button>
              </div>

            </div>

            {/* DESIGNER SPLIT CONTAINER */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* TOOLBOX SIDEBAR (4 Columns) */}
              <div className="lg:col-span-4 space-y-4">
                
                {/* TOOLBOX WIDGET STATIONS */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
                  
                  <div className="flex items-center gap-2 border-b pb-3 mb-4">
                    <Boxes className="w-5 h-5 text-indigo-600" />
                    <span className="text-xs font-black tracking-wider uppercase text-slate-800">Drag/Click Toolbox Widgets</span>
                  </div>

                  <p className="text-[11px] text-slate-400 mb-4 font-sans leading-relaxed">
                    Select a band, then click a widget tool below to instantly append a dynamic slot on the editing preview worksheet sheet:
                  </p>

                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <button 
                      onClick={() => {
                        const bId = selectedBandId || 'detail';
                        addElementToBand(bId, 'label');
                      }}
                      className="p-3 bg-slate-50 border hover:bg-indigo-50 hover:border-indigo-200 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer group transition duration-150"
                    >
                      <Layers className="w-5 h-5 text-indigo-600 mb-1" />
                      <span className="text-xs font-extrabold text-slate-700">Static Label</span>
                      <span className="text-[9px] text-slate-400 mt-0.5">Title Text Header</span>
                    </button>

                    <button 
                      onClick={() => {
                        const bId = selectedBandId || 'detail';
                        addElementToBand(bId, 'field');
                      }}
                      className="p-3 bg-slate-50 border hover:bg-indigo-50 hover:border-indigo-200 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer group transition duration-150"
                    >
                      <Database className="w-5 h-5 text-indigo-600 mb-1" />
                      <span className="text-xs font-extrabold text-slate-700">Database Field</span>
                      <span className="text-[9px] text-slate-400 mt-0.5">accounts.balance</span>
                    </button>

                    <button 
                      onClick={() => {
                        const bId = selectedBandId || 'pageHeader';
                        addElementToBand(bId, 'variable');
                      }}
                      className="p-3 bg-slate-50 border hover:bg-indigo-50 hover:border-indigo-200 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer group transition duration-150"
                    >
                      <Clock className="w-5 h-5 text-indigo-600 mb-1" />
                      <span className="text-xs font-extrabold text-slate-700">Variable Stamp</span>
                      <span className="text-[9px] text-slate-400 mt-0.5">Execution Timestamp</span>
                    </button>

                    <button 
                      onClick={() => {
                        const bId = selectedBandId || 'reportHeader';
                        addElementToBand(bId, 'qrcode');
                      }}
                      className="p-3 bg-slate-50 border hover:bg-indigo-50 hover:border-indigo-200 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer group transition duration-150"
                    >
                      <QrCode className="w-5 h-5 text-indigo-600 mb-1" />
                      <span className="text-xs font-extrabold text-slate-700">QR / Barcode</span>
                      <span className="text-[9px] text-slate-400 mt-0.5">Compliance Stamp</span>
                    </button>
                  </div>

                  <div className="bg-slate-55 p-3 rounded-2xl border border-slate-150 flex items-center gap-3">
                    <Info className="w-5 h-5 text-indigo-600 flex-shrink-0" />
                    <p className="text-[10px] text-slate-500 leading-normal">
                      Active editable band: <span className="font-extrabold text-indigo-600">{selectedBandId || 'None (Clicks band first)'}</span>
                    </p>
                  </div>

                </div>

                {/* RELATION BUILDER STATIONS */}
                <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm">
                  
                  <div className="flex items-center justify-between border-b pb-3 mb-4">
                    <div className="flex items-center gap-2">
                      <GitCommit className="w-5 h-5 text-indigo-600" />
                      <span className="text-xs font-black tracking-wider uppercase text-slate-800">Visual Joint Relations Builder</span>
                    </div>
                    <button 
                      onClick={addJoinRelation}
                      className="px-2 py-1 bg-slate-100 hover:bg-indigo-50 border text-[10px] text-indigo-600 font-extrabold rounded-lg flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Link Table</span>
                    </button>
                  </div>

                  {joins.length === 0 ? (
                    <div className="text-center py-6">
                      <p className="text-xs text-slate-400">No joins configured. Report loads primary database only.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {joins.map((jn, i) => (
                        <div key={jn.id} className="p-3 bg-slate-50 border rounded-2xl relative space-y-2">
                          <button 
                            onClick={() => removeJoinRelation(jn.id)}
                            className="absolute top-2.5 right-2.5 text-slate-400 hover:text-rose-500 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>

                          <div className="text-[10px] font-bold text-slate-400 mb-1">Relation Join #{i+1}</div>

                          <div>
                            <select 
                              value={jn.joinType} 
                              onChange={(e) => updateJoin(jn.id, 'joinType', e.target.value as any)}
                              className="w-full text-[11px] font-bold p-1 border rounded bg-white"
                            >
                              <option value="Inner Join">INNER JOIN (شرط تطابق ثنائي)</option>
                              <option value="Left Join">LEFT JOIN (كل السجلات الأساسية)</option>
                              <option value="Right Join">RIGHT JOIN (سجلات التابع)</option>
                            </select>
                          </div>

                          <div className="grid grid-cols-2 gap-2 mt-2">
                            <div>
                              <span className="text-[9px] text-slate-400 block">Left Field</span>
                              <select 
                                value={jn.leftField} 
                                onChange={(e) => updateJoin(jn.id, 'leftField', e.target.value)}
                                className="w-full text-[10px] p-1 border rounded bg-white font-mono"
                              >
                                <option value="code">code (الحساب)</option>
                                <option value="item_code">item_code</option>
                                <option value="invoice_no">invoice_no</option>
                                <option value="customer_id">customer_id</option>
                              </select>
                            </div>

                            <div>
                              <span className="text-[9px] text-slate-400 block">Right Field</span>
                              <select 
                                value={jn.rightField} 
                                onChange={(e) => updateJoin(jn.id, 'rightField', e.target.value)}
                                className="w-full text-[10px] p-1 border rounded bg-white font-mono"
                              >
                                <option value="code">code (الحساب)</option>
                                <option value="item_code">item_code</option>
                                <option value="invoice_no">invoice_no</option>
                                <option value="customer_id">customer_id</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                </div>

              </div>

              {/* DESIGNER CANVAS WORKSPACE CONTAINER (8 Columns) */}
              <div className="lg:col-span-8 space-y-6">
                
                {/* CANVAS REPEATED BANDS */}
                <div className="bg-[#f1f5f9] p-6 rounded-3xl border border-slate-300 shadow-inner space-y-5">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex justify-between">
                    <span>Enterprise Design Bands Sheets Layout</span>
                    <span>Scroll and click slots to format</span>
                  </div>

                  {bands.map((band) => (
                    <div 
                      key={band.id}
                      onClick={() => setSelectedBandId(band.id)}
                      className={cn(
                        "bg-white border rounded-2xl overflow-hidden transition duration-150 cursor-pointer shadow-sm relative group",
                        selectedBandId === band.id ? "ring-2 ring-indigo-500 border-indigo-400" : "hover:border-indigo-200"
                      )}
                    >
                      
                      {/* BAND HEADER DECALS */}
                      <div className="bg-slate-50 border-b border-slate-100 flex items-center justify-between px-4 py-2.5">
                        <div className="flex items-center gap-2">
                          <Layers className="w-3.5 h-3.5 text-slate-400" />
                          <span className="text-xs font-black text-slate-800">{band.name}</span>
                          <span className="text-[10px] text-slate-400 italic">({band.arabicName})</span>
                        </div>
                        {selectedBandId === band.id && (
                          <span className="bg-indigo-600 text-white text-[9px] font-black uppercase px-2 py-0.5 rounded-full font-mono">SELECTED WORKSPACE</span>
                        )}
                      </div>

                      {/* BAND ELEMENTS DRAWER */}
                      <div className="p-4 flex flex-wrap gap-3.5 min-h-[70px] bg-slate-50/20">
                        {band.elements.length === 0 ? (
                          <div className="flex-1 py-4 flex flex-col items-center justify-center">
                            <span className="text-[10px] text-slate-400 font-mono italic">No elements matching layout. Click Toolbox inside sidebar to add elements.</span>
                          </div>
                        ) : (
                          band.elements.map((el) => (
                            <div 
                              key={el.id}
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedElementId(el.id);
                                setSelectedBandId(band.id);
                              }}
                              className={cn(
                                "p-3 border rounded-xl flex items-center justify-between cursor-pointer md:w-[48%] lg:w-[31%] relative transition",
                                selectedElementId === el.id 
                                  ? "bg-indigo-50 border-indigo-300 text-indigo-950 font-extrabold ring-1 ring-indigo-400" 
                                  : "bg-white hover:bg-slate-50 border-slate-200"
                              )}
                            >
                              
                              <div className="overflow-hidden flex-1 select-none pr-1 pl-1">
                                <div className="flex items-center gap-1 mb-1">
                                  <span className="text-[9px] font-extrabold tracking-wider bg-slate-100 border text-slate-500 px-1 rounded uppercase font-mono">{el.type}</span>
                                  {el.expression && <span className="text-[8px] font-mono bg-amber-50 text-amber-600 px-1 rounded uppercase">FORMULA</span>}
                                </div>
                                <span className="text-xs font-serif text-slate-700 block truncate">{el.label}</span>
                                <span className="text-[10px] text-slate-400 block font-mono bg-slate-50 py-0.5 rounded mt-1 overflow-hidden truncate">
                                  {el.value}
                                </span>
                              </div>

                              <div className="flex flex-col items-end gap-1.5 ml-2">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    removeElementFromBand(band.id, el.id);
                                  }}
                                  className="p-1 hover:bg-rose-55 rounded text-slate-300 hover:text-rose-600 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                                
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    openFormulaEditor(el, band.id);
                                  }}
                                  className="p-1 hover:bg-indigo-100 rounded text-indigo-400 hover:text-indigo-700 cursor-pointer"
                                >
                                  <Code className="w-3.5 h-3.5" />
                                </button>
                              </div>

                            </div>
                          ))
                        )}
                      </div>

                    </div>
                  ))}

                </div>

                {/* DOUBLE PROPERTIES PANELS */}
                {selectedElementId && (
                  <div className="bg-white p-5 rounded-3xl border-2 border-indigo-600 shadow-xl space-y-4">
                    <div className="flex items-center gap-1.5 border-b pb-3">
                      <SlidersIcon className="w-5 h-5 text-indigo-600" />
                      <span className="text-xs font-black tracking-widest text-[#1e293b] uppercase">Active Element Formatting Controller Options</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div>
                        <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Slot Label</label>
                        <input
                          type="text"
                          value={bands.flatMap(b => b.elements).find(e => e.id === selectedElementId)?.label || ''}
                          onChange={(e) => updateElementProperty('label', e.target.value)}
                          className="w-full text-xs p-2 border rounded-xl"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Value Field Binding</label>
                        <input
                          type="text"
                          value={bands.flatMap(b => b.elements).find(e => e.id === selectedElementId)?.value || ''}
                          onChange={(e) => updateElementProperty('value', e.target.value)}
                          className="w-full text-xs p-2 border rounded-xl font-mono text-indigo-700"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Decimal Numbers Prec.</label>
                        <select
                          value={bands.flatMap(b => b.elements).find(e => e.id === selectedElementId)?.formatting.decimals ?? 2}
                          onChange={(e) => updateElementFormatting('decimals', parseInt(e.target.value))}
                          className="w-full text-xs p-2 border rounded-xl bg-white"
                        >
                          <option value="0">0 decimals (Whole Unit value)</option>
                          <option value="2">2 decimals (Accounting Standard)</option>
                          <option value="4">4 decimals (Forex Rates)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Currency Symbol Code</label>
                        <select
                          value={bands.flatMap(b => b.elements).find(e => e.id === selectedElementId)?.formatting.currencySymbol || 'None'}
                          onChange={(e) => updateElementFormatting('currencySymbol', e.target.value)}
                          className="w-full text-xs p-2 border rounded-xl bg-white"
                        >
                          <option value="None">None (Pure numeric score)</option>
                          <option value="YER">YER (Yemeni Rial YER)</option>
                          <option value="USD">USD (US Dollar Vault)</option>
                          <option value="SAR">SAR (Saudi Rial SAR)</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3.5 border-t border-dashed border-slate-100">
                      <div>
                        <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Text alignments</label>
                        <select
                          value={bands.flatMap(b => b.elements).find(e => e.id === selectedElementId)?.align || 'left'}
                          onChange={(e) => updateElementProperty('align', e.target.value)}
                          className="w-full text-xs p-2 border rounded-xl bg-white"
                        >
                          <option value="left">Left align</option>
                          <option value="center">Center align</option>
                          <option value="right">Right align</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Thousand separator</label>
                        <div className="flex items-center gap-2 mt-2">
                          <Switch 
                            checked={bands.flatMap(b => b.elements).find(e => e.id === selectedElementId)?.formatting.thousandSeparator || false} 
                            onChange={(e) => updateElementFormatting('thousandSeparator', e.target.checked)}
                          />
                          <span className="text-xs font-bold font-mono">Use comma (e.g. 10,000,000)</span>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Excel aggregate formulas expressions</label>
                        <button
                          onClick={() => {
                            const found = bands.flatMap(b => b.elements).find(e => e.id === selectedElementId);
                            if (found) openFormulaEditor(found, selectedBandId!);
                          }}
                          className="w-full bg-slate-900 text-white font-bold text-xs py-2 rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                        >
                          <Code className="w-4 h-4 text-emerald-400" />
                          <span>Formula Editor</span>
                        </button>
                      </div>
                    </div>

                  </div>
                )}

              </div>

            </div>

          </div>
        )}

      </div>

      {/* ======================= DIALOG: SHEETS PRINT PREVIEW WORKSHEETS ======================= */}
      {previewOpen && (
        <Dialog 
          open={previewOpen} 
          onClose={() => setPreviewOpen(false)}
          fullWidth
          maxWidth="lg"
          sx={{
            '& .MuiDialog-paper': {
              borderRadius: '24px',
              padding: '0px'
            }
          }}
        >
          <div className="bg-white border text-[#1e293b] font-sans">
            
            {/* WORKHEADER BAR */}
            <div className="bg-slate-900 p-5 flex items-center justify-between text-white border-b sticky top-0 z-10 rounded-t-[24px]">
              <div>
                <h3 className="text-sm font-black font-sans tracking-tight">Financial Print Workpaper Preview</h3>
                <p className="text-[10px] text-slate-300 font-mono mt-0.5">Physical sheet sizing: {pageSize} ORIENTATION: {orientation}</p>
              </div>

              <div className="flex items-center gap-3">
                <select 
                  value={pageSize} 
                  onChange={(e) => setPageSize(e.target.value as any)}
                  className="bg-slate-800 text-white border border-slate-700 text-xs rounded-xl px-2 py-1 cursor-pointer font-bold"
                >
                  <option value="A4">A4 (Standard Desk Sheet)</option>
                  <option value="A3">A3 (Wide Ledger Sheets)</option>
                  <option value="Roll80">Thermal Receipt Roll (80mm)</option>
                </select>

                <select 
                  value={orientation} 
                  onChange={(e) => setOrientation(e.target.value as any)}
                  className="bg-slate-800 text-white border border-slate-700 text-xs rounded-xl px-2 py-1 cursor-pointer font-bold"
                >
                  <option value="Portrait">Portrait</option>
                  <option value="Landscape">Landscape</option>
                </select>

                <button 
                  onClick={() => {
                    winPrintRun();
                    saveAuditMutation.mutate({ action: 'Exported', details: 'User issued window.print() print job dispatch' });
                  }}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Execute Print Job</span>
                </button>

                <button 
                  onClick={() => setPreviewOpen(false)}
                  className="p-1.5 bg-slate-800 hover:bg-slate-750 rounded-full cursor-pointer text-slate-400"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* PREVIEW CONTAINER CLONE PRINT DESIGN */}
            <div className="p-8 bg-slate-100 flex justify-center max-h-[80vh] overflow-y-auto">
              <div 
                id="printable-cooperative-worksheet"
                className={cn(
                  "bg-white rounded-xl shadow-2xl p-8 pr-12 pl-12 text-[#1e293b] print-area font-sans",
                  pageSize === 'A4' && orientation === 'Portrait' && "w-[210mm] min-h-[297mm]",
                  pageSize === 'A4' && orientation === 'Landscape' && "w-[297mm] min-h-[210mm]",
                  pageSize === 'A3' && orientation === 'Portrait' && "w-[297mm] min-h-[420mm]",
                  pageSize === 'A3' && orientation === 'Landscape' && "w-[420mm] min-h-[297mm]",
                  pageSize === 'Roll80' && "w-[80mm] min-h-[140mm] p-4 text-[10px]"
                )}
              >
                
                {/* CSS CHROME OVERRIDES */}
                <style>{`
                  @media print {
                    body * {
                      visibility: hidden;
                    }
                    #printable-cooperative-worksheet, #printable-cooperative-worksheet * {
                      visibility: visible;
                    }
                    #printable-cooperative-worksheet {
                      position: absolute;
                      left: 0;
                      top: 0;
                      width: 100% !important;
                      box-shadow: none !important;
                      border: none !important;
                    }
                  }
                `}</style>

                {/* REPORT HEADER BAND */}
                <div className="border-b-2 border-slate-900 pb-4 mb-4 text-center">
                  <h2 className="text-base font-extrabold text-slate-900 uppercase">
                    YEMEN FOOD COOPERATIVES LTD CORP
                  </h2>
                  <h3 className="text-xl font-black mt-1 text-slate-800 uppercase tracking-tight font-sans">
                    {activeSelectedReport?.name}
                  </h3>
                  <div className="my-2.5 flex justify-center">
                    <QrCode className="w-12 h-12 text-slate-800" />
                  </div>
                </div>

                {/* PAGE HEADER */}
                <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono border-b border-dashed pb-2 mb-4">
                  <span>Printed User: acc.ali.bafadhl@gmail.com</span>
                  <span>Execution Date: {new Date().toLocaleDateString('ar-YE')}</span>
                </div>

                {/* TABULAR LAYOUT LOOP */}
                <div className="overflow-hidden border border-slate-200 rounded-xl mb-6">
                  <table className="w-full text-xs text-slate-700">
                    <thead className="bg-slate-50 border-b border-slate-200 font-bold">
                      <tr>
                        {activeSelectedReport?.bands.find(b => b.id === 'detail')?.elements.map(el => (
                          <th key={el.id} className={cn("py-2.5 px-3 text-slate-800", el.align === 'center' && "text-center", el.align === 'right' && "text-right")}>
                            {el.label}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-sans">
                      {(queryEngineMutation.data?.data || []).map((row, rIdx) => (
                        <tr key={rIdx}>
                          {activeSelectedReport?.bands.find(b => b.id === 'detail')?.elements.map(elem => (
                            <td key={elem.id} className={cn("py-2.5 px-3 truncate", elem.align === 'center' && "text-center", elem.align === 'right' && "text-right font-mono font-medium")}>
                              {evaluateFieldOrExpression(row, elem, rIdx, queryEngineMutation.data?.data || [])}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* STAMP EMBLEMS */}
                <div className="my-8 pt-4 border-t border-double border-slate-850 flex justify-between items-center text-xs">
                  <div>
                    <span className="block font-black text-slate-800">Accounting Supervisor Signature</span>
                    <div className="h-12 mt-1" />
                    <span>___________________________</span>
                  </div>

                  <div className="text-right">
                    <span className="block font-black text-slate-800">Approved Audit Stamp Office</span>
                    <div className="h-12 mt-1" />
                    <span>[ Certified Audit Seal ]</span>
                  </div>
                </div>

              </div>
            </div>

          </div>
        </Dialog>
      )}

      {/* ======================= DIALOG: DYNAMIC EXCEL FORMULA EDITOR ======================= */}
      {expressionEditorElement && (
        <Dialog 
          open={!!expressionEditorElement} 
          onClose={() => setExpressionEditorElement(null)}
          fullWidth
          maxWidth="sm"
          sx={{
            '& .MuiDialog-paper': {
              borderRadius: '24px'
            }
          }}
        >
          <div className="p-6 space-y-4">
            
            <div className="flex justify-between items-center border-b pb-3">
              <div className="flex items-center gap-1.5 text-indigo-600">
                <Code className="w-5 h-5" />
                <h3 className="font-extrabold text-xs uppercase tracking-wider">ANSI SQL/Excel dynamic aggregations builder</h3>
              </div>
              <button 
                onClick={() => setExpressionEditorElement(null)} 
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              Define Excel-style formulas or mathematical relations. The system compiles these operations into backend PostgreSQL aggregate statements and returns real balances:
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Math Expression formula</label>
                <input 
                  type="text" 
                  value={customExpressionText}
                  onChange={(e) => setCustomExpressionText(e.target.value)}
                  className="w-full font-mono text-indigo-700 bg-slate-50 border p-3 rounded-xl focus:outline-none focus:border-indigo-500 text-xs"
                  placeholder="e.g. SUM(accounts.balance)"
                />
              </div>

              {/* Suggestions */}
              <div className="bg-indigo-50/50 p-3 rounded-2xl border border-indigo-150 space-y-2">
                <span className="text-[10px] font-extrabold text-[#4f46e5] uppercase block">Seeded PostgreSQL Planner Operators available:</span>
                <div className="flex flex-wrap gap-2 text-[9px] font-mono">
                  <span 
                    onClick={() => setCustomExpressionText('SUM(accounts.balance)')} 
                    className="bg-white border rounded px-2 py-0.5 cursor-pointer text-indigo-700 hover:bg-slate-50"
                  >
                    SUM(accounts.balance)
                  </span>
                  <span 
                    onClick={() => setCustomExpressionText('Detail.qty * Detail.avg_cost')} 
                    className="bg-white border rounded px-2 py-0.5 cursor-pointer text-indigo-700 hover:bg-slate-50"
                  >
                    Detail.qty * Detail.avg_cost
                  </span>
                  <span 
                    onClick={() => setCustomExpressionText('COUNT(items.item_code)')} 
                    className="bg-white border rounded px-2 py-0.5 cursor-pointer text-indigo-700 hover:bg-slate-50"
                  >
                    COUNT(items.item_code)
                  </span>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <button
                onClick={() => setExpressionEditorElement(null)}
                className="px-4 py-2 border rounded-xl text-slate-500 text-xs hover:bg-slate-50 font-bold cursor-pointer"
              >
                Cancel
              </button>

              <button
                onClick={saveCustomFormula}
                className="px-5 py-2 bg-indigo-600 font-bold hover:bg-indigo-700 text-white rounded-xl text-xs cursor-pointer shadow-md shadow-indigo-100"
              >
                Confirm Formula
              </button>
            </div>

          </div>
        </Dialog>
      )}

      {/* ======================= DRAWER: SCHEDULER DISPATCH AUTOMATION ======================= */}
      <Drawer
        anchor="right"
        open={schedulerDrawerOpen}
        onClose={() => setSchedulerDrawerOpen(false)}
        sx={{
          '& .MuiDrawer-paper': {
            width: '450px',
            borderTopLeftRadius: '24px',
            borderBottomLeftRadius: '24px'
          }
        }}
      >
        <div className="p-6 space-y-6 font-sans">
          
          <div className="flex items-center justify-between border-b pb-3.5">
            <div className="flex items-center gap-2 text-indigo-600">
              <Bell className="w-5 h-5 animate-bounce" />
              <h3 className="font-extrabold text-xs uppercase tracking-wider">Automated Dispatch Scheduler</h3>
            </div>
            <button 
              onClick={() => setSchedulerDrawerOpen(false)} 
              className="text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
            Postgres Daemon Automations: Setup recurrent report rendering jobs. The dynamic engine renders PDF/Excel sheets and emails results to management automatically:
          </p>

          <form onSubmit={handleRegisterSchedule} className="space-y-4">
            <div>
              <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Target Report Template</label>
              <select
                value={schedulerForm.reportName}
                onChange={(e) => {
                  const item = allTemplates.find(t => t.name === e.target.value);
                  setSchedulerForm(prev => ({
                    ...prev,
                    reportName: e.target.value,
                    arabicName: item ? item.arabicName : ''
                  }));
                }}
                className="w-full text-xs p-2 bg-slate-50 border rounded-xl focus:outline-none focus:border-indigo-500 font-extrabold"
              >
                {allTemplates.map(t => (
                  <option key={t.id} value={t.name}>{t.name} ({t.arabicName})</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Dispatch Frequency Interval</label>
              <select
                value={schedulerForm.frequency}
                onChange={(e) => setSchedulerForm(prev => ({ ...prev, frequency: e.target.value as any }))}
                className="w-full text-xs p-2 bg-slate-50 border rounded-xl focus:outline-none focus:border-indigo-500 font-extrabold"
              >
                <option value="daily">Daily Auto Batch (كل صباح)</option>
                <option value="weekly">Weekly Friday audit (تصفية نهاية الأسبوع)</option>
                <option value="monthly">Monthly Consolidated Ledger P&L</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Recipients Dispatch Emails</label>
              <input
                type="text"
                value={schedulerForm.recipients}
                onChange={(e) => setSchedulerForm(prev => ({ ...prev, recipients: e.target.value }))}
                className="w-full font-mono text-xs p-3 border rounded-xl font-bold text-slate-705"
                placeholder="CEO, CFO or auditors email address"
              />
            </div>

            <div>
              <label className="block text-[10px] text-slate-400 font-extrabold uppercase mb-1">Batch Run Time (UTC)</label>
              <div className="relative">
                <Clock className="absolute left-3 top-3.5 w-4 h-4 text-slate-400" />
                <input
                  type="time"
                  value={schedulerForm.time}
                  onChange={(e) => setSchedulerForm(prev => ({ ...prev, time: e.target.value }))}
                  className="w-full font-mono text-xs p-3 border rounded-xl pl-10 font-bold"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition duration-150 shadow-md shadow-indigo-100 cursor-pointer"
            >
              Register Automated Scheduling Alert
            </button>
          </form>

          {/* ACTIVE JOBS LIST */}
          <div className="space-y-3 pt-6 border-t font-sans">
            <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block font-sans">Registered Active Cron Daemon Jobs</span>
            
            {automationsSchedules.length === 0 ? (
              <p className="text-[10px] text-slate-400 font-mono italic">No automated recurring dispatch jobs configured.</p>
            ) : (
              <div className="space-y-2">
                {automationsSchedules.map((job) => (
                  <div key={job.id} className="p-3 bg-slate-50 border rounded-2xl flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-slate-800 block">{job.reportName}</span>
                      <div className="flex gap-2.5 text-[9px] text-slate-400 font-mono mt-0.5">
                        <span className="font-black text-indigo-600 uppercase">{job.frequency}</span>
                        <span>Recipient: {job.recipients.split(',')[0]}</span>
                        <span>Time: {job.time}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => dispatch(toggleSchedule(job.id))}
                      className={cn(
                        "text-[9px] font-bold px-2 py-0.5 rounded cursor-pointer border",
                        job.active ? "bg-emerald-50 text-emerald-700 border-emerald-250" : "bg-slate-100 text-slate-400 border-slate-200"
                      )}
                    >
                      {job.active ? 'Active' : 'Disabled'}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      </Drawer>

      {/* ======================= DRAWER: REVISION ROLLBACK TRAILS ======================= */}
      <Drawer
        anchor="right"
        open={auditLogsDrawerOpen}
        onClose={() => setAuditLogsDrawerOpen(false)}
        sx={{
          '& .MuiDrawer-paper': {
            width: '450px',
            borderTopLeftRadius: '24px',
            borderBottomLeftRadius: '24px'
          }
        }}
      >
        <div className="p-6 space-y-6 font-sans">
          
          <div className="flex items-center justify-between border-b pb-3.5">
            <div className="flex items-center gap-2 text-indigo-600">
              <RotateCcw className="w-5 h-5 text-emerald-400" />
              <h3 className="font-extrabold text-xs uppercase tracking-wider">PostgreSQL Audit trails & rollback version center</h3>
            </div>
            <button 
              onClick={() => setAuditLogsDrawerOpen(false)} 
              className="text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-[11px] text-slate-400 leading-relaxed">
            Maintains absolute auditability over database layout configurations. Every schema selection, join modification, band manipulation registers a ledger version which can be rolled back programmatically:
          </p>

          <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
            {dbAudits.map((currLog: any) => (
              <div 
                key={currLog.id}
                className="p-3 bg-slate-50 border relative hover:border-emerald-250 rounded-2xl transition duration-150 space-y-1"
              >
                <div className="flex items-center justify-between">
                  <Chip 
                    label={currLog.action} 
                    size="small" 
                    className={cn(
                      "text-[9px] font-black",
                      currLog.action === 'Created' && "bg-emerald-100 text-emerald-700",
                      currLog.action === 'Modified' && "bg-indigo-100 text-indigo-700",
                      currLog.action === 'Exported' && "bg-slate-150 text-slate-600",
                      currLog.action === 'Restored' && "bg-amber-100 text-amber-700"
                    )}
                  />
                  <span className="text-[10px] text-slate-400 font-mono">
                    {new Date(currLog.timestamp).toLocaleString('en-US', { hour12: false })}
                  </span>
                </div>

                <p className="text-xs font-serif text-slate-700 mt-1">{currLog.details}</p>
                
                <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono mt-2 pt-2 border-t border-dashed">
                  <span>Author: {currLog.userEmail}</span>
                  <button 
                    onClick={() => {
                      saveAuditMutation.mutate({ action: 'Restored', details: `Executed rollback override operation to snapshot audit version ID ${currLog.id}` });
                      setAuditLogsDrawerOpen(false);
                    }}
                    className="text-[9px] font-extrabold text-emerald-600 hover:text-emerald-800 cursor-pointer"
                  >
                    Rollback to here
                  </button>
                </div>
              </div>
            ))}
          </div>

        </div>
      </Drawer>

      {/* ======================= DIALOG: SMART SEARCH PARAMETERS ======================= */}
      <Dialog
        open={paramModalOpen}
        onClose={() => setParamModalOpen(false)}
        fullWidth
        maxWidth="sm"
        sx={{
          '& .MuiDialog-paper': {
            borderRadius: '24px',
            padding: '24px',
            boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.25)'
          }
        }}
      >
        <div className="space-y-6">
          <div className="flex justify-between items-center border-b pb-4">
            <div className="flex items-center gap-2 text-indigo-600">
              <SlidersHorizontal className="w-5 h-5" />
              <h3 className="font-extrabold text-sm uppercase tracking-wider">
                خيارات البحث والفلترة الذكية
              </h3>
            </div>
            <button
              onClick={() => setParamModalOpen(false)}
              className="text-slate-400 hover:text-slate-650 hover:bg-slate-100 p-1.5 rounded-full transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="bg-indigo-50/50 p-3 rounded-2xl border border-indigo-100 flex items-start gap-2.5">
            <Info className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
            <div className="text-xs text-slate-650">
              <p className="font-bold">حدود استعلام التقرير النظير</p>
              <p className="mt-0.5 text-[11px] text-slate-500">
                سيقوم محرك استعلام PostgreSQL بربط السجلات وبنائها تلقائياً بناءً على الخيارات المحددة أدناه.
              </p>
            </div>
          </div>

          <div className="space-y-4 font-sans">
            {/* Date Inputs */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1.5">{t('reports.date_from')}</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="date"
                    value={tempDates.fromDate}
                    onChange={(e) => setTempDates(prev => ({ ...prev, fromDate: e.target.value }))}
                    className="w-full text-xs font-semibold py-2.5 pl-10 pr-3 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 focus:bg-white rounded-xl focus:outline-none transition font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1.5">{t('reports.date_to')}</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                  <input
                    type="date"
                    value={tempDates.toDate}
                    onChange={(e) => setTempDates(prev => ({ ...prev, toDate: e.target.value }))}
                    className="w-full text-xs font-semibold py-2.5 pl-10 pr-3 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 focus:bg-white rounded-xl focus:outline-none transition font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Warehouse */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1.5">الفرع أو المستودع (Warehouse Scope)</label>
              <select
                value={tempWarehouse}
                onChange={(e) => setTempWarehouse(e.target.value)}
                className="w-full text-xs font-semibold py-2.5 px-3 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-500 focus:bg-white rounded-xl focus:outline-none transition"
              >
                <option value="WH-MAIN (Sana'a)">WH-MAIN (Sana'a) - المركز الرئيسي بصنعاء</option>
                <option value="WH-ADEN (Freezone)">WH-ADEN (Freezone) - فرع المنطقة الحرة عدن</option>
                <option value="WH-TAIZ (Division)">WH-TAIZ (Cold Yard) - ساحة التبريد تعز</option>
              </select>
            </div>

            {/* Cost Center */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1.5">مركز التكلفة (Cost Center Scope)</label>
              <select
                value={tempCostCenter}
                onChange={(e) => setTempCostCenter(e.target.value)}
                className="w-full text-xs font-semibold py-2.5 px-3 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-indigo-505 focus:bg-white rounded-xl focus:outline-none transition"
              >
                <option value="Admin HQ Operations Center">Admin HQ Operations Center - مركز الإدارة العامة</option>
                <option value="Sales Hub YER Ledger">Sales Hub YER Ledger - حركة المبيعات بالعملة الوطنية</option>
                <option value="Aden Port Logistics">Aden Port Logistics - الخدمات اللوجستية ميناء عدن</option>
              </select>
            </div>
          </div>

          <div className="flex gap-3 pt-4 border-t justify-end">
            <button
              onClick={() => setParamModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-xl transition cursor-pointer"
            >
              إلغاء (Cancel)
            </button>
            <button
              onClick={handleConfirmParams}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition shadow-md shadow-indigo-100 cursor-pointer"
            >
              تأكيد وعرض التقرير (Apply & Display)
            </button>
          </div>
        </div>
      </Dialog>

    </div>
  );

  function winPrintRun() {
    window.print();
  }
}
