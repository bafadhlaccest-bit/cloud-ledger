/**
 * RecurringInvoices — الفواتير المتكررة
 * موجود في زوهو/زيرو: جدولة فواتير تلقائية شهرية/أسبوعية/سنوية
 */
import React, { useState, useEffect } from 'react';
import { Plus, RefreshCw, Clock, Play, Pause, X, Search, Calendar } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useRBAC } from '../hooks/useRBAC';

const FREQ_AR: Record<string, string> = {
  daily: 'يومي', weekly: 'أسبوعي', monthly: 'شهري',
  quarterly: 'ربع سنوي', yearly: 'سنوي',
};

export default function RecurringInvoices() {
  const { companyId } = useRBAC();
  const [records, setRecords] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [form, setForm] = useState({
    customer_id: '', frequency: 'monthly', amount: '',
    tax_rate: '15', description: '', start_date: new Date().toISOString().slice(0, 10),
    end_date: '', currency: 'SAR', day_of_month: '1',
  });

  useEffect(() => { if (companyId) load(); }, [companyId]);

  async function load() {
    setIsLoading(true);
    const [{ data: r }, { data: c }] = await Promise.all([
      supabase.from('recurring_invoices').select('*').eq('company_id', companyId).order('created_at', { ascending: false }),
      supabase.from('customers').select('id,name').eq('company_id', companyId),
    ]);
    setRecords(r || []);
    setCustomers(c || []);
    setIsLoading(false);
  }

  const handleSubmit = async () => {
    if (!form.customer_id || !form.amount) return;
    setIsSubmitting(true);
    const cust = customers.find(c => c.id === form.customer_id);
    const amount = parseFloat(form.amount);
    const taxAmount = amount * (parseFloat(form.tax_rate) / 100);
    await supabase.from('recurring_invoices').insert({
      company_id: companyId,
      customer_id: form.customer_id,
      customer_name: cust?.name || '',
      frequency: form.frequency,
      amount, tax_rate: parseFloat(form.tax_rate),
      tax_amount: taxAmount, total: amount + taxAmount,
      description: form.description,
      start_date: form.start_date,
      end_date: form.end_date || null,
      next_date: form.start_date,
      day_of_month: parseInt(form.day_of_month),
      status: 'Active',
      currency: form.currency,
      invoices_generated: 0,
    });
    setShowForm(false);
    load();
    setIsSubmitting(false);
  };

  // Generate invoice from recurring template
  const generateNow = async (rec: any) => {
    const invNum = `INV-REC-${Date.now().toString().slice(-6)}`;
    await supabase.from('invoices').insert({
      company_id: companyId,
      number: invNum,
      customer_id: rec.customer_id,
      date: new Date().toISOString().slice(0, 10),
      status: 'Draft',
      subtotal: rec.amount,
      tax_total: rec.tax_amount,
      total: rec.total,
      notes: `فاتورة متكررة: ${rec.description}`,
      currency: rec.currency,
      is_recurring: true,
      recurring_id: rec.id,
    });

    // Calculate next date
    const next = new Date(rec.next_date || new Date());
    if (rec.frequency === 'monthly') next.setMonth(next.getMonth() + 1);
    else if (rec.frequency === 'weekly') next.setDate(next.getDate() + 7);
    else if (rec.frequency === 'quarterly') next.setMonth(next.getMonth() + 3);
    else if (rec.frequency === 'yearly') next.setFullYear(next.getFullYear() + 1);
    else if (rec.frequency === 'daily') next.setDate(next.getDate() + 1);

    await supabase.from('recurring_invoices').update({
      next_date: next.toISOString().slice(0, 10),
      invoices_generated: (rec.invoices_generated || 0) + 1,
      last_generated: new Date().toISOString().slice(0, 10),
    }).eq('id', rec.id);
    load();
  };

  const toggleStatus = async (rec: any) => {
    await supabase.from('recurring_invoices')
      .update({ status: rec.status === 'Active' ? 'Paused' : 'Active' })
      .eq('id', rec.id);
    load();
  };

  const fmt = (n: number) => n.toLocaleString('ar-SA', { minimumFractionDigits: 2 });
  const filtered = records.filter(r => !search || r.customer_name?.includes(search) || r.description?.includes(search));

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-violet-600 rounded-xl flex items-center justify-center">
            <Clock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">الفواتير المتكررة</h1>
            <p className="text-slate-500 text-sm">{records.filter(r => r.status === 'Active').length} نشط · {records.length} إجمالي</p>
          </div>
        </div>
        <button onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-colors">
          <Plus className="w-4 h-4" /> جدولة فاتورة متكررة
        </button>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث..."
          className="w-full pr-10 pl-4 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-violet-500" />
      </div>

      <div className="grid grid-cols-1 gap-4">
        {isLoading ? (
          <div className="text-center py-12"><RefreshCw className="w-5 h-5 animate-spin mx-auto text-slate-400" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-400 border border-dashed border-slate-200 rounded-2xl">
            لا توجد فواتير متكررة
          </div>
        ) : filtered.map(rec => (
          <div key={rec.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${rec.status === 'Active' ? 'bg-violet-100' : 'bg-slate-100'}`}>
                  <Clock className={`w-5 h-5 ${rec.status === 'Active' ? 'text-violet-600' : 'text-slate-400'}`} />
                </div>
                <div>
                  <div className="font-bold text-slate-800">{rec.customer_name}</div>
                  <div className="text-sm text-slate-500">{rec.description}</div>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs bg-violet-50 text-violet-700 px-2 py-0.5 rounded-full font-medium">
                      {FREQ_AR[rec.frequency]}
                    </span>
                    <span className="text-xs text-slate-400">
                      <Calendar className="w-3 h-3 inline ml-1" />
                      التالي: {rec.next_date || '—'}
                    </span>
                    <span className="text-xs text-slate-400">
                      أُنشئ: {rec.invoices_generated || 0} فاتورة
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-left">
                  <div className="text-lg font-bold text-slate-800">{fmt(rec.total)} {rec.currency}</div>
                  <div className="text-xs text-slate-400">شامل {rec.tax_rate}% ضريبة</div>
                </div>
                <div className="flex flex-col gap-2">
                  <button onClick={() => generateNow(rec)}
                    className="flex items-center gap-1 text-xs px-3 py-1.5 bg-violet-50 hover:bg-violet-100 text-violet-700 rounded-lg font-medium transition-colors">
                    <Play className="w-3 h-3" /> إنشاء الآن
                  </button>
                  <button onClick={() => toggleStatus(rec)}
                    className={`flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg font-medium transition-colors ${rec.status === 'Active' ? 'bg-amber-50 text-amber-700 hover:bg-amber-100' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'}`}>
                    {rec.status === 'Active' ? <><Pause className="w-3 h-3" /> إيقاف</> : <><Play className="w-3 h-3" /> تفعيل</>}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b">
              <h2 className="font-bold">جدولة فاتورة متكررة</h2>
              <button onClick={() => setShowForm(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">العميل *</label>
                <select value={form.customer_id} onChange={e => setForm(f => ({ ...f, customer_id: e.target.value }))}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-violet-500 bg-white">
                  <option value="">اختر العميل</option>
                  {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">الوصف</label>
                <input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  placeholder="مثال: اشتراك شهري — خدمة المحاسبة"
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-violet-500" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">التكرار</label>
                  <select value={form.frequency} onChange={e => setForm(f => ({ ...f, frequency: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-violet-500 bg-white">
                    {Object.entries(FREQ_AR).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">يوم من الشهر</label>
                  <select value={form.day_of_month} onChange={e => setForm(f => ({ ...f, day_of_month: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-violet-500 bg-white">
                    {Array.from({ length: 28 }, (_, i) => i + 1).map(d => <option key={d} value={String(d)}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">المبلغ *</label>
                  <input type="number" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
                    placeholder="0.00"
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-violet-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">الضريبة %</label>
                  <input type="number" value={form.tax_rate} onChange={e => setForm(f => ({ ...f, tax_rate: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-violet-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">تاريخ البداية</label>
                  <input type="date" value={form.start_date} onChange={e => setForm(f => ({ ...f, start_date: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-violet-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">تاريخ النهاية (اختياري)</label>
                  <input type="date" value={form.end_date} onChange={e => setForm(f => ({ ...f, end_date: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-violet-500" />
                </div>
              </div>
              {form.amount && (
                <div className="bg-violet-50 rounded-xl p-3 text-sm font-bold flex justify-between">
                  <span className="text-slate-600">الإجمالي مع الضريبة</span>
                  <span className="text-violet-700">
                    {((parseFloat(form.amount)||0) * (1 + (parseFloat(form.tax_rate)||0)/100)).toLocaleString('ar-SA', { minimumFractionDigits: 2 })} {form.currency}
                  </span>
                </div>
              )}
            </div>
            <div className="flex gap-3 px-6 py-4 border-t">
              <button onClick={() => setShowForm(false)} className="flex-1 border border-slate-200 rounded-xl py-2.5 text-sm font-semibold text-slate-600">إلغاء</button>
              <button onClick={handleSubmit} disabled={isSubmitting || !form.customer_id || !form.amount}
                className="flex-1 bg-violet-600 text-white rounded-xl py-2.5 text-sm font-semibold disabled:opacity-60 hover:bg-violet-700">
                {isSubmitting ? 'جارٍ الحفظ...' : 'جدولة'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
