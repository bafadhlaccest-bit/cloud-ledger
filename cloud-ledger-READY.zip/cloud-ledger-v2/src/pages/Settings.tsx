import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useSettings } from '../context/SettingsContext';
import { safeStorage } from '../utils/safeStorage';
import { 
  Building2, 
  Shield, 
  Globe, 
  Clock, 
  Lock, 
  Mail, 
  Sparkles, 
  Plus, 
  Search, 
  X, 
  CheckCircle2, 
  ArrowRight, 
  ChevronRight, 
  Folder, 
  SlidersHorizontal, 
  Info, 
  FileSpreadsheet, 
  Layers, 
  BarChart3, 
  PieChart, 
  FileText, 
  Boxes, 
  Database, 
  Settings as SettingsIcon,
  Trash2,
  Copy,
  Check,
  Cpu,
  History,
  HardDrive,
  Play,
  Download,
  RefreshCw,
  Activity,
  AlertTriangle,
  Key,
  Network,
  Users
} from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

// Decoupled sub-tabs
import EnterpriseControlTab from '../components/settings/EnterpriseControlTab';
import GeneralSystemTab from '../components/settings/GeneralSystemTab';
import AccountingConfigurationsTab from '../components/settings/AccountingConfigurationsTab';
import GeneralSettings from '../components/settings/GeneralSettings';
import AccountingRules from '../components/settings/AccountingRules';
import WorkflowApprovals from '../components/settings/WorkflowApprovals';
import { db, collection, onSnapshot, query } from '../firebase';
import { useRBAC } from '../hooks/useRBAC';

interface CategoryItem {
  id: string;
  nameKey: string;
  descKey: string;
  icon: React.ComponentType<any>;
}

// Full 19 setting categories matching ERP standards
const SETTING_CATEGORIES: CategoryItem[] = [
  { id: 'cat_general', nameKey: 'settings.cat_general', descKey: 'settings.cat_general_desc', icon: Building2 },
  { id: 'cat_localization', nameKey: 'settings.cat_localization', descKey: 'settings.cat_localization_desc', icon: Globe },
  { id: 'cat_enterprise_control', nameKey: 'settings.cat_enterprise_control', descKey: 'settings.cat_enterprise_control_desc', icon: Shield },
  { id: 'cat_coa_mapping', nameKey: 'settings.cat_coa_mapping', descKey: 'settings.cat_coa_mapping_desc', icon: SlidersHorizontal },
  { id: 'cat_vat_rules', nameKey: 'settings.cat_vat_rules', descKey: 'settings.cat_vat_rules_desc', icon: PercentIcon },
  { id: 'cat_inv_sequence', nameKey: 'settings.cat_inv_sequence', descKey: 'settings.cat_inv_sequence_desc', icon: FileSpreadsheet },
  { id: 'cat_bill_sequence', nameKey: 'settings.cat_bill_sequence', descKey: 'settings.cat_bill_sequence_desc', icon: FileText },
  { id: 'cat_cust_credit', nameKey: 'settings.cat_cust_credit', descKey: 'settings.cat_cust_credit_desc', icon: AlertTriangle },
  { id: 'cat_vendor_terms', nameKey: 'settings.cat_vendor_terms', descKey: 'settings.cat_vendor_terms_desc', icon: Clock },
  { id: 'cat_service_module', nameKey: 'settings.cat_service_module', descKey: 'settings.cat_service_module_desc', icon: SpanIcon },
  { id: 'cat_user_auth', nameKey: 'settings.cat_user_auth', descKey: 'settings.cat_user_auth_desc', icon: Users },
  { id: 'cat_permission_matrix', nameKey: 'settings.cat_permission_matrix', descKey: 'settings.cat_permission_matrix_desc', icon: Lock },
  { id: 'cat_multi_company', nameKey: 'settings.cat_multi_company', descKey: 'settings.cat_multi_company_desc', icon: Layers },
  { id: 'cat_inventory_control', nameKey: 'settings.cat_inventory_control', descKey: 'settings.cat_inventory_control_desc', icon: Boxes },
  { id: 'cat_audit_logs', nameKey: 'settings.cat_audit_logs', descKey: 'settings.cat_audit_logs_desc', icon: History },
  { id: 'cat_api_channels', nameKey: 'settings.cat_api_channels', descKey: 'settings.cat_api_channels_desc', icon: Key },
  { id: 'cat_automated_rules', nameKey: 'settings.cat_automated_rules', descKey: 'settings.cat_automated_rules_desc', icon: Play },
  { id: 'cat_diagnostics', nameKey: 'settings.cat_diagnostics', descKey: 'settings.cat_diagnostics_desc', icon: Database },
  { id: 'cat_ai_accountant', nameKey: 'settings.cat_ai_accountant', descKey: 'settings.cat_ai_accountant_desc', icon: Cpu }
];

function PercentIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="19" x2="5" y1="5" y2="19" />
      <circle cx="6.5" cy="6.5" r="2.5" />
      <circle cx="17.5" cy="17.5" r="2.5" />
    </svg>
  );
}

function SpanIcon(props: any) {
  return <Sparkles className="w-4 h-4" {...props} />;
}

export default function Settings() {
  const { t, i18n } = useTranslation();
  const { settings, isLoading: isCtxLoading, updateSettings } = useSettings();
  const isRtl = i18n.language === 'ar';

  // Navigation and search states
  const [activeCategory, setActiveCategory] = useState<string>('cat_general');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'failed'>('idle');

  // Load COA accounts for mapping dropdowns
  const [accountsList, setAccountsList] = useState<any[]>([]);
  const [isAccountsLoading, setIsAccountsLoading] = useState<boolean>(true);

  // States for sub-form entities
  const [users] = useState<any[]>([
    { id: 'u1', name: 'Ali Bafadhl (Admin)', email: 'acc.ali.bafadhl@gmail.com', role: 'Admin', status: 'Active' },
    { id: 'u2', name: 'Waleed Mohsen', email: 'waleed.m@huraibi.com', role: 'Accountant', status: 'Active' },
    { id: 'u3', name: 'Khaled Omar', email: 'khaled.o@huraibi.com', role: 'Sales', status: 'Pending' }
  ]);
  const [companies] = useState<any[]>([
    { id: 'c1', name: 'Al-Huraibi Trading HQ', code: 'AHTC', isDefault: true, address: "Sana'a Main Office" },
    { id: 'c2', name: 'Al-Huraibi Logistics & Retail LLC', code: 'AHLR', isDefault: false, address: 'Aden Freezone Branch' }
  ]);
  const [apiKeys] = useState<any[]>([
    { key: 'sec_8fa09bc0f...2c114', name: 'Al-Kuraimi Exchange Webhook Integrator', scope: 'Read/Write Ledger Transactions', created: '2026-05-18' },
    { key: 'sec_1a0cb7fe4...8fe3b', name: 'OCR AI Engine Mobile Client Pipeline', scope: 'General Account Matching only', created: '2026-06-01' }
  ]);
  const [automationRules] = useState<any[]>([
    { id: 'a1', name: 'WhatsApp Settle Payment Alert', trigger: 'On Journal Post Success', action: 'Trigger immediate automated WhatsApp delivery', isActive: true },
    { id: 'a2', name: 'Slack Low Inventory Alert', trigger: 'Stock Drops Below Reorder Level', action: 'Push JSON webhook message to warehouse channel', isActive: false }
  ]);

  // Form states initialized to settings values or overrides
  const [formConfig, setFormConfig] = useState({
    systemName: '',
    systemLogo: '',
    timezone: '',
    theme: 'light' as 'light' | 'dark',
    currency: 'YER',
    defaultSalesAccountId: '',
    defaultPayableAccountId: '',
    defaultCashAccountId: '',
    vatPercentage: 15,
    invoicePrefix: '',
    invoiceSuffix: '',
    billPrefix: '',
    billSuffix: '',
    customerCreditLimitRestriction: true,
    vendorPaymentTermThreshold: 30,
    enableServiceModule: true,
    permissionsMatrix: {
      Admin: { read: true, create: true, update: true, delete: true },
      Accountant: { read: true, create: true, update: true, delete: false },
      Vendor: { read: true, create: false, update: false, delete: false }
    }
  });

  // Fetch true accounts list from Firestore db
  useEffect(() => {
    try {
      const q = collection(db, 'accounts');
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const fetched: any[] = [];
        snapshot.forEach((d) => {
          fetched.push({ id: d.id, ...d.data() });
        });
        setAccountsList(fetched.sort((a, b) => a.code.localeCompare(b.code)));
        setIsAccountsLoading(false);
      }, (error) => {
        console.warn("Could not load accounts for mapping configuration list real-time:", error.message);
        setIsAccountsLoading(false);
      });
      return () => unsubscribe();
    } catch (e) {
      console.warn("Failed loading accounts for mapping configuration list", e);
      setIsAccountsLoading(false);
    }
  }, []);

  // Update form input whenever global configuration changes or completes loading
  useEffect(() => {
    if (settings) {
      setFormConfig({
        systemName: settings.systemName || '',
        systemLogo: settings.systemLogo || '',
        timezone: settings.timezone || 'Asia/Aden',
        theme: settings.theme || 'light',
        currency: settings.currency || 'YER',
        defaultSalesAccountId: settings.defaultSalesAccountId || '',
        defaultPayableAccountId: settings.defaultPayableAccountId || '',
        defaultCashAccountId: settings.defaultCashAccountId || '',
        vatPercentage: settings.vatPercentage || 15,
        invoicePrefix: settings.invoicePrefix || 'INV',
        invoiceSuffix: settings.invoiceSuffix || '',
        billPrefix: settings.billPrefix || 'BILL',
        billSuffix: settings.billSuffix || '',
        customerCreditLimitRestriction: typeof settings.customerCreditLimitRestriction !== 'undefined' ? !!settings.customerCreditLimitRestriction : true,
        vendorPaymentTermThreshold: settings.vendorPaymentTermThreshold || 30,
        enableServiceModule: typeof settings.enableServiceModule !== 'undefined' ? !!settings.enableServiceModule : true,
        permissionsMatrix: settings.permissionsMatrix || {
          Admin: { read: true, create: true, update: true, delete: true },
          Accountant: { read: true, create: true, update: true, delete: false },
          Vendor: { read: true, create: false, update: false, delete: false }
        }
      });
    }
  }, [settings]);

  const handleInputChange = (key: string, value: any) => {
    setFormConfig(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handlePermissionsChange = (role: 'Admin' | 'Accountant' | 'Vendor', action: 'read' | 'create' | 'update' | 'delete', checked: boolean) => {
    setFormConfig(prev => {
      const copy = { ...prev.permissionsMatrix };
      copy[role] = {
        ...copy[role],
        [action]: checked
      };
      return {
        ...prev,
        permissionsMatrix: copy
      };
    });
  };

  const handleLanguageChange = (lang: string) => {
    i18n.changeLanguage(lang);
    try {
      safeStorage.setItem('i18nextLng', lang);
    } catch {}
  };

  // Submit and save configuration parameters
  const saveAllSettings = async () => {
    setSaveStatus('saving');
    try {
      const success = await updateSettings(formConfig);
      if (success) {
        setSaveStatus('saved');
        setTimeout(() => setSaveStatus('idle'), 3000);
      } else {
        setSaveStatus('failed');
      }
    } catch {
      setSaveStatus('failed');
    }
  };

  // Filter Categories for Sidebar
  const filteredCategories = SETTING_CATEGORIES.filter(c => {
    const name = t(c.nameKey).toLowerCase();
    const desc = t(c.descKey).toLowerCase();
    const query = searchTerm.toLowerCase();
    return name.includes(query) || desc.includes(query);
  });

  const generalCategories = [
    'cat_general', 
    'cat_localization', 
    'cat_user_auth', 
    'cat_permission_matrix', 
    'cat_audit_logs', 
    'cat_api_channels', 
    'cat_automated_rules', 
    'cat_diagnostics', 
    'cat_ai_accountant'
  ];

  const renderActiveCategoryForm = () => {
    if (activeCategory === 'cat_general' || activeCategory === 'cat_localization' || activeCategory === 'cat_multi_company') {
      return (
        <GeneralSettings
          formConfig={formConfig}
          handleInputChange={handleInputChange}
          handleLanguageChange={handleLanguageChange}
          isRtl={isRtl}
        />
      );
    }

    if (activeCategory === 'cat_coa_mapping' || activeCategory === 'cat_vat_rules') {
      return (
        <AccountingRules
          formConfig={formConfig}
          handleInputChange={handleInputChange}
          accountsList={accountsList}
          isAccountsLoading={isAccountsLoading}
          isRtl={isRtl}
        />
      );
    }

    if (activeCategory === 'cat_permission_matrix' || activeCategory === 'cat_cust_credit') {
      return (
        <WorkflowApprovals
          formConfig={formConfig}
          handleInputChange={handleInputChange}
          handlePermissionsChange={handlePermissionsChange}
          isRtl={isRtl}
        />
      );
    }

    if (activeCategory === 'cat_enterprise_control') {
      return (
        <EnterpriseControlTab 
          accountsList={accountsList}
          isAccountsLoading={isAccountsLoading}
          isRtl={isRtl}
        />
      );
    }

    if (generalCategories.includes(activeCategory)) {
      return (
        <GeneralSystemTab 
          activeCategory={activeCategory}
          formConfig={formConfig}
          handleInputChange={handleInputChange}
          handlePermissionsChange={handlePermissionsChange}
          handleLanguageChange={handleLanguageChange}
          users={users}
          apiKeys={apiKeys}
          automationRules={automationRules}
          isRtl={isRtl}
        />
      );
    }

    return (
      <AccountingConfigurationsTab 
        activeCategory={activeCategory}
        formConfig={formConfig}
        handleInputChange={handleInputChange}
        accountsList={accountsList}
        isAccountsLoading={isAccountsLoading}
        companies={companies}
        isRtl={isRtl}
      />
    );
  };

  return (
    <div className={cn("p-6 flex flex-col gap-6 w-full min-h-screen bg-slate-50 text-slate-800", isRtl ? "text-right" : "text-left")} dir={isRtl ? "rtl" : "ltr"}>
      
      {/* Top Banner & Control Board */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            <SettingsIcon className="w-6 h-6 text-indigo-600" />
            {t('settings.title')}
          </h1>
          <p className="text-slate-500 text-sm mt-1 max-w-xl leading-relaxed">
            {isRtl 
              ? 'بوابة ضبط معايير النظام المحاسبي المتكامل، الأرقام التسلسلية، الهوية، الربط المحاسبي وصلاحيات المستخدمين.' 
              : 'Enterprise-grade system core adjustments, numbering sequence formats, rules matching and fine-grained permissions grid.'
            }
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-semibold border border-emerald-200/60 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            PostgreSQL Active
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold border border-indigo-200/60 font-mono">
            <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse shrink-0" />
            Firestore Online
          </div>

          <button
            onClick={saveAllSettings}
            disabled={saveStatus === 'saving'}
            className={cn(
              "flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold shadow-sm transition-all text-sm cursor-pointer",
              saveStatus === 'saving' ? "bg-slate-300 text-slate-500 cursor-not-allowed" :
              saveStatus === 'saved' ? "bg-emerald-600 text-white hover:bg-emerald-700" :
              saveStatus === 'failed' ? "bg-rose-600 text-white hover:bg-rose-700" :
              "bg-indigo-600 text-white hover:bg-indigo-700 hover:shadow-indigo-100"
            )}
          >
            {saveStatus === 'saving' && <RefreshCw className="w-4 h-4 animate-spin" />}
            {saveStatus === 'saved' && <Check className="w-4 h-4" />}
            {saveStatus === 'failed' && <X className="w-4 h-4" />}
            {saveStatus === 'saving' ? (isRtl ? 'جاري الحفظ...' : 'Saving...') :
             saveStatus === 'saved' ? (isRtl ? 'تم الحفظ بنجاح!' : 'Configuration Saved!') :
             saveStatus === 'failed' ? (isRtl ? 'فشل الاتصال' : 'Failed Saving!') :
             (isRtl ? 'حفظ إعدادات النظام' : 'Save System Settings')}
          </button>
        </div>
      </div>

      {saveStatus === 'saved' && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-emerald-50 border border-emerald-300 rounded-xl p-4 text-emerald-800 text-sm flex items-center gap-3 shadow-sm font-medium"
        >
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{t('settings.saved_success')}</span>
        </motion.div>
      )}

      {/* Main Settings Panel Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        
        {/* Left Navigator Pane */}
        <div className="lg:col-span-1 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col gap-4">
          <div className="relative">
            <Search className="absolute top-2.5 left-3 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={t('common.search', 'Search...')}
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')} 
                className="absolute top-2.5 right-3 text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="flex flex-col gap-1 max-h-[500px] overflow-y-auto pr-1">
            {filteredCategories.map((cat) => {
              const IconComp = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={cn(
                    "flex flex-col items-start gap-1 p-3 rounded-xl transition-all cursor-pointer border text-left",
                    isActive 
                      ? "bg-indigo-50/60 border-indigo-200/70 text-indigo-950" 
                      : "bg-transparent border-transparent hover:bg-slate-50 text-slate-700",
                    isRtl && "text-right"
                  )}
                >
                  <div className="flex items-center gap-2.5 w-full">
                    <div className={cn(
                      "p-1.5 rounded-lg shrink-0",
                      isActive ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-500"
                    )}>
                      <IconComp className="w-4.5 h-4.5" />
                    </div>
                    <span className="font-semibold text-sm line-clamp-1">{t(cat.nameKey)}</span>
                  </div>
                  <p className="text-xs text-slate-400/90 leading-normal line-clamp-1 mt-0.5">
                    {t(cat.descKey)}
                  </p>
                </button>
              );
            })}

            {filteredCategories.length === 0 && (
              <div className="text-center py-8 text-slate-400 text-sm">
                {isRtl ? 'لا توجد تطابقات لعملية البحث' : 'No matching categories found'}
              </div>
            )}
          </div>
        </div>

        {/* Right Active Configuration Workspace */}
        <div className="lg:col-span-3 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm min-h-[550px]">
          
          {/* Breadcrumbs workspace path */}
          <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
              <span>{isRtl ? 'إعدادات النظام المحاسبي' : 'ERP System Settings'}</span>
              <ChevronRight className="w-3.5 h-3.5 shrink-0" />
              <span className="text-indigo-600 font-bold">
                {t(SETTING_CATEGORIES.find(c => c.id === activeCategory)?.nameKey || '')}
              </span>
            </div>
            
            <div className="text-xs text-slate-400/90 italic font-medium">
              Category ID: <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">{activeCategory}</span>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.15 }}
              className="space-y-6"
            >
              {renderActiveCategoryForm()}
            </motion.div>
          </AnimatePresence>

        </div>
      </div>
    </div>
  );
}
