/**
 * PurchaseOrders — أوامر الشراء
 * موجود في زوهو/زيرو، ناقص من النظام
 */
import React, { useState, useEffect } from 'react';
import { Plus, FileText, CheckCircle2, X, Search, RefreshCw, ArrowRight, Package } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useRBAC } from '../hooks/useRBAC';

const STATUS_STYLE: Record<string, string> = {
  Draft: 'bg-slate-100 text-slate-600', Sent: 'bg-blue-100 text-blue-700',
  Received: 'bg-emerald-100 text-emerald-700', Cancelled: 'bg-red-100 text-red-600',
  Partial: 'bg-amber-100 text-amber-700',
};
const STATUS_AR: Record<string, string> = {
  Draft: 'مسودة', Sent: 'مُرسَل', Received: 'مستلم', Cancelled: 'ملغى', Partial: 'استلام جزئي',
};

export default function PurchaseOrders() {
  const { companyId } = useRBAC();
  const [orders, setOrders] = useState<any[]>([]);
  const [vendors, setVendors] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [form, setForm] = useState({
    vendor_id: '', date: new Date().toISOString().slice(0, 10),
    expected_date: '', currency: 'SAR', notes: '',
    lines: [{ description: '', quantity: 1, rate: 0, tax_rate: 15, amount: 0 }] as any[],
  });

  useEffect(() => { if (companyId) load(); }, [companyId]);

  async function load() {
    setIsLoading(true);
    const [{ data: o }, { data: v }] = await Promise.all([
      supabase.from('purchase_orders').select('*').eq('company_id', companyId).order('date', { ascending: false }),
      supabase.from('vendors').select('id,name').eq('company_id', companyId),
    ]);
    setOrders(o || []);
    setVendors(v || []);
    setIsLoading(false);
  }

  const calcLine = (line: any) => ({ ...line, amount: line.quantity * line.rate });
  const subtotal = form.lines.reduce((s, l) => s + l.amount, 0);
  const taxTotal = form.lines.reduce((s, l) => s + l.amount * (l.tax_rate / 100), 0);
  const total = subtotal + taxTotal;
  const fmt = (n: number) => n.toLocaleString('ar-SA', { minimumFractionDigits: 2 });

  const handleSubmit = async () => {
    if (!form.vendor_id) return;
    setIsSubmitting(true);
    const vend = vendors.find(v => v.id === form.vendor_id);
    await supabase.from('purchase_orders').insert({
      company_id: companyId, number: `PO-${Date.now().toString().slice(-6)}`,
      vendor_id: form.vendor_id, vendor_name: vend?.name || '',
      date: form.date, expected_date: form.expected_date || null,
      status: 'Draft', subtotal, tax_total: taxTotal, total,
      notes: form.notes, currency: form.currency, lines: form.lines,
    });
    setShowForm(false);
    load();
    setIsSubmitting(false);
  };

  // Convert PO → Bill
  const convertToBill = async (po: any) => {
    if (po.status === 'Received') return;
    await supabase.from('bills').insert({
      company_id: companyId, number: `BILL-${Date.now().toString().slice(-6)}`,
      vendor_id: po.vendor_id, date: new Date().toISOString().slice(0, 10),
      due_date: new Date(Date.now() + 30 * 864e5).toISOString().slice(0, 10),
      status: 'Unpaid', subtotal: po.subtotal, tax_total: po.tax_total, total: po.total,
      notes: `محوَّل من أمر شراء ${po.number}`, currency: po.currency,
    });
    await supabase.from('purchase_orders').update({ status: 'Received' }).eq('id', po.id);
    load();
  };

  const filtered = orders.filter(o => !search || o.number?.includes(search) || o.vendor_name?.includes(search));

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center">
            <Package className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">أوامر الشراء</h1>
            <p className="text-slate-500 text-sm">{orders.length} أمر شراء</p>
          </div>
        </div>
        <button onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-colors">
          <Plus className="w-4 h-4" /> أمر شراء جديد
        </button>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث..."
          className="w-full pr-10 pl-4 py-2.5 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-sm" />
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {['رقم الأمر', 'المورد', 'التاريخ', 'الإجمالي', 'الحالة', 'إجراءات'].map(h => (
                <th key={h} className="text-right px-4 py-3 text-xs font-bold text-slate-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {isLoading ? (
              <tr><td colSpan={6} className="text-center py-12"><RefreshCw className="w-5 h-5 animate-spin text-slate-400 mx-auto" /></td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={6} className="text-center py-12 text-slate-400">لا توجد أوامر شراء</td></tr>
            ) : filtered.map(o => (
              <tr key={o.id} className="hover:bg-slate-50">
                <td className="px-4 py-3 font-mono font-medium text-emerald-600">{o.number}</td>
                <td className="px-4 py-3 font-medium text-slate-800">{o.vendor_name}</td>
                <td className="px-4 py-3 text-slate-500">{o.date}</td>
                <td className="px-4 py-3 font-bold">{fmt(o.total)} {o.currency}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${STATUS_STYLE[o.status]}`}>
                    {STATUS_AR[o.status]}
                  </span>
                </td>
                <td className="px-4 py-3">
                  {o.status !== 'Received' && o.status !== 'Cancelled' && (
                    <button onClick={() => convertToBill(o)}
                      className="flex items-center gap-1 text-xs px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg font-medium">
                      <ArrowRight className="w-3 h-3" /> فاتورة شراء
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b">
              <h2 className="font-bold">أمر شراء جديد</h2>
              <button onClick={() => setShowForm(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">المورد *</label>
                  <select value={form.vendor_id} onChange={e => setForm(f => ({ ...f, vendor_id: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500 bg-white">
                    <option value="">اختر المورد</option>
                    {vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">العملة</label>
                  <select value={form.currency} onChange={e => setForm(f => ({ ...f, currency: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500 bg-white">
                    {['SAR','AED','USD','KWD','QAR','BHD','EGP'].map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">التاريخ</label>
                  <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">تاريخ التسليم المتوقع</label>
                  <input type="date" value={form.expected_date} onChange={e => setForm(f => ({ ...f, expected_date: e.target.value }))}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500" />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-xs font-semibold text-slate-600">البنود</span>
                  <button onClick={() => setForm(f => ({ ...f, lines: [...f.lines, { description: '', quantity: 1, rate: 0, tax_rate: 15, amount: 0 }] }))}
                    className="text-xs text-emerald-600 font-medium flex items-center gap-1">
                    <Plus className="w-3 h-3" /> إضافة
                  </button>
                </div>
                {form.lines.map((line, i) => (
                  <div key={i} className="grid grid-cols-12 gap-2 mb-2">
                    <input value={line.description} onChange={e => { const l = [...form.lines]; l[i] = calcLine({ ...l[i], description: e.target.value }); setForm(f => ({ ...f, lines: l })); }}
                      placeholder="وصف" className="col-span-5 px-2.5 py-2 border border-slate-200 rounded-lg text-xs outline-none" />
                    <input type="number" value={line.quantity} onChange={e => { const l = [...form.lines]; l[i] = calcLine({ ...l[i], quantity: +e.target.value }); setForm(f => ({ ...f, lines: l })); }}
                      className="col-span-2 px-2.5 py-2 border border-slate-200 rounded-lg text-xs outline-none" />
                    <input type="number" value={line.rate} onChange={e => { const l = [...form.lines]; l[i] = calcLine({ ...l[i], rate: +e.target.value }); setForm(f => ({ ...f, lines: l })); }}
                      className="col-span-2 px-2.5 py-2 border border-slate-200 rounded-lg text-xs outline-none" />
                    <input type="number" value={line.tax_rate} onChange={e => { const l = [...form.lines]; l[i] = calcLine({ ...l[i], tax_rate: +e.target.value }); setForm(f => ({ ...f, lines: l })); }}
                      className="col-span-2 px-2.5 py-2 border border-slate-200 rounded-lg text-xs outline-none" />
                    <button onClick={() => setForm(f => ({ ...f, lines: f.lines.filter((_, j) => j !== i) }))}
                      className="col-span-1 p-1.5 text-red-400 hover:bg-red-50 rounded-lg flex items-center justify-center">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="bg-slate-50 rounded-xl p-3 text-sm space-y-1.5">
                <div className="flex justify-between"><span className="text-slate-500">قبل الضريبة</span><span>{fmt(subtotal)}</span></div>
                <div className="flex justify-between"><span className="text-slate-500">الضريبة</span><span>{fmt(taxTotal)}</span></div>
                <div className="flex justify-between font-bold border-t border-slate-200 pt-2"><span>الإجمالي</span><span className="text-emerald-600">{fmt(total)} {form.currency}</span></div>
              </div>
            </div>
            <div className="flex gap-3 px-6 py-4 border-t">
              <button onClick={() => setShowForm(false)} className="flex-1 border border-slate-200 rounded-xl py-2.5 text-sm font-semibold text-slate-600">إلغاء</button>
              <button onClick={handleSubmit} disabled={isSubmitting || !form.vendor_id}
                className="flex-1 bg-emerald-600 text-white rounded-xl py-2.5 text-sm font-semibold disabled:opacity-60">
                {isSubmitting ? 'حفظ...' : 'حفظ'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
