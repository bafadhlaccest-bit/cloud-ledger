import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { TrendingUp, TrendingDown, DollarSign, Users, ShoppingCart, AlertCircle, RefreshCw, FileText, CheckCircle2, Clock, Zap, Brain } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from 'recharts';
import { useDashboardData } from '../../../hooks/useDashboardData';
import { Link } from 'react-router-dom';
import WeeklyHealthReport from '../../../components/WeeklyHealthReport';

const fmt = (n: number, currency = 'SAR') =>
  n >= 1_000_000 ? `${(n / 1_000_000).toFixed(1)}م`
  : n >= 1_000 ? `${(n / 1_000).toFixed(1)}ك`
  : n.toFixed(0);

const STATUS_COLORS: Record<string, string> = {
  Paid: 'bg-emerald-100 text-emerald-700',
  Sent: 'bg-blue-100 text-blue-700',
  Draft: 'bg-slate-100 text-slate-600',
  Overdue: 'bg-red-100 text-red-700',
  Cancelled: 'bg-slate-100 text-slate-400',
};

export const ExecutiveDashboard: React.FC = () => {
  const { t, i18n } = useTranslation();
  const isRtl = i18n.language === 'ar';
  const d = useDashboardData();
  const [showWeeklyReport, setShowWeeklyReport] = useState(false);

  if (d.isLoading) return (
    <div className="flex items-center justify-center h-64 text-slate-400">
      <RefreshCw className="w-5 h-5 animate-spin mr-2" />
      <span>{isRtl ? 'جارٍ تحميل البيانات...' : 'Loading dashboard...'}</span>
    </div>
  );

  if (d.error) return (
    <div className="p-4 bg-red-50 rounded-xl text-red-600 flex items-center gap-2">
      <AlertCircle className="w-4 h-4" /> {d.error}
    </div>
  );

  const kpis = [
    {
      label: isRtl ? 'إجمالي الإيرادات' : 'Total Revenue',
      value: fmt(d.totalRevenue),
      sub: isRtl ? `هذا الشهر: ${fmt(d.revenueThisMonth)}` : `This month: ${fmt(d.revenueThisMonth)}`,
      trend: d.revenueGrowth, icon: DollarSign, color: 'indigo',
    },
    {
      label: isRtl ? 'صافي الربح' : 'Net Income',
      value: fmt(d.netIncome),
      sub: `${d.netMargin.toFixed(1)}% ${isRtl ? 'هامش ربح' : 'margin'}`,
      trend: d.netIncome > 0 ? 10 : -10, icon: TrendingUp, color: 'emerald',
    },
    {
      label: isRtl ? 'ذمم مدينة' : 'Receivables',
      value: fmt(d.totalReceivables),
      sub: isRtl ? `متأخرة: ${fmt(d.overdueReceivables)}` : `Overdue: ${fmt(d.overdueReceivables)}`,
      trend: d.overdueReceivables > 0 ? -5 : 5, icon: Clock, color: 'amber',
    },
    {
      label: isRtl ? 'رصيد الصندوق والبنك' : 'Cash & Bank',
      value: fmt(d.cashBalance),
      sub: isRtl ? `مطلوبات: ${fmt(d.totalPayables)}` : `Payables: ${fmt(d.totalPayables)}`,
      trend: d.cashBalance > d.totalPayables ? 8 : -8, icon: DollarSign, color: 'blue',
    },
  ];

  const colorMap: Record<string, string> = {
    indigo: 'bg-indigo-50 text-indigo-600 border-indigo-100',
    emerald: 'bg-emerald-50 text-emerald-600 border-emerald-100',
    amber: 'bg-amber-50 text-amber-600 border-amber-100',
    blue: 'bg-blue-50 text-blue-600 border-blue-100',
  };

  return (
    <div className="space-y-6 p-1" dir={isRtl ? 'rtl' : 'ltr'}>
      {showWeeklyReport && <WeeklyHealthReport onClose={() => setShowWeeklyReport(false)} />}

      {/* AI Advisor Banner */}
      <div className="flex items-center justify-between p-4 rounded-2xl bg-gradient-to-l from-indigo-900 to-slate-900 text-white">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-indigo-500/30 flex items-center justify-center">
            <Brain className="w-5 h-5 text-indigo-300" />
          </div>
          <div>
            <div className="font-semibold text-sm">المستشار المالي الذكي جاهز</div>
            <div className="text-indigo-300 text-xs">اسأله عن أي قرار مالي أو تحليل للأداء</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowWeeklyReport(true)}
            className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 bg-emerald-500 hover:bg-emerald-400 text-white rounded-lg transition-colors">
            <Zap className="w-3.5 h-3.5" /> تقرير أسبوعي
          </button>
          <Link to="/advisor"
            className="flex items-center gap-1.5 text-xs font-semibold px-3 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors">
            <Brain className="w-3.5 h-3.5" /> استشارة مالية
          </Link>
        </div>
      </div>
      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map(k => {
          const Icon = k.icon;
          const isUp = k.trend >= 0;
          return (
            <div key={k.label} className={`bg-white rounded-2xl p-5 border ${colorMap[k.color].split(' ')[2]} shadow-sm`}>
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 rounded-xl ${colorMap[k.color].split(' ').slice(0,2).join(' ')}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span className={`text-xs font-semibold flex items-center gap-0.5 ${isUp ? 'text-emerald-600' : 'text-red-500'}`}>
                  {isUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {Math.abs(k.trend).toFixed(0)}%
                </span>
              </div>
              <div className="text-2xl font-bold text-slate-800 mb-1">{k.value}</div>
              <div className="text-xs text-slate-500">{k.label}</div>
              <div className="text-xs text-slate-400 mt-0.5">{k.sub}</div>
            </div>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Revenue vs Expenses */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-4 text-sm">
            {isRtl ? 'الإيرادات والمصروفات — آخر 6 أشهر' : 'Revenue vs Expenses — Last 6 Months'}
          </h3>
          {d.monthlyTrend.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={d.monthlyTrend} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} tickFormatter={v => fmt(v)} />
                <Tooltip formatter={(v: any) => fmt(Number(v))} />
                <Legend />
                <Bar dataKey="revenue" name={isRtl ? 'إيرادات' : 'Revenue'} fill="#6366f1" radius={[4,4,0,0]} />
                <Bar dataKey="expenses" name={isRtl ? 'مصروفات' : 'Expenses'} fill="#f43f5e" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-slate-400 text-sm">
              {isRtl ? 'لا توجد بيانات بعد — أضف فواتير أولاً' : 'No data yet — add invoices first'}
            </div>
          )}
        </div>

        {/* Profit trend */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-4 text-sm">
            {isRtl ? 'منحنى صافي الربح' : 'Net Profit Trend'}
          </h3>
          {d.monthlyTrend.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={d.monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} tickFormatter={v => fmt(v)} />
                <Tooltip formatter={(v: any) => fmt(Number(v))} />
                <Line type="monotone" dataKey="profit" name={isRtl ? 'صافي ربح' : 'Net Profit'} stroke="#10b981" strokeWidth={2.5} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-48 flex items-center justify-center text-slate-400 text-sm">
              {isRtl ? 'لا توجد بيانات' : 'No data yet'}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Invoice Summary */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-4 text-sm flex items-center gap-2">
            <FileText className="w-4 h-4 text-slate-400" />
            {isRtl ? 'ملخص الفواتير' : 'Invoice Summary'}
          </h3>
          <div className="space-y-3">
            {[
              { label: isRtl ? 'إجمالي' : 'Total', value: d.totalInvoices, color: 'slate' },
              { label: isRtl ? 'مدفوعة' : 'Paid', value: d.paidInvoices, color: 'emerald' },
              { label: isRtl ? 'مسودة' : 'Draft', value: d.draftInvoices, color: 'slate' },
              { label: isRtl ? 'متأخرة' : 'Overdue', value: d.overdueInvoices, color: 'red' },
            ].map(item => (
              <div key={item.label} className="flex justify-between items-center">
                <span className="text-sm text-slate-600">{item.label}</span>
                <span className={`font-bold text-sm ${item.color === 'emerald' ? 'text-emerald-600' : item.color === 'red' ? 'text-red-600' : 'text-slate-800'}`}>
                  {item.value}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-3 gap-2 text-center text-xs">
            <div><div className="font-bold text-slate-700">{d.totalCustomers}</div><div className="text-slate-400">{isRtl ? 'عميل' : 'Customers'}</div></div>
            <div><div className="font-bold text-slate-700">{d.totalVendors}</div><div className="text-slate-400">{isRtl ? 'مورد' : 'Vendors'}</div></div>
            <div><div className="font-bold text-slate-700">{d.totalItems}</div><div className="text-slate-400">{isRtl ? 'صنف' : 'Items'}</div></div>
          </div>
        </div>

        {/* Top Customers */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-4 text-sm flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-400" />
            {isRtl ? 'أكبر العملاء' : 'Top Customers'}
          </h3>
          {d.topCustomers.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-sm">{isRtl ? 'لا توجد بيانات' : 'No data yet'}</div>
          ) : (
            <div className="space-y-3">
              {d.topCustomers.map((c, i) => (
                <div key={c.name} className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${i === 0 ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'}`}>{i + 1}</div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-800 truncate">{c.name}</div>
                    <div className="w-full bg-slate-100 rounded-full h-1 mt-1">
                      <div className="bg-indigo-500 h-1 rounded-full" style={{ width: `${Math.min(100, (c.total / (d.topCustomers[0]?.total || 1)) * 100)}%` }} />
                    </div>
                  </div>
                  <div className="text-sm font-bold text-slate-700 shrink-0">{fmt(c.total)}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Invoices */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
          <h3 className="font-bold text-slate-800 mb-4 text-sm flex items-center gap-2">
            <ShoppingCart className="w-4 h-4 text-slate-400" />
            {isRtl ? 'أحدث الفواتير' : 'Recent Invoices'}
          </h3>
          {d.recentInvoices.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-sm">{isRtl ? 'لا توجد فواتير بعد' : 'No invoices yet'}</div>
          ) : (
            <div className="space-y-2.5">
              {d.recentInvoices.slice(0, 5).map(inv => (
                <div key={inv.id} className="flex items-center justify-between">
                  <div className="min-w-0">
                    <div className="text-xs font-medium text-slate-800 truncate">{inv.customer}</div>
                    <div className="text-xs text-slate-400">{inv.number} · {inv.date}</div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${STATUS_COLORS[inv.status] || 'bg-slate-100 text-slate-500'}`}>{inv.status}</span>
                    <span className="text-xs font-bold text-slate-700">{fmt(inv.total)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
