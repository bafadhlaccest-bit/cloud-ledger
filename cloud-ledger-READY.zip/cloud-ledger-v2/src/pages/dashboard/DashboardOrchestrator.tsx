import React from 'react';
import { ExecutiveDashboard } from './levels/ExecutiveDashboard';

// All roles get the same real-data dashboard
// Role-based filtering happens within useDashboardData
export const DashboardOrchestrator: React.FC = () => {
  return <ExecutiveDashboard />;
};
