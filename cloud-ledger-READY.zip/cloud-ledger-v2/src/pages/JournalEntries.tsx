import React from 'react';
import { useTranslation } from 'react-i18next';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  serverTimestamp,
  orderBy,
  writeBatch
import { JournalEntry, Account, JournalEntryLine } from '../types';
import { SEEDED_ACCOUNTS, getMergedAccounts } from '../data/initialData';
import { formatCurrency, cn, formatDate, getLocalizedLabel, getLocalizedField, getLocalizedName } from '../lib/utils';
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';
import { Download, UploadCloud } from 'lucide-react';
import ImportModal from '../components/ImportModal';
import { exportToExcel, exportToPDF } from '../utils/exportImport';
import { 
  Plus, 
  Search, 
  Trash2, 
  Loader2, 
  ArrowLeft, 
  Calendar, 
  DollarSign, 
  CheckCircle2, 
  AlertTriangle, 
  Check, 
  X, 
  Copy, 
  PlusCircle, 
  Undo2, 
  ChevronRight, 
  FileSpreadsheet, 
  BookOpen, 
  MapPin, 
  Briefcase,
  Inbox,
  Edit2,
  ArrowRightLeft
} from 'lucide-react';
import { db, collection, addDoc, updateDoc, deleteDoc, onSnapshot, query, where, orderBy, serverTimestamp, doc } from '../firebase';

// Interfaces for inline editor rows
interface RowState {
  accountId: string;
  accountCode: string;
  accountName: string;
  description: string;
  debit: string;
  credit: string;
  taxRate: number; // e.g. 15 for 15% VAT, 5 for 5% tax, 0 for Tax Exempt / No Tax
  taxLabel: string;
  region: string;
  department: string;
  projectId: string;
  branchId: string;
  departmentId: string;
}

export default function JournalEntries() {
  const { t } = useTranslation();
  const { companyId } = useRBAC();

  // Core App State
  const [entries, setEntries] = React.useState<JournalEntry[]>([]);
  const [isImportModalOpen, setIsImportModalOpen] = React.useState(false);
  const [isExportDropdownOpen, setIsExportDropdownOpen] = React.useState(false);
  const [accounts, setAccounts] = React.useState<Account[]>(SEEDED_ACCOUNTS);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSaving, setIsSaving] = React.useState(false);
  
  // Navigation / View state
  const [viewMode, setViewMode] = React.useState<'list' | 'create' | 'edit'>('list');
  const [selectedEntry, setSelectedEntry] = React.useState<JournalEntry | null>(null);
  
  // Search & Filters state
  const [searchTerm, setSearchTerm] = React.useState('');
  const [statusFilter, setStatusFilter] = React.useState<'All' | 'Draft' | 'Posted'>('All');

  // Dedicated Form State
  const [editingEntryId, setEditingEntryId] = React.useState<string | null>(null);
  const [globalNarration, setGlobalNarration] = React.useState('');
  const [journalDate, setJournalDate] = React.useState('');
  const [reference, setReference] = React.useState('');
  const [taxTreatment, setTaxTreatment] = React.useState<'Inclusive' | 'Exclusive' | 'NoTax'>('NoTax');
  const [autoReverse, setAutoReverse] = React.useState(false);

  // Repeating / Recurring Journal Form State
  const [isRepeating, setIsRepeating] = React.useState(false);
  const [repeatInterval, setRepeatInterval] = React.useState<number>(1);
  const [repeatUnit, setRepeatUnit] = React.useState<'Weeks' | 'Months'>('Months');
  const [repeatsEndType, setRepeatsEndType] = React.useState<'Date' | 'Count' | 'Infinite'>('Infinite');
  const [repeatsEndDate, setRepeatsEndDate] = React.useState('');
  const [repeatsEndCount, setRepeatsEndCount] = React.useState<number>(10);
  const [saveAsStatus, setSaveAsStatus] = React.useState<'Draft' | 'Posted'>('Draft');
  const [isRepeatingActive, setIsRepeatingActive] = React.useState(true);

  // Keyboard and Input rows state
  const [rows, setRows] = React.useState<RowState[]>([]);
  const [focusedCell, setFocusedCell] = React.useState<{ rowIdx: number; colName: string } | null>(null);
  const [accountSearchText, setAccountSearchText] = React.useState<{ [key: number]: string }>({});
  const [activeDropdownRowIdx, setActiveDropdownRowIdx] = React.useState<number | null>(null);
  const [highlightedAccountIndex, setHighlightedAccountIndex] = React.useState(0);

  // Options configuration
  const taxRatesList = [
    { label: 'No Tax (0%)', value: 0 },
    { label: 'Tax Exempt (0%)', value: 0 },
    { label: 'Standard GST (5%)', value: 5 },
    { label: 'Standard VAT (15%)', value: 15 },
  ];

  const regionsList = ['None', 'BR-Sanaa-HQ', 'BR-Aden-Mina', 'BR-Hudaydah-Port', 'BR-Taiz-Central'];
  const departmentsList = ['None', 'Sales', 'Engineering', 'Marketing', 'HR', 'Operations'];
  const projectsList = ['None', 'PRJ-2026-HQ-UPGRADE', 'PRJ-2026-RETAIL-EXP', 'PRJ-2026-BIO-FUEL', 'PRJ-2026-CLOUD-T'];

  // Load standard entries and Chart of Accounts from Firebase Firestore
  React.useEffect(() => {
    const entriesPath = 'journalEntries';
    const accountsPath = 'accounts';

    const qEntries = query(
      collection(db, entriesPath),
      where('companyId', '==', companyId),
      orderBy('createdAt', 'desc')
    );

    const qAccounts = query(
      collection(db, accountsPath),
      where('companyId', '==', companyId)
    );

    const unsubEntries = onSnapshot(qEntries, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as JournalEntry[];
      setEntries(data);
      setIsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, entriesPath);
      setIsLoading(false);
    });

    const unsubAccounts = onSnapshot(qAccounts, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Account[];
      setAccounts(getMergedAccounts(data));
    }, (error) => {
      console.warn('Real-time standard accounts synchronization status (using local/fallback state):', error.message);
    });

    return () => {
      unsubEntries();
      unsubAccounts();
    };
  }, [companyId]);

  // Calculate next repetition date helper function
  const calculateNextRepetitionDate = (startDateStr: string, interval: number, unit: 'Weeks' | 'Months'): string => {
    if (!startDateStr) return '';
    const date = new Date(startDateStr);
    if (isNaN(date.getTime())) return '';
    if (unit === 'Weeks') {
      date.setDate(date.getDate() + (interval * 7));
    } else {
      date.setMonth(date.getMonth() + interval);
    }
    return date.toISOString().split('T')[0];
  };

  // Automated repeating journal scheduler background simulator
  React.useEffect(() => {
    if (isLoading || entries.length === 0) return;

    const processRepeatingJournals = async () => {
      const todayStr = new Date().toISOString().split('T')[0];
      
      for (const entry of entries) {
        if (!entry.isRepeating || !entry.isRepeatingActive || !entry.nextJournalDate) continue;

        let currentNextDate = entry.nextJournalDate;

        // Iteratively process if the next schedule date is reached or passed
        while (currentNextDate && currentNextDate <= todayStr) {
          
          // Check Specific End Date Option
          if (entry.repeatsEndType === 'Date' && entry.repeatsEndDate && currentNextDate > entry.repeatsEndDate) {
            await updateDoc(doc(db, 'journalEntries', entry.id), {
              isRepeatingActive: false,
              updatedAt: serverTimestamp()
            });
            break;
          }

          // Check Repetition Count Limit Option
          if (entry.repeatsEndType === 'Count' && entry.repeatsRemainingCount !== undefined && entry.repeatsRemainingCount <= 0) {
            await updateDoc(doc(db, 'journalEntries', entry.id), {
              isRepeatingActive: false,
              updatedAt: serverTimestamp()
            });
            break;
          }

          // Create the next sequential automated Journal Entry
          const runDateCompact = currentNextDate.replace(/-/g, '');
          const newRef = `${entry.reference}-A-${runDateCompact}`;

          // Safety check: ensure we do not log duplicates if already processed
          const exists = entries.some(e => e.reference === newRef || (e.parentJournalId === entry.id && e.date === currentNextDate));
          if (!exists) {
            try {
              const saveLines = (entry.lines || []).map(line => ({
                accountId: line.accountId,
                accountName: line.accountName,
                accountCode: line.accountCode || '',
                debit: line.debit,
                credit: line.credit,
                description: line.description || `${entry.description} (Auto Repeating)`,
                taxRate: line.taxRate || 0,
                taxLabel: line.taxLabel || 'No Tax (0%)',
                region: line.region || 'None',
                department: line.department || 'None'
              }));

              await addDoc(collection(db, 'journalEntries'), {
                date: currentNextDate,
                reference: newRef,
                description: `${entry.description} (Recurring Run)`,
                totalDebit: entry.totalDebit,
                totalCredit: entry.totalCredit,
                status: entry.saveAsStatus || 'Draft',
                companyId: companyId,
                taxTreatment: entry.taxTreatment || 'NoTax',
                autoReverse: false,
                isReversal: false,
                parentJournalId: entry.id,
                lines: saveLines,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
              });
            } catch (err) {
              console.error("Scheduler failed to create recurring entry:", err);
            }
          }

          // Calculate next repetition date
          const nextDate = calculateNextRepetitionDate(currentNextDate, entry.repeatInterval || 1, entry.repeatUnit || 'Months');

          // Decrement repetitions counts if applicable
          let remaining = entry.repeatsRemainingCount;
          if (entry.repeatsEndType === 'Count' && remaining !== undefined) {
            remaining = Math.max(0, remaining - 1);
          }

          // Perform transaction-style update to advance state
          const updatePayload: any = {
            nextJournalDate: nextDate,
            updatedAt: serverTimestamp()
          };

          if (entry.repeatsEndType === 'Count' && remaining !== undefined) {
            updatePayload.repeatsRemainingCount = remaining;
            if (remaining <= 0) {
              updatePayload.isRepeatingActive = false;
            }
          }

          try {
            await updateDoc(doc(db, 'journalEntries', entry.id), updatePayload);
          } catch (err) {
            console.error("Failed to commit advanced repeating parameters:", err);
          }

          // Advance looping var
          currentNextDate = nextDate;
        }
      }
    };

    processRepeatingJournals();
  }, [entries, isLoading]);

  // Helper: Seed Default professional Chart of Accounts
  const seedDefaultAccounts = async () => {
    setIsSaving(true);
    try {
      const batch = writeBatch(db);
      const defaultAccs = [
        { code: '1000', name: 'Silicon Valley Operating Checking', type: 'Asset' as const },
        { code: '1200', name: 'Accounts Receivable (A/R)', type: 'Asset' as const },
        { code: '1500', name: 'Prepaid Operational Expenses', type: 'Asset' as const },
        { code: '2000', name: 'Accounts Payable (A/P)', type: 'Liability' as const },
        { code: '2200', name: 'Sales Tax Payable (VAT)', type: 'Liability' as const },
        { code: '3000', name: 'Owner\'s Equity Contribution', type: 'Equity' as const },
        { code: '3300', name: 'Retained Undistributed Earnings', type: 'Equity' as const },
        { code: '4000', name: 'Product Sales Revenues', type: 'Income' as const },
        { code: '4100', name: 'Interest Yield Revenues', type: 'Income' as const },
        { code: '5000', name: 'Cost of Sales (COGS)', type: 'Expense' as const },
        { code: '5200', name: 'Travel & Local Transportation', type: 'Expense' as const },
        { code: '5300', name: 'IT Security & Cloud Hosting', type: 'Expense' as const },
        { code: '5400', name: 'Meals, Clients & Entertainment', type: 'Expense' as const },
        { code: '5500', name: 'Office Assets and Supplies', type: 'Expense' as const }
      ];

      defaultAccs.forEach(acc => {
        const accRef = doc(collection(db, 'accounts'));
        batch.set(accRef, {
          code: acc.code,
          name: acc.name,
          type: acc.type,
          balance: 0,
          status: 'active' as const,
          companyId,
          createdAt: serverTimestamp()
        });
      });
      await batch.commit();
    } catch (err) {
      console.error("Failed to seed default accounts:", err);
    } finally {
      setIsSaving(false);
    }
  };

  // Create an elegant clean structure for a new row state
  const createEmptyRow = (customDesc = ''): RowState => ({
    accountId: '',
    accountCode: '',
    accountName: '',
    description: customDesc || globalNarration || '',
    debit: '',
    credit: '',
    taxRate: 0,
    taxLabel: 'No Tax (0%)',
    region: 'None',
    department: 'None',
    projectId: 'None',
    branchId: 'None',
    departmentId: 'None'
  });

  // Turn manual journal mode into NEW editing workspace
  const handleStartCreate = () => {
    setEditingEntryId(null);
    setGlobalNarration('');
    setJournalDate(new Date().toISOString().split('T')[0]);
    // Generate a clean next Reference sequence
    const count = entries.length + 1;
    setReference(`JE-MJ-${String(count).padStart(4, '0')}`);
    setTaxTreatment('NoTax');
    setAutoReverse(false);

    // Reset repeats state for a fresh journal
    setIsRepeating(false);
    setRepeatInterval(1);
    setRepeatUnit('Months');
    setRepeatsEndType('Infinite');
    setRepeatsEndDate('');
    setRepeatsEndCount(10);
    setSaveAsStatus('Draft');
    setIsRepeatingActive(true);
    
    // Always welcome users with exactly 4 empty rows
    setRows([
      createEmptyRow(),
      createEmptyRow(),
      createEmptyRow(),
      createEmptyRow(),
    ]);
    
    setAccountSearchText({});
    setActiveDropdownRowIdx(null);
    setViewMode('create');
    setSelectedEntry(null);
  };

  // Edit / Modify existing entry
  const handleStartEdit = (entry: JournalEntry) => {
    setEditingEntryId(entry.id);
    setGlobalNarration(entry.description);
    setJournalDate(entry.date);
    setReference(entry.reference);
    setTaxTreatment(entry.taxTreatment || 'NoTax');
    setAutoReverse(entry.autoReverse || false);

    // Map stored repeating parameters
    setIsRepeating(entry.isRepeating || false);
    setRepeatInterval(entry.repeatInterval || 1);
    setRepeatUnit(entry.repeatUnit || 'Months');
    setRepeatsEndType(entry.repeatsEndType || 'Infinite');
    setRepeatsEndDate(entry.repeatsEndDate || '');
    setRepeatsEndCount(entry.repeatsEndCount || 10);
    setSaveAsStatus(entry.saveAsStatus || 'Draft');
    setIsRepeatingActive(entry.isRepeatingActive !== undefined ? entry.isRepeatingActive : true);

    // Map internal line structures back to RowState structure
    if (entry.lines && entry.lines.length > 0) {
      const mappedRows = entry.lines.map((line): RowState => {
        const matchingAcct = accounts.find(a => a.id === line.accountId || a.code === line.accountCode);
        return {
          accountId: line.accountId,
          accountCode: line.accountCode || matchingAcct?.code || '',
          accountName: line.accountName || matchingAcct?.name || '',
          description: line.description || entry.description,
          debit: line.debit > 0 ? String(line.debit) : '',
          credit: line.credit > 0 ? String(line.credit) : '',
          taxRate: line.taxRate || 0,
          taxLabel: line.taxLabel || 'No Tax (0%)',
          region: line.region || 'None',
          department: line.department || 'None',
          projectId: line.projectId || 'None',
          branchId: line.branchId || line.region || 'None',
          departmentId: line.departmentId || line.department || 'None'
        };
      });
      // Always guarantee at least 4 rows for clean feel
      while (mappedRows.length < 4) {
        mappedRows.push(createEmptyRow());
      }
      setRows(mappedRows);
    } else {
      setRows([
        createEmptyRow(),
        createEmptyRow(),
        createEmptyRow(),
        createEmptyRow(),
      ]);
    }
    
    setAccountSearchText({});
    setActiveDropdownRowIdx(null);
    setViewMode('edit');
    setSelectedEntry(null);
  };

  // Duplicate/Clone action
  const handleCloneEntry = (entry: JournalEntry) => {
    setEditingEntryId(null);
    setGlobalNarration(`Copy of ${entry.description}`);
    setJournalDate(new Date().toISOString().split('T')[0]);
    const count = entries.length + 1;
    setReference(`JE-MJ-${String(count).padStart(4, '0')}`);
    setTaxTreatment(entry.taxTreatment || 'NoTax');
    setAutoReverse(entry.autoReverse || false);

    // Cloned entry doesn't inherit repeating status setup by default
    setIsRepeating(false);
    setRepeatInterval(1);
    setRepeatUnit('Months');
    setRepeatsEndType('Infinite');
    setRepeatsEndDate('');
    setRepeatsEndCount(10);
    setSaveAsStatus('Draft');
    setIsRepeatingActive(true);

    if (entry.lines) {
      const clonedRows = entry.lines.map((line): RowState => {
        const matchingAcct = accounts.find(a => a.id === line.accountId || a.code === line.accountCode);
        return {
          accountId: line.accountId,
          accountCode: line.accountCode || matchingAcct?.code || '',
          accountName: line.accountName || matchingAcct?.name || '',
          description: line.description || entry.description,
          debit: line.debit > 0 ? String(line.debit) : '',
          credit: line.credit > 0 ? String(line.credit) : '',
          taxRate: line.taxRate || 0,
          taxLabel: line.taxLabel || 'No Tax (0%)',
          region: line.region || 'None',
          department: line.department || 'None',
          projectId: line.projectId || 'None',
          branchId: line.branchId || line.region || 'None',
          departmentId: line.departmentId || line.department || 'None'
        };
      });
      while (clonedRows.length < 4) {
        clonedRows.push(createEmptyRow());
      }
      setRows(clonedRows);
    }
    setViewMode('create');
  };

  // Swaps cells and publishes reversed duplicate immediately
  const handleImmediateReverse = async (entry: JournalEntry) => {
    if (!confirm(`Are you sure you want to reverse this journal entry immediately? This will create a mirroring transaction with swapped Debits and Credits.`)) return;
    setIsSaving(true);
    try {
      const selectedD = entry.date;
      const parsedDate = new Date(selectedD);
      const revDate = isNaN(parsedDate.getTime())
        ? new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1).toISOString().split('T')[0]
        : new Date(parsedDate.getFullYear(), parsedDate.getMonth() + 1, 1).toISOString().split('T')[0];

      const swappedLines = entry.lines.map((line): JournalEntryLine => ({
        accountId: line.accountId,
        accountName: line.accountName,
        accountCode: line.accountCode || '',
        debit: line.credit, // SWAPPED
        credit: line.debit, // SWAPPED
        description: `(Reverse) ${line.description || entry.description}`,
        taxRate: line.taxRate || 0,
        taxLabel: line.taxLabel || 'No Tax',
        region: line.region || 'None',
        department: line.department || 'None',
        projectId: line.projectId || 'None',
        branchId: line.branchId || line.region || 'None',
        departmentId: line.departmentId || line.department || 'None'
      }));

      const newRef = `${entry.reference}-REVERSED`;

      await addDoc(collection(db, 'journalEntries'), {
        date: revDate,
        reference: newRef,
        description: `Reversal of [${entry.reference}] - ${entry.description}`,
        totalDebit: entry.totalCredit,
        totalCredit: entry.totalDebit,
        status: 'Posted',
        companyId,
        taxTreatment: entry.taxTreatment || 'NoTax',
        autoReverse: false,
        isReversal: true,
        parentJournalId: entry.id,
        lines: swappedLines,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });

      // Update parent journal entry to store linking reversal
      await updateDoc(doc(db, 'journalEntries', entry.id), {
        reversalDate: revDate,
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'journalEntries');
    } finally {
      setIsSaving(false);
    }
  };

  // Helper calculations for summary panels
  const listTotals = React.useMemo(() => {
    const total = entries.length;
    const drafts = entries.filter(e => e.status === 'Draft').length;
    const posted = entries.filter(e => e.status === 'Posted').length;
    return { total, drafts, posted };
  }, [entries]);

  // Total balancing test: check if all DEBITS equal CREDITS across database
  const systemBalancingState = React.useMemo(() => {
    const totalD = entries.filter(e => e.status === 'Posted').reduce((sum, e) => sum + (e.totalDebit || 0), 0);
    const totalC = entries.filter(e => e.status === 'Posted').reduce((sum, e) => sum + (e.totalCredit || 0), 0);
    const diff = Math.abs(totalD - totalC);
    return {
      balanced: diff < 0.01,
      totalD,
      totalC,
      difference: diff
    };
  }, [entries]);

  // Filter entries
  const filteredEntries = React.useMemo(() => {
    return entries.filter(entry => {
      const matchSearch = 
        entry.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entry.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (entry.lines && entry.lines.some(l => l.accountName?.toLowerCase().includes(searchTerm.toLowerCase())));
      
      if (statusFilter === 'All') return matchSearch;
      return matchSearch && entry.status === statusFilter;
    });
  }, [entries, searchTerm, statusFilter]);

  // Rows and Math updates
  const updateRowValue = (rowIdx: number, colName: keyof RowState, val: any) => {
    setRows(prev => prev.map((r, idx) => {
      if (idx !== rowIdx) return r;
      
      const updated = { ...r, [colName]: val };
      
      // Locking UX Logic:
      // If debit is filled, credit gets disabled and is cleared to ''
      if (colName === 'debit' && val && val !== '0' && val !== '') {
        updated.credit = '';
      }
      // If credit is filled, debit gets disabled and is cleared to ''
      if (colName === 'credit' && val && val !== '0' && val !== '') {
        updated.debit = '';
      }
      
      return updated;
    }));
  };

  // Generate dynamic calculation summary
  const calculatedFormTotals = React.useMemo(() => {
    let debitsBaseSum = 0;
    let creditsBaseSum = 0;
    let debitsTaxSum = 0;
    let creditsTaxSum = 0;

    rows.forEach(r => {
      const dVal = parseFloat(r.debit) || 0;
      const cVal = parseFloat(r.credit) || 0;
      const rate = r.taxRate || 0;

      if (taxTreatment === 'Exclusive') {
        debitsBaseSum += dVal;
        creditsBaseSum += cVal;
        debitsTaxSum += dVal * (rate / 100);
        creditsTaxSum += cVal * (rate / 100);
      } else if (taxTreatment === 'Inclusive') {
        const dTax = dVal * (rate / (100 + rate));
        const cTax = cVal * (rate / (100 + rate));
        debitsBaseSum += dVal - dTax;
        creditsBaseSum += cVal - cTax;
        debitsTaxSum += dTax;
        creditsTaxSum += cTax;
      } else {
        // NoTax
        debitsBaseSum += dVal;
        creditsBaseSum += cVal;
      }
    });

    const finalDebitTotal = taxTreatment === 'Exclusive' ? (debitsBaseSum + debitsTaxSum) : (debitsBaseSum + debitsTaxSum);
    const finalCreditTotal = taxTreatment === 'Exclusive' ? (creditsBaseSum + creditsTaxSum) : (creditsBaseSum + creditsTaxSum);
    const difference = Math.abs(finalDebitTotal - finalCreditTotal);
    const isBalanced = difference < 0.009;

    return {
      debitsBaseSum,
      creditsBaseSum,
      debitsTaxSum,
      creditsTaxSum,
      finalDebitTotal,
      finalCreditTotal,
      difference,
      isBalanced
    };
  }, [rows, taxTreatment]);

  // Triggered on FOCUS or CLICK into empty input cell
  const handleFocusDebit = (rowIdx: number) => {
    setFocusedCell({ rowIdx, colName: 'debit' });
    const row = rows[rowIdx];
    if (!row.debit && !row.credit) {
      // Calculate current net outstanding difference of other rows to offer matching balance
      const otherRowDebits = rows.reduce((sum, r, idx) => {
        if (idx === rowIdx) return sum;
        const base = parseFloat(r.debit) || 0;
        const dTax = taxTreatment === 'Exclusive' ? (base * r.taxRate / 100) : 0;
        return sum + base + dTax;
      }, 0);

      const otherRowCredits = rows.reduce((sum, r, idx) => {
        if (idx === rowIdx) return sum;
        const base = parseFloat(r.credit) || 0;
        const cTax = taxTreatment === 'Exclusive' ? (base * r.taxRate / 100) : 0;
        return sum + base + cTax;
      }, 0);

      const needed = otherRowCredits - otherRowDebits;
      if (needed > 0) {
        // Adjust for exclusive tax rate if any
        const rate = row.taxRate || 0;
        const netNeeded = taxTreatment === 'Exclusive' ? (needed / (1 + rate / 100)) : needed;
        updateRowValue(rowIdx, 'debit', netNeeded.toFixed(2));
      }
    }
  };

  const handleFocusCredit = (rowIdx: number) => {
    setFocusedCell({ rowIdx, colName: 'credit' });
    const row = rows[rowIdx];
    if (!row.credit && !row.debit) {
      // Calculate current net outstanding difference of other rows to offer matching balance
      const otherRowDebits = rows.reduce((sum, r, idx) => {
        if (idx === rowIdx) return sum;
        const base = parseFloat(r.debit) || 0;
        const dTax = taxTreatment === 'Exclusive' ? (base * r.taxRate / 100) : 0;
        return sum + base + dTax;
      }, 0);

      const otherRowCredits = rows.reduce((sum, r, idx) => {
        if (idx === rowIdx) return sum;
        const base = parseFloat(r.credit) || 0;
        const cTax = taxTreatment === 'Exclusive' ? (base * r.taxRate / 100) : 0;
        return sum + base + cTax;
      }, 0);

      const needed = otherRowDebits - otherRowCredits;
      if (needed > 0) {
        // Adjust for exclusive tax rate of this row
        const rate = row.taxRate || 0;
        const netNeeded = taxTreatment === 'Exclusive' ? (needed / (1 + rate / 100)) : needed;
        updateRowValue(rowIdx, 'credit', netNeeded.toFixed(2));
      }
    }
  };

  // Keyboard navigation & Event Router
  const handleCellKeyDown = (e: React.KeyboardEvent, rowIdx: number, colName: string) => {
    const isEnter = e.key === 'Enter';
    const isArrowUp = e.key === 'ArrowUp';
    const isArrowDown = e.key === 'ArrowDown';
    
    // Tab out of fields logic
    if (e.key === 'Tab' && !e.shiftKey) {
      const columnsOrder = ['account', 'description', 'debit', 'credit', 'taxRate', 'region', 'department', 'projectId'];
      const currentColIdx = columnsOrder.indexOf(colName);
      
      // If we are on the very last column cell of the last row
      if (rowIdx === rows.length - 1 && currentColIdx === columnsOrder.length - 1) {
        e.preventDefault();
        // Automatically insert a new row to let them continue fast data entry
        setRows(prev => [...prev, createEmptyRow()]);
        setTimeout(() => {
          const nextCell = document.getElementById(`cell-${rowIdx + 1}-account-input`);
          nextCell?.focus();
        }, 10);
        return;
      }
    }

    if (isArrowUp && rowIdx > 0 && colName !== 'account') {
      e.preventDefault();
      const el = document.getElementById(`cell-${rowIdx - 1}-${colName}`);
      el?.focus();
    } else if (isArrowDown && rowIdx < rows.length - 1 && colName !== 'account') {
      e.preventDefault();
      const el = document.getElementById(`cell-${rowIdx + 1}-${colName}`);
      el?.focus();
    }
  };

  // Custom Search Account selection dropdown filters
  const getFilteredAccounts = (rowIdx: number): Account[] => {
    const txt = accountSearchText[rowIdx] || '';
    const rootCodes = ['1000', '2000', '3000', '4000', '5000'];
    return accounts.filter(a => 
      !rootCodes.includes(a.code) && (
        a.code.toLowerCase().includes(txt.toLowerCase()) || 
        a.name.toLowerCase().includes(txt.toLowerCase())
      )
    );
  };

  const handleAccountSearchChange = (rowIdx: number, val: string) => {
    setAccountSearchText(prev => ({ ...prev, [rowIdx]: val }));
    setActiveDropdownRowIdx(rowIdx);
    setHighlightedAccountIndex(0);
    
    // If user deleted the text completely, wipe selected Account fields
    if (!val) {
      updateRowValue(rowIdx, 'accountId', '');
      updateRowValue(rowIdx, 'accountCode', '');
      updateRowValue(rowIdx, 'accountName', '');
    }
  };

  const selectAccountOption = (rowIdx: number, account: Account) => {
    updateRowValue(rowIdx, 'accountId', account.id);
    updateRowValue(rowIdx, 'accountCode', account.code);
    updateRowValue(rowIdx, 'accountName', account.name);
    setAccountSearchText(prev => ({ ...prev, [rowIdx]: `${account.code} - ${account.name}` }));
    setActiveDropdownRowIdx(null);
    
    // Auto-focus next logical cell: description
    setTimeout(() => {
      document.getElementById(`cell-${rowIdx}-description`)?.focus();
    }, 10);
  };

  const handleAccountInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, rowIdx: number) => {
    const filtered = getFilteredAccounts(rowIdx);
    
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveDropdownRowIdx(rowIdx);
      setHighlightedAccountIndex(prev => Math.min(prev + 1, filtered.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveDropdownRowIdx(rowIdx);
      setHighlightedAccountIndex(prev => Math.max(prev - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[highlightedAccountIndex]) {
        selectAccountOption(rowIdx, filtered[highlightedAccountIndex]);
      } else {
        setActiveDropdownRowIdx(null);
      }
    } else if (e.key === 'Escape') {
      setActiveDropdownRowIdx(null);
    }
  };

  // Delete line row
  const removeRowLine = (rowIdx: number) => {
    if (rows.length <= 2) {
      alert("At least two journal lines are required for double-entry bookkeeping.");
      return;
    }
    setRows(prev => prev.filter((_, idx) => idx !== rowIdx));
  };

  // Add line row manually
  const appendRowLine = () => {
    setRows(prev => [...prev, createEmptyRow()]);
  };

  // Save Manual Journal Entry (Draft or Post)
  const submitJournalEntry = async (status: 'Draft' | 'Posted') => {
    const isAr = document.documentElement.lang === 'ar';
    // 1. Basic Validations
    if (!globalNarration.trim()) {
      alert("Please enter a valid General Narration (وصف القيد العام).");
      return;
    }
    if (!journalDate) {
      alert("Please select a Journal Date.");
      return;
    }
    if (!reference.trim()) {
      alert("Please enter a Journal Reference.");
      return;
    }

    // Filter out rows that do not have an selected account code
    const activeRows = rows.filter(r => r.accountId && (parseFloat(r.debit) > 0 || parseFloat(r.credit) > 0));
    
    if (activeRows.length < 2) {
      alert("You must supply at least two active item lines with accounts and debit/credit balances.");
      return;
    }

    const { finalDebitTotal, finalCreditTotal, isBalanced } = calculatedFormTotals;

    // posted ledger must balance perfectly
    if (status === 'Posted' && !isBalanced) {
      alert(`Bookkeeping Error: Journal is out of balance. Debits total ${formatCurrency(finalDebitTotal)} and Credits total ${formatCurrency(finalCreditTotal)}. They must match perfectly before posting.`);
      return;
    }

    // Prepare firebase save package
    setIsSaving(true);
    const saveLines = activeRows.map((ar): JournalEntryLine => ({
      accountId: ar.accountId,
      accountName: ar.accountName,
      accountCode: ar.accountCode,
      debit: parseFloat(ar.debit) || 0,
      credit: parseFloat(ar.credit) || 0,
      description: ar.description || globalNarration,
      taxRate: ar.taxRate,
      taxLabel: ar.taxLabel,
      region: ar.region,
      department: ar.department,
      projectId: ar.projectId || 'None',
      branchId: ar.branchId || ar.region || 'None',
      departmentId: ar.departmentId || ar.department || 'None'
    }));

    const saveObject = {
      date: journalDate,
      reference: reference,
      description: globalNarration,
      totalDebit: finalDebitTotal,
      totalCredit: finalCreditTotal,
      status: status,
      companyId: companyId,
      taxTreatment: taxTreatment,
      autoReverse: autoReverse,
      lines: saveLines,
      updatedAt: serverTimestamp(),
      
      // Repeating settings
      isRepeating: isRepeating,
      repeatInterval: isRepeating ? repeatInterval : 1,
      repeatUnit: isRepeating ? repeatUnit : 'Months',
      repeatsEndType: isRepeating ? repeatsEndType : 'Infinite',
      repeatsEndDate: isRepeating && repeatsEndType === 'Date' ? repeatsEndDate : '',
      repeatsEndCount: isRepeating && repeatsEndType === 'Count' ? repeatsEndCount : 10,
      repeatsRemainingCount: isRepeating && repeatsEndType === 'Count' 
        ? (editingEntryId ? (entries.find(e => e.id === editingEntryId)?.repeatsRemainingCount ?? repeatsEndCount) : repeatsEndCount) 
        : null,
      nextJournalDate: isRepeating ? calculateNextRepetitionDate(journalDate, repeatInterval, repeatUnit) : '',
      isRepeatingActive: isRepeating ? isRepeatingActive : false,
      saveAsStatus: isRepeating ? saveAsStatus : 'Draft'
    };

    try {
      if (!navigator.onLine) {
        const { offlineDb } = await import('../utils/offlineDb');
        const isAr = document.documentElement.lang === 'ar';
        const offlineRecord = {
          ...saveObject,
          id: editingEntryId || `journal-off-${Date.now()}`,
          isOfflineDraft: true,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        await offlineDb.saveRecord('offline_journal_entries', offlineRecord);
        alert(
          isAr
            ? 'تم حفظ القيد اليومي محلياً بأمان بسبب انقطاع الإنترنت. يرجى المزامنة يدوياً من الأعلى عند عودة الاتصال.'
            : 'No internet connection detected. Journal entry saved securely in local Offline Queue. Please sync manually from the top bar once connected.'
        );
        setViewMode('list');
        setEditingEntryId(null);
        return;
      }

      let docId = editingEntryId;
      if (editingEntryId) {
        // Enforce strict immutable check
        const originalEntry = entries.find(e => e.id === editingEntryId);
        if (originalEntry && (originalEntry.status?.toUpperCase() === 'POSTED')) {
          alert(isAr 
            ? 'خطأ محاسبي حرج: هذا القيد مرحل ومحمي من التعديل تماماً تحت معايير IFRS!' 
            : 'CRITICAL AUDIT ERROR: This journal entry is already posted and locked under strict IFRS standards!');
          setIsSaving(false);
          return;
        }
        // Update original doc
        await updateDoc(doc(db, 'journalEntries', editingEntryId), saveObject);
      } else {
        // Insert new doc
        const resDoc = await addDoc(collection(db, 'journalEntries'), {
          ...saveObject,
          createdAt: serverTimestamp()
        });
        docId = resDoc.id;
      }

      // 2. Schedule Auto-Reversal on 1st of next month if toggle is active!
      if (autoReverse && docId) {
        const parsedDate = new Date(journalDate);
        const firstOfNext = isNaN(parsedDate.getTime())
          ? new Date(new Date().getFullYear(), new Date().getMonth() + 1, 1).toISOString().split('T')[0]
          : new Date(parsedDate.getFullYear(), parsedDate.getMonth() + 1, 1).toISOString().split('T')[0];

        // Swapping debit side and credit side on reversal entry
        const reversalLines = saveLines.map((line): JournalEntryLine => ({
          ...line,
          debit: line.credit, // SWAPPED
          credit: line.debit, // SWAPPED
          description: `(Reverse) ${line.description || globalNarration}`
        }));

        // Insert mirrored reversed entry to preserve database integrity
        await addDoc(collection(db, 'journalEntries'), {
          date: firstOfNext,
          reference: `${reference}-REV`,
          description: `Reversing Journal: ${globalNarration}`,
          totalDebit: finalCreditTotal,
          totalCredit: finalDebitTotal,
          status: status, // Matches original status
          companyId: companyId,
          taxTreatment: taxTreatment,
          autoReverse: false,
          isReversal: true,
          parentJournalId: docId,
          lines: reversalLines,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });

        // Store scheduled link in original element if we updated or saved
        await updateDoc(doc(db, 'journalEntries', docId), {
          reversalDate: firstOfNext,
          updatedAt: serverTimestamp()
        });
      }

      // Exit back to dashboard list
      setViewMode('list');
      setEditingEntryId(null);
    } catch (err) {
      handleFirestoreError(err, editingEntryId ? OperationType.UPDATE : OperationType.CREATE, 'journalEntries');
    } finally {
      setIsSaving(false);
    }
  };

  // Delete Action
  const deleteJournalEntry = async (id: string) => {
    const isAr = document.documentElement.lang === 'ar';
    // Enforce strict immutable check
    const originalEntry = entries.find(e => e.id === id);
    if (originalEntry && (originalEntry.status?.toUpperCase() === 'POSTED')) {
      alert(isAr 
        ? 'خطأ محاسبي حرج: هذا القيد مرحل ومحمي من الحذف تماماً تحت معايير IFRS!' 
        : 'CRITICAL AUDIT ERROR: This journal entry is already posted and locked under strict IFRS standards!');
      return;
    }
    if (!confirm('Are you absolutely sure you want to delete this manual journal entry? This will permanently remove its debit/credit lines from the Ledger.')) return;
    try {
      await deleteDoc(doc(db, 'journalEntries', id));
      if (selectedEntry?.id === id) {
        setSelectedEntry(null);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'journalEntries');
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 sm:px-6">
      
      {/* ==============================================
          MODE A: MAIN JOURNAL LIST OVERVIEW SCREEN
          ============================================== */}
      {viewMode === 'list' && (
        <div className="space-y-6">
          
          {/* Top Banner Action Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 id="journal-heading-title" className="text-3xl font-extrabold tracking-tight text-slate-900 font-sans">
                {t('sidebar.journals', 'Manual Journals')}
              </h1>
              <p className="text-slate-500 text-sm mt-1">
                {t('journals.subtitle', 'Verify ledgers, log complex corrections, and track tax adjustments with a professional interface.')}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsImportModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-indigo-650 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
              >
                <UploadCloud className="w-4 h-4" />
                {t('global.import_excel', 'Import from Excel')}
              </button>

              <div className="relative">
                <button
                  onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
                  className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  {t('global.export', 'Export')}
                </button>
                {isExportDropdownOpen && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setIsExportDropdownOpen(false)} />
                    <div className="absolute right-0 mt-1.5 w-48 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 z-20">
                      <button
                        onClick={() => {
                          setIsExportDropdownOpen(false);
                          exportToExcel(
                            entries,
                            ['number', 'reference', 'narration', 'date', 'totalDebit', 'totalCredit', 'status'],
                            ['Journal Number', 'Reference Code', 'Global Narration', 'Journal Date', 'Total Debit', 'Total Credit', 'Status'],
                            'System_Manual_Journals'
                          );
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                      >
                        {t('global.export_excel', 'Export to Excel (.xlsx)')}
                      </button>
                      <button
                        onClick={() => {
                          setIsExportDropdownOpen(false);
                          exportToPDF(
                            entries,
                            ['number', 'reference', 'narration', 'date', 'totalDebit', 'totalCredit', 'status'],
                            ['Journal Number', 'Reference Code', 'Global Narration', 'Journal Date', 'Total Debit', 'Total Credit', 'Status'],
                            'Advanced Accounting - Manual Journal Ledger Registry',
                            'System_Manual_Journals'
                          );
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                      >
                        {t('global.export_pdf', 'Export to PDF (.pdf)')}
                      </button>
                    </div>
                  </>
                )}
              </div>

              <button 
                id="btn-new-manual-journal"
                onClick={handleStartCreate}
                className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-semibold shadow-md cursor-pointer hover:shadow-lg"
              >
                <Plus className="w-4 h-4" />
                {t('journals.new_entry', 'New Manual Journal')}
              </button>
            </div>
          </div>

          {/* Key Metrics Widgets Section */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Total count */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Journals</span>
                <p className="text-2xl font-bold text-slate-900">{listTotals.total}</p>
                <p className="text-xs text-slate-400">Recorded adjustments</p>
              </div>
              <div className="bg-indigo-50 p-3 rounded-xl text-indigo-600">
                <BookOpen className="w-5 h-5" />
              </div>
            </div>

            {/* Total Posted */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Posted Ledger</span>
                <p className="text-2xl font-bold text-emerald-600">{listTotals.posted}</p>
                <p className="text-xs text-slate-400">Locked &amp; finalized</p>
              </div>
              <div className="bg-emerald-50 p-3 rounded-xl text-emerald-600">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            </div>

            {/* Total Drafts */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider font-sans">Drafts Queue</span>
                <p className="text-2xl font-bold text-amber-500">{listTotals.drafts}</p>
                <p className="text-xs text-slate-400">Awaiting balance check</p>
              </div>
              <div className="bg-amber-50 p-3 rounded-xl text-amber-600">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
            </div>

            {/* Trial Balanced audit state */}
            <div className={cn(
              "p-5 rounded-2xl border transition-all duration-300 shadow-sm flex items-center justify-between",
              systemBalancingState.balanced 
                ? "bg-slate-50 border-slate-200" 
                : "bg-rose-50/50 border-rose-200"
            )}>
              <div className="space-y-1">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Trial Balance Sync</span>
                <div className="flex items-center gap-1.5">
                  <span className={cn(
                    "w-2.5 h-2.5 rounded-full inline-block animate-ping",
                    systemBalancingState.balanced ? "bg-emerald-500" : "bg-rose-500"
                  )} />
                  <span className={cn(
                    "text-sm font-bold",
                    systemBalancingState.balanced ? "text-emerald-700" : "text-rose-700"
                  )}>
                    {systemBalancingState.balanced ? 'Trial Balanced' : 'Out-Of-Balance'}
                  </span>
                </div>
                {systemBalancingState.balanced ? (
                  <p className="text-xs text-slate-400">Debits == Credits (Posted)</p>
                ) : (
                  <p className="text-xs text-rose-600 font-medium">Diff: {formatCurrency(systemBalancingState.difference)}</p>
                )}
              </div>
              <div className={cn(
                "p-3 rounded-xl",
                systemBalancingState.balanced ? "bg-emerald-100/60 text-emerald-700" : "bg-rose-100 text-rose-600"
              )}>
                {systemBalancingState.balanced ? <Check className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
              </div>
            </div>
          </div>

          {/* Seed Promp Banner when database has 0 Chart of Accounts accounts */}
          {accounts.length === 0 && !isLoading && (
            <div id="seed-banner" className="bg-slate-950 text-white rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="bg-indigo-500/30 p-2 rounded-lg text-indigo-400">
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-bold">Instantiate standard Chart of Accounts?</h3>
                </div>
                <p className="text-slate-300 text-sm max-w-2xl">
                  We detected that your database hasn&apos;t loaded any General Ledger accounts yet. To fully preview and experience the keyboard-centric dropdown selectors in real-time, click to populate 14 default accounts.
                </p>
              </div>
              <button
                onClick={seedDefaultAccounts}
                disabled={isSaving}
                className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 text-white font-semibold text-sm rounded-lg hover:bg-indigo-700 transition-all cursor-pointer shadow-md disabled:opacity-50 shrink-0"
              >
                {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                Populate COAs Ledger
              </button>
            </div>
          )}

          {/* Search, Filter & List Container */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row items-center gap-4 justify-between bg-slate-50/50">
              
              <div className="relative w-full sm:max-w-md">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                <input 
                  id="search-input"
                  type="text" 
                  placeholder="Search by reference, account names or narration..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow placeholder:text-slate-400 font-mono text-slate-700"
                />
              </div>

              {/* Status Pill Pickers */}
              <div className="flex items-center bg-slate-100 p-1 rounded-lg self-stretch sm:self-auto shrink-0">
                {(['All', 'Draft', 'Posted'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setStatusFilter(st)}
                    className={cn(
                      "px-4 py-1.5 rounded-md text-xs font-semibold uppercase transition-all tracking-wider cursor-pointer",
                      statusFilter === st 
                        ? "bg-white text-slate-900 shadow-sm font-bold" 
                        : "text-slate-500 hover:text-slate-800"
                    )}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* Table or Empty indicator */}
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-24 space-y-4">
                <Loader2 className="w-10 h-10 animate-spin text-indigo-600" />
                <span className="text-sm font-semibold text-slate-500">Retrieving Ledgers...</span>
              </div>
            ) : filteredEntries.length === 0 ? (
              <div className="text-center py-20 px-4">
                <div className="bg-slate-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 border border-slate-100 text-slate-400">
                  <Inbox className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-slate-900">No manual journals found</h3>
                <p className="text-slate-500 text-sm mt-1 max-w-md mx-auto">
                  {searchTerm 
                    ? "We couldn&apos;t match any general ledger entries to your search term. Try checking for shorthand codes or numbers."
                    : "There are no journal logs stored for the chosen parameters. Click New Manual Journal to write one."
                  }
                </p>
                {searchTerm && (
                  <button 
                    onClick={() => setSearchTerm('')} 
                    className="mt-4 text-xs font-bold text-indigo-600 hover:underline"
                  >
                    Clear Filter
                  </button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-slate-500 font-semibold text-xs uppercase tracking-wider border-b border-slate-100">
                      <th className="py-4 px-6 font-semibold">{getLocalizedLabel('Date')}</th>
                      <th className="py-4 px-6 font-semibold">{getLocalizedLabel('Reference')}</th>
                      <th className="py-4 px-6 font-semibold text-center">{getLocalizedLabel('Status')}</th>
                      <th className="py-4 px-6 font-semibold">{getLocalizedLabel('Narration')}</th>
                      <th className="py-4 px-6 font-semibold text-right">{getLocalizedLabel('Debit')} ({getLocalizedLabel('Total')})</th>
                      <th className="py-4 px-6 font-semibold text-right">{getLocalizedLabel('Credit')} ({getLocalizedLabel('Total')})</th>
                      <th className="py-4 px-6 font-semibold text-center">{getLocalizedLabel('Actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {filteredEntries.map((entry) => (
                      <tr 
                        key={entry.id} 
                        className={cn(
                          "hover:bg-slate-50/70 transition-colors group cursor-pointer",
                          selectedEntry?.id === entry.id ? "bg-indigo-50/30" : ""
                        )}
                        onClick={() => setSelectedEntry(selectedEntry?.id === entry.id ? null : entry)}
                      >
                        <td className="py-4 px-6 text-slate-600 whitespace-nowrap">
                          {formatDate(entry.date)}
                        </td>
                        <td className="py-4 px-6 font-bold text-slate-900 font-mono">
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span>{entry.reference}</span>
                            {entry.isReversal && (
                              <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 text-[9px] uppercase font-bold tracking-tight">
                                Reversal
                              </span>
                            )}
                            {entry.reversalDate && (
                              <span className="px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 text-[9px] uppercase font-bold tracking-tight">
                                Reversing Scheduled
                              </span>
                            )}
                            {entry.isRepeating && (
                              <span className={cn(
                                "px-1.5 py-0.5 rounded text-[9px] uppercase font-bold tracking-wider inline-flex items-center gap-1 border shadow-xs",
                                entry.isRepeatingActive 
                                  ? "bg-indigo-50 text-indigo-700 border-indigo-200" 
                                  : "bg-slate-100 text-slate-400 border-slate-200 line-through"
                              )} title={entry.isRepeatingActive ? `Calculated Next Post: ${entry.nextJournalDate}` : 'Paused repetition'}>
                                🔁 {entry.repeatInterval} {entry.repeatUnit === 'Weeks' ? 'Wk(s)' : 'Mo(s)'}
                                {entry.isRepeatingActive ? ` (Next: ${entry.nextJournalDate})` : ' (Paused)'}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-4 px-6 text-center whitespace-nowrap">
                          <span className={cn(
                            "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide inline-block",
                            entry.status === 'Posted' 
                              ? "bg-emerald-100 text-emerald-800 border border-emerald-200" 
                              : "bg-slate-100 text-slate-500 border border-slate-200"
                          )}>
                            {entry.status}
                          </span>
                        </td>
                        <td className="py-4 px-6 text-slate-600 font-medium max-w-xs truncate">
                          {entry.description}
                        </td>
                        <td className="py-4 px-6 text-right font-bold text-slate-900 font-mono">
                          {formatCurrency(entry.totalDebit)}
                        </td>
                        <td className="py-4 px-6 text-right font-bold text-slate-900 font-mono">
                          {formatCurrency(entry.totalCredit)}
                        </td>
                        <td className="py-4 px-6 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-center gap-2">
                            <button 
                              title="Edit Entry"
                              onClick={() => handleStartEdit(entry)}
                              className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded transition-all"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button 
                              title="Clone Layout"
                              onClick={() => handleCloneEntry(entry)}
                              className="p-1.5 text-slate-400 hover:text-cyan-600 hover:bg-slate-100 rounded transition-all"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                            {!entry.reversalDate && !entry.isReversal && entry.status === 'Posted' && (
                              <button 
                                title="Reverse Entry next Month"
                                onClick={() => handleImmediateReverse(entry)}
                                className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-slate-100 rounded transition-all"
                              >
                                <ArrowRightLeft className="w-4 h-4" />
                              </button>
                            )}
                            <button 
                              title="Delete permanently"
                              onClick={() => deleteJournalEntry(entry.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-100 rounded transition-all"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Detailed Read-only ledger sidebar picker to see nested lines */}
          {selectedEntry && (
            <div className="bg-slate-950 text-white rounded-2xl p-6 shadow-xl border border-slate-800 animate-fadeIn space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="space-y-1">
                  <span className="text-xs font-semibold tracking-widest uppercase text-indigo-400">Selected Ledger Detail</span>
                  <h3 className="text-xl font-mono font-bold">{selectedEntry.reference}</h3>
                </div>
                <button 
                  onClick={() => setSelectedEntry(null)} 
                  className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
                <div>
                  <span className="block text-slate-400 text-xs uppercase font-semibold">General Narration</span>
                  <span className="block text-slate-200 mt-1 font-medium">{selectedEntry.description}</span>
                </div>
                <div>
                  <span className="block text-slate-400 text-xs uppercase font-semibold">Post Date</span>
                  <span className="block text-slate-200 mt-1 font-mono">{formatDate(selectedEntry.date)}</span>
                </div>
                <div>
                  <span className="block text-slate-400 text-xs uppercase font-semibold text-right">Tax Treatment Status</span>
                  <span className="block text-slate-200 mt-1 text-right font-semibold">
                    {selectedEntry.taxTreatment === 'Inclusive' ? 'Tax Inclusive' : selectedEntry.taxTreatment === 'Exclusive' ? 'Tax Exclusive' : 'No Tax applied'}
                  </span>
                </div>
              </div>

              <div className="border border-slate-800 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs bg-slate-900">
                  <thead>
                    <tr className="bg-slate-800/60 text-slate-400 font-semibold uppercase">
                      <th className="py-3 px-4 font-semibold">{getLocalizedLabel('Account')}</th>
                      <th className="py-3 px-4 font-semibold">{getLocalizedLabel('Description')}</th>
                      <th className="py-3 px-4 font-semibold text-right">{getLocalizedLabel('Debit')}</th>
                      <th className="py-3 px-4 font-semibold text-right">{getLocalizedLabel('Credit')}</th>
                      <th className="py-3 px-4 font-semibold">{getLocalizedLabel('Tax Amount')}</th>
                      <th className="py-3 px-4 font-semibold">{getLocalizedLabel('Reference')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/40 text-slate-300 font-mono">
                    {selectedEntry.lines?.map((line, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/20">
                        <td className="py-3 px-4 font-bold text-slate-100">
                          {line.accountCode ? `${line.accountCode} - ` : ''}{line.accountName}
                        </td>
                        <td className="py-3 px-4 italic text-slate-400">
                          {line.description || selectedEntry.description}
                        </td>
                        <td className="py-3 px-4 text-right text-emerald-400 font-semibold">
                          {line.debit > 0 ? formatCurrency(line.debit) : '—'}
                        </td>
                        <td className="py-3 px-4 text-right text-amber-400 font-semibold">
                          {line.credit > 0 ? formatCurrency(line.credit) : '—'}
                        </td>
                        <td className="py-3 px-4 text-slate-400">
                          {line.taxLabel || 'No Tax (0%)'}
                        </td>
                        <td className="py-3 px-4 text-slate-400">
                          <div className="flex flex-col gap-0.5 text-[10px]">
                            {line.region && line.region !== 'None' && <span>📍 {line.region}</span>}
                            {line.department && line.department !== 'None' && <span>💼 {line.department}</span>}
                            {(!line.region || line.region === 'None') && (!line.department || line.department === 'None') && <span>—</span>}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>
      )}

      {/* ==============================================
          MODE B: INTERACTIVE JOURNAL WORKSPACE EDITOR
          ============================================== */}
      {(viewMode === 'create' || viewMode === 'edit') && (
        <div className="space-y-6">
          
          {/* Top Form Action Rail */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-5">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setViewMode('list')}
                className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                title="Go Back"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div>
                <span className="text-xs font-bold tracking-widest text-indigo-600 uppercase font-sans">
                  {editingEntryId ? 'Update Existing General Ledger' : 'New Manual Entry Journal'}
                </span>
                <h1 className="text-2xl font-bold text-slate-900 tracking-tight font-sans">
                  {"New Manual Journal"}
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className="px-4 py-2 border border-slate-200 rounded-lg text-slate-600 font-semibold text-sm hover:bg-slate-50 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={() => submitJournalEntry('Draft')}
                className="px-4 py-2 bg-slate-100 border border-slate-200 text-slate-700 font-semibold text-sm rounded-lg hover:bg-slate-200 transition-colors cursor-pointer disabled:opacity-50"
              >
                Save as Draft
              </button>
              <button
                type="button"
                disabled={isSaving || !calculatedFormTotals.isBalanced}
                onClick={() => submitJournalEntry('Posted')}
                className={cn(
                  "px-5 py-2 text-white font-semibold text-sm rounded-lg transition-all shadow shadow-indigo-600/10 cursor-pointer disabled:opacity-50",
                  calculatedFormTotals.isBalanced 
                    ? "bg-indigo-600 hover:bg-indigo-700" 
                    : "bg-indigo-400 cursor-not-allowed"
                )}
              >
                {isSaving ? <Loader2 className="w-4 h-4 animate-spin inline mr-1" /> : null}
                Post Journal
              </button>
            </div>
          </div>

          {/* Form Header Controls Header Card */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
            
            {/* Top Row fields */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              
              {/* General Narration (وصف القيد العام) - Full-Width equivalent logic */}
              <div className="md:col-span-2 space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                  General Narration (وصف القيد العام) *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="e.g. Accrue Q2 Cloud Infrastructure Costs or Tax Write off"
                    value={globalNarration}
                    onChange={(e) => setGlobalNarration(e.target.value)}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-50/50 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-400 font-sans"
                  />
                </div>
              </div>

              {/* Date selection */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                  Journal Date *
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-400" />
                  <input
                    type="date"
                    required
                    value={journalDate}
                    onChange={(e) => setJournalDate(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-50/50 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-slate-700 font-mono"
                  />
                </div>
              </div>

              {/* Reference */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                  Reference # *
                </label>
                <input
                  type="text"
                  required
                  value={reference}
                  onChange={(e) => setReference(e.target.value)}
                  placeholder="JE-MJ-0001"
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-lg text-sm bg-slate-50/50 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all font-mono text-slate-700"
                />
              </div>

            </div>

            {/* Second Row fields: Tax options & auto reversing */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100">
              
              {/* Amounts are: Tax Inclusive / Tax Exclusive / No Tax */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Tax treatment of amounts (الضرائب بالأقيد)
                </label>
                <div className="grid grid-cols-3 gap-2 bg-slate-100 p-1 rounded-lg">
                  {[
                    { key: 'NoTax', label: 'No Tax' },
                    { key: 'Exclusive', label: 'Tax Exclusive' },
                    { key: 'Inclusive', label: 'Tax Inclusive' },
                  ].map((option) => (
                    <button
                      key={option.key}
                      type="button"
                      onClick={() => setTaxTreatment(option.key as any)}
                      className={cn(
                        "py-2 rounded-md text-xs font-semibold transition-all px-2 cursor-pointer",
                        taxTreatment === option.key 
                          ? "bg-white text-indigo-600 shadow-sm font-bold scale-[1.02]" 
                          : "text-slate-500 hover:text-slate-800"
                      )}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Auto Reversing Engine toggle on 1st of next month */}
              <div className="flex items-center space-x-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <input
                  id="auto-reverse-checkbox"
                  type="checkbox"
                  checked={autoReverse}
                  onChange={(e) => setAutoReverse(e.target.checked)}
                  className="w-4.5 h-4.5 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500 transition-colors cursor-pointer"
                />
                <div className="space-y-0.5">
                  <label htmlFor="auto-reverse-checkbox" className="block text-xs font-bold text-slate-900 uppercase tracking-wider cursor-pointer select-none">
                    Auto-reverse journal next month
                  </label>
                  <p className="text-[11px] text-slate-500">
                    If selected, we automatically schedule and submit an exact Swapped Reversal log on the 1st day of the next fiscal month.
                  </p>
                </div>
              </div>

            </div>

            {/* Repeating Journal (تكرار القيد) Section Block based on standard Workflow */}
            <div className="pt-5 border-t border-slate-100">
              <div className="flex items-start gap-4 p-5 rounded-2xl border border-slate-200 bg-slate-50/40">
                <div className="flex items-center h-5">
                  <input
                    id="checkbox-is-repeating"
                    type="checkbox"
                    checked={isRepeating}
                    onChange={(e) => setIsRepeating(e.target.checked)}
                    className="w-5 h-5 rounded text-indigo-600 border-slate-300 focus:ring-indigo-500 cursor-pointer transition-transform duration-200 hover:scale-105"
                  />
                </div>
                <div className="flex-1 space-y-1.5">
                  <label htmlFor="checkbox-is-repeating" className="flex items-center gap-2 text-sm font-bold text-slate-800 uppercase tracking-wide cursor-pointer select-none">
                    <span>Repeating Journal (تكرار القيد)</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-indigo-50 text-indigo-700 tracking-tight border border-indigo-200 font-sans">
                      Standard Workflow
                    </span>
                  </label>
                  <p className="text-xs text-slate-500 leading-relaxed font-sans">
                    Enable automatic recurring entries at desired intervals. The system background scheduler will automatically post Draft or Posted journal logs upon reaching the designated schedule dates.
                  </p>

                  {/* Collapsible config settings, fully visible when isRepeating is true */}
                  {isRepeating && (
                    <div className="mt-5 pt-5 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fadeIn font-sans">
                      
                      {/* Repeat every N weeks/months */}
                      <div className="space-y-2">
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                          Repeat This Journal Every (دورية التكرار)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            min="1"
                            value={repeatInterval}
                            onChange={(e) => setRepeatInterval(Math.max(1, parseInt(e.target.value) || 1))}
                            className="w-20 px-3 py-2 border border-slate-200 rounded-lg text-sm font-semibold text-slate-700 bg-white focus:ring-1 focus:ring-indigo-500 outline-none shadow-sm"
                          />
                          <select
                            value={repeatUnit}
                            onChange={(e) => setRepeatUnit(e.target.value as any)}
                            className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm font-semibold text-slate-600 bg-white cursor-pointer focus:ring-1 focus:ring-indigo-500 outline-none shadow-sm"
                          >
                            <option value="Weeks">Week(s)</option>
                            <option value="Months">Month(s)</option>
                          </select>
                        </div>
                      </div>

                      {/* Journal Date (First Run) inherited from parent date, and calculated next journal date */}
                      <div className="space-y-2">
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                          Next Journal Date (تاريخ التكرار القادم)
                        </label>
                        <div className="relative">
                          <input
                            type="date"
                            disabled
                            value={calculateNextRepetitionDate(journalDate, repeatInterval, repeatUnit)}
                            className="w-full px-4 py-2 border border-slate-100 rounded-lg text-sm bg-slate-100/80 text-indigo-700 font-mono font-bold outline-none"
                          />
                          <p className="text-[10px] text-slate-400 mt-1 italic">
                            Auto-calculated next execution date.
                          </p>
                        </div>
                      </div>

                      {/* Save Status */}
                      <div className="space-y-2">
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                          Status of Generated Journal (حالة القيد المولد)
                        </label>
                        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg border border-slate-200 shadow-inner">
                          <button
                            type="button"
                            onClick={() => setSaveAsStatus('Draft')}
                            className={cn(
                              "py-1.5 rounded-md text-xs font-bold transition-all px-2 cursor-pointer",
                              saveAsStatus === 'Draft'
                                ? "bg-white text-indigo-700 shadow-sm font-extrabold"
                                : "text-slate-500 hover:text-slate-700"
                            )}
                          >
                            Save as Draft
                          </button>
                          <button
                            type="button"
                            onClick={() => setSaveAsStatus('Posted')}
                            className={cn(
                              "py-1.5 rounded-md text-xs font-bold transition-all px-2 cursor-pointer",
                              saveAsStatus === 'Posted'
                                ? "bg-white text-emerald-700 shadow-sm font-extrabold"
                                : "text-slate-500 hover:text-slate-700"
                            )}
                          >
                            Post Directly
                          </button>
                        </div>
                      </div>

                      {/* Repetition End Mode options (Option A, B, or C) */}
                      <div className="md:col-span-2 lg:col-span-3 space-y-3 pt-4 border-t border-slate-200/60">
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                          End Date / Repetitions (نهاية التكرار وعددها)
                        </label>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {/* Option C: Infinite / No End Date */}
                          <label className={cn(
                            "p-4 rounded-xl border cursor-pointer flex flex-col space-y-1.5 text-xs transition-all",
                            repeatsEndType === 'Infinite' ? "border-indigo-500 bg-indigo-50/10 ring-1 ring-indigo-500" : "border-slate-200 bg-white hover:border-slate-300"
                          )}>
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                name="repeatsEndType"
                                checked={repeatsEndType === 'Infinite'}
                                onChange={() => setRepeatsEndType('Infinite')}
                                className="w-4 h-4 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                              />
                              <span className="font-extrabold text-slate-800">Indefinitely / No End Date (ما لا نهاية)</span>
                            </div>
                            <span className="text-slate-400 pl-6 text-[11px] leading-relaxed">Runs forever until manually paused or terminated.</span>
                          </label>

                          {/* Option A: Specific End Date */}
                          <label className={cn(
                            "p-4 rounded-xl border cursor-pointer flex flex-col space-y-1.5 text-xs transition-all",
                            repeatsEndType === 'Date' ? "border-indigo-500 bg-indigo-50/10 ring-1 ring-indigo-500" : "border-slate-200 bg-white hover:border-slate-300"
                          )}>
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                name="repeatsEndType"
                                checked={repeatsEndType === 'Date'}
                                onChange={() => setRepeatsEndType('Date')}
                                className="w-4 h-4 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                              />
                              <span className="font-extrabold text-slate-800">Specific End Date (تاريخ انتهاء محدد)</span>
                            </div>
                            <span className="text-slate-400 pl-6 text-[11px] leading-relaxed">Stops once the scheduled date crosses target date.</span>
                          </label>

                          {/* Option B: Number of Times */}
                          <label className={cn(
                            "p-4 rounded-xl border cursor-pointer flex flex-col space-y-1.5 text-xs transition-all",
                            repeatsEndType === 'Count' ? "border-indigo-500 bg-indigo-50/10 ring-1 ring-indigo-500" : "border-slate-200 bg-white hover:border-slate-300"
                          )}>
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                name="repeatsEndType"
                                checked={repeatsEndType === 'Count'}
                                onChange={() => setRepeatsEndType('Count')}
                                className="w-4 h-4 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                              />
                              <span className="font-extrabold text-slate-800">Number of Times (عدد تكرار محدد)</span>
                            </div>
                            <span className="text-slate-400 pl-6 text-[11px] leading-relaxed">Completes and deactivates after specified run count.</span>
                          </label>
                        </div>

                        {/* End Mode Specific Inputs */}
                        {repeatsEndType === 'Date' && (
                          <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-2 max-w-sm animate-fadeIn">
                            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wide">Select End Target Date *</label>
                            <input
                              type="date"
                              required={isRepeating && repeatsEndType === 'Date'}
                              value={repeatsEndDate}
                              onChange={(e) => setRepeatsEndDate(e.target.value)}
                              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-mono text-slate-800 shadow-sm"
                            />
                          </div>
                        )}

                        {repeatsEndType === 'Count' && (
                          <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-2 max-w-sm animate-fadeIn">
                            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wide">Number of repetitions *</label>
                            <input
                              type="number"
                              min="1"
                              required={isRepeating && repeatsEndType === 'Count'}
                              value={repeatsEndCount}
                              onChange={(e) => setRepeatsEndCount(Math.max(1, parseInt(e.target.value) || 1))}
                              className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-mono font-bold text-slate-800 shadow-sm"
                            />
                          </div>
                        )}
                      </div>

                      {/* Pause / Resume Controls if editing an existing template */}
                      {editingEntryId && (
                        <div className="md:col-span-2 lg:col-span-3 flex items-center gap-3 p-4 bg-amber-50 border border-amber-200 rounded-xl">
                          <input
                            id="isRepeatingActiveToggle"
                            type="checkbox"
                            checked={isRepeatingActive}
                            onChange={(e) => setIsRepeatingActive(e.target.checked)}
                            className="w-4.5 h-4.5 rounded text-amber-600 border-slate-300 focus:ring-amber-500 cursor-pointer"
                          />
                          <div className="space-y-0.5">
                            <label htmlFor="isRepeatingActiveToggle" className="block text-xs font-bold text-amber-900 cursor-pointer select-none">
                              Repetition schedule is ACTIVE (قيد التكرار نشط)
                            </label>
                            <p className="text-[11px] text-amber-700">
                              Uncheck this box to pause automated run postings for this schedule indefinitely.
                            </p>
                          </div>
                        </div>
                      )}

                    </div>
                  )}

                </div>
              </div>
            </div>

          </div>

          {/* Complete Keyboard-Navigable Rows Container */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                Double-Entry Line Items
              </span>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[1000px]">
                <thead>
                  <tr className="bg-slate-100/50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-200">
                    <th className="py-3 px-4 w-[240px]">{getLocalizedLabel('Account')} (Code - Name) *</th>
                    <th className="py-3 px-4 w-[200px]">{getLocalizedLabel('Description')}</th>
                    <th className="py-3 px-4 w-[110px] text-right">{getLocalizedLabel('Debit')}</th>
                    <th className="py-3 px-4 w-[110px] text-right">{getLocalizedLabel('Credit')}</th>
                    <th className="py-3 px-4 w-[130px]">{getLocalizedLabel('Tax Amount')}</th>
                    <th className="py-3 px-4 w-[120px]">Branch (الفرع)</th>
                    <th className="py-3 px-4 w-[120px]">Department (القسم)</th>
                    <th className="py-3 px-4 w-[120px]">Project (المشروع)</th>
                    <th className="py-3 px-2 w-[50px] text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {rows.map((row, idx) => {
                    const filteredAccts = getFilteredAccounts(idx);
                    const isDebitLocked = !!row.credit && row.credit !== '';
                    const isCreditLocked = !!row.debit && row.debit !== '';

                    return (
                      <tr 
                        key={idx} 
                        className={cn(
                          "hover:bg-slate-50/50 transition-colors text-slate-700",
                          focusedCell?.rowIdx === idx ? "bg-indigo-50/10" : ""
                        )}
                      >
                        
                        {/* 1. Account Search Autocomplete column */}
                        <td className="py-3 px-4 relative align-top">
                          <div className="relative">
                            <input
                              id={`cell-${idx}-account-input`}
                              type="text"
                              required
                              placeholder="Account search Code..."
                              value={
                                accountSearchText[idx] !== undefined 
                                  ? accountSearchText[idx] 
                                  : (row.accountCode ? `${row.accountCode} - ${row.accountName}` : '')
                              }
                              onChange={(e) => handleAccountSearchChange(idx, e.target.value)}
                              onKeyDown={(e) => handleAccountInputKeyDown(e, idx)}
                              onFocus={() => {
                                setFocusedCell({ rowIdx: idx, colName: 'account' });
                                setActiveDropdownRowIdx(idx);
                                setHighlightedAccountIndex(0);
                              }}
                              onBlur={() => {
                                // Delay slightly so click events on list register before hiding
                                setTimeout(() => {
                                  if (activeDropdownRowIdx === idx) {
                                    setActiveDropdownRowIdx(null);
                                  }
                                }, 220);
                              }}
                              className={cn(
                                "w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-sans font-medium placeholder:text-slate-300",
                                row.accountId ? "border-slate-300 font-semibold text-slate-800" : "border-slate-200"
                              )}
                            />

                            {/* Dropdown Options Popup List */}
                            {activeDropdownRowIdx === idx && (
                              <div className="absolute left-0 right-0 top-full mt-1.5 bg-white border border-slate-200 rounded-xl shadow-2xl z-50 max-h-[220px] overflow-y-auto divide-y divide-slate-50 font-sans">
                                {filteredAccts.length === 0 ? (
                                  <div className="p-3 text-xs text-slate-400 italic">No matching ledger charts</div>
                                ) : (
                                  filteredAccts.map((acct, itemIdx) => (
                                    <div
                                      key={acct.id}
                                      onMouseDown={() => selectAccountOption(idx, acct)}
                                      onMouseEnter={() => setHighlightedAccountIndex(itemIdx)}
                                      className={cn(
                                        "px-4 py-2.5 text-xs font-semibold cursor-pointer select-none transition-colors",
                                        highlightedAccountIndex === itemIdx 
                                          ? "bg-slate-900 text-white" 
                                          : "text-slate-700 hover:bg-slate-100"
                                      )}
                                    >
                                      <span className="font-mono font-bold mr-2">{acct.code}</span>
                                      <span>— {acct.name}</span>
                                      <span className="float-right text-[10px] uppercase opacity-70 px-1 bg-slate-100 rounded text-slate-500 font-mono">
                                        {acct.type}
                                      </span>
                                    </div>
                                  ))
                                )}
                              </div>
                            )}
                          </div>
                        </td>

                        {/* 2. Line Description column */}
                        <td className="py-3 px-4 align-top">
                          <input
                            id={`cell-${idx}-description`}
                            type="text"
                            placeholder="Line narration memo..."
                            value={row.description}
                            onChange={(e) => updateRowValue(idx, 'description', e.target.value)}
                            onFocus={() => {
                              setFocusedCell({ rowIdx: idx, colName: 'description' });
                              // Auto pre-populate empty description with global Narration
                              if (!row.description.trim()) {
                                updateRowValue(idx, 'description', globalNarration);
                              }
                            }}
                            onKeyDown={(e) => handleCellKeyDown(e, idx, 'description')}
                            className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm hover:border-slate-300 focus:ring-1 focus:ring-indigo-500 outline-none bg-white placeholder:text-slate-300 transition-colors"
                          />
                        </td>

                        {/* 3. Debit column */}
                        <td className="py-3 px-4 align-top text-right">
                          <input
                            id={`cell-${idx}-debit`}
                            type="text"
                            disabled={isDebitLocked}
                            placeholder={isDebitLocked ? "Locked" : "0.00"}
                            value={row.debit}
                            onChange={(e) => {
                              // Accept only decimals or empty string
                              const sanitized = e.target.value.replace(/[^0-9.]/g, '');
                              updateRowValue(idx, 'debit', sanitized);
                            }}
                            onFocus={() => handleFocusDebit(idx)}
                            onKeyDown={(e) => handleCellKeyDown(e, idx, 'debit')}
                            className={cn(
                              "w-full px-3 py-2 border rounded-lg text-sm text-right focus:ring-1 focus:ring-indigo-500 outline-none font-mono tracking-wider transition-colors uppercase font-semibold",
                              isDebitLocked ? "bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed" : "bg-white border-slate-200 hover:border-slate-300 text-slate-800"
                            )}
                          />
                        </td>

                        {/* 4. Credit column */}
                        <td className="py-3 px-4 align-top text-right">
                          <input
                            id={`cell-${idx}-credit`}
                            type="text"
                            disabled={isCreditLocked}
                            placeholder={isCreditLocked ? "Locked" : "0.00"}
                            value={row.credit}
                            onChange={(e) => {
                              const sanitized = e.target.value.replace(/[^0-9.]/g, '');
                              updateRowValue(idx, 'credit', sanitized);
                            }}
                            onFocus={() => handleFocusCredit(idx)}
                            onKeyDown={(e) => handleCellKeyDown(e, idx, 'credit')}
                            className={cn(
                              "w-full px-3 py-2 border rounded-lg text-sm text-right focus:ring-1 focus:ring-indigo-500 outline-none font-mono tracking-wider transition-colors uppercase font-semibold",
                              isCreditLocked ? "bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed" : "bg-white border-slate-200 hover:border-slate-300 text-slate-800"
                            )}
                          />
                        </td>

                        {/* 5. Tax Rate column */}
                        <td className="py-3 px-4 align-top">
                          <select
                            id={`cell-${idx}-taxRate`}
                            value={row.taxRate}
                            onChange={(e) => {
                              const rateVal = parseInt(e.target.value);
                              const item = taxRatesList.find(t => t.value === rateVal);
                              setRows(prev => prev.map((r, rIndex) => rIndex === idx ? {
                                ...r,
                                taxRate: rateVal,
                                taxLabel: item?.label || 'No Tax (0%)'
                              } : r));
                            }}
                            onFocus={() => setFocusedCell({ rowIdx: idx, colName: 'taxRate' })}
                            onKeyDown={(e) => handleCellKeyDown(e, idx, 'taxRate')}
                            className="w-full px-2 py-2 border border-slate-200 rounded-lg text-xs bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-600 font-medium tracking-tight cursor-pointer"
                          >
                            {taxRatesList.map((trOption, trIdx) => (
                              <option key={trIdx} value={trOption.value}>
                                {trOption.label}
                              </option>
                            ))}
                          </select>
                        </td>

                        {/* 6. Analytical custom Department (Branch) category columns */}
                        <td className="py-3 px-4 align-top">
                          <select
                            id={`cell-${idx}-region`}
                            value={row.region}
                            onChange={(e) => {
                              updateRowValue(idx, 'region', e.target.value);
                              updateRowValue(idx, 'branchId', e.target.value);
                            }}
                            onFocus={() => setFocusedCell({ rowIdx: idx, colName: 'region' })}
                            onKeyDown={(e) => handleCellKeyDown(e, idx, 'region')}
                            className="w-full px-2 py-2 border border-slate-200 rounded-lg text-xs bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-500 font-medium cursor-pointer"
                          >
                            {regionsList.map((reg, regIdx) => (
                              <option key={regIdx} value={reg}>
                                {reg === 'None' ? 'None (No Branch)' : reg}
                              </option>
                            ))}
                          </select>
                        </td>

                        {/* 7. Analytical custom Department category columns */}
                        <td className="py-3 px-4 align-top">
                          <select
                            id={`cell-${idx}-department`}
                            value={row.department}
                            onChange={(e) => {
                              updateRowValue(idx, 'department', e.target.value);
                              updateRowValue(idx, 'departmentId', e.target.value);
                            }}
                            onFocus={() => setFocusedCell({ rowIdx: idx, colName: 'department' })}
                            onKeyDown={(e) => handleCellKeyDown(e, idx, 'department')}
                            className="w-full px-2 py-2 border border-slate-200 rounded-lg text-xs bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-500 font-medium cursor-pointer"
                          >
                            {departmentsList.map((dept, deptIdx) => (
                              <option key={deptIdx} value={dept}>
                                {dept === 'None' ? 'None (No Dept)' : dept}
                              </option>
                            ))}
                          </select>
                        </td>

                        {/* 7.5. Analytical custom Project ID category columns */}
                        <td className="py-3 px-4 align-top">
                          <select
                            id={`cell-${idx}-projectId`}
                            value={row.projectId || 'None'}
                            onChange={(e) => updateRowValue(idx, 'projectId', e.target.value)}
                            onFocus={() => setFocusedCell({ rowIdx: idx, colName: 'projectId' })}
                            onKeyDown={(e) => handleCellKeyDown(e, idx, 'projectId')}
                            className="w-full px-2 py-2 border border-slate-200 rounded-lg text-xs bg-white focus:ring-1 focus:ring-indigo-500 outline-none text-slate-500 font-medium cursor-pointer"
                          >
                            {projectsList.map((proj, projIdx) => (
                              <option key={projIdx} value={proj}>
                                {proj === 'None' ? 'None (No Project)' : proj}
                              </option>
                            ))}
                          </select>
                        </td>

                        {/* 8. Deletion line button */}
                        <td className="py-3 px-2 align-top text-center">
                          <button
                            type="button"
                            onClick={() => removeRowLine(idx)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-all cursor-pointer"
                            title="Remove Line"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Quick manual row injection rail */}
            <div className="p-4 bg-slate-50/50 border-t border-slate-200 flex items-center justify-between">
              <button
                type="button"
                onClick={appendRowLine}
                className="flex items-center gap-1.5 px-4 py-2 text-indigo-600 hover:text-indigo-700 hover:bg-indigo-50 border border-indigo-200 bg-white rounded-lg text-xs font-bold transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add a line
              </button>
              
              <span className="text-[11px] text-slate-400 italic">
                Pro Tip: Press TAB on the last input cell to append a line instantly.
              </span>
            </div>
          </div>

          {/* Balanced Warning & Totals pane */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
            
            {/* Out-Of-Balance Warn Box */}
            <div>
              {!calculatedFormTotals.isBalanced ? (
                <div id="unbalanced-warning" className="bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl p-5 flex items-start gap-3 mt-1 animate-fadeIn">
                  <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold uppercase tracking-wider text-rose-900">
                      Unbalanced Bookkeeping Warning
                    </h4>
                    <p className="text-xs text-slate-600">
                      Your manual journal entry is currently unbalanced by <span className="font-mono font-bold text-rose-700">{formatCurrency(calculatedFormTotals.difference)}</span>. 
                      Double-entry accounting principles dictate that posted ledger debits must balance credits.
                    </p>
                    <p className="text-xs text-slate-500 font-medium italic mt-2">
                       Hint: Press TAB on an empty Debit or Credit input or click into it and the system will automatically prefill it with the exact matching value needed to balanced.
                    </p>
                  </div>
                </div>
              ) : (
                <div id="balanced-success" className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl p-5 flex items-start gap-3 mt-1">
                  <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold uppercase tracking-wider text-emerald-900">
                      Ledger is Perfectly Balanced
                    </h4>
                    <p className="text-xs text-slate-600">
                      The sum of Debits equals Credits (<span className="font-mono font-bold">{formatCurrency(calculatedFormTotals.finalDebitTotal)}</span>). You can proceed to lock and publish this entry to your trial balance journals.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Subtotal table summaries aligned to bottom right */}
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-4">
              <span className="block text-xs font-bold text-slate-500 uppercase tracking-wider">
                Journals Totals Summary
              </span>

              <div className="space-y-2.5 text-sm font-sans">
                
                {/* Net Subtotal */}
                <div className="flex items-center justify-between text-slate-600">
                  <span>Subtotal before taxes</span>
                  <div className="flex items-center gap-6 font-mono text-slate-500 text-xs">
                    <div>Dr: {formatCurrency(calculatedFormTotals.debitsBaseSum)}</div>
                    <div>Cr: {formatCurrency(calculatedFormTotals.creditsBaseSum)}</div>
                  </div>
                </div>

                {/* Tax subtotal */}
                {taxTreatment !== 'NoTax' && (
                  <div className="flex items-center justify-between text-slate-600 border-t border-slate-200/60 pt-2.5">
                    <span>Tax Amount ({taxTreatment === 'Inclusive' ? 'Inclusive' : 'Exclusive'})</span>
                    <div className="flex items-center gap-6 font-mono text-slate-500 text-xs">
                      <div>Dr: {formatCurrency(calculatedFormTotals.debitsTaxSum)}</div>
                      <div>Cr: {formatCurrency(calculatedFormTotals.creditsTaxSum)}</div>
                    </div>
                  </div>
                )}

                {/* Final locks */}
                <div className="flex items-center justify-between text-slate-900 font-bold border-t border-slate-200 pt-3">
                  <span className="text-sm font-extrabold uppercase">Total Amount</span>
                  <div className="flex items-center gap-6 font-mono text-base">
                    <div className="text-emerald-700">Dr: {formatCurrency(calculatedFormTotals.finalDebitTotal)}</div>
                    <div className="text-amber-700">Cr: {formatCurrency(calculatedFormTotals.finalCreditTotal)}</div>
                  </div>
                </div>

              </div>

            </div>

          </div>

          {/* Bottom Action Form bar duplicate */}
          <div className="flex items-center justify-between border-t border-slate-200 pt-6">
            <span className="text-xs text-slate-400 italic">
              * Required details for posting. Out-Of-Balance entries are accepted only as Draft status.
            </span>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className="px-6 py-2.5 border border-slate-200 rounded-lg text-slate-700 font-semibold text-sm hover:bg-slate-50 transition-colors cursor-pointer"
              >
                Go Back to entries
              </button>
              <button
                type="button"
                disabled={isSaving}
                onClick={() => submitJournalEntry('Draft')}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 font-semibold text-sm rounded-lg transition-colors cursor-pointer disabled:opacity-50"
              >
                Save as Draft
              </button>
              <button
                type="button"
                disabled={isSaving || !calculatedFormTotals.isBalanced}
                onClick={() => submitJournalEntry('Posted')}
                className={cn(
                  "px-6 py-2.5 text-white font-bold text-sm rounded-lg transition-all cursor-pointer shadow-indigo-600/10 shadow disabled:opacity-50",
                  calculatedFormTotals.isBalanced 
                    ? "bg-indigo-600 hover:bg-indigo-700" 
                    : "bg-indigo-400 cursor-not-allowed"
                )}
              >
                {isSaving ? <Loader2 className="w-4.5 h-4.5 animate-spin inline mr-1" /> : null}
                Post Journal Entry
              </button>
            </div>
          </div>

        </div>
      )}

      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        moduleId="journals"
        existingRecords={entries}
        onImportSuccess={(cnt) => {
          setIsImportModalOpen(false);
        }}
      />
    </div>
  );
}
