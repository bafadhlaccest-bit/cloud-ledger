/**
 * AuditTrail — سجل التدقيق
 * موجود في زوهو/زيرو: تتبع كل تغيير في النظام
 */
import React, { useState, useEffect } from 'react';
import { Shield, Search, RefreshCw, Download } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useRBAC } from '../hooks/useRBAC';
import * as XLSX from 'xlsx';

const ACTION_STYLE: Record<string, string> = {
  CREATE: 'bg-emerald-100 text-emerald-700',
  UPDATE: 'bg-blue-100 text-blue-700',
  DELETE: 'bg-red-100 text-red-700',
  LOGIN:  'bg-slate-100 text-slate-600',
  EXPORT: 'bg-amber-100 text-amber-700',
  POST:   'bg-purple-100 text-purple-700',
};
const TABLE_AR: Record<string, string> = {
  invoices: 'الفواتير', bills: 'فواتير الشراء', customers: 'العملاء',
  vendors: 'الموردين', accounts: 'الحسابات', journal_entries: 'القيود',
  items: 'الأصناف', bank_accounts: 'الحسابات البنكية', expenses: 'المصروفات',
  quotations: 'عروض الأسعار', purchase_orders: 'أوامر الشراء',
};

export default function AuditTrail() {
  const { companyId } = useRBAC();
  const [logs, setLogs] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterAction, setFilterAction] = useState('');
  const [filterTable, setFilterTable] = useState('');
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  useEffect(() => { if (companyId) load(); }, [companyId, page]);

  async function load() {
    setIsLoading(true);
    let q = supabase.from('financial_audit_trails')
      .select('*')
      .eq('company_id', companyId)
      .order('created_at', { ascending: false })
      .range(page * PAGE_SIZE, (page + 1) * PAGE_SIZE - 1);
    if (filterAction) q = q.eq('action', filterAction);
    if (filterTable)  q = q.eq('table_name', filterTable);
    const { data } = await q;
    setLogs(data || []);
    setIsLoading(false);
  }

  // Log a manual action
  const logAction = async (action: string, tableName: string, detail: string) => {
    await supabase.from('financial_audit_trails').insert({
      company_id: companyId,
      action, table_name: tableName,
      new_values: { detail },
      created_at: new Date().toISOString(),
    });
    load();
  };

  const exportExcel = () => {
    const rows = logs.map(l => ({
      'التاريخ': new Date(l.created_at).toLocaleString('ar-SA'),
      'الإجراء': l.action,
      'الجدول': TABLE_AR[l.table_name] || l.table_name,
      'رقم السجل': l.record_id || '',
      'التفاصيل': JSON.stringify(l.new_values || {}),
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Audit Trail');
    XLSX.writeFile(wb, `audit_trail_${new Date().toISOString().slice(0,10)}.xlsx`);
  };

  const filtered = logs.filter(l =>
    !search ||
    l.action?.includes(search.toUpperCase()) ||
    (TABLE_AR[l.table_name] || l.table_name || '').includes(search) ||
    l.record_id?.includes(search)
  );

  const tables = [...new Set(logs.map(l => l.table_name).filter(Boolean))];
  const actions = [...new Set(logs.map(l => l.action).filter(Boolean))];

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">سجل التدقيق</h1>
            <p className="text-slate-500 text-sm">كل تغيير في النظام موثق ومؤرشف</p>
          </div>
        </div>
        <button onClick={exportExcel}
          className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold px-4 py-2.5 rounded-xl transition-colors">
          <Download className="w-4 h-4" /> تصدير
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث في السجل..."
            className="w-full pr-10 pl-4 py-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-slate-500" />
        </div>
        <select value={filterAction} onChange={e => { setFilterAction(e.target.value); setPage(0); load(); }}
          className="px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none bg-white focus:ring-2 focus:ring-slate-500">
          <option value="">كل الإجراءات</option>
          {actions.map(a => <option key={a} value={a}>{a}</option>)}
        </select>
        <select value={filterTable} onChange={e => { setFilterTable(e.target.value); setPage(0); load(); }}
          className="px-3 py-2.5 border border-slate-200 rounded-xl text-sm outline-none bg-white focus:ring-2 focus:ring-slate-500">
          <option value="">كل الجداول</option>
          {tables.map(t => <option key={t} value={t}>{TABLE_AR[t] || t}</option>)}
        </select>
        <button onClick={load} className="p-2.5 border border-slate-200 rounded-xl hover:bg-slate-50">
          <RefreshCw className="w-4 h-4 text-slate-500" />
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              {['التاريخ والوقت', 'الإجراء', 'الجدول', 'رقم السجل', 'التفاصيل'].map(h => (
                <th key={h} className="text-right px-4 py-3 text-xs font-bold text-slate-500">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {isLoading ? (
              <tr><td colSpan={5} className="text-center py-12"><RefreshCw className="w-5 h-5 animate-spin mx-auto text-slate-400" /></td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={5} className="text-center py-16 text-slate-400">
                <Shield className="w-10 h-10 mx-auto mb-3 text-slate-200" />
                <div>لا توجد سجلات تدقيق</div>
                <div className="text-xs mt-1">ستُسجَّل كل العمليات هنا تلقائياً</div>
              </td></tr>
            ) : filtered.map(log => (
              <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-3 text-slate-500 text-xs font-mono whitespace-nowrap">
                  {new Date(log.created_at).toLocaleString('ar-SA')}
                </td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${ACTION_STYLE[log.action] || 'bg-slate-100 text-slate-600'}`}>
                    {log.action}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-600 text-xs">{TABLE_AR[log.table_name] || log.table_name || '—'}</td>
                <td className="px-4 py-3 text-slate-400 font-mono text-xs truncate max-w-[100px]">{log.record_id?.slice(0,8) || '—'}</td>
                <td className="px-4 py-3 text-slate-500 text-xs truncate max-w-[200px]">
                  {log.new_values ? JSON.stringify(log.new_values).slice(0, 80) : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-100">
          <button onClick={() => setPage(p => Math.max(0, p-1))} disabled={page === 0}
            className="text-xs px-3 py-1.5 border border-slate-200 rounded-lg disabled:opacity-40 hover:bg-slate-50">
            ← السابق
          </button>
          <span className="text-xs text-slate-500">صفحة {page + 1}</span>
          <button onClick={() => setPage(p => p+1)} disabled={logs.length < PAGE_SIZE}
            className="text-xs px-3 py-1.5 border border-slate-200 rounded-lg disabled:opacity-40 hover:bg-slate-50">
            التالي →
          </button>
        </div>
      </div>
    </div>
  );
}
