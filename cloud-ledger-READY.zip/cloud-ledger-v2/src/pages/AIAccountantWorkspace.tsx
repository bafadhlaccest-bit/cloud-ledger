import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAIAccountant } from '../hooks/useAIAccountant';
import { safeStorage } from '../utils/safeStorage';
import { useAuthStore } from '../store/useAuthStore';
import { getLocalizedLabel, getActiveLanguage } from '../lib/utils';
import { useSettings } from '../context/SettingsContext';
import { useRBAC } from '../hooks/useRBAC';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid,
  BarChart,
  Bar
} from 'recharts';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  serverTimestamp,
  doc,
  setDoc,
  query,
  where
import { 
  Sparkles, 
  Send, 
  Mic, 
  MicOff, 
  Paperclip, 
  FileText, 
  Loader2, 
  CheckCircle2, 
  X, 
  ArrowRight, 
  HelpCircle, 
  AlertCircle,
  TrendingUp,
  FileCheck2,
  FileUp
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { db, collection, addDoc, onSnapshot, query, where, serverTimestamp, doc } from '../firebase';

// Chart of Accounts Local/Active Interface
interface Account {
  id: string;
  code: string;
  name: string;
  type: string;
  description?: string;
  balance?: number;
  status?: string;
}

interface Message {
  id: string;
  sender: 'user' | 'system';
  text: string;
  timestamp: Date;
  file?: {
    name: string;
    type: string;
    size: string;
  };
  journal?: {
    date: string;
    reference: string;
    description: string;
    totalDebit: number;
    totalCredit: number;
    lines: Array<{
      accountId: string;
      accountName: string;
      accountCode: string;
      debit: number;
      credit: number;
      description: string;
    }>;
  } | null;
  proposedNewAccount?: {
    name: string;
    type: string;
    parentId: string;
    description?: string;
  } | null;
  settingsUpdate?: {
    key: 'companyProfile' | 'modulesMap';
    updatedFields: any;
  } | null;
  executedAction?: {
    success: boolean;
    customerId?: string;
    supplierId?: string;
    invoiceNo?: string;
    journalId?: string;
    actionTaken?: string;
    tableName?: string;
    data?: any;
    record?: any;
    header?: any;
    categories?: any[];
    statementType?: string;
    period?: string;
    totalRevenue?: number;
    totalExpense?: number;
    netProfit?: number;
    totalAssets?: number;
    totalLiabilities?: number;
    totalEquity?: number;
  } | null;
  forecast?: {
    title: string;
    type: 'Revenue' | 'CashFlow';
    data: Array<{
      name: string;
      value: number;
      projected: number;
      isForecast: boolean;
    }>;
  } | null;
  saveState?: 'none' | 'confirming' | 'saving' | 'saved' | 'cancelled';
  savedEntryId?: string;
}

export default function AIAccountantWorkspace() {
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const isRtl = i18n.language === 'ar';
  const { settings } = useSettings();
  const { companyId } = useRBAC();
  const [userRole, setUserRole] = useState<'Admin' | 'Accountant' | 'Auditor' | 'Vendor'>('Admin');

  const {
    messages,
    inputText,
    setInputText,
    accounts,
    isLoading,
    isRecording,
    setIsRecording,
    activeFile,
    setActiveFile,
    ocrStage,
    ocrLogs,
    recentSavedDrafts,
    sendMessage,
    commitJournalToDatabase,
    cancelJournalTransaction,
    messagesEndRef,
    fileInputRef
  } = useAIAccountant(userRole);

  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const [dragActive, setDragActive] = useState(false);
  const speechRecognitionRef = useRef<any>(null);
  const [journalCount, setJournalCount] = useState<number>(0);

  // Live subscription to journal entries to calculate total transactional historical density
  useEffect(() => {
    if (!isAuthenticated) return;
    const q = query(
      collection(db, 'journalEntries'),
      where('companyId', '==', companyId)
    );
    return onSnapshot(q, (snap) => {
      setJournalCount(snap.size);
    }, (error) => {
      console.warn("Journal entries subscription disabled:", error.message);
    });
  }, [isAuthenticated, companyId]);

  // Web Speech API for real voice-to-text
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'ar-YE';

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(prev => prev + ' ' + transcript);
        setIsRecording(false);
      };

      rec.onerror = (e: any) => {
        console.error("Speech Recognition Error", e);
        setIsRecording(false);
      };

      rec.onend = () => {
        setIsRecording(false);
      };

      speechRecognitionRef.current = rec;
    }
  }, [companyId]);

  // Check for stored drill-down analysis query on landing and post it automatically
  useEffect(() => {
    try {
      const pendingQuery = safeStorage.getItem('ai_erp_copilot_context_query');
      if (pendingQuery) {
        safeStorage.removeItem('ai_erp_copilot_context_query');
        sendMessage(pendingQuery);
      }
    } catch {}
  }, [accounts]);

  const toggleRecording = () => {
    if (!speechRecognitionRef.current) {
      alert("Speech recognition is not supported in this browser or iframe wrapper.");
      return;
    }

    if (isRecording) {
      speechRecognitionRef.current.stop();
      setIsRecording(false);
    } else {
      setIsRecording(true);
      speechRecognitionRef.current.start();
    }
  };

  // Drag and Drop files handlers
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processUploadedFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processUploadedFile(e.target.files[0]);
    }
  };

  // Convert File to base64, detect XLSX and parse with SheetJS
  const processUploadedFile = (file: File) => {
    const reader = new FileReader();
    const sizeStr = (file.size / 1024).toFixed(1) + ' KB';

    if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
      reader.onload = (e: any) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[firstSheetName];
          const csvText = XLSX.utils.sheet_to_csv(sheet);

          setActiveFile({
            name: file.name,
            type: file.type || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            base64: '',
            size: sizeStr,
            textParsed: csvText.substring(0, 8000)
          });
        } catch (err) {
          console.error("XLSX parsing error", err);
          alert("Failed to parse Excel spreadsheet.");
        }
      };
      reader.readAsArrayBuffer(file);
    } else {
      reader.onloadend = () => {
        const base64Data = reader.result as string;
        const cleanBase64 = base64Data.split(',')[1] || base64Data;

        setActiveFile({
          name: file.name,
          type: file.type || 'application/octet-stream',
          base64: cleanBase64,
          size: sizeStr
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const clearActiveFile = () => {
    setActiveFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !activeFile) return;
    const currentAttachment = activeFile ? { ...activeFile } : undefined;
    clearActiveFile();
    await sendMessage(inputText, currentAttachment);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] gap-6" id="ai-accountant-workspace-main">
      {/* Top Banner Header */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-gradient-to-tr from-indigo-500 to-violet-600 rounded-xl flex items-center justify-center shadow-md">
            <Sparkles className="text-white w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 leading-tight">المساعد المالي التنفيذي (Copilot)</h1>
            <p className="text-xs text-slate-500 font-mono tracking-wide">Enterprise AI Financial Copilot • Microsoft Copilot & SAP Joule Standards</p>
          </div>
        </div>

        {/* Secure Workspace Context Metadata Session Inspector Badge */}
        <div className="hidden lg:flex items-center gap-2 bg-slate-100 border border-slate-200 rounded-xl px-3 py-1.5 text-[10px] font-mono text-slate-700">
          <div className="flex items-center gap-1.5 border-r border-slate-200 pr-2">
            <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
            <span className="font-semibold text-slate-500">Company:</span>
            <span className="font-extrabold text-slate-800">{settings?.systemName || 'Al-Huraibi Trading HQ'}</span>
          </div>
          <div className="flex items-center gap-1.5 border-r border-slate-200 px-2">
            <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></span>
            <span className="font-semibold text-slate-500">Role:</span>
            <span className="font-extrabold text-slate-800">{userRole}</span>
          </div>
          <div className="flex items-center gap-1.5 border-r border-slate-200 px-2">
            <span className="w-1.5 h-1.5 bg-purple-500 rounded-full"></span>
            <span className="font-semibold text-slate-500">Fiscal Year:</span>
            <span className="font-extrabold text-slate-800">2026 Context</span>
          </div>
          <div className="flex items-center gap-1.5 pl-1">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
            <span className="font-semibold text-slate-500">State:</span>
            <span className="font-extrabold text-slate-800">/ai-accountant</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-indigo-50 border border-indigo-150 rounded-xl px-3.5 py-1.5 text-xs text-indigo-900 font-sans">
            <span className="font-extrabold text-indigo-950">صلاحيات الاختبار:</span>
            <select 
              value={userRole} 
              onChange={(e) => setUserRole(e.target.value as any)}
              className="bg-white border border-indigo-200 rounded-lg px-2.5 py-1.5 font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer text-indigo-950"
            >
              <option value="Admin">مدير النظام الـ CFO (كامل الصلاحيات)</option>
              <option value="Accountant">محاسب مالي (العمليات اليومية)</option>
              <option value="Auditor">مدقق خارجي (قراءة التقارير فقط)</option>
              <option value="Vendor">مورد خارجي (ممنوع من الوصول)</option>
            </select>
          </div>

          <div className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold text-slate-600">
            <span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-ping"></span>
            <span>دليل الحسابات النشط: {accounts.length} حساب متاح للمطابقة</span>
          </div>
        </div>
      </div>

      {/* Main Split Layout Panel */}
      <div className="flex-1 flex gap-6 overflow-hidden">
        {/* Left Module: Central Chat interactive Timeline */}
        <div className="flex-1 flex flex-col bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm relative">
          
          {/* Scrollable chat messages container */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50">
            {messages.map((message) => {
              const isSystem = message.sender === 'system';
              return (
                <div 
                  key={message.id} 
                  className={`flex gap-4 ${isSystem ? 'justify-start' : 'justify-end'}`}
                >
                  {isSystem && (
                    <div className="w-9 h-9 bg-indigo-100 border border-indigo-200 rounded-lg flex items-center justify-center text-indigo-600 font-bold shrink-0 shadow-sm">
                      <Sparkles className="w-5 h-5" />
                    </div>
                  )}

                  <div className="max-w-[80%] flex flex-col gap-2">
                    {/* Message Bubble itself */}
                    <div className={`p-4 rounded-2xl text-sm leading-relaxed shadow-sm ${
                      isSystem 
                        ? 'bg-white text-slate-800 border border-slate-100 rounded-tl-none' 
                        : 'bg-indigo-600 text-white rounded-tr-none'
                    }`}>
                      {/* Attached file status display if applicable */}
                      {message.file && (
                        <div className={`flex items-center gap-2.5 p-3 rounded-xl mb-3 text-xs border ${
                          isSystem ? 'bg-slate-50 border-slate-150 text-slate-700' : 'bg-indigo-700 border-indigo-500 text-indigo-50'
                        }`}>
                          <FileText className="w-5 h-5 text-indigo-400" />
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold truncate">{message.file.name}</p>
                            <p className="opacity-75 font-mono">{message.file.size} • Raw Document</p>
                          </div>
                        </div>
                      )}

                      {/* Message content in pre-wrap markdown styled wrapper */}
                      <div className="whitespace-pre-wrap leading-relaxed text-right rtl">
                        {message.text}
                      </div>

                      {/* Display Custom Double Entry Balanced Voucher interface right inside chat list */}
                      {message.journal && (
                        <div className="mt-4 border-t border-slate-150 pt-4 text-slate-800 text-right">
                          {message.proposedNewAccount && (
                            <div className="mb-3.5 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-3.5 text-right flex items-start gap-2.5">
                              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-bold text-amber-900 leading-tight">حساب مفقود مكتشف تلقائياً بالدليل المالي 📢</p>
                                <p className="text-xs text-slate-600 mt-1 lines-leading-relaxed">
                                  لاحظ المساعد المحاسبي أن الحساب <span className="font-extrabold text-amber-950">"{message.proposedNewAccount.name}"</span> غير متوفر حالياً بدليل الحسابات النشط.
                                  سيقوم النظام تلقائياً بإنشاء الحساب وتوليد الرمز التسلسلي المناسب تحت فئة <span className="font-extrabold font-mono text-indigo-700">[{message.proposedNewAccount.type}]</span> وبناء المعاملة القيد المزدوج مباشرة عند التأكيد.
                                </p>
                              </div>
                            </div>
                          )}

                          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
                            <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-3 text-xs text-slate-500 font-bold">
                              <span>قيد اليومية المقترح (مسودة)</span>
                              <span>المرجع: {message.journal.reference}</span>
                            </div>

                            <p className="text-xs font-bold text-slate-700 mb-1">البيان: {message.journal.description}</p>
                            <p className="text-xs text-slate-500 mb-3">التاريخ: {message.journal.date}</p>

                            <div className="space-y-1.5 border-b border-slate-100 pb-3 mb-2 font-mono text-xs">
                              {message.journal.lines.map((line, idx) => {
                                const isDebit = line.debit > 0;
                                return (
                                  <div 
                                    key={idx} 
                                    className={`flex items-center justify-between p-1.5 gap-4 rounded ${
                                      isDebit ? 'bg-emerald-50/50 text-emerald-950' : 'bg-blue-50/30 text-blue-950'
                                    }`}
                                  >
                                    <span className="font-semibold truncate">
                                      {isDebit ? 'مدين (Debit)' : 'دائن (Credit)'}: {line.accountName} [{line.accountCode || 'PENDING'}]
                                    </span>
                                    <span className="font-bold whitespace-nowrap">
                                      {isDebit 
                                        ? `+ ${line.debit.toLocaleString()} YER` 
                                        : `- ${line.credit.toLocaleString()} YER`
                                      }
                                    </span>
                                  </div>
                                );
                              })}
                            </div>

                            {/* Total Balance Check status */}
                            <div className="flex items-center justify-between text-xs font-bold text-indigo-700">
                              <span>إجمالي المتوازن</span>
                              <span>{message.journal.totalDebit.toLocaleString()} YER</span>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Display Custom Financial Forecast Trend AreaCharts */}
                      {message.forecast && (
                        <div className="mt-4 border-t border-slate-150 pt-4 text-right" dir="rtl">
                          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl">
                            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                              <div className="flex items-center gap-2">
                                <TrendingUp className="w-5 h-5 text-emerald-500" />
                                <span className="font-bold text-sm tracking-tight text-slate-100">{message.forecast.title}</span>
                              </div>
                              <span className="font-mono text-[10px] uppercase tracking-widest bg-slate-800 px-2.5 py-1 rounded-full text-slate-400">
                                {message.forecast.type === 'Revenue' ? 'توقعات الإيرادات' : 'صادرات النقد كاش'}
                              </span>
                            </div>
                            
                            <p className="text-xs text-slate-400 mb-4 font-sans leading-relaxed">
                              التوقعات الإحصائية للأشهر الثلاثة القادمة (يونيو، يوليو، أغسطس 2026) مستخلصة بدقة رياضية عبر خوارزميات الانحدار الخطي من واقع قيود اليومية التاريخية.
                            </p>

                            {journalCount < 30 ? (
                              <div className="bg-slate-800/80 border border-amber-500/25 rounded-2xl p-5 text-center text-xs space-y-2 my-2 animate-fadeIn" dir="rtl">
                                <AlertCircle className="w-5 h-5 text-amber-500 mx-auto" />
                                <h4 className="font-bold text-amber-400">{isRtl ? 'حظر تفعيل توقعات الاتجاه منخفضة الكثافة' : 'Low-Density Forecasting Threshold Protected'}</h4>
                                <p className="text-slate-350 leading-relaxed font-sans text-[11px]">
                                  {isRtl 
                                    ? `يتطلب المعالج الإحصائي المحاسبي وجود 30 قيد يومية مسجلاً في القوائم والترتيبات لإنشاء خط توجيه إحصائي سليم ومستقر. القيود الحالية المكتشفة: ${journalCount} / 30.`
                                    : `Forecasting requires at least 30 historical ledger postings to construct a valid linear trend projection. Current: ${journalCount} / 30.`
                                  }
                                </p>
                              </div>
                            ) : (
                              <div style={{ width: '100%', height: '300px', minWidth: '300px', position: 'relative', direction: 'ltr' }}>
                                <ResponsiveContainer width="100%" height="100%">
                                  <AreaChart data={message.forecast.data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                                    <defs>
                                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor={message.forecast.type === 'Revenue' ? '#10B981' : '#3B82F6'} stopOpacity={0.4}/>
                                        <stop offset="95%" stopColor={message.forecast.type === 'Revenue' ? '#10B981' : '#3B82F6'} stopOpacity={0.0}/>
                                      </linearGradient>
                                    </defs>
                                    <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                                    <XAxis dataKey="name" stroke="#64748B" fontSize={10} tickLine={false} />
                                    <YAxis stroke="#64748B" fontSize={10} tickLine={false} tickFormatter={(v) => (v / 1000000) + 'M'} />
                                    <Tooltip 
                                      contentStyle={{ backgroundColor: '#0F172A', borderColor: '#1E293B', borderRadius: '12px', fontSize: '11px', color: '#fff' }}
                                      formatter={(v: any) => [`${Number(v).toLocaleString()} YER`, 'المبلغ']}
                                    />
                                    <Area 
                                      type="monotone" 
                                      dataKey="projected" 
                                      stroke={message.forecast.type === 'Revenue' ? '#10B981' : '#3B82F6'} 
                                      strokeWidth={3}
                                      fillOpacity={1} 
                                      fill="url(#colorValue)" 
                                    />
                                  </AreaChart>
                                </ResponsiveContainer>
                              </div>
                            )}

                            <div className="mt-4 grid grid-cols-3 gap-2.5 text-center">
                              {message.forecast.data.filter(d => d.isForecast).map((d, index) => (
                                <div key={index} className="bg-slate-800/50 p-2.5 rounded-2xl border border-slate-8001 bg-slate-800/50">
                                  <p className="text-[10px] text-slate-400 font-bold">{d.name}</p>
                                  <p className={`font-mono text-xs font-bold mt-1 ${message.forecast ? (message.forecast.type === 'Revenue' ? 'text-emerald-400' : 'text-blue-400') : ''}`}>
                                    {(d.projected / 1000000).toFixed(2)}M
                                  </p>
                                  <span className="text-[8px] text-slate-500 font-medium">متوقع</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Display Custom Executed Action Logs and Statement grids */}
                      {message.executedAction && message.executedAction.success && (
                        <div className="mt-4 border-t border-slate-150 pt-4 text-right" dir="rtl">
                          <div className="bg-gradient-to-br from-indigo-50/50 to-purple-50/30 border border-indigo-100 rounded-3xl p-5 shadow-sm">
                            <div className="flex items-center gap-2 mb-3">
                              <CheckCircle2 className="w-5 h-5 text-indigo-750 shrink-0" />
                              <span className="font-extrabold text-indigo-950 text-sm">تم تنفيذ العملية ببرمجة دقيقة ⚡</span>
                            </div>

                            {message.executedAction.customerId && (
                              <div className="space-y-1.5 text-xs text-slate-705 text-right">
                                <p><strong className="text-slate-900">العميل الجديد بالشركة:</strong> {message.executedAction.record?.customer_name || message.executedAction.data?.customer_name}</p>
                                <p><strong className="text-slate-900">رمز المعرِّف الاستدلالي (ID):</strong> <span className="font-mono bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded font-extrabold">{message.executedAction.customerId}</span></p>
                                <p><strong className="text-slate-900">الفرع / المدينة:</strong> {message.executedAction.record?.city}</p>
                                <p><strong className="text-slate-900 font-bold">سقف الائتمان المقر:</strong> {Number(message.executedAction.record?.credit_limit || 0).toLocaleString()} YER</p>
                              </div>
                            )}

                            {message.executedAction.supplierId && (
                              <div className="space-y-1.5 text-xs text-slate-705 text-right">
                                <p><strong className="text-slate-900 font-bold">المورد المعتمد بالتجارة:</strong> {message.executedAction.record?.vendor_name}</p>
                                <p><strong className="text-slate-900">رمز المعرِّف الاستدلالي (ID):</strong> <span className="font-mono bg-purple-100 text-purple-800 px-2 py-0.5 rounded font-extrabold">{message.executedAction.supplierId}</span></p>
                                <p><strong className="text-slate-900">الفرع الرئيسي:</strong> {message.executedAction.record?.contact}</p>
                                <p><strong className="text-slate-900">الرصيد المفتوح:</strong> {Number(message.executedAction.record?.balance || 0).toLocaleString()} YER</p>
                              </div>
                            )}

                            {message.executedAction.invoiceNo && (
                              <div className="space-y-1.5 text-xs text-slate-705 text-right">
                                <p><strong className="text-slate-900 font-bold">رقم الفاتورة الصادرة (Draft):</strong> <span className="font-mono bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-extrabold">{message.executedAction.invoiceNo}</span></p>
                                <p><strong className="text-slate-900">العميل المفوتر:</strong> {message.executedAction.data?.customer_id}</p>
                                <p><strong className="text-slate-900">مستودع التخزين:</strong> {message.executedAction.data?.warehouse_code}</p>
                                <p><strong className="text-slate-900">الإجمالي قبل الرسوم:</strong> {Number(message.executedAction.data?.sub_total || 0).toLocaleString()} YER</p>
                                <p><strong className="text-slate-900">ضريبة القيمة المضافة (15%):</strong> {Number(message.executedAction.data?.tax_amount || 0).toLocaleString()} YER</p>
                                <p><strong className="text-indigo-950 font-extrabold">صافي الفاتورة الكلي (Grand Total):</strong> {Number(message.executedAction.data?.grand_total || 0).toLocaleString()} YER</p>
                              </div>
                            )}

                            {/* Statements Grid output from Tools */}
                            {message.executedAction.categories && (
                              <div className="mt-2 space-y-3">
                                <div className="border-b border-indigo-100 pb-2 flex items-center justify-between text-xs font-bold text-indigo-950">
                                  <span>{message.executedAction.statementType === 'ProfitAndLoss' ? 'بيان الأرباح والخسائر للشركة (P&L)' : 'الميزانية العمومية الموحدة (Balance Sheet)'}</span>
                                  <span>{message.executedAction.period}</span>
                                </div>
                                <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
                                  {message.executedAction.categories.map((cat: any, cIdx: number) => (
                                    <div key={cIdx} className="bg-white/80 p-2.5 rounded-xl border border-indigo-50">
                                      <p className="text-[10px] font-bold text-slate-400 mb-1">{cat.groupName}</p>
                                      <div className="space-y-1 text-right">
                                        {cat.items?.map((it: any, itIdx: number) => (
                                          <div key={itIdx} className="flex justify-between text-slate-650 text-[11px]">
                                            <span className="truncate">{it.name} ({it.code})</span>
                                            <span>{Number(it.balance || 0).toLocaleString()} YER</span>
                                          </div>
                                        ))}
                                      </div>
                                      <div className="mt-1.5 pt-1.5 border-t border-slate-100 flex justify-between text-xs font-bold text-indigo-900">
                                        <span>إجمالي الفئة</span>
                                        <span>{Number(cat.subTotal || 0).toLocaleString()} YER</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                
                                {message.executedAction.statementType === 'ProfitAndLoss' ? (
                                  <div className="p-3 bg-indigo-950 rounded-2xl text-white flex justify-between items-center text-xs font-bold">
                                    <span>صافي الأرباح التشغيلية</span>
                                    <span className="text-emerald-400 font-mono">{Number(message.executedAction.netProfit || 0).toLocaleString()} YER</span>
                                  </div>
                                ) : (
                                  <div className="space-y-1 bg-indigo-950 p-2.5 rounded-2xl text-white text-xs font-mono text-right">
                                    <div className="flex justify-between">
                                      <span>إجمالي الأصول المقابلة:</span>
                                      <span>{Number(message.executedAction.totalAssets || 0).toLocaleString()} YER</span>
                                    </div>
                                    <div className="flex justify-between">
                                      <span>الالتزامات + رأس المال:</span>
                                      <span>{Number((message.executedAction.totalLiabilities || 0) + (message.executedAction.totalEquity || 0)).toLocaleString()} YER</span>
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* INTERACTIVE ACTION MESSAGES TRIGGER FOR SAVING AS DRAFT */}
                    {message.journal && message.saveState && message.saveState !== 'none' && (
                      <div className="mt-2 bg-gradient-to-r from-indigo-50 to-violet-50 border border-indigo-150 rounded-2xl p-4 text-right">
                        
                        {message.saveState === 'confirming' && (
                          <div className="flex flex-col gap-3">
                            <p className="text-xs font-bold text-slate-800 flex items-center justify-start gap-1.5">
                              <HelpCircle className="w-4 h-4 text-indigo-600" />
                              <span>هل تود ترحيل ومعالجة هذه الفاتورة وإدراجها كمسودة في حساباتك الرسمية؟</span>
                            </p>
                            <div className="flex items-center gap-2.5 self-start">
                              <button 
                                onClick={() => commitJournalToDatabase(message.id, message.journal, message.proposedNewAccount)}
                                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors cursor-pointer"
                              >
                                {message.proposedNewAccount ? 'Confirm Creation & Save Draft Journal' : 'تأكيد وحفظ كمسودة (Confirm Draft)'}
                              </button>
                              <button
                                onClick={() => cancelJournalTransaction(message.id)}
                                className="px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 text-xs font-bold rounded-lg transition-colors cursor-pointer"
                              >
                                إلغاء
                              </button>
                            </div>
                          </div>
                        )}

                        {message.saveState === 'saving' && (
                          <div className="flex items-center gap-2.5 py-1 text-slate-600 text-xs font-bold">
                            <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                            <span>جاري معالجة القيود وضخ المعاملة إلى قاعدة البيانات...</span>
                          </div>
                        )}

                        {message.saveState === 'saved' && (
                          <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl p-3.5 flex items-start gap-2.5">
                            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-extrabold leading-tight">Journal Entry saved successfully as a Draft.</p>
                              <p className="text-xs opacity-90 mt-1">تمت معالجة قيد اليومية بوضعية مسودة مع الحسابات.</p>
                              <button 
                                onClick={() => navigate('/journals')}
                                className="text-indigo-600 hover:text-indigo-800 font-extrabold text-xs mt-2 flex items-center gap-1 cursor-pointer"
                              >
                                [انقر هنا لمراجعة المسودة وتعديلها • Click here to review draft]
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        )}

                        {message.saveState === 'cancelled' && (
                          <p className="text-xs text-slate-500 font-bold italic py-1">⚠️ تم إلغاء ترحيل المعاملة وبقيت كقراءة نصية فقط.</p>
                        )}
                      </div>
                    )}

                    {/* Operational System Settings dynamic confirmation block */}
                    {message.settingsUpdate && (
                      <div className="mt-2 bg-emerald-50 border border-emerald-250 rounded-2xl p-4 text-right">
                        <div className="flex items-start gap-2.5">
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                          <div className="flex-1 min-w-0 text-slate-800">
                            <p className="text-xs font-extrabold text-emerald-950">تم تطبيق الإعدادات وتأكيد تفعيلها تلقائياً ⚙️</p>
                            <p className="text-xs text-slate-500 mt-1">System settings updated successfully.</p>
                            <pre className="text-[10px] uppercase font-mono bg-white/60 p-2.5 rounded-lg border border-slate-100 mt-2 text-left whitespace-pre-wrap leading-normal">
                              {JSON.stringify(message.settingsUpdate, null, 2)}
                            </pre>
                            <button 
                              onClick={() => window.location.reload()}
                              className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs px-3.5 py-1.5 mt-3 rounded-lg flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-all text-center self-start"
                            >
                              [Click here to refresh configuration layout]
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {/* Simulated Live OCR progress status block */}
            {ocrStage !== 'idle' && (
              <div className="bg-indigo-900 text-indigo-100 border border-indigo-950 p-4 rounded-2xl flex gap-3.5 max-w-[85%] shadow-md animate-pulse">
                <Loader2 className="w-5 h-5 animate-spin text-indigo-400 shrink-0 mt-1" />
                <div className="flex-1 min-w-0 text-right">
                  <p className="text-xs font-bold">سير عمل معالجة الملف الذكي (AI OCR Pipeline)...</p>
                  <div className="text-[11px] opacity-80 space-y-1 mt-2.5 font-mono">
                    {ocrLogs.map((log, idx) => (
                      <p key={idx} className="flex items-center justify-start gap-1">
                        <span>•</span>
                        <span>{log}</span>
                      </p>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Loading general reply message typing */}
            {isLoading && ocrStage === 'idle' && (
              <div className="flex gap-4">
                <div className="w-9 h-9 bg-indigo-100 border border-indigo-200 rounded-lg flex items-center justify-center text-indigo-600 font-bold shrink-0">
                  <Sparkles className="w-5 h-5 animate-pulse" />
                </div>
                <div className="bg-white border border-slate-100 p-4 rounded-2xl text-slate-500 text-xs flex items-center gap-2 font-bold select-none">
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                  <span>{i18n.language === 'ar' ? 'المساعد المحاسبي يقوم بالتفكير وصياغة القيود...' : 'AI Accountant is thinking and preparing standard double entry...'}</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Interactive Chat Form Input & Mic controls */}
          <form 
            onSubmit={handleSendMessage}
            className="p-4 bg-white border-t border-slate-200 flex flex-col gap-3 shrink-0"
          >
            {/* Display selected file name if uploaded */}
            {activeFile && (
              <div className="bg-indigo-50 border border-indigo-150 rounded-xl p-2.5 flex items-center justify-between text-xs text-indigo-950">
                <div className="flex items-center gap-2 truncate">
                  <FileText className="w-4 h-4 text-indigo-600" />
                  <span className="font-semibold truncate">{activeFile.name} ({activeFile.size})</span>
                </div>
                <button 
                  type="button" 
                  onClick={clearActiveFile}
                  className="p-1 text-indigo-500 hover:text-indigo-800 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            <div className="flex items-center gap-2">
              <div className="flex-1 min-w-0 relative flex items-center bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 focus-within:ring-2 focus-within:ring-indigo-500 focus-within:border-indigo-500 transition-all">
                <textarea 
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={i18n.language === 'ar' ? 'اسأل سؤالاً محاسبياً، أو اكتب بياناً للقيود، أو حلل مرفقاً...' : 'Ask an accounting question, write a journal narration, or attach a document...'}
                  className={`bg-transparent border-none focus:ring-0 text-sm w-full outline-none resize-none h-10 pr-1 pl-12 text-slate-800 leading-relaxed ${i18n.language === 'ar' ? 'text-right' : 'text-left'}`}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage(e);
                    }
                  }}
                />

                {/* Left Absolute attachments trigger button */}
                <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 z-10">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all cursor-pointer"
                    title={i18n.language === 'ar' ? 'مرفق (PDF, Images, XLSX)' : 'Attachment (PDF, Images, XLSX)'}
                  >
                    <Paperclip className="w-5 h-5" />
                  </button>
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    accept=".pdf,.png,.jpg,.jpeg,.xlsx,.xls"
                    className="hidden"
                  />
                  
                  <button
                    type="button"
                    onClick={toggleRecording}
                    className={`p-2 rounded-lg transition-all cursor-pointer ${
                      isRecording 
                        ? 'bg-rose-100 text-rose-600 animate-pulse' 
                        : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100'
                    }`}
                    title={i18n.language === 'ar' ? 'ميكروفون صوتي' : 'Voice Dictation'}
                  >
                    {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading || (!inputText.trim() && !activeFile)}
                className="h-11 w-11 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 text-white rounded-xl flex items-center justify-center shadow transition-all shrink-0 cursor-pointer"
              >
                <Send className="w-5 h-5 transform rotate-180" />
              </button>
            </div>
          </form>
        </div>

        {/* Right Module: OCR Parser Workspace sidebar */}
        <div className="w-[380px] shrink-0 flex flex-col gap-5 overflow-y-auto">
          
          {/* Box 1: Dropzone for Document Upload */}
          <div 
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            className={`bg-white border-2 border-dashed rounded-2xl p-6 text-center transition-all shadow-sm ${
              dragActive 
                ? 'border-indigo-500 bg-indigo-50/50 scale-[1.01]' 
                : 'border-slate-300 hover:border-indigo-400 hover:bg-slate-50/50'
            }`}
          >
            <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 mx-auto mb-4">
              <FileUp className="w-6 h-6" />
            </div>

            <p className="text-sm font-bold text-slate-800 mb-1">
              {i18n.language === 'ar' ? 'صندوق معالجة المستندات الفوري' : 'Instant Document Processing Dropzone'}
            </p>
            <p className="text-xs text-slate-500 leading-normal px-2 mb-4">
              {i18n.language === 'ar' 
                ? 'اسحب الفاتورة أو تذكرة تسوية الكهرباء أو كشف البنك وأفلتها هنا، وسنقوم تلقائياً بتحليل قيدها'
                : 'Drag and drop any invoice, utility bill receipt, or bank statement here, and we will automatically map its logical entries.'}
            </p>

            <button 
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold rounded-xl border border-indigo-200 transition-colors cursor-pointer"
            >
              {i18n.language === 'ar' ? 'اختر ملف من جهازك' : 'Choose file from your device'}
            </button>
            <p className="text-[10px] text-slate-400 mt-2.5 font-mono">PDF • PNG • JPG • XLSX</p>
          </div>

          {/* Box 2: System COA Accounting mapping info */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-slate-500" />
              <span>{i18n.language === 'ar' ? 'مطابقة الحسابات بالذكاء الاصطناعي' : 'AI Account Mapping Engine'}</span>
            </h3>

            <p className="text-xs text-slate-600 leading-normal mb-4">
              {i18n.language === 'ar'
                ? 'مساعدك يتعرف على الحساب الأمثل لتسجيل الفواتير تلقائياً استناداً إلى الكلمات المفتاحية في المستند:'
                : 'Your virtual assistant identifies the optimal ledger account by scanning keywords in your files:'}
            </p>

            <div className="space-y-2.5 text-xs">
              <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl">
                <p className={`font-extrabold text-slate-800 ${i18n.language === 'ar' ? 'text-right' : 'text-left'}`}>
                  {i18n.language === 'ar' ? 'فاتورة كهرباء / إنترنت' : 'Electricity & Communications Invoices'}
                </p>
                <p className={`text-slate-500 text-[11px] mt-1 leading-normal ${i18n.language === 'ar' ? 'text-right' : 'text-left'}`}>
                  {i18n.language === 'ar'
                    ? 'يفحص النظام COA ويطابق لـ: "Yemen Mobile Corporate Internet Line" أو حساب المصروف المخصص.'
                    : 'Scans the ledger template and maps to: "Yemen Mobile Corporate Internet Line" or respective utilities expenses.'}
                </p>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl">
                <p className={`font-extrabold text-slate-800 ${i18n.language === 'ar' ? 'text-right' : 'text-left'}`}>
                  {i18n.language === 'ar' ? 'متحصلات المبيعات النقدية' : 'Cash Sales Registry'}
                </p>
                <p className={`text-slate-500 text-[11px] mt-1 leading-normal ${i18n.language === 'ar' ? 'text-right' : 'text-left'}`}>
                  {i18n.language === 'ar'
                    ? 'يقوم بحجز مبالغ القبض بالصناديق النشطة مثل: "Al-Kuraimi Cash YER" أو "Cash USD Vault".'
                    : 'Books cash receipt balances straight into active vault assets like "Al-Kuraimi Cash YER" or "Cash USD Vault".'}
                </p>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl">
                <p className={`font-extrabold text-slate-800 ${i18n.language === 'ar' ? 'text-right' : 'text-left'}`}>
                  {i18n.language === 'ar' ? 'مستند مشتريات من المورد' : 'Supplier Purchase Documents'}
                </p>
                <p className={`text-slate-500 text-[11px] mt-1 leading-normal ${i18n.language === 'ar' ? 'text-right' : 'text-left'}`}>
                  {i18n.language === 'ar'
                    ? 'يتم مطابقة الالتزام بحساب المورد وتكلفة المبيعات: "Cost of Goods Sold" لإبقاء التقارير متوافقة.'
                    : 'Syndicates liabilities directly between accounts payable and standard "Cost of Goods Sold" (COGS).'}
                </p>
              </div>
            </div>
          </div>

          {/* Box 3: Historical Draft journal entries Created recently by AI */}
          {recentSavedDrafts.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3.5 flex items-center gap-1.5">
                <FileCheck2 className="w-4 h-4 text-emerald-600" />
                <span>{i18n.language === 'ar' ? 'المسودات المرحّلة حديثاً' : 'Recently Saved AI Drafts'}</span>
              </h3>

              <div className="space-y-2">
                {recentSavedDrafts.map((draft) => (
                  <div 
                    key={draft.id}
                    className={`p-3 bg-slate-50 hover:bg-slate-100 border border-slate-100 rounded-xl transition-colors flex flex-col gap-1 relative group ${i18n.language === 'ar' ? 'text-right' : 'text-left'}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-mono bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md font-bold">{draft.reference}</span>
                      <span className="text-[10px] text-slate-400">
                        {i18n.language === 'ar' ? 'مسودة معتمدة' : 'Approved Draft Record'}
                      </span>
                    </div>
                    <p className="text-xs font-bold text-slate-800 truncate mt-1">{draft.desc}</p>
                    <p className="text-[11px] font-extrabold text-indigo-600 mt-0.5">{draft.total.toLocaleString()} YER</p>
                    
                    <button
                      onClick={() => navigate('/journals')}
                      className={`absolute bottom-2.5 opacity-0 group-hover:opacity-100 text-[10px] font-bold text-indigo-600 hover:text-indigo-800 transition-opacity cursor-pointer ${i18n.language === 'ar' ? 'left-2.5' : 'right-2.5'}`}
                    >
                      {i18n.language === 'ar' ? 'مراجعة ➔' : 'Review ➔'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
