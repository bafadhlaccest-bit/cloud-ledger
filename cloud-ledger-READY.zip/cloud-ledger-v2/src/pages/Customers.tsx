import React from 'react';
import { ColumnDef } from '@tanstack/react-table';
import { DataTable } from '../components/DataTable';
import { Customer } from '../types';
import { formatCurrency, cn, getLocalizedName, getLocalizedLabel } from '../lib/utils';
import { useRBAC } from '../hooks/useRBAC';
import { useTranslation } from 'react-i18next';
import { Plus, Search, Mail, Phone, Loader2, Edit2, Trash2, MapPin, Globe, DollarSign, Download, UploadCloud } from 'lucide-react';
import Modal from '../components/Modal';
import ImportModal from '../components/ImportModal';
import { exportToExcel, exportToPDF } from '../utils/exportImport';
import FileAttachments from '../components/FileAttachments';
import { saveDraftAttachments } from '../lib/attachmentStorage';
import { Paperclip as PaperclipIcon } from 'lucide-react';

import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  serverTimestamp,
  getDocs,
  setDoc
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';
import { countries, states, currencies as availableCurrencies } from '../lib/countryStateData';
import { db, collection, addDoc, getDocs, updateDoc, deleteDoc, onSnapshot, query, where, serverTimestamp, doc } from '../firebase';

interface GovernorateOrState {
  id: string;
  name: string;
  arabicName?: string;
}

export const GLOBAL_GEOGRAPHY: Record<string, { name: string; iso2: string; states: GovernorateOrState[] }> = {
  "YE": {
    name: "Yemen (اليمن)",
    iso2: "YE",
    states: [
      { id: "YE-AD", name: "Aden (عدن)", arabicName: "عدن" },
      { id: "YE-SA", name: "Sana'a (صنعاء)", arabicName: "صنعاء" },
      { id: "YE-TA", name: "Taiz (تعز)", arabicName: "تعز" },
      { id: "YE-HD", name: "Hadhramaut (حضرموت)", arabicName: "حضرموت" },
      { id: "YE-IB", name: "Ibb (إب)", arabicName: "إب" },
      { id: "YE-HJ", name: "Hajjah (حجة)", arabicName: "حجة" },
      { id: "YE-DA", name: "Dhamar (ذمار)", arabicName: "ذمار" },
      { id: "YE-AM", name: "Amran (عمران)", arabicName: "عمران" },
      { id: "YE-SH", name: "Shabwah (شبوة)", arabicName: "شبوة" },
      { id: "YE-MR", name: "Al Mahrah (المهرة)", arabicName: "المهرة" },
      { id: "YE-BA", name: "Al Bayda (البيضاء)", arabicName: "البيضاء" },
      { id: "YE-JA", name: "Al Jawf (الجوف)", arabicName: "الجوف" },
      { id: "YE-MA", name: "Marib (مأرب)", arabicName: "مأرب" },
      { id: "YE-AB", name: "Abyan (أبين)", arabicName: "أبين" },
      { id: "YE-LA", name: "Lahij (لحج)", arabicName: "لحج" },
      { id: "YE-RA", name: "Raymah (ريمة)", arabicName: "ريمة" },
      { id: "YE-SN", name: "Arhab/Sana'a Suburbs (ضواحي صنعاء)", arabicName: "ضواحي صنعاء" },
      { id: "YE-SU", name: "Socotra (سقطرى)", arabicName: "سقطرى" }
    ]
  },
  "SA": {
    name: "Saudi Arabia (المملكة العربية السعودية)",
    iso2: "SA",
    states: [
      { id: "SA-RI", name: "Riyadh (الرياض)", arabicName: "الرياض" },
      { id: "SA-ME", name: "Makkah (مكة المكرمة)", arabicName: "مكة المكرمة" },
      { id: "SA-MD", name: "Madinah (المدينة المنورة)", arabicName: "المدينة المنورة" },
      { id: "SA-EP", name: "Eastern Province (المنطقة الشرقية)", arabicName: "المنطقة الشرقية" },
      { id: "SA-AS", name: "Asir (عسير)", arabicName: "عسير" },
      { id: "SA-QA", name: "Al-Qassim (القصيم)", arabicName: "القصيم" },
      { id: "SA-HA", name: "Hail (حائل)", arabicName: "حائل" },
      { id: "SA-TB", name: "Tabuk (تبوك)", arabicName: "تبوك" },
      { id: "SA-BA", name: "Al-Bahah (الباحة)", arabicName: "الباحة" },
      { id: "SA-JI", name: "Jazan (جازان)", arabicName: "جازان" },
      { id: "SA-NA", name: "Najran (نجران)", arabicName: "نجران" },
      { id: "SA-SH", name: "Northern Borders (الحدود الشمالية)", arabicName: "الحدود الشمالية" },
      { id: "SA-JF", name: "Al-Jawf (الجوف)", arabicName: "الجوف" }
    ]
  },
  "EG": {
    name: "Egypt (مصر)",
    iso2: "EG",
    states: [
      { id: "EG-C", name: "Cairo (القاهرة)", arabicName: "القاهرة" },
      { id: "EG-G", name: "Giza (الجيزة)", arabicName: "الجيزة" },
      { id: "EG-ALX", name: "Alexandria (الإسكندرية)", arabicName: "الإسكندرية" },
      { id: "EG-DK", name: "Dakahlia (الدقهلية)", arabicName: "الدقهلية" },
      { id: "EG-SHR", name: "Sharqia (الشرقية)", arabicName: "الشرقية" },
      { id: "EG-GHR", name: "Gharbia (الغربية)", arabicName: "الغربية" },
      { id: "EG-KB", name: "Qalyubia (القليوبية)", arabicName: "القليوبية" },
      { id: "EG-BH", name: "Beheira (البحيرة)", arabicName: "البحيرة" },
      { id: "EG-FYM", name: "Fayoum (الفيوم)", arabicName: "الفيوم" },
      { id: "EG-MN", name: "Minya (المنيا)", arabicName: "المنيا" },
      { id: "EG-ASY", name: "Asyut (أسيوط)", arabicName: "أسيوط" },
      { id: "EG-SO", name: "Sohag (سوهاج)", arabicName: "سوهاج" },
      { id: "EG-KN", name: "Qena (قنا)", arabicName: "قنا" },
      { id: "EG-LX", name: "Luxor (الأقصر)", arabicName: "الأقصر" },
      { id: "EG-ASN", name: "Aswan (أسوان)", arabicName: "أسوان" }
    ]
  },
  "AE": {
    name: "United Arab Emirates (الإمارات العربية المتحدة)",
    iso2: "AE",
    states: [
      { id: "AE-AZ", name: "Abu Dhabi (أبو ظبي)", arabicName: "أبو ظبي" },
      { id: "AE-DU", name: "Dubai (دبي)", arabicName: "دبي" },
      { id: "AE-SH", name: "Sharjah (الشارقة)", arabicName: "الشارقة" },
      { id: "AE-AJ", name: "Ajman (عجمان)", arabicName: "عجمان" },
      { id: "AE-UM", name: "Umm Al Quwain (أم القيوين)", arabicName: "أم القيوين" },
      { id: "AE-RK", name: "Ras Al Khaimah (رأس الخيمة)", arabicName: "رأس الخيمة" },
      { id: "AE-FU", name: "Fujairah (الفجيرة)", arabicName: "الفجيرة" }
    ]
  },
  "US": {
    name: "United States (الولايات المتحدة)",
    iso2: "US",
    states: [
      { id: "US-CA", name: "California" },
      { id: "US-NY", name: "New York" },
      { id: "US-TX", name: "Texas" },
      { id: "US-FL", name: "Florida" },
      { id: "US-IL", name: "Illinois" },
      { id: "US-PA", name: "Pennsylvania" },
      { id: "US-OH", name: "Ohio" },
      { id: "US-GA", name: "Georgia" },
      { id: "US-MI", name: "Michigan" },
      { id: "US-NC", name: "North Carolina" }
    ]
  },
  "GB": {
    name: "United Kingdom (المملكة المتحدة)",
    iso2: "GB",
    states: [
      { id: "GB-ENG", name: "England" },
      { id: "GB-SCT", name: "Scotland" },
      { id: "GB-WLS", name: "Wales" },
      { id: "GB-NIR", name: "Northern Ireland" }
    ]
  }
};

export const getGovernoratesForCountry = (countryId: string, apiStatesList: any[], apiCountriesList: any[]) => {
  const countryObj = apiCountriesList.find(c => 
    String(c.id) === String(countryId) || 
    String(c.iso2) === String(countryId) || 
    String(c.name) === String(countryId)
  );
  const iso2 = countryObj ? String(countryObj.iso2).toUpperCase() : '';
  // Fix: compare as strings (CSV values are strings, countryId may be number or string)
  let list = [...apiStatesList.filter(s => 
    String(s.countryId) === String(countryId) || 
    String(s.country_id) === String(countryId) ||
    (iso2 && String(s.countryCode).toUpperCase() === iso2) ||
    (iso2 && String(s.country_code).toUpperCase() === iso2)
  )];
  if (iso2 && GLOBAL_GEOGRAPHY[iso2]) {
    const geoStates = GLOBAL_GEOGRAPHY[iso2].states.map(s => ({
      id: s.id,
      name: s.name,
      countryId: countryId,
      countryCode: iso2,
      countryName: countryObj ? countryObj.name : ''
    }));
    const seenNames = new Set(list.map(s => s.name.toLowerCase()));
    geoStates.forEach(gs => {
      if (!seenNames.has(gs.name.toLowerCase())) {
        list.push(gs);
      }
    });
  }
  return list.sort((a, b) => a.name.localeCompare(b.name));
};

export default function Customers() {
  const { t } = useTranslation();
  const { canPerform, validateRowSecurity } = useRBAC();
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = React.useState(false);
  const [isExportDropdownOpen, setIsExportDropdownOpen] = React.useState(false);
  const [customers, setCustomers] = React.useState<Customer[]>([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [isSaving, setIsSaving] = React.useState(false);
  const [editingCustomer, setEditingCustomer] = React.useState<Customer | null>(null);
  const [searchTerm, setSearchTerm] = React.useState('');
  
  // Country & State selections in form
  const [selectedCountry, setSelectedCountry] = React.useState<string>('');
  const [selectedGovernorate, setSelectedGovernorate] = React.useState<string>('');
  const [selectedCurrencies, setSelectedCurrencies] = React.useState<string[]>([]);
  const [currencySearch, setCurrencySearch] = React.useState('');
  const [activeTab, setActiveTab] = React.useState<'profile' | 'documents'>('profile');
  const [currentEntityId, setCurrentEntityId] = React.useState<string>('');
  const [deleteError, setDeleteError] = React.useState<string | null>(null);


  // Master data — use local CSV files directly (fast, no network needed)
  const [apiCountries] = React.useState<any[]>(() => 
    [...countries].sort((a, b) => a.name.localeCompare(b.name))
  );
  const [apiStates] = React.useState<any[]>(() => 
    [...states].sort((a, b) => a.name.localeCompare(b.name))
  );
  const [apiCurrencies] = React.useState<any[]>(() => availableCurrencies);

  const activeCountries = apiCountries;
  const activeStates = apiStates;
  const activeCurrencies = apiCurrencies;

  const { companyId } = useRBAC();

  React.useEffect(() => {
    const path = 'customers';
    const q = query(
      collection(db, path),
      where('companyId', '==', companyId)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Customer[];
      setCustomers(data);
      setIsLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });

    return () => unsubscribe();
  }, [companyId]);

  const handleOpenNew = () => {
    setEditingCustomer(null);
    setSelectedCountry('');
    setSelectedGovernorate('');
    setSelectedCurrencies([]);
    setCurrencySearch('');
    setActiveTab('profile');
    const tempId = 'temp_cust_' + Math.random().toString(36).substring(2, 11);
    setCurrentEntityId(tempId);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (customer: Customer) => {
    setEditingCustomer(customer);
    setCurrentEntityId(customer.id);
    setActiveTab('profile');
    
    let countryId = customer.countryId || '';
    if (!countryId && customer.country) {
      const match = activeCountries.find(c => c.name === customer.country);
      if (match) countryId = match.id;
    }
    
    let govId = customer.governorateId || '';
    if (!govId && customer.governorate) {
      const match = activeStates.find(s => s.name === customer.governorate && String(s.countryId) === String(countryId));
      if (match) govId = match.id;
    }

    setSelectedCountry(String(countryId));
    setSelectedGovernorate(String(govId));
    setSelectedCurrencies(customer.currencies || []);
    setCurrencySearch('');
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSaving(true);
    const formData = new FormData(e.currentTarget);
    
    const name = formData.get('name') as string;
    const email = (formData.get('email') as string) || '';
    const phone = (formData.get('phone') as string) || '';
    const taxNumber = (formData.get('taxNumber') as string) || '';
    const streetAddress = (formData.get('streetAddress') as string) || '';
    const city = (formData.get('city') as string) || '';

    const countryObj = activeCountries.find(c => String(c.id) === String(selectedCountry));
    const countryName = countryObj ? countryObj.name : '';
    const stateObj = activeStates.find(s => String(s.id) === String(selectedGovernorate));
    const stateName = stateObj ? stateObj.name : '';

    const data = {
      name,
      email,
      phone,
      taxNumber,
      balance: editingCustomer ? editingCustomer.balance : 0,
      status: 'active',
      is_active: true,
      companyId,
      country: countryName,
      governorate: stateName,
      countryId: selectedCountry,
      governorateId: selectedGovernorate,
      currencies: selectedCurrencies,
      streetAddress: streetAddress || '',
      city: city || '',
      updatedAt: serverTimestamp(),
    };

    try {
      let customerId = '';
      if (editingCustomer) {
        customerId = editingCustomer.id;
        await updateDoc(doc(db, 'customers', customerId), data);
      } else {
        const docRef = await addDoc(collection(db, 'customers'), {
          ...data,
          createdAt: serverTimestamp(),
        });
        customerId = docRef.id;
        await saveDraftAttachments(currentEntityId, customerId);
      }

      // Synchronize join table / sub-resource mapping: customerCurrencies
      // 1. Delete previous customerCurrencies mapping rows
      const q = query(
        collection(db, 'customerCurrencies'),
        where('customerId', '==', customerId)
      );
      const querySnapshot = await getDocs(q);
      for (const d of querySnapshot.docs) {
        await deleteDoc(doc(db, 'customerCurrencies', d.id));
      }

      // 2. Insert new user allowed currencies mappings
      for (const currencyCode of selectedCurrencies) {
        const mappingId = `${customerId}_${currencyCode}`;
        await setDoc(doc(db, 'customerCurrencies', mappingId), {
          customerId,
          currencyCode,
          companyId,
          createdAt: serverTimestamp()
        });
      }

      setIsModalOpen(false);
      setEditingCustomer(null);
    } catch (error) {
      handleFirestoreError(error, editingCustomer ? OperationType.UPDATE : OperationType.CREATE, 'customers');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeleteError(null);

    // 1. Verify user role permission
    if (!canPerform('delete')) {
      alert("🚨 حظر أمني: الحساب الحالي لا يملك صلاحية حذف السجلات في النظام المالي.");
      return;
    }

    const cust = customers.find(c => c.id === id);
    if (!cust) return;

    // 2. Row Level Security check (RLS) under active company
    const secureRow = (cust as any).companyId ? cust : { ...cust, companyId };
    if (!validateRowSecurity(secureRow)) {
      alert("🚨 خطأ في الصلاحيات: السجل الذي تحاول حذفه ينتمي لمنشأة محاسبية أخرى!");
      return;
    }

    // 3. Confirm with User
    if (!window.confirm("هل أنت متأكد من حذف هذا السجل نهائياً؟ (لا يمكن التراجع عن هذه العملية)")) {
      return;
    }

    try {
      // 4. Verify outstanding receivables balance
      const hasPendingBalance = Math.abs(cust.balance || 0) > 0.01;

      // 5. Query for open/pending invoices (anything except Paid or Cancelled)
      const invoicesQuery = query(
        collection(db, 'invoices'),
        where('customerId', '==', id)
      );
      const invoicesSnap = await getDocs(invoicesQuery);
      const hasOpenInvoices = invoicesSnap.docs.some(d => {
        const inv = d.data();
        return inv.status !== 'Paid' && inv.status !== 'Cancelled';
      });

      if (hasPendingBalance || hasOpenInvoices) {
        const conflictMsg = 'Cannot delete customer. Open invoices or pending ledger entries are currently locked under this profile.';
        setDeleteError(conflictMsg);
        alert("🚨 حظر أمني محاسبي: لا يمكن حذف هذا العميل/المورد لارتباطه بفواتير قيود مالية سابقة في النظام!");
        return;
      }

      console.log(`🗑️ جاري حذف السجل ذو المعرف: ${id} من قاعدة البيانات...`);

      // 6. Delete from database
      await deleteDoc(doc(db, 'customers', id));

      // 7. Instant local state update for seamless transition
      setCustomers((prev) => prev.filter((item) => item.id !== id));

      console.log("✅ تم الحذف وتحديث حالة الواجهة بنجاح.");
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `customers/${id}`);
      alert("حدث خطأ غير متوقع أثناء الحذف بالسيرفر، يرجى مراجعة Console المطور.");
    }
  };

  const toggleCurrencySelection = (code: string) => {
    setSelectedCurrencies(prev => 
      prev.includes(code) ? prev.filter(c => c !== code) : [...prev, code]
    );
  };

  // Filter governorates by selected country ID using our high-fidelity dynamic automated dictionary
  const filteredGovernorates = getGovernoratesForCountry(selectedCountry, activeStates, activeCountries);

  const filteredCustomers = customers.filter(c => c.is_active !== false).filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.email || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.taxNumber || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.country || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (c.governorate || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredCurrencies = activeCurrencies.filter(c =>
    c.code.toLowerCase().includes(currencySearch.toLowerCase()) ||
    c.name.toLowerCase().includes(currencySearch.toLowerCase())
  );

  const columns: ColumnDef<Customer>[] = [
    {
      header: getLocalizedLabel('Customer Name'),
      accessorKey: 'name',
      cell: (info) => (
        <div className="flex flex-col">
          <span className="font-bold text-slate-900">{getLocalizedName(info.row.original)}</span>
          {info.row.original.taxNumber && (
            <span className="text-xs text-slate-500 font-mono">Tax: {info.row.original.taxNumber}</span>
          )}
        </div>
      ),
    },
    {
      header: getLocalizedLabel('Contact'),
      accessorKey: 'email',
      cell: (info) => {
        const row = info.row.original;
        if (!row.email && !row.phone) {
          return <span className="text-slate-400 italic font-medium">No contact</span>;
        }
        return (
          <div className="flex flex-col gap-1 text-xs">
            {row.email && (
              <div className="flex items-center gap-1.5 text-slate-600">
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                {row.email}
              </div>
            )}
            {row.phone && (
              <div className="flex items-center gap-1.5 text-slate-600">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                {row.phone}
              </div>
            )}
          </div>
        );
      },
    },
    {
      header: getLocalizedLabel('Location'),
      id: 'location',
      cell: (info) => {
        const row = info.row.original;
        const exists = row.country || row.governorate;
        return (
          <div className="flex flex-col text-xs text-slate-600 gap-0.5">
            {exists ? (
              <>
                <div className="flex items-center gap-1 font-medium text-slate-900">
                  <MapPin className="w-3 h-3 text-rose-500" />
                  {row.governorate || 'n/a'}
                </div>
                <div className="flex items-center gap-1 pl-4 text-slate-500">
                  {row.country || 'n/a'}
                </div>
              </>
            ) : (
              <span className="text-slate-400">Not set</span>
            )}
          </div>
        );
      }
    },
    {
      header: getLocalizedLabel('Currencies'),
      accessorKey: 'currencies',
      cell: (info) => {
        const customerCurrencies = (info.getValue() as string[]) || [];
        return (
          <div className="flex flex-wrap gap-1 max-w-[180px]">
            {customerCurrencies.length > 0 ? (
              customerCurrencies.map(code => {
                const cur = activeCurrencies.find(c => c.code === code);
                return (
                  <span 
                    key={code} 
                    title={cur?.name}
                    className="px-2 py-0.5 rounded bg-indigo-50 border border-indigo-100 text-indigo-700 text-[10px] font-bold uppercase tracking-wider"
                  >
                    {cur?.symbol || ''} {code}
                  </span>
                );
              })
            ) : (
              <span className="text-xs text-slate-400 font-medium italic">Unassigned</span>
            )}
          </div>
        );
      }
    },
    {
      header: getLocalizedLabel('Receivables'),
      accessorKey: 'balance',
      cell: (info) => {
        const balance = info.getValue() as number;
        return (
          <span className={cn(
            "font-extrabold text-sm",
            balance > 0 ? "text-rose-600" : balance < 0 ? "text-emerald-600" : "text-slate-950"
          )}>
            {formatCurrency(balance)}
          </span>
        );
      },
    },
    {
      header: 'Status',
      accessorKey: 'status',
      cell: (info) => (
        <span className={cn(
          "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider",
          info.getValue() === 'active' ? "bg-emerald-100 text-emerald-800" : "bg-slate-100 text-slate-600"
        )}>
          {info.getValue() as string}
        </span>
      ),
    },
    {
      header: 'Actions',
      id: 'actions',
      cell: (info) => (
        <div className="flex items-center gap-2">
          <button 
            onClick={() => handleOpenEdit(info.row.original)}
            className="p-1 px-2 border border-slate-200 rounded text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
          <button 
            onClick={() => handleDelete(info.row.original.id)}
            className="p-1 px-2 border border-slate-200 rounded text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      ),
    }
  ];

  return (
    <div className="space-y-6">
      {deleteError && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl flex items-center justify-between text-sm animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-2 font-medium">
            <span>⚠️ {deleteError}</span>
          </div>
          <button onClick={() => setDeleteError(null)} className="text-rose-500 hover:text-rose-800 font-extrabold cursor-pointer text-lg">×</button>
        </div>
      )}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Customers</h1>
          <p className="text-slate-500 text-sm">Manage client information, multi-currency profiles, real countries/governorates, and receivables.</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 hover:text-indigo-650 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
          >
            <UploadCloud className="w-4 h-4" />
            Import from Excel
          </button>

          <div className="relative">
            <button
              onClick={() => setIsExportDropdownOpen(!isExportDropdownOpen)}
              className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-all text-sm font-semibold text-slate-600 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Export
            </button>
            {isExportDropdownOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setIsExportDropdownOpen(false)} />
                <div className="absolute right-0 mt-1.5 w-48 bg-white border border-slate-200 rounded-xl shadow-lg py-1.5 z-20">
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToExcel(
                        customers,
                        ['name', 'email', 'phone', 'taxNumber', 'streetAddress', 'city', 'balance', 'status'],
                        ['Customer Name', 'Email Address', 'Phone Number', 'Tax Number', 'Street Address', 'City', 'Balance', 'Status'],
                        'System_Customers'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    Export to Excel (.xlsx)
                  </button>
                  <button
                    onClick={() => {
                      setIsExportDropdownOpen(false);
                      exportToPDF(
                        customers,
                        ['name', 'email', 'phone', 'taxNumber', 'streetAddress', 'city', 'balance', 'status'],
                        ['Customer Name', 'Email Address', 'Phone Number', 'Tax Number', 'Street Address', 'City', 'Balance', 'Status'],
                        'Advanced Accounting - Customer Directory',
                        'System_Customers'
                      );
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-bold text-slate-705 hover:bg-slate-50 cursor-pointer"
                  >
                    Export to PDF (.pdf)
                  </button>
                </div>
              </>
            )}
          </div>

          <button 
            onClick={handleOpenNew}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-semibold shadow-sm cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            New Customer
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search by name, email, country, state, or tax ID..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
        </div>
      ) : (
        <DataTable columns={columns} data={filteredCustomers} />
      )}

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => {
          setIsModalOpen(false);
          setEditingCustomer(null);
        }} 
        title={editingCustomer ? "Edit Customer Details" : "Create New Customer"} 
        size="lg"
      >
        <form onSubmit={handleSave} className="space-y-6">
          {/* Tabs Menu */}
          <div className="flex border-b border-slate-200 mb-2">
            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className={cn(
                "px-4 py-2 text-xs font-bold border-b-2 transition-all uppercase tracking-wider",
                activeTab === 'profile' 
                  ? "border-indigo-600 text-indigo-600 font-extrabold" 
                  : "border-transparent text-slate-500 hover:text-slate-800"
              )}
            >
              General Profile
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('documents')}
              className={cn(
                "px-4 py-2 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 uppercase tracking-wider",
                activeTab === 'documents' 
                  ? "border-indigo-600 text-indigo-600 font-extrabold" 
                  : "border-transparent text-slate-500 hover:text-slate-800"
              )}
            >
              <PaperclipIcon className="w-3.5 h-3.5" />
              Documents / Attachments
            </button>
          </div>

          {activeTab === 'profile' ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-h-[60vh] overflow-y-auto p-1">
              {/* Box 1: Display Name & Contacts */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4 hover:border-indigo-300 transition-all">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                  <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">1</div>
                  <h4 className="font-bold text-sm text-slate-950 uppercase tracking-wider flex items-center gap-1.5">
                    Display Name & Profile
                  </h4>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Display Name <span className="text-rose-500">*</span>
                    </label>
                    <input name="name" defaultValue={editingCustomer?.name} required type="text" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="Business or Person Name" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
                    <input name="email" defaultValue={editingCustomer?.email} type="email" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="billing@company.com" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
                    <input name="phone" defaultValue={editingCustomer?.phone} type="tel" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="+1 (555) 000-0000" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Tax Registration ID (VAT/GST)</label>
                    <input name="taxNumber" defaultValue={editingCustomer?.taxNumber} type="text" className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="e.g. GB1234567" />
                  </div>
                </div>
              </div>

              {/* Box 2: Country & Location selection */}

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4 hover:border-indigo-300 transition-all">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">2</div>
                <h4 className="font-bold text-sm text-slate-950 uppercase tracking-wider flex items-center gap-1.5">
                  Country & Location
                </h4>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                    <Globe className="w-3.5 h-3.5 text-slate-400" />
                    Country <span className="text-rose-500">*</span>
                  </label>
                  <select 
                    value={selectedCountry}
                    onChange={(e) => {
                      setSelectedCountry(e.target.value);
                      setSelectedGovernorate(''); // Reset state/governorate on country change
                    }}
                    required
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded bg-white outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="">-- Choose --</option>
                    {activeCountries.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.iso2})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    Governorate
                  </label>
                  <select 
                    value={selectedGovernorate}
                    onChange={(e) => setSelectedGovernorate(e.target.value)}
                    disabled={!selectedCountry}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded bg-white outline-none focus:ring-2 focus:ring-indigo-500 disabled:bg-slate-100 disabled:text-slate-400"
                  >
                    <option value="">-- Choose --</option>
                    {filteredGovernorates.map(gov => (
                      <option key={gov.id} value={gov.id}>
                        {gov.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Street Address</label>
                  <input 
                    type="text"
                    name="streetAddress" 
                    defaultValue={editingCustomer?.streetAddress}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" 
                    placeholder="Street and house number" 
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">City</label>
                  <input 
                    type="text"
                    name="city" 
                    defaultValue={editingCustomer?.city}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" 
                    placeholder="Specific City name" 
                  />
                </div>
              </div>
            </div>

            {/* Box 3: Multi-Currency Access */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4 hover:border-indigo-300 transition-all">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-200">
                <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">3</div>
                <h4 className="font-bold text-sm text-slate-950 uppercase tracking-wider flex items-center gap-1.5">
                  Multi-Currency Access <span className="text-rose-500">*</span>
                </h4>
              </div>
              <div className="space-y-3">
                <label className="block text-xs text-slate-500 leading-relaxed">
                  Select one or more currencies that this customer profile is permitted to transact in:
                </label>
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
                  <input 
                    type="text"
                    placeholder="Search currencies..."
                    value={currencySearch}
                    onChange={(e) => setCurrencySearch(e.target.value)}
                    className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                
                <div className="border border-slate-200 rounded divide-y divide-slate-100 max-h-[140px] overflow-y-auto bg-white">
                  {filteredCurrencies.length > 0 ? (
                    filteredCurrencies.map(currency => {
                      const isChecked = selectedCurrencies.includes(currency.code);
                      return (
                        <label 
                          key={currency.code} 
                          className="flex items-center gap-3 px-3 py-2 hover:bg-slate-50 cursor-pointer text-xs"
                        >
                          <input 
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => toggleCurrencySelection(currency.code)}
                            className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 h-3.5 w-3.5"
                          />
                          <div className="flex-1 flex justify-between font-medium">
                            <span className="text-slate-900 font-bold uppercase tracking-wider">
                              {currency.code} <span className="text-slate-500 text-[10px] font-normal">({currency.symbol})</span>
                            </span>
                            <span className="text-slate-500 font-normal truncate max-w-[120px]" title={currency.name}>
                              {currency.name}
                            </span>
                          </div>
                        </label>
                      );
                    })
                  ) : (
                    <div className="p-3 text-center text-xs text-slate-400 italic">No currencies found</div>
                  )}
                </div>

                {/* Selected currency badges */}
                <div className="flex flex-wrap gap-1.5 pt-1.5">
                  {selectedCurrencies.map(code => (
                    <span 
                      key={code} 
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 text-[10px] font-bold"
                    >
                      {code}
                      <button 
                        type="button" 
                        onClick={() => toggleCurrencySelection(code)}
                        className="text-indigo-400 hover:text-indigo-700 font-bold ml-1 text-xs animate-none"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                  {selectedCurrencies.length === 0 && (
                    <span className="text-xs text-rose-500 italic font-semibold flex items-center gap-1">
                      ⚠️ Please select at least one currency
                    </span>
                  )}
                </div>
              </div>
            </div>
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 min-h-[300px]">
              <h4 className="font-bold text-sm text-slate-800 mb-3 flex items-center gap-1.5 uppercase tracking-wide">
                <PaperclipIcon className="w-4 h-4 text-indigo-600" />
                Uploaded Documents
              </h4>
              <p className="text-xs text-slate-500 mb-4 font-medium">
                Upload and manage invoices, contracts, agreements or notes associated with this profile.
              </p>
              <FileAttachments entityId={currentEntityId} />
            </div>
          )}

          <div className="flex items-center gap-4 pt-4 border-t">
            <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-semibold text-slate-600 text-sm">Cancel</button>
            <button 
              type="submit" 
              disabled={isSaving || selectedCurrencies.length === 0}
              className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-semibold shadow-sm flex items-center justify-center gap-2 text-sm disabled:bg-slate-300 disabled:cursor-not-allowed"
            >
              {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
              {isSaving ? 'Saving...' : (editingCustomer ? 'Update Profile' : 'Create Profile')}
            </button>
          </div>
        </form>
      </Modal>

      <ImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        moduleId="customers"
        existingRecords={customers}
        onImportSuccess={(cnt) => {
          setIsImportModalOpen(false);
        }}
      />
    </div>
  );
}
