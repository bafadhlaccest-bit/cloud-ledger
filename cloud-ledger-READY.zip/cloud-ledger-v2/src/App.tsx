import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Provider } from 'react-redux';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { reduxStore } from './store/index';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import Register from './pages/Register';
import Onboarding from './pages/Onboarding';
import Landing from './pages/Landing';
import ChartOfAccounts from './pages/ChartOfAccounts';
import Customers from './pages/Customers';
import Sales from './pages/Sales';
import Vendors from './pages/Vendors';
import Purchases from './pages/Purchases';
import Items from './pages/Items';
import Banking from './pages/Banking';
import JournalEntries from './pages/JournalEntries';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import AIAccountantWorkspace from './pages/AIAccountantWorkspace';
import FinancialAdvisor from './pages/FinancialAdvisor';
import Quotations from './pages/Quotations';
import PurchaseOrders from './pages/PurchaseOrders';
import Expenses from './pages/Expenses';
import RecurringInvoices from './pages/RecurringInvoices';
import VATReport from './pages/VATReport';
import AuditTrail from './pages/AuditTrail';
import Integrations from './pages/Integrations';
import { ErrorBoundary } from './components/ErrorBoundary';
import { SettingsProvider } from './context/SettingsContext';
import { AccountingProvider } from './context/AccountingContext';
import ScreenGuard from './components/ScreenGuard';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { refetchOnWindowFocus: false, retry: 1 },
  },
});

function InitialLaunchNetworkEnforcer({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

export default function App() {
  return (
    <ErrorBoundary>
      <Provider store={reduxStore}>
        <QueryClientProvider client={queryClient}>
          <AccountingProvider>
            <SettingsProvider>
              <InitialLaunchNetworkEnforcer>
                <BrowserRouter>
                  <Routes>
                    {/* Public */}
                    <Route path="/home" element={<Landing />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/onboarding" element={<Onboarding />} />

                    {/* App */}
                    <Route path="/" element={<Layout />}>
                      <Route index element={<ScreenGuard><Dashboard /></ScreenGuard>} />
                      <Route path="accounts" element={<ScreenGuard><ChartOfAccounts /></ScreenGuard>} />
                      <Route path="customers" element={<ScreenGuard><Customers /></ScreenGuard>} />
                      <Route path="sales" element={<ScreenGuard><Sales /></ScreenGuard>} />
                      <Route path="vendors" element={<ScreenGuard><Vendors /></ScreenGuard>} />
                      <Route path="purchases" element={<ScreenGuard><Purchases /></ScreenGuard>} />
                      <Route path="items" element={<ScreenGuard><Items /></ScreenGuard>} />
                      <Route path="banking" element={<ScreenGuard><Banking /></ScreenGuard>} />
                      <Route path="journals" element={<ScreenGuard><JournalEntries /></ScreenGuard>} />
                      <Route path="reports" element={<ScreenGuard><Reports /></ScreenGuard>} />
                      <Route path="ai-accountant" element={<ScreenGuard><AIAccountantWorkspace /></ScreenGuard>} />
                      <Route path="advisor" element={<ScreenGuard><FinancialAdvisor /></ScreenGuard>} />
                      <Route path="quotations" element={<ScreenGuard><Quotations /></ScreenGuard>} />
                      <Route path="purchase-orders" element={<ScreenGuard><PurchaseOrders /></ScreenGuard>} />
                      <Route path="expenses" element={<ScreenGuard><Expenses /></ScreenGuard>} />
                      <Route path="recurring" element={<ScreenGuard><RecurringInvoices /></ScreenGuard>} />
                      <Route path="vat-report" element={<ScreenGuard><VATReport /></ScreenGuard>} />
                      <Route path="audit-trail" element={<ScreenGuard><AuditTrail /></ScreenGuard>} />
                      <Route path="integrations" element={<ScreenGuard><Integrations /></ScreenGuard>} />
                      <Route path="settings" element={<ScreenGuard><Settings /></ScreenGuard>} />
                    </Route>

                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </BrowserRouter>
              </InitialLaunchNetworkEnforcer>
            </SettingsProvider>
          </AccountingProvider>
        </QueryClientProvider>
      </Provider>
    </ErrorBoundary>
  );
}
