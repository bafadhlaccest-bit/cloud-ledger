import { Account, Item } from '../types';

export const SEEDED_ACCOUNTS: Account[] = [
  // Roots (5 protected roots)
  {
    id: 'root-1000',
    code: '1000',
    name: 'الأصول (Assets)',
    type: 'Asset',
    balance: 0,
    status: 'active',
    parentId: 'root',
    description: 'أصول المنشأة والموارد الاقتصادية والتشغيلية'
  },
  {
    id: 'root-2000',
    code: '2000',
    name: 'الالتزامات الخصوم (Liabilities)',
    type: 'Liability',
    balance: 0,
    status: 'active',
    parentId: 'root',
    description: 'الالتزامات والخصوم المتداولة وغير المتداولة المطالب بها'
  },
  {
    id: 'root-3000',
    code: '3000',
    name: "حقوق الملكية للملاك (Owners' Rights)",
    type: 'Equity',
    balance: 0,
    status: 'active',
    parentId: 'root',
    description: 'حقوق ملكية الملاك والشركاء والاحتياطيات والأرباح'
  },
  {
    id: 'root-4000',
    code: '4000',
    name: 'الإيرادات التشغيلية (Revenues)',
    type: 'Income',
    balance: 0,
    status: 'active',
    parentId: 'root',
    description: 'العائد الإجمالي المحقق من النشاط والتشغيل الرئيسي للمنشأة'
  },
  {
    id: 'root-5000',
    code: '5000',
    name: 'المصاريف التشغيلية (Expenses)',
    type: 'Expense',
    balance: 0,
    status: 'active',
    parentId: 'root',
    description: 'مصاريف النشاط والتشغيل بمختلف أنواعها الإدارية والتشغيلية'
  },

  // Sub-accounts under ASSET (1000)
  {
    id: 'sub-1100',
    code: '1100',
    name: '1100 - الذمم المدينة (العملاء)',
    type: 'Asset',
    balance: 0,
    status: 'active',
    parentId: 'root-1000',
    description: 'العملاء والذمم المدينة التجارية النشطة المتصلة بالفواتير والمبيعات'
  },
  {
    id: 'sub-1200',
    code: '1200',
    name: '1200 - حساب البنك الرئيسي',
    type: 'Asset',
    balance: 0,
    status: 'active',
    parentId: 'root-1000',
    description: 'الحساب الجاري البنكي الرئيسي للتسويات والعمليات المصرفية والمدفوعات'
  },
  {
    id: 'sub-1300',
    code: '1300',
    name: '1300 - الصندوق (النقدية)',
    type: 'Asset',
    balance: 0,
    status: 'active',
    parentId: 'root-1000',
    description: 'النقدية المقبوضة والجاهزة للتسويات بالخزائن والصناديق'
  },
  {
    id: 'sub-1400',
    code: '1400',
    name: '1400 - مخزون البضائع',
    type: 'Asset',
    balance: 0,
    status: 'active',
    parentId: 'root-1000',
    description: 'مخزون السلع المتاحة للبيع وفق تقييم Costing FIFO/WAC'
  },

  // Sub-accounts under LIABILITY (2000)
  {
    id: 'sub-2100',
    code: '2100',
    name: '2100 - الذمم الدائنة (الموردين)',
    type: 'Liability',
    balance: 0,
    status: 'active',
    parentId: 'root-2000',
    description: 'الالتزامات للموردين وشراء البضائع والخدمات التجارية الآجلة'
  },
  {
    id: 'sub-2200',
    code: '2200',
    name: '2200 - ضريبة القيمة المضافة المستحقة',
    type: 'Liability',
    balance: 0,
    status: 'active',
    parentId: 'root-2000',
    description: 'حساب الضرائب المحتسبة للمشتريات والمبيعات المستحقة للجهة الضريبية'
  },

  // Sub-accounts under EQUITY (3000)
  {
    id: 'sub-3100',
    code: '3100',
    name: '3100 - رأس المال',
    type: 'Equity',
    balance: 0,
    status: 'active',
    parentId: 'root-3000',
    description: 'رأس المال المدفوع والمستثمر الرئيسي بالمنشأة'
  },
  {
    id: 'sub-3200',
    code: '3200',
    name: '3200 - الأرباح المبقاة',
    type: 'Equity',
    balance: 0,
    status: 'active',
    parentId: 'root-3000',
    description: 'الأرباح والخسائر المتراكمة والمحققة غير الموزعة حتى نهاية الفترة'
  },

  // Sub-accounts under INCOME (4000)
  {
    id: 'sub-4100',
    code: '4100',
    name: '4100 - إيرادات المبيعات',
    type: 'Income',
    balance: 0,
    status: 'active',
    parentId: 'root-4000',
    description: 'إيرادات مبيعات البضائع والمنتجات والخدمات للعملاء والنشاط'
  },
  {
    id: 'sub-4200',
    code: '4200',
    name: '4200 - مردودات المبيعات',
    type: 'Income',
    balance: 0,
    status: 'active',
    parentId: 'root-4000',
    description: 'مرتجع المبيعات والخصومات المسموح بها والموافق عليها من قبل الإدارة'
  },

  // Sub-accounts under EXPENSE (5000)
  {
    id: 'sub-5100',
    code: '5100',
    name: '5100 - تكلفة البضاعة المباعة (COGS)',
    type: 'Expense',
    balance: 0,
    status: 'active',
    parentId: 'root-5000',
    description: 'تكاليف البضائع المباعة الفعلية والمسلمة للعملاء وقياس الهامش'
  },
  {
    id: 'sub-5200',
    code: '5200',
    name: '5200 - مردودات المشتريات',
    type: 'Expense',
    balance: 0,
    status: 'active',
    parentId: 'root-5000',
    description: 'مرتجع المشتريات والخصومات المكتسبة والمستردّة من الموردين'
  },
  {
    id: 'sub-5300',
    code: '5300',
    name: '5300 - المصاريف الإدارية والعمومية',
    type: 'Expense',
    balance: 0,
    status: 'active',
    parentId: 'root-5000',
    description: 'كافة مصاريف التشغيل والمصاريف الإدارية والعمومية العامة والمباني والأدوات'
  }
];

export const SEEDED_ITEMS: Item[] = [
  {
    id: 'prod-001',
    sku: 'SKU-MX01',
    name: 'مكسب هواء / خلاط تجاري',
    code: 'MX01',
    type: 'Product',
    salesPrice: 450,
    purchasePrice: 280,
    stockOnHand: 15,
    unit: 'Units',
    productType: 'Storable',
    invoicingPolicy: 'Ordered',
    routesBuy: true,
    routesMTO: false,
    traceability: 'None',
    costing_method: 'WAC',
    inventory_account_id: '1400',
    income_account_id: '4100',
    expense_account_id: '5100',
    incomeAccountId: 'sub-4100',
    expenseAccountId: 'sub-5100',
    priceDiffAccountId: 'sub-5300',
    companyId: '__COMPANY_ID__' // replaced at runtime by useRBAC
  },
  {
    id: 'prod-002',
    sku: 'SKU-PG02',
    name: 'قطع غيار قياسية',
    code: 'PG02',
    type: 'Product',
    salesPrice: 120,
    purchasePrice: 65,
    stockOnHand: 110,
    unit: 'Units',
    productType: 'Storable',
    invoicingPolicy: 'Ordered',
    routesBuy: true,
    routesMTO: false,
    traceability: 'None',
    costing_method: 'FIFO',
    inventory_account_id: '1400',
    income_account_id: '4100',
    expense_account_id: '5100',
    incomeAccountId: 'sub-4100',
    expenseAccountId: 'sub-5100',
    priceDiffAccountId: 'sub-5300',
    companyId: '__COMPANY_ID__' // replaced at runtime by useRBAC
  },
  {
    id: 'prod-003',
    sku: 'SKU-CM03',
    name: 'خدمة تركيب وصيانة متكاملة',
    code: 'CM03',
    type: 'Service',
    salesPrice: 350,
    purchasePrice: 150,
    stockOnHand: 0,
    unit: 'Hours',
    productType: 'Service',
    invoicingPolicy: 'Delivered',
    routesBuy: false,
    routesMTO: false,
    traceability: 'None',
    costing_method: 'FIFO',
    inventory_account_id: '1400',
    income_account_id: '4100',
    expense_account_id: '5100',
    incomeAccountId: 'sub-4100',
    expenseAccountId: 'sub-5100',
    priceDiffAccountId: 'sub-5300',
    companyId: '__COMPANY_ID__' // replaced at runtime by useRBAC
  }
];

export const getMergedAccounts = (dbAccounts: Account[]): Account[] => {
  if (!dbAccounts || dbAccounts.length === 0) {
    return SEEDED_ACCOUNTS;
  }
  
  // Merge ensuring seeded accounts are present
  const merged = [...dbAccounts];
  SEEDED_ACCOUNTS.forEach(seeded => {
    if (!merged.some(a => a.code === seeded.code)) {
      merged.push(seeded);
    }
  });
  return merged;
};

export const getMergedItems = (dbItems: Item[]): Item[] => {
  if (!dbItems || dbItems.length === 0) {
    return SEEDED_ITEMS;
  }
  
  const merged = [...dbItems];
  SEEDED_ITEMS.forEach(seeded => {
    if (!merged.some(item => item.sku === seeded.sku)) {
      merged.push(seeded);
    }
  });
  return merged;
};
