export type AccountType = 'Asset' | 'Liability' | 'Equity' | 'Income' | 'Expense';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'accountant' | 'sales' | 'purchases' | 'viewer';
  avatar?: string;
  companyId?: string;
}

export interface Company {
  id: string;
  name: string;
  logo?: string;
  taxId?: string;
  currency: string;
  fiscalYearStart: string;
}

export interface Account {
  id: string;
  code: string;
  name: string;
  type: AccountType;
  balance: number;
  parentId?: string;
  status: 'active' | 'inactive';
  description?: string;
  budget?: number;
  accountCategory?: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'INCOME' | 'EXPENSE';
  ifrsMapping?: 'CURRENT_ASSET' | 'NON_CURRENT_ASSET' | 'CURRENT_LIABILITY' | 'REVENUE' | 'COGS' | 'OPERATING_EXPENSE' | 'RETAINED_EARNINGS' | 'EQUITY_BASE';
}

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  taxNumber?: string;
  balance: number;
  status: 'active' | 'inactive';
  country?: string;
  governorate?: string;
  countryId?: string;
  governorateId?: string;
  currencies?: string[];
  streetAddress?: string;
  city?: string;
  attachments?: Attachment[];
  is_active?: boolean;
}

export interface Currency {
  id: string;
  code: string;
  name: string;
  symbol: string;
}

export interface CustomerCurrency {
  id: string;
  customerId: string;
  currencyCode: string;
  companyId: string;
}

export interface Vendor {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  taxNumber?: string;
  balance: number;
  status: 'active' | 'inactive';
  country?: string;
  governorate?: string;
  countryId?: string;
  governorateId?: string;
  currencies?: string[];
  streetAddress?: string;
  city?: string;
  attachments?: Attachment[];
  is_active?: boolean;
}

export interface Item {
  id: string;
  sku: string;
  name: string;
  type: 'Product' | 'Service';
  salesPrice: number;
  purchasePrice: number;
  stockOnHand: number;
  unit: string;
  productType?: 'Consumable' | 'Service' | 'Storable';
  invoicingPolicy?: 'Ordered' | 'Delivered';
  routesBuy?: boolean;
  routesMTO?: boolean;
  traceability?: 'Serial' | 'Lots' | 'None';
  weight?: number;
  volume?: number;
  customerLeadTime?: number;
  incomeAccountId?: string;
  expenseAccountId?: string;
  priceDiffAccountId?: string;
  minReorderingQty?: number;
  maxReorderingQty?: number;
  reorderingEnabled?: boolean;
  companyId?: string;
  code?: string;
  costing_method?: 'FIFO' | 'WAC';
  inventory_account_id?: string;
  income_account_id?: string;
  expense_account_id?: string;
}

export interface Invoice {
  id: string;
  number: string;
  customerId: string;
  customerName: string;
  date: string;
  dueDate: string;
  total: number;
  status: 'Draft' | 'Sent' | 'Partially Paid' | 'Paid' | 'Overdue' | 'Cancelled' | 'Posted';
  subTotal?: number;
  discountPercent?: number;
  shippingCharges?: number;
  adjustment?: number;
  customerNotes?: string;
  termsConditions?: string;
  attachments?: Attachment[];
  isCreditNote?: boolean;
  originalInvoiceId?: string;
  originalInvoiceNumber?: string;
  taxPercent?: number;
  currency?: string;
  exchangeRate?: number;
  items?: Array<{
    itemId: string;
    name: string;
    sku: string;
    quantity: number;
    rate: number;
    taxPercent: number;
    taxLabel: string;
    amount: number;
  }>;
}

export interface Bill {
  id: string;
  number: string;
  vendorId: string;
  vendorName: string;
  date: string;
  dueDate: string;
  total: number;
  status: 'Draft' | 'Unpaid' | 'Partially Paid' | 'Paid' | 'Overdue' | 'Posted' | 'Cancelled';
  subTotal?: number;
  discountPercent?: number;
  shippingCharges?: number;
  adjustment?: number;
  customerNotes?: string;
  termsConditions?: string;
  attachments?: Attachment[];
  isDebitNote?: boolean;
  currency?: string;
  exchangeRate?: number;
  originalBillId?: string;
  originalBillNumber?: string;
  items?: Array<{
    itemId: string;
    name: string;
    sku: string;
    quantity: number;
    rate: number;
    taxPercent: number;
    taxLabel: string;
    amount: number;
    accountId?: string;
    accountName?: string;
  }>;
  isServiceBill?: boolean;
  jobDescription?: string;
  serviceStatus?: 'Draft' | 'Received' | 'In Progress' | 'Ready for Delivery' | 'Delivered';
  receivingDate?: string;
  estimatedDeliveryDate?: string;
  serviceExpenses?: Array<{
    id: string;
    description: string;
    amount: number;
    accountId: string;
    accountName: string;
  }>;
  consumedItems?: Array<{
    id: string;
    itemId: string;
    name: string;
    sku: string;
    quantity: number;
    rate: number;
    amount: number;
  }>;
}

export interface JournalEntry {
  id: string;
  date: string;
  reference: string;
  description: string;
  totalDebit: number;
  totalCredit: number;
  status: 'Draft' | 'Posted';
  lines: JournalEntryLine[];
  taxTreatment?: 'Inclusive' | 'Exclusive' | 'NoTax';
  autoReverse?: boolean;
  reversalDate?: string;
  isReversal?: boolean;
  parentJournalId?: string;
  // Repeating Journal Settings
  isRepeating?: boolean;
  repeatInterval?: number;
  repeatUnit?: 'Weeks' | 'Months';
  repeatsEndType?: 'Date' | 'Count' | 'Infinite';
  repeatsEndDate?: string;
  repeatsEndCount?: number;
  repeatsRemainingCount?: number;
  nextJournalDate?: string;
  isRepeatingActive?: boolean;
  saveAsStatus?: 'Draft' | 'Posted';
}

export interface JournalEntryLine {
  accountId: string;
  accountName: string;
  accountCode?: string;
  debit: number;
  credit: number;
  description?: string;
  taxRate?: number;
  taxLabel?: string;
  region?: string;
  department?: string;
  projectId?: string;
  branchId?: string;
  departmentId?: string;
}

export interface BankAccount {
  id: string;
  name: string;
  accountNumber: string;
  bankName: string;
  balance: number;
  currency: string;
  status: 'active' | 'inactive';
}

export interface BankTransaction {
  id: string;
  bankAccountId: string;
  date: string;
  description: string;
  amount: number;
  type: 'Deposit' | 'Withdrawal' | 'Transfer';
  status: 'Unreconciled' | 'Reconciled';
}

export interface Attachment {
  id: string;
  entityId: string;
  name: string;
  size: number;
  type: string;
  url: string; // Base64 data URL
  createdAt?: string;
}

export enum IFRSMapping {
  CURRENT_ASSET = 'CURRENT_ASSET',
  NON_CURRENT_ASSET = 'NON_CURRENT_ASSET',
  CURRENT_LIABILITY = 'CURRENT_LIABILITY',
  REVENUE = 'REVENUE',
  COGS = 'COGS',
  OPERATING_EXPENSE = 'OPERATING_EXPENSE',
  RETAINED_EARNINGS = 'RETAINED_EARNINGS',
  EQUITY_BASE = 'EQUITY_BASE',
}

export interface JournalLine {
  id?: string;
  accountId: string;
  accountName?: string;
  accountCode: string;
  accountType?: string;
  ifrsMapping?: IFRSMapping | string;
  debit: number;
  credit: number;
  description?: string;
  branch?: string;
  warehouse?: string;
  projectId?: string;
  departmentId?: string;
  branchId?: string;
  costCenterId?: string;
  currencyCode?: string;
  exchangeRate?: number;
  amountInBaseCurrency?: number;
}


