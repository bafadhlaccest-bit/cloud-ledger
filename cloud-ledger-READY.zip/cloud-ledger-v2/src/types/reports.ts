export interface DBField {
  name: string;
  type: 'string' | 'number' | 'date' | 'boolean';
  label: string;
  arabicLabel: string;
}

export interface DBTable {
  id: string;
  name: string;
  label: string;
  arabicLabel: string;
  fields: DBField[];
  module: 'Accounts' | 'Inventory' | 'Sales' | 'Purchasing';
}

export interface TableJoin {
  id: string;
  leftTable: string;
  rightTable: string;
  joinType: 'Inner Join' | 'Left Join' | 'Right Join';
  leftField: string;
  rightField: string;
}

export type ElementType = 'label' | 'field' | 'image' | 'variable' | 'barcode' | 'qrcode';

export interface FormattingSettings {
  decimals: number;
  currencySymbol: 'YER' | 'USD' | 'SAR' | 'None';
  currencyPlacement: 'prefix' | 'suffix';
  thousandSeparator: boolean;
  dateFormat: 'YYYY-MM-DD' | 'DD/MM/YYYY' | 'MM-DD-YYYY';
  conditionalFormatting?: {
    expression: string; // e.g. "Detail.margin < 10"
    textColor?: string;
    bgColor?: string;
    isBold?: boolean;
  };
}

export interface ReportElement {
  id: string;
  type: ElementType;
  label: string;
  value: string; // static string, field name e.g. "accounts.code", system variable, etc.
  width: number; // grid or relative width percentage
  align: 'left' | 'center' | 'right';
  formatting: FormattingSettings;
  expression?: string; // custom Excel-style expression e.g. "Detail.debit - Detail.credit"
}

export interface ReportBand {
  id: 'reportHeader' | 'pageHeader' | 'groupHeader' | 'detail' | 'groupFooter' | 'pageFooter' | 'reportFooter';
  name: string;
  arabicName: string;
  elements: ReportElement[];
  isCollapsed?: boolean;
}

export interface ReportLayout {
  id: string;
  name: string;
  arabicName: string;
  description: string;
  version: number;
  isShared: boolean;
  roleAccess: string[]; // e.g. ['admin', 'manager', 'accountant']
  selectedTables: string[]; // ids of tables included
  joins: TableJoin[];
  bands: ReportBand[];
  groupField: string; // e.g. "sales.warehouse"
  showChart: boolean;
  chartType: 'bar' | 'line' | 'pie' | 'kpi';
  chartXField: string;
  chartYField: string;
  pageSize: 'A4' | 'A3' | 'Roll80';
  orientation: 'Portrait' | 'Landscape';
}

export interface ReportAuditLog {
  id: string;
  userId: string;
  userEmail: string;
  action: 'Created' | 'Modified' | 'Exported' | 'Restored';
  timestamp: string;
  details: string;
}
