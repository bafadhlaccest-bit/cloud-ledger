import { configureStore } from '@reduxjs/toolkit';
import reportsReducer from './reportsSlice';

export const reduxStore = configureStore({
  reducer: {
    reports: reportsReducer,
  },
});

export type RootState = ReturnType<typeof reduxStore.getState>;
export type AppDispatch = typeof reduxStore.dispatch;
