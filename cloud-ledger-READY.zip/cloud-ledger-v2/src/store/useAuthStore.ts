import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { User } from '../types';
import { supabase } from '../lib/supabase';
import { safeStorage } from '../utils/safeStorage';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (user: User, token: string) => void;
  logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      login: (user, token) => set({ user, token, isAuthenticated: true }),
      logout: async () => {
        await supabase.auth.signOut();
        set({ user: null, token: null, isAuthenticated: false });
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => ({
        getItem: (name) => safeStorage.getItem(name),
        setItem: (name, value) => {
          try { safeStorage.setItem(name, value); } catch {}
        },
        removeItem: (name) => {
          try { safeStorage.removeItem(name); } catch {}
        },
      })),
    }
  )
);
