import { create } from 'zustand';
import { safeStorage } from '../utils/safeStorage';
import { db, getDoc, onSnapshot, doc } from '../firebase';

interface CompanyProfile {
  name: string;
  arabicName: string;
  logo: string;
  address: string;
  contact: string;
  website: string;
  language: string;
  timezone: string;
  dateFormat: string;
  currency: string;
  decimalFormat: string;
}

interface PermissionsMatrixItem {
  read: boolean;
  create: boolean;
  update: boolean;
  delete: boolean;
}

interface PermissionsMatrix {
  Admin: PermissionsMatrixItem;
  Accountant: PermissionsMatrixItem;
  Vendor: PermissionsMatrixItem;
}

interface SettingsState {
  companyProfile: CompanyProfile;
  enableServiceModule: boolean;
  isLoading: boolean;
  permissionsMatrix: PermissionsMatrix;
  setCompanyProfile: (profile: Partial<CompanyProfile>) => void;
  loadSettings: () => Promise<void>;
  syncSettings: (payload: any) => void;
}

const DEFAULT_PROFILE: CompanyProfile = {
  name: 'Al-Huraibi Trading Company Ltd.',
  arabicName: 'شركة الحريبي للتجارة المحدودة',
  logo: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=128&q=80',
  address: "Sana'a - Sixty Street, Yemen",
  contact: '+967 1 445566',
  website: 'https://huraibi-trading.com',
  language: 'ar',
  timezone: 'Asia/Aden (GMT+3)',
  dateFormat: 'YYYY-MM-DD',
  currency: 'YER',
  decimalFormat: '2 Decimals (.00)'
};

const DEFAULT_PERMISSIONS_MATRIX: PermissionsMatrix = {
  Admin: { read: true, create: true, update: true, delete: true },
  Accountant: { read: true, create: true, update: true, delete: false },
  Vendor: { read: true, create: false, update: false, delete: false }
};

export const useSettingsStore = create<SettingsState>((set, get) => ({
  companyProfile: DEFAULT_PROFILE,
  enableServiceModule: true,
  isLoading: false,
  permissionsMatrix: DEFAULT_PERMISSIONS_MATRIX,

  setCompanyProfile: (profile) => {
    const updated = { ...get().companyProfile, ...profile };
    set({ companyProfile: updated });
    initiateThemeEngine(updated.logo, updated.name);
  },

  syncSettings: (payload) => {
    if (payload) {
      if (payload.companyProfile) {
        set({ companyProfile: { ...DEFAULT_PROFILE, ...payload.companyProfile } });
        initiateThemeEngine(payload.companyProfile.logo, payload.companyProfile.name);
      }
      if (payload.modulesMap && typeof payload.modulesMap.enableServiceModule !== 'undefined') {
        set({ enableServiceModule: !!payload.modulesMap.enableServiceModule });
      } else if (typeof payload.enableServiceModule !== 'undefined') {
        set({ enableServiceModule: !!payload.enableServiceModule });
      }
      if (payload.permissionsMatrix) {
        set({ permissionsMatrix: payload.permissionsMatrix });
      }
    }
  },

  loadSettings: async () => {
    set({ isLoading: true });
    
    // 1. Fallback / Immediate Load from local storage
    const saved = safeStorage.getItem('cloud_ledger_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed.companyProfile) {
          set({ companyProfile: { ...DEFAULT_PROFILE, ...parsed.companyProfile } });
          initiateThemeEngine(parsed.companyProfile.logo, parsed.companyProfile.name);
        }
        if (parsed.modulesMap && typeof parsed.modulesMap.enableServiceModule !== 'undefined') {
          set({ enableServiceModule: !!parsed.modulesMap.enableServiceModule });
        } else if (typeof parsed.enableServiceModule !== 'undefined') {
          set({ enableServiceModule: !!parsed.enableServiceModule });
        }
        if (parsed.permissionsMatrix) {
          set({ permissionsMatrix: parsed.permissionsMatrix });
        }
      } catch (e) {
        console.warn('Faulty local storage state parsing in store initializer', e);
      }
    } else {
      initiateThemeEngine(DEFAULT_PROFILE.logo, DEFAULT_PROFILE.name);
    }

    // 2. Fetch from PostgreSQL server /api/settings if available
    try {
      const response = await fetch('/api/settings');
      if (response.ok) {
        const remoteData = await response.json();
        if (remoteData) {
          if (remoteData.companyProfile) {
            set({ companyProfile: { ...DEFAULT_PROFILE, ...remoteData.companyProfile } });
            initiateThemeEngine(remoteData.companyProfile.logo, remoteData.companyProfile.name);
          }
          if (remoteData.modulesMap && typeof remoteData.modulesMap.enableServiceModule !== 'undefined') {
            set({ enableServiceModule: !!remoteData.modulesMap.enableServiceModule });
          } else if (typeof remoteData.enableServiceModule !== 'undefined') {
            set({ enableServiceModule: !!remoteData.enableServiceModule });
          }
          if (remoteData.permissionsMatrix) {
            set({ permissionsMatrix: remoteData.permissionsMatrix });
          }
          set({ isLoading: false });
          return;
        }
      }
    } catch (err) {
      console.warn('Backend settings read configuration fallback:', err);
    }

    // 3. Real-time Firebase firestore global_config listener attachment
    try {
      const settingsRef = doc(db, 'settings', 'global_config');
      const docSnap = await getDoc(settingsRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        if (data) {
          if (data.companyProfile) {
            set({ companyProfile: { ...DEFAULT_PROFILE, ...data.companyProfile } });
            initiateThemeEngine(data.companyProfile.logo, data.companyProfile.name);
          }
          if (data.modulesMap && typeof data.modulesMap.enableServiceModule !== 'undefined') {
            set({ enableServiceModule: !!data.modulesMap.enableServiceModule });
          } else if (typeof data.enableServiceModule !== 'undefined') {
            set({ enableServiceModule: !!data.enableServiceModule });
          }
          if (data.permissionsMatrix) {
            set({ permissionsMatrix: data.permissionsMatrix });
          }
        }
      }
    } catch (e) {
      console.warn('Firestore settings document access fallback', e);
    }

    set({ isLoading: false });
  }
}));

// Real-time Firestore Settings Subscriber
try {
  const settingsRef = doc(db, 'settings', 'global_config');
  onSnapshot(settingsRef, (snapshot) => {
    if (snapshot.exists()) {
      const data = snapshot.data();
      if (data && data.companyProfile) {
        useSettingsStore.getState().syncSettings(data);
      }
    }
  }, (error) => {
    console.warn('Could not read settings from Firestore (permissions/offline). Using defaults or cache.', error);
  });
} catch (e) {
  console.warn('Could not establish real-time settings live snapshot subscriber:', e);
}

// Visual layout dynamic auto-theming helper engine
function fallbackHashColor(str: string): string {
  if (!str) return '#4f46e5';
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const palette = [
    '#4F46E5', // Indigo
    '#2563EB', // Blue
    '#059669', // Emerald
    '#D97706', // Amber
    '#DC2626', // Red
    '#7C3AED', // Violet
    '#0891B2', // Cyan
    '#1B3B6F', // Steel Navy
    '#028090', // Teal
  ];
  return palette[Math.abs(hash) % palette.length];
}

function getContrastTextColor(hexColor: string): string {
  let r = 79, g = 70, b = 229;
  if (hexColor.startsWith('#')) {
    const raw = hexColor.slice(1);
    if (raw.length === 3) {
      r = parseInt(raw[0] + raw[0], 16);
      g = parseInt(raw[1] + raw[1], 16);
      b = parseInt(raw[2] + raw[2], 16);
    } else if (raw.length === 6) {
      r = parseInt(raw.slice(0, 2), 16);
      g = parseInt(raw.slice(2, 4), 16);
      b = parseInt(raw.slice(4, 6), 16);
    }
  }
  // Formula to calculate relative luminance
  const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
  return luminance > 140 ? '#1E1E1E' : '#FFFFFF';
}

function getHoverColor(hexColor: string, isLight: boolean): string {
  let r = 79, g = 70, b = 229;
  if (hexColor.startsWith('#')) {
    const raw = hexColor.slice(1);
    if (raw.length === 6) {
      r = parseInt(raw.slice(0, 2), 16);
      g = parseInt(raw.slice(2, 4), 16);
      b = parseInt(raw.slice(4, 6), 16);
    }
  }
  const factor = isLight ? -30 : 30;
  const clamp = (val: number) => Math.min(255, Math.max(0, Math.round(val + factor)));
  const hr = clamp(r).toString(16).padStart(2, '0');
  const hg = clamp(g).toString(16).padStart(2, '0');
  const hb = clamp(b).toString(16).padStart(2, '0');
  return `#${hr}${hg}${hb}`;
}

export function applyThemeVariables(primaryColor: string) {
  const contrastTextColor = getContrastTextColor(primaryColor);
  const isLight = contrastTextColor === '#1E1E1E';
  const hoverColor = getHoverColor(primaryColor, isLight);

  const root = document.documentElement;
  root.style.setProperty('--color-primary', primaryColor);
  root.style.setProperty('--color-primary-text', contrastTextColor);
  root.style.setProperty('--color-primary-hover', hoverColor);
  root.style.setProperty('--color-primary-rgb', hexToRgb(primaryColor));
}

function hexToRgb(hex: string): string {
  let r = 79, g = 70, b = 229;
  if (hex.startsWith('#')) {
    const raw = hex.slice(1);
    if (raw.length === 6) {
      r = parseInt(raw.slice(0, 2), 16);
      g = parseInt(raw.slice(2, 4), 16);
      b = parseInt(raw.slice(4, 6), 16);
    }
  }
  return `${r}, ${g}, ${b}`;
}

let colorExtractionCache: Record<string, string> = {};

function initiateThemeEngine(logoUrl: string, companyName: string) {
  // Try immediate hash fallback
  const fallbackColor = fallbackHashColor(logoUrl || companyName);
  
  if (colorExtractionCache[logoUrl]) {
    applyThemeVariables(colorExtractionCache[logoUrl]);
    return;
  }

  applyThemeVariables(fallbackColor);

  if (!logoUrl || !logoUrl.startsWith('http')) {
    return;
  }

  // extract properly from image canvas of logo
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1;
      canvas.height = 1;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, 1, 1);
        const data = ctx.getImageData(0, 0, 1, 1).data;
        if (data && data[3] > 0) { // Check opacity
          const [r, g, b] = data;
          
          // Format extracted hex
          const hex = '#' + [r, g, b].map(x => {
            const h = x.toString(16);
            return h.length === 1 ? '0' + h : h;
          }).join('');

          colorExtractionCache[logoUrl] = hex;
          applyThemeVariables(hex);
        }
      }
    } catch (e) {
      console.warn('Canvas color analysis failed for logoUrl:', logoUrl, e);
    }
  };
  img.src = logoUrl;
}
