import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { ReportLayout, ReportAuditLog } from '../types/reports';

interface ReportsState {
  selectedTemplateId: string | null;
  filters: {
    fromDate: string;
    toDate: string;
    branches: string[];
    warehouses: string[];
    costCenters: string[];
    customerVendorScope: string;
    productCategory: string;
  };
  schedules: Array<{
    id: string;
    reportName: string;
    arabicName: string;
    frequency: 'daily' | 'weekly' | 'monthly';
    recipients: string;
    time: string;
    active: boolean;
  }>;
  customDesigns: ReportLayout[];
  historyLogs: ReportAuditLog[];
}

const initialState: ReportsState = {
  selectedTemplateId: null,
  filters: {
    fromDate: '2026-01-01',
    toDate: '2026-12-31',
    branches: ["Sana'a Main HQ branch", "Aden Port Operations branch"],
    warehouses: ['WH-MAIN (Sana\'a)', 'WH-ADEN (Freezone)'],
    costCenters: ['Admin HQ Operations Center', 'Sales Hub YER Ledger'],
    customerVendorScope: 'All',
    productCategory: 'All'
  },
  schedules: [
    {
      id: 'sch-1',
      reportName: 'Trial Balance Ledger',
      arabicName: 'ميزان المراجعة بالمجاميع والأرصدة',
      frequency: 'weekly',
      recipients: 'management@company.com, cfo@company.com',
      time: '08:00',
      active: true,
    }
  ],
  customDesigns: [],
  historyLogs: []
};

const reportsSlice = createSlice({
  name: 'reports',
  initialState,
  reducers: {
    setSelectedTemplateId(state, action: PayloadAction<string | null>) {
      state.selectedTemplateId = action.payload;
    },
    updateFilters(state, action: PayloadAction<Partial<ReportsState['filters']>>) {
      state.filters = { ...state.filters, ...action.payload };
    },
    addSchedule(state, action: PayloadAction<Omit<ReportsState['schedules'][0], 'id'>>) {
      const newSchedule = {
        ...action.payload,
        id: `sch_${Date.now()}`
      };
      state.schedules.push(newSchedule);
    },
    toggleSchedule(state, action: PayloadAction<string>) {
      const item = state.schedules.find(s => s.id === action.payload);
      if (item) item.active = !item.active;
    },
    removeSchedule(state, action: PayloadAction<string>) {
      state.schedules = state.schedules.filter(s => s.id !== action.payload);
    },
    setCustomDesigns(state, action: PayloadAction<ReportLayout[]>) {
      state.customDesigns = action.payload;
    },
    addHistoryLog(state, action: PayloadAction<ReportAuditLog>) {
      state.historyLogs.unshift(action.payload);
    }
  }
});

export const {
  setSelectedTemplateId,
  updateFilters,
  addSchedule,
  toggleSchedule,
  removeSchedule,
  setCustomDesigns,
  addHistoryLog
} = reportsSlice.actions;

export default reportsSlice.reducer;
