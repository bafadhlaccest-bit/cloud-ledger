import { PostingEngine } from '../../services/PostingEngine';
import { db, collection, serverTimestamp, runTransaction, doc } from '../../firebase';

export class ERPEventBus {
  /**
   * Emits an ERP event, registers it immediately in the transactional event log,
   * and dispatches necessary accounting flows if we notice specific transactional triggers.
   */
  public static async emitEvent(
    eventType: string,
    payload: any,
    companyId: string,
    actorId: string
  ): Promise<{ success: boolean; eventId: string; postedLedgerTx?: string; error?: string }> {
    
    // Create reference to a new document in the erp_event_bus collection
    const eventRef = doc(collection(db, 'erp_event_bus'));
    const eventId = eventRef.id;

    try {
      // 1. Commit event immediately to the log in PENDING status
      await runTransaction(db, async (transaction) => {
        const eventData = {
          id: eventId,
          eventType,
          payload,
          companyId,
          actorId,
          processedByWorkflow: false,
          processedByAccounting: false,
          status: 'PENDING',
          createdAt: serverTimestamp()
        };

        transaction.set(eventRef, eventData);
      });

      // 2. Trigger automated processing pipeline for eligible events
      if (eventType === 'INVOICE_APPROVED' || eventType === 'STOCK_OUT') {
        try {
          console.info(`[ERPEventBus] Processing event pipeline for automatic journal ledger mapping: ${eventType}`);
          
          // Call the posting engine automatic generator
          const postingResult = await PostingEngine.generateAutoEntryFromEvent(eventType, payload, companyId);
          
          if (!postingResult.success) {
            throw new Error(postingResult.error || 'Failed to auto-generate corresponding ledger posting entry.');
          }

          // Update the event log document status to 'PROCESSED'
          await runTransaction(db, async (transaction) => {
            transaction.update(eventRef, {
              status: 'PROCESSED',
              processedByAccounting: true,
              processedByWorkflow: true,
              postedLedgerTx: postingResult.journalEntryId || 'AUTO_TX',
              updatedAt: serverTimestamp()
            });
          });

          return {
            success: true,
            eventId,
            postedLedgerTx: postingResult.journalEntryId
          };

        } catch (pipelineError: any) {
          console.error(`[ERPEventBus] Pipeline failed for ${eventType}:`, pipelineError.message);
          
          // Requirement 4: If the workflow engine fails or the transaction rolls back, 
          // mark the event status as 'FAILED_RETRY' in the log to ensure no loose entries compromise financial traceability.
          await runTransaction(db, async (transaction) => {
            transaction.update(eventRef, {
              status: 'FAILED_RETRY',
              processedByAccounting: false,
              processedByWorkflow: false,
              error: pipelineError.message || 'Pipeline execution failed.',
              updatedAt: serverTimestamp()
            });
          });

          return {
            success: false,
            eventId,
            error: pipelineError.message || 'Workflow pipeline execution failure.'
          };
        }
      }

      // Default resolution for other events
      await runTransaction(db, async (transaction) => {
        transaction.update(eventRef, {
          status: 'PROCESSED',
          processedByWorkflow: true,
          updatedAt: serverTimestamp()
        });
      });

      return {
        success: true,
        eventId
      };

    } catch (dbError: any) {
      console.error('[ERPEventBus] Transactional block insertion error:', dbError.message);
      
      // Fallback for immediate recovery to mark as failed
      try {
        await runTransaction(db, async (transaction) => {
          transaction.set(eventRef, {
            id: eventId,
            eventType,
            payload,
            companyId,
            actorId,
            status: 'FAILED_RETRY',
            processedByWorkflow: false,
            processedByAccounting: false,
            error: dbError.message || 'Main transactional emission failed.',
            createdAt: serverTimestamp()
          });
        });
      } catch (innerError) {
        console.error('[ERPEventBus] Deep failure saving fallback log:', innerError);
      }

      return {
        success: false,
        eventId,
        error: dbError.message || 'Database transactional error.'
      };
    }
  }
}
