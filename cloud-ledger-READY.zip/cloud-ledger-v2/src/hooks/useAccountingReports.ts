/**
 * useAccountingReports — ربط التقارير المحاسبية بـ Supabase
 * يحسب الأرصدة الفعلية من journal_lines + accounts
 */
import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useRBAC } from './useRBAC';

export interface AccountBalance {
  id: string;
  code: string;
  name: string;
  type: string;           // ASSET | LIABILITY | EQUITY | REVENUE | EXPENSE
  ifrsMapping?: string;   // CURRENT_ASSET | NON_CURRENT_ASSET | CURRENT_LIABILITY | etc.
  normalBalance: 'debit' | 'credit';
  openingBalance: number;
  totalDebit: number;
  totalCredit: number;
  balance: number;        // net balance (sign depends on normalBalance)
  budget?: number;
  parentId?: string;
  level?: number;
}

export interface JournalLine {
  id: string;
  journalEntryId: string;
  accountId: string;
  accountCode: string;
  accountName: string;
  accountType: string;
  debit: number;
  credit: number;
  description: string;
  date: string;
  reference: string;
  status: string;
}

function normalBalanceForType(type: string): 'debit' | 'credit' {
  const t = (type || '').toUpperCase();
  if (t.includes('ASSET') || t.includes('EXPENSE') || t === 'ASSET' || t === 'EXPENSE') return 'debit';
  return 'credit';
}

export function useAccountingReports(dateFrom?: string, dateTo?: string) {
  const { companyId } = useRBAC();
  const [accounts, setAccounts] = useState<AccountBalance[]>([]);
  const [journalLines, setJournalLines] = useState<JournalLine[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!companyId) return;
    setIsLoading(true);
    setError(null);

    try {
      // 1. Fetch all accounts
      const { data: accsRaw, error: accErr } = await supabase
        .from('accounts')
        .select('*')
        .eq('company_id', companyId)
        .order('code');
      if (accErr) throw accErr;

      // 2. Fetch posted journal entries (with optional date filter)
      let jeQuery = supabase
        .from('journal_entries')
        .select('id, date, reference, description, status')
        .eq('company_id', companyId)
        .in('status', ['Posted', 'POSTED', 'posted']);
      if (dateFrom) jeQuery = jeQuery.gte('date', dateFrom);
      if (dateTo)   jeQuery = jeQuery.lte('date', dateTo);
      const { data: entriesRaw, error: jeErr } = await jeQuery;
      if (jeErr) throw jeErr;

      if (!entriesRaw?.length) {
        // No entries — return accounts with zero balances
        const mapped = (accsRaw || []).map(a => ({
          id: a.id,
          code: a.code || '',
          name: a.name || '',
          type: a.type || '',
          ifrsMapping: a.ifrs_mapping || a.ifrsMapping || '',
          normalBalance: normalBalanceForType(a.type),
          openingBalance: Number(a.opening_balance || 0),
          totalDebit: 0,
          totalCredit: 0,
          balance: Number(a.opening_balance || 0),
          budget: Number(a.budget || 0),
          parentId: a.parent_id || a.parentId,
          level: a.level || 1,
        }));
        setAccounts(mapped);
        setJournalLines([]);
        setIsLoading(false);
        return;
      }

      const entryIds = entriesRaw.map(e => e.id);
      const entryMap: Record<string, any> = {};
      entriesRaw.forEach(e => { entryMap[e.id] = e; });

      // 3. Fetch journal lines for those entries
      const { data: linesRaw, error: lineErr } = await supabase
        .from('journal_lines')
        .select('*')
        .eq('company_id', companyId)
        .in('journal_entry_id', entryIds);
      if (lineErr) throw lineErr;

      // 4. Build account map for fast lookup
      const accMap: Record<string, any> = {};
      (accsRaw || []).forEach(a => { accMap[a.id] = a; });

      // 5. Aggregate debit/credit per account
      const totals: Record<string, { debit: number; credit: number }> = {};
      const lines: JournalLine[] = [];

      for (const line of (linesRaw || [])) {
        const acc = accMap[line.account_id || line.accountId];
        const entry = entryMap[line.journal_entry_id || line.journalEntryId];
        if (!entry) continue;

        const accId = acc?.id || line.account_id || line.accountId || '';
        if (!totals[accId]) totals[accId] = { debit: 0, credit: 0 };
        totals[accId].debit  += Number(line.debit  || 0);
        totals[accId].credit += Number(line.credit || 0);

        lines.push({
          id: line.id,
          journalEntryId: entry.id,
          accountId: accId,
          accountCode: acc?.code || line.account_code || '',
          accountName: acc?.name || line.account_name || '',
          accountType: acc?.type || '',
          debit: Number(line.debit || 0),
          credit: Number(line.credit || 0),
          description: line.description || entry.description || '',
          date: entry.date || '',
          reference: entry.reference || '',
          status: entry.status || 'Posted',
        });
      }

      // 6. Compute final balances
      const balances: AccountBalance[] = (accsRaw || []).map(a => {
        const nb = normalBalanceForType(a.type);
        const opening = Number(a.opening_balance || 0);
        const td = totals[a.id]?.debit  || 0;
        const tc = totals[a.id]?.credit || 0;
        // Balance = opening + movement in normal direction
        const balance = nb === 'debit'
          ? opening + td - tc
          : opening + tc - td;
        return {
          id: a.id,
          code: a.code || '',
          name: a.name || '',
          type: a.type || '',
          ifrsMapping: a.ifrs_mapping || a.ifrsMapping || '',
          normalBalance: nb,
          openingBalance: opening,
          totalDebit: td,
          totalCredit: tc,
          balance,
          budget: Number(a.budget || 0),
          parentId: a.parent_id || a.parentId,
          level: a.level || 1,
        };
      });

      setAccounts(balances);
      setJournalLines(lines);
    } catch (err: any) {
      console.error('[useAccountingReports]', err.message);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [companyId, dateFrom, dateTo]);

  useEffect(() => { load(); }, [load]);

  // ── Computed report views ──────────────────────────────────────

  // Trial Balance
  const trialBalance = accounts.filter(a => a.totalDebit > 0 || a.totalCredit > 0 || a.openingBalance !== 0);

  // Balance Sheet (Assets = Liabilities + Equity)
  const balanceSheet = {
    currentAssets:    accounts.filter(a => (a.ifrsMapping || a.type).includes('CURRENT_ASSET')),
    nonCurrentAssets: accounts.filter(a => (a.ifrsMapping || a.type).includes('NON_CURRENT_ASSET') || a.type === 'ASSET'),
    currentLiab:      accounts.filter(a => (a.ifrsMapping || a.type).includes('CURRENT_LIAB')),
    nonCurrentLiab:   accounts.filter(a => (a.ifrsMapping || a.type).includes('NON_CURRENT_LIAB') || a.type === 'LIABILITY'),
    equity:           accounts.filter(a => (a.ifrsMapping || a.type).includes('EQUITY') || a.type === 'EQUITY'),
    totalAssets:      accounts.filter(a => a.type === 'ASSET' || a.type.includes('ASSET')).reduce((s, a) => s + a.balance, 0),
    totalLiabEquity:  accounts.filter(a => a.type === 'LIABILITY' || a.type === 'EQUITY' || a.type.includes('LIAB') || a.type.includes('EQUITY')).reduce((s, a) => s + a.balance, 0),
  };

  // Income Statement (P&L)
  const incomeStatement = {
    revenue:   accounts.filter(a => a.type === 'REVENUE' || a.type.includes('REVENUE') || a.type.includes('INCOME')),
    expenses:  accounts.filter(a => a.type === 'EXPENSE' || a.type.includes('EXPENSE') || a.type.includes('COGS')),
    totalRevenue:  accounts.filter(a => a.type === 'REVENUE' || a.type.includes('REVENUE') || a.type.includes('INCOME')).reduce((s, a) => s + a.balance, 0),
    totalExpenses: accounts.filter(a => a.type === 'EXPENSE' || a.type.includes('EXPENSE') || a.type.includes('COGS')).reduce((s, a) => s + a.balance, 0),
    get netIncome() { return this.totalRevenue - this.totalExpenses; },
  };

  // Check balance (Assets = Liabilities + Equity)
  const isBalanced = Math.abs(balanceSheet.totalAssets - balanceSheet.totalLiabEquity) < 0.01;

  return {
    accounts,
    journalLines,
    isLoading,
    error,
    refresh: load,
    trialBalance,
    balanceSheet,
    incomeStatement,
    isBalanced,
  };
}
