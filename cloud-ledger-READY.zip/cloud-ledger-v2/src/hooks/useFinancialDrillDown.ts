import { useNavigate } from 'react-router-dom';

export const useFinancialDrillDown = () => {
  const navigate = useNavigate();

  const drillToGeneralLedger = (accountId: string, fromDate: string, toDate: string, branchId?: string) => {
    const params = new URLSearchParams({
      account_id: accountId,
      from: fromDate,
      to: toDate,
      mode: 'drill_down'
    });
    if (branchId) params.append('branch_id', branchId);
    
    // الانتقال الفوري لدفتر الأستاذ مع تمرير الفلاتر الصارمة
    navigate(`/reports/general-ledger?${params.toString()}`);
  };

  const drillToSourceDocument = (sourceType: 'INVOICE' | 'BILL' | 'PAYMENT', sourceId: string) => {
    const routes = {
      INVOICE: `/sales/invoices/${sourceId}`,
      BILL: `/purchases/bills/${sourceId}`,
      PAYMENT: `/finance/payments/${sourceId}`
    };
    navigate(routes[sourceType]);
  };

  return { drillToGeneralLedger, drillToSourceDocument };
};
