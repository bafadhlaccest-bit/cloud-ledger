/**
 * useFinancialAdvisor
 * ─────────────────────────────────────────────────────────────────
 * مستشار مالي ذكي يقرأ كل بيانات الشركة قبل أي إجابة.
 * يختلف عن المحاسب الذكي في:
 *   - يعطي توصيات استراتيجية، ليس فقط قيوداً
 *   - ينبّه على أخطاء محاسبية تلقائياً
 *   - يشخّص الوضع المالي الكامل
 *   - يتذكر السياق طوال المحادثة
 */
import { useState, useCallback, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { useRBAC } from './useRBAC';

// ── Types ──────────────────────────────────────────────────────────
export interface AdvisorMessage {
  id: string;
  role: 'user' | 'advisor' | 'alert';
  content: string;
  timestamp: Date;
  alerts?: AccountingAlert[];
  suggestions?: string[];
  metrics?: FinancialSnapshot;
}

export interface AccountingAlert {
  severity: 'critical' | 'warning' | 'info';
  code: string;
  title: string;
  detail: string;
  recommendation: string;
}

export interface FinancialSnapshot {
  totalRevenue: number;
  totalExpenses: number;
  netIncome: number;
  netMargin: number;
  cashBalance: number;
  totalReceivables: number;
  totalPayables: number;
  currentRatio: number;
  quickRatio: number;
  debtToEquity: number;
  isBalanced: boolean;
  trialBalanceDiff: number;
  overdueInvoices: number;
  overdueAmount: number;
  currency: string;
}

// ── Main Hook ──────────────────────────────────────────────────────
export function useFinancialAdvisor() {
  const { companyId } = useRBAC();
  const [messages, setMessages] = useState<AdvisorMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [snapshot, setSnapshot] = useState<FinancialSnapshot | null>(null);
  const [alerts, setAlerts] = useState<AccountingAlert[]>([]);
  const conversationHistory = useRef<Array<{ role: string; content: string }>>([]);

  // ── Load full company financial data ──────────────────────────
  const loadCompanyData = useCallback(async () => {
    if (!companyId) return null;

    const [
      { data: accounts },
      { data: invoices },
      { data: bills },
      { data: journalEntries },
      { data: journalLines },
      { data: bankAccounts },
      { data: customers },
      { data: vendors },
      { data: items },
      { data: settings },
    ] = await Promise.all([
      supabase.from('accounts').select('*').eq('company_id', companyId),
      supabase.from('invoices').select('*').eq('company_id', companyId),
      supabase.from('bills').select('*').eq('company_id', companyId),
      supabase.from('journal_entries').select('*').eq('company_id', companyId).order('date', { ascending: false }).limit(200),
      supabase.from('journal_lines').select('*').eq('company_id', companyId),
      supabase.from('bank_accounts').select('*').eq('company_id', companyId),
      supabase.from('customers').select('id,name,balance').eq('company_id', companyId),
      supabase.from('vendors').select('id,name,balance').eq('company_id', companyId),
      supabase.from('items').select('id,name,quantity,cost_price,sale_price').eq('company_id', companyId),
      supabase.from('company_settings').select('key,value').eq('company_id', companyId),
    ]);

    return {
      accounts:       accounts       || [],
      invoices:       invoices       || [],
      bills:          bills          || [],
      journalEntries: journalEntries || [],
      journalLines:   journalLines   || [],
      bankAccounts:   bankAccounts   || [],
      customers:      customers      || [],
      vendors:        vendors        || [],
      items:          items          || [],
      settings:       Object.fromEntries((settings || []).map(s => [s.key, s.value])),
    };
  }, [companyId]);

  // ── Compute financial snapshot ─────────────────────────────────
  const computeSnapshot = (data: any): FinancialSnapshot => {
    const inv = data.invoices || [];
    const bl  = data.bills    || [];
    const acc = data.accounts || [];
    const jl  = data.journalLines || [];
    const ba  = data.bankAccounts || [];

    const paidInv = inv.filter((i: any) => ['Paid', 'Sent', 'Posted'].includes(i.status));
    const totalRevenue  = paidInv.reduce((s: number, i: any) => s + Number(i.total || 0), 0);
    const totalExpenses = bl.filter((b: any) => b.status !== 'Cancelled').reduce((s: number, b: any) => s + Number(b.total || 0), 0);
    const netIncome  = totalRevenue - totalExpenses;
    const netMargin  = totalRevenue > 0 ? (netIncome / totalRevenue) * 100 : 0;
    const cashBalance = ba.reduce((s: number, a: any) => s + Number(a.current_balance || a.balance || 0), 0);
    const totalReceivables = inv.filter((i: any) => i.status === 'Sent').reduce((s: number, i: any) => s + Number(i.total || 0), 0);
    const totalPayables    = bl.filter((b: any) => b.status === 'Unpaid').reduce((s: number, b: any) => s + Number(b.total || 0), 0);

    // Balance sheet ratios
    const currentAssets = acc.filter((a: any) => a.type === 'ASSET' || a.type?.includes('ASSET')).reduce((s: number, a: any) => s + Number(a.balance || 0), 0);
    const currentLiab   = acc.filter((a: any) => a.type === 'LIABILITY' || a.type?.includes('LIAB')).reduce((s: number, a: any) => s + Number(a.balance || 0), 0);
    const equity        = acc.filter((a: any) => a.type === 'EQUITY').reduce((s: number, a: any) => s + Number(a.balance || 0), 0);
    const currentRatio  = currentLiab > 0 ? currentAssets / currentLiab : 999;
    const quickRatio    = currentLiab > 0 ? (currentAssets - Number(data.items?.reduce((s: number, i: any) => s + Number(i.quantity || 0) * Number(i.cost_price || 0), 0) || 0)) / currentLiab : 999;
    const debtToEquity  = equity > 0 ? currentLiab / equity : 0;

    // Trial balance check
    const totalDebit  = jl.reduce((s: number, l: any) => s + Number(l.debit  || 0), 0);
    const totalCredit = jl.reduce((s: number, l: any) => s + Number(l.credit || 0), 0);
    const trialBalanceDiff = Math.abs(totalDebit - totalCredit);
    const isBalanced = trialBalanceDiff < 0.01;

    // Overdue
    const today = new Date().toISOString().slice(0, 10);
    const overdueInv = inv.filter((i: any) => i.status === 'Sent' && i.due_date && i.due_date < today);
    const overdueAmount = overdueInv.reduce((s: number, i: any) => s + Number(i.total || 0), 0);

    return {
      totalRevenue, totalExpenses, netIncome, netMargin,
      cashBalance, totalReceivables, totalPayables,
      currentRatio, quickRatio, debtToEquity,
      isBalanced, trialBalanceDiff,
      overdueInvoices: overdueInv.length, overdueAmount,
      currency: data.settings?.currency || 'SAR',
    };
  };

  // ── Detect accounting alerts ───────────────────────────────────
  const detectAlerts = (data: any, snap: FinancialSnapshot): AccountingAlert[] => {
    const found: AccountingAlert[] = [];

    if (!snap.isBalanced) {
      found.push({
        severity: 'critical', code: 'TB001',
        title: 'ميزان المراجعة غير متوازن',
        detail: `الفرق: ${snap.trialBalanceDiff.toFixed(2)} ${snap.currency}`,
        recommendation: 'راجع آخر القيود المحاسبية وتأكد من اكتمال كل قيد بمدين ودائن متساويين',
      });
    }

    if (snap.overdueInvoices > 0) {
      found.push({
        severity: 'warning', code: 'AR001',
        title: `${snap.overdueInvoices} فاتورة متأخرة التحصيل`,
        detail: `إجمالي المتأخر: ${snap.overdueAmount.toLocaleString()} ${snap.currency}`,
        recommendation: 'أرسل تذكيرات للعملاء فوراً وفكّر في سياسة حسم للدفع المبكر',
      });
    }

    if (snap.currentRatio < 1 && snap.currentRatio > 0) {
      found.push({
        severity: 'critical', code: 'LQ001',
        title: 'نسبة السيولة أقل من 1',
        detail: `النسبة الحالية: ${snap.currentRatio.toFixed(2)}`,
        recommendation: 'المطلوبات المتداولة تتجاوز الأصول المتداولة — تحقق من التدفق النقدي فوراً',
      });
    } else if (snap.currentRatio < 1.5 && snap.currentRatio > 0) {
      found.push({
        severity: 'warning', code: 'LQ002',
        title: 'نسبة السيولة منخفضة',
        detail: `النسبة: ${snap.currentRatio.toFixed(2)} (المعيار: 1.5-2)`,
        recommendation: 'حسّن إدارة التدفق النقدي وسرّع تحصيل الذمم',
      });
    }

    if (snap.netMargin < 0) {
      found.push({
        severity: 'critical', code: 'PL001',
        title: 'الشركة تعمل بخسارة',
        detail: `هامش الربح: ${snap.netMargin.toFixed(1)}%`,
        recommendation: 'راجع هيكل التكاليف وأسعار البيع — قد تحتاج إعادة تسعير أو تخفيض مصروفات',
      });
    } else if (snap.netMargin < 5) {
      found.push({
        severity: 'warning', code: 'PL002',
        title: 'هامش ربح منخفض جداً',
        detail: `هامش الربح: ${snap.netMargin.toFixed(1)}%`,
        recommendation: 'هامش أقل من 5% يعني هشاشة في مواجهة أي صدمة. راجع التسعير والتكاليف',
      });
    }

    if (snap.debtToEquity > 2) {
      found.push({
        severity: 'warning', code: 'FS001',
        title: 'نسبة الدين إلى حقوق الملكية مرتفعة',
        detail: `النسبة: ${snap.debtToEquity.toFixed(2)} (المعيار: أقل من 2)`,
        recommendation: 'الشركة مديونة بشكل مفرط — فكّر في زيادة رأس المال أو تسديد الديون',
      });
    }

    // Accounts with zero activity
    const acc = data.accounts || [];
    const activeAccIds = new Set((data.journalLines || []).map((l: any) => l.account_id));
    const dormant = acc.filter((a: any) => !activeAccIds.has(a.id) && a.balance !== 0);
    if (dormant.length > 0) {
      found.push({
        severity: 'info', code: 'AC001',
        title: `${dormant.length} حساب بدون حركة لكن برصيد`,
        detail: dormant.slice(0, 3).map((a: any) => a.name).join('، '),
        recommendation: 'راجع هذه الحسابات — قد تحتاج ترحيل أرصدة أو إغلاق',
      });
    }

    return found;
  };

  // ── Build context for AI ───────────────────────────────────────
  const buildContext = (data: any, snap: FinancialSnapshot, detectedAlerts: AccountingAlert[]): string => {
    const fmt = (n: number) => n.toLocaleString('ar-SA', { maximumFractionDigits: 0 });
    const cur = snap.currency;

    return `
أنت مستشار مالي خبير ومحاسب قانوني معتمد. تعمل لصالح هذه الشركة وعندك صلاحية الاطلاع على جميع بياناتها المالية.

══ البيانات المالية الحالية للشركة ══

📊 ملخص الأداء:
- الإيرادات الإجمالية: ${fmt(snap.totalRevenue)} ${cur}
- إجمالي المصروفات: ${fmt(snap.totalExpenses)} ${cur}
- صافي الربح/الخسارة: ${fmt(snap.netIncome)} ${cur} (${snap.netMargin.toFixed(1)}%)
- الرصيد النقدي (بنك + صندوق): ${fmt(snap.cashBalance)} ${cur}

💳 الذمم:
- ذمم مدينة (للتحصيل): ${fmt(snap.totalReceivables)} ${cur}
- ذمم دائنة (للدفع): ${fmt(snap.totalPayables)} ${cur}
- فواتير متأخرة: ${snap.overdueInvoices} فاتورة بإجمالي ${fmt(snap.overdueAmount)} ${cur}

📐 النسب المالية:
- نسبة السيولة الحالية: ${snap.currentRatio.toFixed(2)}
- نسبة السيولة السريعة: ${snap.quickRatio.toFixed(2)}
- نسبة الدين إلى حقوق الملكية: ${snap.debtToEquity.toFixed(2)}
- ميزان المراجعة: ${snap.isBalanced ? '✅ متوازن' : `❌ غير متوازن (فرق: ${snap.trialBalanceDiff.toFixed(2)})`}

🏢 حجم الأعمال:
- عدد العملاء: ${data.customers?.length || 0}
- عدد الموردين: ${data.vendors?.length || 0}
- عدد الأصناف: ${data.items?.length || 0}
- عدد الحسابات في دليل الحسابات: ${data.accounts?.length || 0}
- عدد القيود المحاسبية: ${data.journalEntries?.length || 0}

${detectedAlerts.length > 0 ? `
⚠️ تنبيهات محاسبية مكتشفة:
${detectedAlerts.map(a => `[${a.severity.toUpperCase()}] ${a.code}: ${a.title} — ${a.detail}`).join('\n')}
` : '✅ لا توجد تنبيهات محاسبية حرجة'}

🗂️ الحسابات الرئيسية (أول 30):
${(data.accounts || []).slice(0, 30).map((a: any) => `${a.code} | ${a.name} | ${a.type} | رصيد: ${Number(a.balance || 0).toFixed(0)}`).join('\n')}

══ تعليمات الرد ══
- أجب دائماً كمستشار مالي خبير، لا كنظام محاسبة
- استخدم اللغة العربية الواضحة مع المصطلحات المالية الصحيحة
- قدّم أرقاماً دقيقة من البيانات أعلاه
- إذا وجدت مشاكل، اذكرها بجرأة مع توصيات قابلة للتنفيذ
- إذا كان السؤال خارج نطاق البيانات المتاحة، قل ذلك بوضوح
- ضع في نهاية كل إجابة: "💡 اقتراح:" بتوصية عملية واحدة
`.trim();
  };

  // ── Send message ───────────────────────────────────────────────
  const sendMessage = useCallback(async (userText: string) => {
    if (!userText.trim() || isLoading) return;

    const userMsg: AdvisorMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: userText,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMsg]);
    conversationHistory.current.push({ role: 'user', content: userText });
    setIsLoading(true);

    try {
      // Load fresh company data
      const data = await loadCompanyData();
      if (!data) throw new Error('لم يتم تحميل بيانات الشركة');

      const snap = computeSnapshot(data);
      const detectedAlerts = detectAlerts(data, snap);
      setSnapshot(snap);
      setAlerts(detectedAlerts);

      const systemPrompt = buildContext(data, snap, detectedAlerts);

      // Build messages for API
      const apiMessages = [
        ...conversationHistory.current.slice(-10), // last 10 turns for context
      ];

      const response = await fetch('/api/ai-accountant/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userPrompt: userText,
          advisorMode: true,
          systemPrompt,
          conversationHistory: apiMessages,
          accounts: data.accounts?.slice(0, 50),
          metadata_session: {
            user_role_permissions: 'Admin',
            mode: 'financial_advisor',
          },
        }),
      });

      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.error || 'خطأ في الاتصال بالمستشار الذكي');
      }

      const result = await response.json();
      const advisorText = result.explanation || result.advice || result.text || 'لم أتمكن من معالجة طلبك';

      conversationHistory.current.push({ role: 'assistant', content: advisorText });

      const advisorMsg: AdvisorMessage = {
        id: `a-${Date.now()}`,
        role: 'advisor',
        content: advisorText,
        timestamp: new Date(),
        alerts: detectedAlerts.filter(a => a.severity === 'critical'),
        metrics: snap,
        suggestions: result.suggestions || [],
      };

      setMessages(prev => [...prev, advisorMsg]);

    } catch (err: any) {
      setMessages(prev => [...prev, {
        id: `e-${Date.now()}`,
        role: 'advisor',
        content: `عذراً، حدث خطأ: ${err.message}`,
        timestamp: new Date(),
      }]);
    } finally {
      setIsLoading(false);
    }
  }, [companyId, isLoading, loadCompanyData]);

  // ── Full diagnosis ─────────────────────────────────────────────
  const runFullDiagnosis = useCallback(async () => {
    await sendMessage(
      'قم بتشخيص مالي شامل للشركة: الوضع المالي العام، نقاط القوة، نقاط الضعف، المخاطر، والتوصيات الاستراتيجية للأشهر الثلاثة القادمة.'
    );
  }, [sendMessage]);

  const clearChat = useCallback(() => {
    setMessages([]);
    conversationHistory.current = [];
  }, []);

  return {
    messages, isLoading, snapshot, alerts,
    sendMessage, runFullDiagnosis, clearChat,
  };
}
