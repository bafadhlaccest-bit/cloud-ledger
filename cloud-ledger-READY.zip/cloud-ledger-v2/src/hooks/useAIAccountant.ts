import { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { useSettings } from '../context/SettingsContext';
import { useAuthStore } from '../store/useAuthStore';
import { db, collection, addDoc, onSnapshot, serverTimestamp, doc } from '../firebase';
import { useRBAC } from './useRBAC';

export interface Account {
  id: string;
  code: string;
  name: string;
  type: string;
  description?: string;
  balance?: number;
  status?: string;
}

export interface Message {
  id: string;
  sender: 'user' | 'system';
  text: string;
  timestamp: Date;
  file?: {
    name: string;
    type: string;
    size: string;
  };
  journal?: {
    date: string;
    reference: string;
    description: string;
    totalDebit: number;
    totalCredit: number;
    lines: Array<{
      accountId: string;
      accountName: string;
      accountCode: string;
      debit: number;
      credit: number;
      description: string;
    }>;
  } | null;
  proposedNewAccount?: {
    name: string;
    type: string;
    parentId: string;
    description?: string;
  } | null;
  settingsUpdate?: {
    key: 'companyProfile' | 'modulesMap';
    updatedFields: any;
  } | null;
  executedAction?: {
    success: boolean;
    customerId?: string;
    supplierId?: string;
    invoiceNo?: string;
    journalId?: string;
    actionTaken?: string;
    tableName?: string;
    data?: any;
    record?: any;
    header?: any;
    categories?: any[];
    statementType?: string;
    period?: string;
    totalRevenue?: number;
    totalExpense?: number;
    netProfit?: number;
    totalAssets?: number;
    totalLiabilities?: number;
    totalEquity?: number;
  } | null;
  forecast?: {
    title: string;
    type: 'Revenue' | 'CashFlow';
    data: Array<{
      name: string;
      value: number;
      projected: number;
      isForecast: boolean;
    }>;
  } | null;
  saveState?: 'none' | 'confirming' | 'saving' | 'saved' | 'cancelled';
  savedEntryId?: string;
}

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export function useAIAccountant(userRole: 'Admin' | 'Accountant' | 'Auditor' | 'Vendor') {
  const { companyId } = useRBAC();
  const { t, i18n } = useTranslation();
  const { settings } = useSettings();
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-welcome',
      sender: 'system',
      text: '',
      timestamp: new Date()
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [activeFile, setActiveFile] = useState<{ name: string; type: string; base64: string; size: string; textParsed?: string } | null>(null);
  const [ocrStage, setOcrStage] = useState<'idle' | 'reading' | 'mapping' | 'done'>('idle');
  const [ocrLogs, setOcrLogs] = useState<string[]>([]);
  const [recentSavedDrafts, setRecentSavedDrafts] = useState<Array<{ id: string; reference: string; desc: string; total: number }>>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Synchronize accounts from database
  useEffect(() => {
    if (!isAuthenticated) return;
    return onSnapshot(collection(db, 'accounts'), (snap) => {
      const list: Account[] = [];
      snap.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as Account);
      });
      setAccounts(list);
    }, (error) => {
      console.warn("Account live feed offline:", error.message);
    });
  }, [isAuthenticated]);

  // Welcome message updates
  useEffect(() => {
    const isAr = i18n.language === 'ar';
    const welcomeText = isAr
      ? `مرحباً بك في مساعد الذكاء الاصطناعي المحاسبي لمنصة Cloud Ledger! 👋
أنا هنا لمساعدتك في أتمتة الأعمال المحاسبية اليومية، وقراءة وفحص المستندات مثل فواتير الموردين والكهرباء وتذاكر السفر بكل سهولة.

💡 **أبرز الإمكانيات المتاحة:**
1. قراءة وتحليل الفواتير والمستندات الورقية عبر تقنية OCR.
2. اقتراح قيود اليومية المزدوجة ومطابقتها تلقائياً مع دليل الحسابات النشط في النظام.
3. الترحيل الفوري المباشر كمسودة لتأكيد الحسابات وحفظها.

يمكنك طرح أي سؤال محاسبي، أو سحب وإفلات أي فاتورة هنا للبدء مباشرة!`
      : `Welcome to the Cloud Ledger AI Accountant Assistant! 👋
I am here to help you automate daily accounting tasks, read and analyze documents like supplier invoices, utility bills, and travel tickets with ease.

💡 **Key Features Available:**
1. Read and analyze paper invoices & documents using OCR.
2. Propose balanced double-entry journals and map them automatically to active accounts.
3. Instant ledger posting as draft to confirm and save entries.

You can ask any accounting question, or drag and drop any invoice here to start right away!`;

    setMessages(prev => {
      const exists = prev.some(m => m.id === 'msg-welcome');
      if (exists) {
        return prev.map(m => m.id === 'msg-welcome' ? { ...m, text: welcomeText } : m);
      } else {
        return [
          { id: 'msg-welcome', sender: 'system', text: welcomeText, timestamp: new Date() },
          ...prev
        ];
      }
    });
  }, [i18n.language]);

  const generateAccountCode = (type: string) => {
    const typeAccounts = accounts.filter(a => a.type.toLowerCase() === type.toLowerCase());
    const codes = typeAccounts.map(a => parseInt(a.code)).filter(c => !isNaN(c));
    let maxCode = 0;
    if (codes.length > 0) {
      maxCode = Math.max(...codes);
    } else {
      const lower = type.toLowerCase();
      if (lower === 'asset') maxCode = 1000;
      else if (lower === 'liability') maxCode = 2000;
      else if (lower === 'equity') maxCode = 3000;
      else if (lower === 'income') maxCode = 4000;
      else if (lower === 'expense') maxCode = 5000;
      else maxCode = 5000;
    }
    let nextCode = maxCode + 1;
    while (accounts.some(a => a.code === nextCode.toString().padStart(4, '0'))) {
      nextCode++;
    }
    return nextCode.toString().padStart(4, '0');
  };

  const applySystemSettingsUpdate = async (update: { key: 'companyProfile' | 'modulesMap'; updatedFields: any }) => {
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(update)
      });
    } catch (err) {
      console.error("Failed to write setts update", err);
    }
  };

  const sendMessage = async (customText?: string, attachment?: { name: string; type: string; base64: string; size: string; textParsed?: string }) => {
    const textToSend = customText !== undefined ? customText : inputText;
    if (!textToSend.trim() && !attachment) return;

    // Secure Standard Role check: standard vendors shouldn't fetch ledgers or do general operations
    if (userRole === 'Vendor' && textToSend.toLowerCase().includes('ledger')) {
      const errId = `sys-err-${Date.now()}`;
      setMessages(prev => [...prev, {
        id: errId,
        sender: 'system',
        text: "عذراً! ليس لديك الصلاحية لاستعراض تقارير الأستاذ العام أو الحسابات الحساسة.",
        timestamp: new Date()
      }]);
      return;
    }

    // append user message representation
    const userMsgId = `usr-${Date.now()}`;
    const userMsg: Message = {
      id: userMsgId,
      sender: 'user',
      text: textToSend,
      timestamp: new Date(),
      file: attachment ? { name: attachment.name, type: attachment.type, size: attachment.size } : undefined
    };

    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);
    setInputText('');
    setActiveFile(null);

    if (attachment) {
      setOcrStage('reading');
      setOcrLogs(["بدء سحب المعرف البصري للمستند...", "جاري فك تشفير الفاتورة واستخراج الكلمات المفتاحية..."]);
      await sleep(1000);
      setOcrLogs(prev => [...prev, "تحديد المورد وتصنيف مجموع الأوعية الضريبية...", "جاري مطابقة بنود الفاتورة بالحسابات المطابقة..."]);
      setOcrStage('mapping');
    }

    try {
      const payload = {
        prompt: textToSend,
        file: attachment ? { name: attachment.name, type: attachment.type, base64: attachment.base64 } : undefined,
        mimeType: attachment?.type || undefined,
        textParsed: attachment?.textParsed || undefined,
        accounts: accounts,
        metadata_session: {
          active_company_id: settings?.systemName || 'Al-Huraibi Trading HQ',
          user_role_permissions: userRole,
          fiscal_year_context: '2026',
          active_route_module: '/ai-accountant'
        }
      };

      const response = await fetch("/api/ai-accountant/parse", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorJson = await response.json();
        throw new Error(errorJson.error || "خطأ غير معروف في خادم الذكاء الاصطناعي");
      }

      const answer = await response.json();
      await sleep(500);
      setOcrLogs(prev => [...prev, "تم تصميم قيد القيد المزدوج المتوازن والتشهير بنجاح!"]);
      setOcrStage('done');

      if (answer.settingsUpdate) {
        await applySystemSettingsUpdate(answer.settingsUpdate);
      }

      const systemMsgId = `sys-${Date.now()}`;
      setMessages(prev => [...prev, {
        id: systemMsgId,
        sender: 'system',
        text: answer.explanation || "تم معالجة المستند بنجاح.",
        timestamp: new Date(),
        journal: answer.journal || null,
        proposedNewAccount: answer.proposedNewAccount || null,
        settingsUpdate: answer.settingsUpdate || null,
        executedAction: answer.executedAction || null,
        forecast: answer.forecast || null,
        saveState: answer.journal ? 'confirming' : 'none'
      }]);

    } catch (err: any) {
      console.error("AI accountant chat error", err);
      setOcrStage('idle');
      setMessages(prev => [...prev, {
        id: `sys-err-${Date.now()}`,
        sender: 'system',
        text: `عذراً، حدث خطأ أثناء إجراء الجلسة المحاسبية. يرجى مراجعة إعدادات مفتاح API الخاص بك في لوحة الإعدادات أو المحاولة مرة أخرى لاحقاً.\nالخطأ: ${err.message || String(err)}`,
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
      setTimeout(() => setOcrStage('idle'), 3000);
    }
  };

  const commitJournalToDatabase = async (msgId: string, journal: any, proposedNewAccount?: any) => {
    setMessages(prev => prev.map(m => m.id === msgId ? { ...m, saveState: 'saving' } : m));

    try {
      let activeLines = [...journal.lines];

      if (proposedNewAccount) {
        const nextAccountCode = generateAccountCode(proposedNewAccount.type);
        const accountDocRef = await addDoc(collection(db, 'accounts'), {
          code: nextAccountCode,
          name: proposedNewAccount.name,
          type: proposedNewAccount.type,
          parentId: proposedNewAccount.parentId || 'root',
          description: proposedNewAccount.description || 'Auto-created by Autonomous Financial Agent',
          balance: 0,
          status: 'active',
          companyId: companyId,
          createdAt: serverTimestamp()
        });

        const newAccountId = accountDocRef.id;
        activeLines = activeLines.map((line: any) => {
          if (line.accountId === 'PENDING_NEW_ACCOUNT') {
            return {
              ...line,
              accountId: newAccountId,
              accountCode: nextAccountCode,
              accountName: proposedNewAccount.name
            };
          }
          return line;
        });
      }

      const formattedLines = activeLines.map((l: any) => ({
        accountId: l.accountId || '',
        accountName: l.accountName || 'Unknown mapping',
        accountCode: l.accountCode || '',
        debit: parseFloat(l.debit) || 0,
        credit: parseFloat(l.credit) || 0,
        description: l.description || journal.description,
        taxRate: 0,
        taxLabel: 'No Tax (0%)',
        region: 'None',
        department: 'None'
      }));

      const firestorePayload = {
        date: journal.date || new Date().toISOString().split('T')[0],
        reference: journal.reference || `AI-REF-${Date.now()}`,
        description: journal.description || 'AI Auto Ingested manual entry',
        totalDebit: parseFloat(journal.totalDebit) || 0,
        totalCredit: parseFloat(journal.totalCredit) || 0,
        status: 'Draft',
        companyId: companyId,
        taxTreatment: 'NoTax',
        autoReverse: false,
        lines: formattedLines,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        isRepeating: false,
        repeatInterval: 1,
        repeatUnit: 'Months',
        repeatsEndType: 'Infinite',
        repeatsEndDate: '',
        repeatsEndCount: 10,
        repeatsRemainingCount: null,
        nextJournalDate: '',
        isRepeatingActive: false,
        saveAsStatus: 'Draft'
      };

      const docRef = await addDoc(collection(db, 'journalEntries'), firestorePayload);

      await fetch("/api/journal-entries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: docRef.id,
          date: firestorePayload.date,
          reference: firestorePayload.reference,
          description: firestorePayload.description,
          lines: formattedLines
        })
      });

      setMessages(prev => prev.map(m => m.id === msgId ? { 
        ...m, 
        saveState: 'saved', 
        savedEntryId: docRef.id 
      } : m));

      setRecentSavedDrafts(prev => [
        {
          id: docRef.id,
          reference: firestorePayload.reference,
          desc: firestorePayload.description,
          total: firestorePayload.totalDebit
        },
        ...prev
      ]);

    } catch (err: any) {
      console.error("Failed to commit AI entry", err);
      alert("Error committing transaction to accounting database.");
      setMessages(prev => prev.map(m => m.id === msgId ? { ...m, saveState: 'none' } : m));
    }
  };

  const cancelJournalTransaction = (msgId: string) => {
    setMessages(prev => prev.map(m => m.id === msgId ? { ...m, saveState: 'cancelled' } : m));
  };

  return {
    messages,
    inputText,
    setInputText,
    accounts,
    isLoading,
    isRecording,
    setIsRecording,
    activeFile,
    setActiveFile,
    ocrStage,
    ocrLogs,
    recentSavedDrafts,
    sendMessage,
    commitJournalToDatabase,
    cancelJournalTransaction,
    messagesEndRef,
    fileInputRef
  };
}
