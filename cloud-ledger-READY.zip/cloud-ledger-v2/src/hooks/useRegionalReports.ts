import { useState, useEffect } from 'react';
import { supabase } from '../services/supabaseClient';

export function useRegionalReports(companyId: string) {
  const [regionsData, setRegionsData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchRegionalData() {
      setLoading(true);
      try {
        // جلب أسطر القيود مجمعة بحسب المحافظة/الفرع والحساب
        // نستخدم .eq بدلاً من .character لتوافقية مكتبة Supabase JS
        const { data: lines, error } = await supabase
          .from('journal_lines')
          .select(`
            branch_id,
            debit,
            credit,
            accounts (id, name, classification, company_id)
          `)
          .eq('accounts.company_id', companyId);

        if (error) {
          console.error("فشل جلب تقارير المحافظات:", error);
          setLoading(false);
          return;
        }

        // تجميع البيانات بحسب المحافظة (صنعاء، عدن، إلخ)
        const groupedByRegion = (lines || []).reduce((acc: any, line: any) => {
          const region = line.branch_id || 'المركز الرئيسي / غير محدد';
          if (!acc[region]) {
            acc[region] = { regionName: region, totalAssets: 0, totalRevenue: 0, totalExpenses: 0 };
          }

          const classification = line.accounts?.classification;
          const debit = Number(line.debit) || 0;
          const credit = Number(line.credit) || 0;

          if (classification === 'ASSETS') {
            acc[region].totalAssets += (debit - credit);
          } else if (classification === 'REVENUE') {
            acc[region].totalRevenue += (credit - debit);
          } else if (classification === 'EXPENSES' || classification === 'COGS') {
            acc[region].totalExpenses += (debit - credit);
          }

          return acc;
        }, {});

        setRegionsData(Object.values(groupedByRegion));
      } catch (err) {
        console.error("حدث خطأ غير متوقع أثناء معالجة البيانات الإقليمية:", err);
      } finally {
        setLoading(false);
      }
    }

    if (companyId) {
      fetchRegionalData();
    } else {
      setRegionsData([]);
      setLoading(false);
    }
  }, [companyId]);

  return { regionsData, loading };
}

// تصدير متوافق بالاسم الدقيق المبتدئ بحرف كبير المطلوب كما هو في الكود المرفق
export { useRegionalReports as UseRegionalReports };
