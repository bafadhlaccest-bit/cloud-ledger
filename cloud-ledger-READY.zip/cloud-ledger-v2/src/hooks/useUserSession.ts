import { useAuthStore } from '../store/useAuthStore';

export function useUserSession() {
  const { user } = useAuthStore();
  const role = user?.role || 'viewer';

  // Determine permission tokens based on user roles
  const userPermissions: string[] = [];

  if (role === 'admin') {
    userPermissions.push('ACCESS_EXECUTIVE_KPI', 'ACCESS_FINANCIAL_METRICS');
  } else if (role === 'accountant') {
    userPermissions.push('ACCESS_FINANCIAL_METRICS');
  }

  return {
    user,
    role,
    userPermissions,
  };
}
