import { useAuthStore } from '../store/useAuthStore';
import { useSettingsStore } from '../store/useSettingsStore';
import { supabase } from '../lib/supabase';
import React from 'react';

export function useRBAC() {
  const { user } = useAuthStore();
  const { permissionsMatrix } = useSettingsStore();
  const [realCompanyId, setRealCompanyId] = React.useState<string>('default-company');

  // Get company_id from Supabase session metadata
  React.useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      const cid = data.session?.user?.user_metadata?.company_id;
      if (cid) setRealCompanyId(cid);
    });
  }, []);

  // Fallback: use from user store if available
  const companyId = (user as any)?.companyId || realCompanyId;
  const userRole = user?.role || 'admin'; // default admin for dev

  const getMatrixRoleKey = (): 'Admin' | 'Accountant' | 'Vendor' => {
    const r = userRole.toLowerCase();
    if (r === 'admin') return 'Admin';
    if (r === 'accountant') return 'Accountant';
    return 'Vendor';
  };

  const activeRoleKey = getMatrixRoleKey();
  const rolePermissions = permissionsMatrix[activeRoleKey] || {
    read: true, create: true, update: true, delete: true
  };

  const canPerform = (action: 'read' | 'create' | 'update' | 'delete'): boolean => {
    if (userRole === 'admin') return true;
    return !!rolePermissions[action];
  };

  const canAccessScreen = (path: string): boolean => {
    const normalized = path.replace(/^\/|\/$/g, '').split('/')[0];
    const roleLower = userRole.toLowerCase();
    if (roleLower === 'admin') return true;
    if (roleLower === 'accountant') return !['settings', 'integrations'].includes(normalized);
    if (roleLower === 'sales') return ['sales', 'customers', 'items', ''].includes(normalized);
    if (roleLower === 'purchases') return ['purchases', 'vendors', 'items', ''].includes(normalized);
    return ['', 'customers', 'vendors', 'items'].includes(normalized);
  };

  // Fix: compare both company_id and companyId, and treat 'default-company' as wildcard
  const validateRowSecurity = (row: any): boolean => {
    if (!row) return true;
    const rowCid = row.companyId || row.company_id;
    if (!rowCid || rowCid === 'default-company') return true;
    return rowCid === companyId;
  };

  const isFieldEditable = (field: string): boolean => {
    const roleLower = userRole.toLowerCase();
    if (roleLower === 'admin') return true;
    const criticalFields = [
      'defaultSalesAccountId','defaultPayableAccountId','defaultCashAccountId',
      'vatPercentage','currency','permissionsMatrix','budget'
    ];
    if (criticalFields.includes(field)) return roleLower === 'accountant';
    return canPerform('update');
  };

  return {
    userRole,
    companyId,
    rolePermissions,
    canPerform,
    canAccessScreen,
    validateRowSecurity,
    isFieldEditable,
  };
}
