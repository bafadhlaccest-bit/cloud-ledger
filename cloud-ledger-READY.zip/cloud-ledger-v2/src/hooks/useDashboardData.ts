/**
 * useDashboardData — بيانات حقيقية للـ Dashboard من Supabase
 */
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useRBAC } from './useRBAC';

export interface DashboardStats {
  // Revenue
  totalRevenue: number;
  revenueThisMonth: number;
  revenueLastMonth: number;
  revenueGrowth: number;
  // Expenses
  totalExpenses: number;
  expensesThisMonth: number;
  // Profit
  netIncome: number;
  netMargin: number;
  // AR/AP
  totalReceivables: number;
  totalPayables: number;
  overdueReceivables: number;
  // Invoices
  totalInvoices: number;
  paidInvoices: number;
  overdueInvoices: number;
  draftInvoices: number;
  // Cash
  cashBalance: number;
  // Customers/Vendors
  totalCustomers: number;
  totalVendors: number;
  totalItems: number;
  // Monthly trend (last 6 months)
  monthlyTrend: Array<{ month: string; revenue: number; expenses: number; profit: number }>;
  // Top customers by revenue
  topCustomers: Array<{ name: string; total: number }>;
  // Recent invoices
  recentInvoices: Array<{ id: string; number: string; customer: string; total: number; status: string; date: string }>;
  isLoading: boolean;
  error: string | null;
}

const EMPTY: DashboardStats = {
  totalRevenue: 0, revenueThisMonth: 0, revenueLastMonth: 0, revenueGrowth: 0,
  totalExpenses: 0, expensesThisMonth: 0,
  netIncome: 0, netMargin: 0,
  totalReceivables: 0, totalPayables: 0, overdueReceivables: 0,
  totalInvoices: 0, paidInvoices: 0, overdueInvoices: 0, draftInvoices: 0,
  cashBalance: 0,
  totalCustomers: 0, totalVendors: 0, totalItems: 0,
  monthlyTrend: [], topCustomers: [], recentInvoices: [],
  isLoading: true, error: null,
};

export function useDashboardData(): DashboardStats {
  const { companyId } = useRBAC();
  const [stats, setStats] = useState<DashboardStats>(EMPTY);

  useEffect(() => {
    if (!companyId) return;
    load();
  }, [companyId]);

  async function load() {
    setStats(s => ({ ...s, isLoading: true, error: null }));
    try {
      const now = new Date();
      const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
      const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().slice(0, 10);
      const lastMonthEnd   = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().slice(0, 10);
      const sixMonthsAgo   = new Date(now.getFullYear(), now.getMonth() - 5, 1).toISOString().slice(0, 10);

      const [
        { data: invoices },
        { data: bills },
        { data: customers },
        { data: vendors },
        { data: items },
        { data: bankAccounts },
        { data: journalLines },
      ] = await Promise.all([
        supabase.from('invoices').select('id,number,total,status,date,customer_id').eq('company_id', companyId),
        supabase.from('bills').select('id,total,status,due_date').eq('company_id', companyId),
        supabase.from('customers').select('id,name').eq('company_id', companyId),
        supabase.from('vendors').select('id').eq('company_id', companyId),
        supabase.from('items').select('id').eq('company_id', companyId),
        supabase.from('bank_accounts').select('id,balance,current_balance').eq('company_id', companyId),
        supabase.from('journal_lines').select('account_id,debit,credit,journal_entries(date,status)').eq('company_id', companyId),
      ]);

      const inv = invoices || [];
      const bl  = bills    || [];

      // Revenue = paid + sent invoices
      const paidInv   = inv.filter(i => ['Paid', 'Sent', 'Posted'].includes(i.status));
      const totalRevenue    = paidInv.reduce((s, i) => s + Number(i.total || 0), 0);
      const revenueThisMonth = paidInv.filter(i => i.date >= thisMonthStart).reduce((s, i) => s + Number(i.total || 0), 0);
      const revenueLastMonth = paidInv.filter(i => i.date >= lastMonthStart && i.date <= lastMonthEnd).reduce((s, i) => s + Number(i.total || 0), 0);
      const revenueGrowth = revenueLastMonth > 0 ? ((revenueThisMonth - revenueLastMonth) / revenueLastMonth) * 100 : 0;

      // Expenses from bills
      const totalExpenses = bl.filter(b => b.status !== 'Cancelled').reduce((s, b) => s + Number(b.total || 0), 0);
      const expensesThisMonth = bl.filter(b => b.status !== 'Cancelled').reduce((s, b) => s + Number(b.total || 0), 0);

      // AR/AP
      const totalReceivables = inv.filter(i => i.status === 'Sent').reduce((s, i) => s + Number(i.total || 0), 0);
      const overdueReceivables = inv.filter(i => i.status === 'Sent' && i.date < new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10)).reduce((s, i) => s + Number(i.total || 0), 0);
      const totalPayables = bl.filter(b => b.status === 'Unpaid').reduce((s, b) => s + Number(b.total || 0), 0);

      // Cash balance from bank accounts
      const cashBalance = (bankAccounts || []).reduce((s, a) => s + Number(a.current_balance || a.balance || 0), 0);

      // Net
      const netIncome = totalRevenue - totalExpenses;
      const netMargin = totalRevenue > 0 ? (netIncome / totalRevenue) * 100 : 0;

      // Monthly trend (last 6 months)
      const monthlyTrend = [];
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const start = d.toISOString().slice(0, 7); // YYYY-MM
        const label = d.toLocaleDateString('ar-SA', { month: 'short', year: '2-digit' });
        const rev = paidInv.filter(x => x.date?.startsWith(start)).reduce((s, x) => s + Number(x.total || 0), 0);
        const exp = bl.filter(x => (x as any).date?.startsWith(start)).reduce((s, x) => s + Number(x.total || 0), 0);
        monthlyTrend.push({ month: label, revenue: rev, expenses: exp, profit: rev - exp });
      }

      // Top customers by revenue
      const custRevMap: Record<string, number> = {};
      paidInv.forEach(i => {
        if (i.customer_id) custRevMap[i.customer_id] = (custRevMap[i.customer_id] || 0) + Number(i.total || 0);
      });
      const custMap: Record<string, string> = {};
      (customers || []).forEach(c => { custMap[c.id] = c.name; });
      const topCustomers = Object.entries(custRevMap)
        .sort(([, a], [, b]) => b - a).slice(0, 5)
        .map(([id, total]) => ({ name: custMap[id] || 'عميل', total }));

      // Recent invoices
      const recentInvoices = [...inv]
        .sort((a, b) => (b.date || '').localeCompare(a.date || ''))
        .slice(0, 8)
        .map(i => ({
          id: i.id, number: i.number || '—',
          customer: custMap[i.customer_id] || '—',
          total: Number(i.total || 0),
          status: i.status || 'Draft',
          date: i.date || '',
        }));

      setStats({
        totalRevenue, revenueThisMonth, revenueLastMonth, revenueGrowth,
        totalExpenses, expensesThisMonth,
        netIncome, netMargin,
        totalReceivables, totalPayables, overdueReceivables,
        totalInvoices: inv.length,
        paidInvoices: inv.filter(i => i.status === 'Paid').length,
        overdueInvoices: inv.filter(i => i.status === 'Overdue').length,
        draftInvoices: inv.filter(i => i.status === 'Draft').length,
        cashBalance,
        totalCustomers: (customers || []).length,
        totalVendors: (vendors || []).length,
        totalItems: (items || []).length,
        monthlyTrend, topCustomers, recentInvoices,
        isLoading: false, error: null,
      });
    } catch (err: any) {
      setStats(s => ({ ...s, isLoading: false, error: err.message }));
    }
  }

  return stats;
}
