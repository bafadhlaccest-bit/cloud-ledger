import { useState, useEffect } from 'react';
import { useAuthStore } from '../store/useAuthStore';
import { db, collection, getDocs, query, where } from '../firebase';

export function useRegionalAndFinancialReports() {
  const { user } = useAuthStore();
  const companyId = user?.companyId;
  
  const [reports, setReports] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function compileReports() {
      if (!companyId) {
        setLoading(false);
        return;
      }

      try {
        // جلب قيود اليومية للشركة المحددة فقط
        const q = query(collection(db, 'journal_entries'), where('companyId', '==', companyId));
        const querySnapshot = await getDocs(q);
        
        let revenue = 0;
        let cogs = 0;
        let expenses = 0;
        let branchData: any = {};

        querySnapshot.forEach((docSnap) => {
          const entry = docSnap.data();
          
          // افتراض أن الأسطر موجودة داخل القيد (Sub-collection أو Array)
          if (entry.lines && Array.isArray(entry.lines)) {
            entry.lines.forEach((line: any) => {
              const debit = Number(line.debit) || 0;
              const credit = Number(line.credit) || 0;
              const branch = line.branch_id || 'المركز الرئيسي';

              // تجميع البيانات بحسب الفروع/المحافظات
              if (!branchData[branch]) {
                branchData[branch] = { branchName: branch, totalDebit: 0, totalCredit: 0 };
              }
              branchData[branch].totalDebit += debit;
              branchData[branch].totalCredit += credit;

              // تجميع القوائم المالية بناءً على المعايير الدولية للشجرة
              if (line.classification === 'REVENUE') revenue += (credit - debit);
              if (line.classification === 'COGS') cogs += (debit - credit);
              if (line.classification === 'EXPENSES') expenses += (debit - credit);
            });
          }
        });

        setReports({
          incomeStatement: { revenue, cogs, netProfit: (revenue - cogs) - expenses },
          branches: Object.values(branchData)
        });
        setLoading(false);
      } catch (err) {
        console.error("خطأ تجميع قيود الـ Firestore:", err);
        setLoading(false);
      }
    }

    compileReports();
  }, [companyId]);

  return { reports, loading };
}
