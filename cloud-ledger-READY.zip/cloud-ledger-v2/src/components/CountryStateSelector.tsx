import React, { useState, useEffect } from 'react';
import { countries, states, CountryData, StateData } from '../data/countryStateData';

interface CountryStateSelectorProps {
  selectedCountryId: string;
  selectedStateId: string;
  onCountryChange: (countryId: string, countryName: string) => void;
  onStateChange: (stateId: string, stateName: string) => void;
  className?: string;
}

export const CountryStateSelector: React.FC<CountryStateSelectorProps> = ({
  selectedCountryId,
  selectedStateId,
  onCountryChange,
  onStateChange,
  className = "p-2 border rounded-lg bg-white text-right dir-rtl w-full focus:ring-2 focus:ring-indigo-500 text-slate-800"
}) => {
  const [filteredStates, setFilteredStates] = useState<StateData[]>([]);

  // فلترة المحافظات تلقائياً فور اختيار أو تغيير الدولة
  useEffect(() => {
    if (selectedCountryId) {
      // الربط بين معرف الدولة ومعرف المحافظة المذكور في ملف states.csv الخاص بك
      const result = states.filter(
        (state) => String(state.countryId) === String(selectedCountryId)
      );
      setFilteredStates(result);
    } else {
      setFilteredStates([]);
    }
  }, [selectedCountryId]);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full text-right" dir="rtl">
      {/* 1. قائمة اختيار الدولة */}
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold text-slate-700">الدولة:</label>
        <select
          value={selectedCountryId}
          onChange={(e) => {
            const cId = e.target.value;
            const countryObj = countries.find(c => String(c.id) === String(cId));
            onCountryChange(cId, countryObj ? countryObj.name : '');
            // تصفير المحافظة عند تغيير الدولة لمنع التضارب
            onStateChange('', '');
          }}
          className={className}
        >
          <option value="" className="text-slate-500">-- اختر الدولة --</option>
          {countries.map((country) => (
            <option key={country.id} value={country.id} className="text-slate-800">
              {country.name === "Yemen" || country.name === "اليمن" ? "اليمن 🇾🇪" : country.name}
            </option>
          ))}
        </select>
      </div>

      {/* 2. قائمة اختيار المحافظة / الولاية المفلترة */}
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold text-slate-700">المحافظة / الولاية:</label>
        <select
          value={selectedStateId}
          onChange={(e) => {
            const sId = e.target.value;
            const stateObj = filteredStates.find(s => String(s.id) === String(sId));
            onStateChange(sId, stateObj ? stateObj.name : '');
          }}
          className={className}
          disabled={!selectedCountryId}
        >
          <option value="" className="text-slate-500">
            {selectedCountryId ? "-- اختر المحافظة --" : "⚠️ يرجى اختيار الدولة أولاً"}
          </option>
          {filteredStates.map((state) => (
            <option key={state.id} value={state.id} className="text-slate-800">
              {state.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
};
