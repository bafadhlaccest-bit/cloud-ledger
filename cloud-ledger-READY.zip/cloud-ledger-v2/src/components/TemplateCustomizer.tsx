import React from 'react';
import { 
  Palette, 
  Type, 
  EyeOff, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  FileText, 
  Trash2,
  Sliders,
  Check
} from 'lucide-react';

const GOOGLE_FONTS = [
  { id: 'Inter', name: 'Inter (Sans-serif)' },
  { id: 'Tajawal', name: 'Tajawal (Arabic & English)' },
  { id: 'Roboto', name: 'Roboto (Modern Sans)' },
  { id: 'Arial', name: 'Arial (Classic Sans)' },
  { id: 'Courier New', name: 'Courier New (Monospace)' }
];

const PRESET_PRIMARY_COLORS = [
  { value: '#4f46e5', name: 'Indigo' },
  { value: '#0284c7', name: 'Sky Blue' },
  { value: '#059669', name: 'Emerald' },
  { value: '#e11d48', name: 'Rose Red' },
  { value: '#d97706', name: 'Amber' },
  { value: '#1e293b', name: 'Midnight' }
];

const PRESET_SECONDARY_COLORS = [
  { value: '#475569', name: 'Slate' },
  { value: '#64748b', name: 'Cool Gray' },
  { value: '#14b8a6', name: 'Teal' },
  { value: '#b45309', name: 'Dark Amber' },
  { value: '#4b5563', name: 'Standard Gray' }
];

interface TemplateCustomizerProps {
  settings: {
    templateStyle: 'standard' | 'professional' | 'modern';
    logoUrl: string;
    logoAlignment: 'left' | 'center' | 'right';
    logoSize: 'small' | 'medium' | 'large';
    primaryColor: string;
    secondaryColor: string;
    fontFamily: 'Inter' | 'Arial' | 'Roboto' | 'Tajawal' | 'Courier New';
    hideTaxColumn: boolean;
    hideShippingCharges: boolean;
    hideTermsAndConditions: boolean;
    hideCustomerNotes: boolean;
  };
  onChange: React.Dispatch<React.SetStateAction<any>>;
  onLogoUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function TemplateCustomizer({ settings, onChange, onLogoUpload }: TemplateCustomizerProps) {
  const updateSetting = (key: string, value: any) => {
    onChange((prev: any) => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <div className="space-y-6">
      {/* Customizer Sidebar Heading */}
      <div className="border-b border-slate-100 pb-4">
        <div className="flex items-center gap-2.5 text-indigo-600 mb-1">
          <Palette className="w-5 h-5 text-indigo-600" />
          <h3 className="font-bold text-slate-800 tracking-tight text-sm uppercase">Layout Customize Panel</h3>
        </div>
        <p className="text-xs text-slate-400">Enterprise Style Template Builder</p>
      </div>

      {/* 1. Template Selector */}
      <div className="space-y-2">
        <label className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <Sliders className="w-3.5 h-3.5 text-slate-400" />
          1. Selection Layout
        </label>
        <div className="grid grid-cols-1 gap-2">
          {[
            { id: 'standard', name: 'Standard Style', desc: 'Classic layout perfect for standard businesses' },
            { id: 'professional', name: 'Professional Band', desc: 'Bold primary color background header banner' },
            { id: 'modern', name: 'Modern Minimalist', desc: 'High-end sleek borders and spacious layouts' }
          ].map(tpl => (
            <button
              key={tpl.id}
              type="button"
              onClick={() => updateSetting('templateStyle', tpl.id)}
              className={`w-full text-left p-3 rounded-xl border transition-all ${
                settings.templateStyle === tpl.id
                  ? 'border-indigo-600 bg-indigo-50/50 shadow-sm ring-1 ring-indigo-600'
                  : 'border-slate-100 hover:border-slate-200 bg-white hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-800 capitalize">{tpl.name}</span>
                {settings.templateStyle === tpl.id && (
                  <div className="w-3.5 h-3.5 bg-indigo-600 text-white rounded-full flex items-center justify-center p-0.5">
                    <Check className="w-2.5 h-2.5" />
                  </div>
                )}
              </div>
              <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">{tpl.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Company Signature Branding */}
      <div className="space-y-4 pt-1">
        <label className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <FileText className="w-3.5 h-3.5 text-slate-400" />
          2. Branding & Logo
        </label>
        
        {/* Logo selector box */}
        <div className="p-4 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200 space-y-3">
          {settings.logoUrl ? (
            <div className="space-y-2">
              <div className="relative bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-center h-20 group">
                <img src={settings.logoUrl} alt="Logo preview" className="max-h-full max-w-full object-contain" />
                <button
                  type="button"
                  onClick={() => updateSetting('logoUrl', '')}
                  className="absolute top-1 right-1 bg-rose-600 text-white p-1 rounded-full hover:bg-rose-700 transition shadow"
                  title="Remove logo"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
              <p className="text-[10px] text-emerald-600 font-bold text-center">✓ Logo Uploaded Successfully</p>
            </div>
          ) : (
            <label className="flex flex-col items-center justify-center py-4 px-2 border border-dashed border-slate-300 rounded-xl hover:bg-slate-100/50 cursor-pointer text-slate-400 transition select-none bg-white">
              <span className="text-[10px] font-bold text-slate-600">Select Image File</span>
              <span className="text-[9px] text-slate-400 mt-0.5">PNG, JPG recommended</span>
              <input 
                type="file" 
                accept="image/*" 
                onChange={onLogoUpload} 
                className="hidden" 
              />
            </label>
          )}

          {/* Alignment controls */}
          {settings.logoUrl && (
            <div className="space-y-2 pt-2">
              <span className="text-[10.5px] font-bold text-slate-600 block">Logo Alignment</span>
              <div className="grid grid-cols-3 gap-1 bg-white p-0.5 rounded-lg border border-slate-200">
                {(['left', 'center', 'right'] as const).map(align => (
                  <button
                    key={align}
                    type="button"
                    onClick={() => updateSetting('logoAlignment', align)}
                    className={`py-1 flex items-center justify-center rounded-md text-[10px] font-semibold transition ${
                      settings.logoAlignment === align 
                        ? 'bg-indigo-600 text-white shadow-sm' 
                        : 'text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    {align === 'left' && <AlignLeft className="w-3 h-3 mr-1" />}
                    {align === 'center' && <AlignCenter className="w-3 h-3 mr-1" />}
                    {align === 'right' && <AlignRight className="w-3 h-3 mr-1" />}
                    <span className="capitalize">{align}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Size controls */}
          {settings.logoUrl && (
            <div className="space-y-2">
              <span className="text-[10.5px] font-bold text-slate-600 block">Logo Size Scale</span>
              <div className="grid grid-cols-3 gap-1 bg-white p-0.5 rounded-lg border border-slate-200">
                {(['small', 'medium', 'large'] as const).map(sz => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => updateSetting('logoSize', sz)}
                    className={`py-1 text-center rounded-md text-[10px] font-bold transition capitalize ${
                      settings.logoSize === sz 
                        ? 'bg-indigo-600 text-white shadow-sm' 
                        : 'text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. Color pickers */}
      <div className="space-y-4 pt-1">
        <label className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <Palette className="w-3.5 h-3.5 text-slate-400" />
          3. Colors & Typography
        </label>
        
        {/* Primary Color selection */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-slate-600">Primary Theme Color</span>
            <div className="flex items-center gap-1.5 border rounded-lg px-2 py-0.5 bg-white shadow-sm">
              <input 
                type="color" 
                value={settings.primaryColor}
                onChange={(e) => updateSetting('primaryColor', e.target.value)}
                className="w-5 h-5 border-none outline-none rounded cursor-pointer bg-transparent"
              />
              <span className="font-mono text-[10px] font-bold text-slate-400 uppercase">{settings.primaryColor}</span>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 pt-1">
            {PRESET_PRIMARY_COLORS.map(c => (
              <button
                key={c.value}
                type="button"
                onClick={() => updateSetting('primaryColor', c.value)}
                style={{ backgroundColor: c.value }}
                className={`w-5 h-5 rounded-full transition-transform hover:scale-110 shadow-sm relative ${
                  settings.primaryColor === c.value ? 'ring-2 ring-indigo-500 ring-offset-2' : ''
                }`}
                title={c.name}
              >
                {settings.primaryColor === c.value && (
                  <span className="absolute inset-0 flex items-center justify-center text-white text-[10px] font-black">✓</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Secondary Color selection */}
        <div className="space-y-2 pt-1">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-slate-600">Secondary Text Color</span>
            <div className="flex items-center gap-1.5 border rounded-lg px-2 py-0.5 bg-white shadow-sm">
              <input 
                type="color" 
                value={settings.secondaryColor}
                onChange={(e) => updateSetting('secondaryColor', e.target.value)}
                className="w-5 h-5 border-none outline-none rounded cursor-pointer bg-transparent"
              />
              <span className="font-mono text-[10px] font-bold text-slate-400 uppercase">{settings.secondaryColor}</span>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 pt-1">
            {PRESET_SECONDARY_COLORS.map(c => (
              <button
                key={c.value}
                type="button"
                onClick={() => updateSetting('secondaryColor', c.value)}
                style={{ backgroundColor: c.value }}
                className={`w-5 h-5 rounded-full transition-transform hover:scale-110 shadow-sm relative ${
                  settings.secondaryColor === c.value ? 'ring-2 ring-indigo-400 ring-offset-2' : ''
                }`}
                title={c.name}
              >
                {settings.secondaryColor === c.value && (
                  <span className="absolute inset-0 flex items-center justify-center text-white text-[10px] font-black">✓</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Typography Selector */}
        <div className="space-y-2 pt-1">
          <span className="text-xs font-bold text-slate-600 flex items-center gap-1.5">
            <Type className="w-3.5 h-3.5 text-slate-500" />
            Selected Letter Font
          </span>
          <select
            value={settings.fontFamily}
            onChange={(e) => updateSetting('fontFamily', e.target.value)}
            className="w-full px-3 py-2 border border-slate-200 rounded-xl outline-none text-xs font-bold text-slate-700 bg-white shadow-sm"
          >
            {GOOGLE_FONTS.map(f => (
              <option key={f.id} value={f.id}>{f.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* 4. Display Toggles */}
      <div className="space-y-3 pt-2">
        <label className="text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <EyeOff className="w-3.5 h-3.5 text-slate-400" />
          4. Fields & Column Toggles
        </label>
        
        <div className="p-3 bg-slate-50/50 rounded-2xl border border-slate-100 space-y-2.5">
          {[
            { key: 'hideTaxColumn', label: 'Hide Tax Columns' },
            { key: 'hideShippingCharges', label: 'Hide Shipping Charges' },
            { key: 'hideTermsAndConditions', label: 'Hide Terms & Conditions' },
            { key: 'hideCustomerNotes', label: 'Hide Customer Notes' }
          ].map(field => (
            <label key={field.key} className="flex items-center gap-2.5 cursor-pointer select-none">
              <input 
                type="checkbox"
                checked={!!(settings as any)[field.key]}
                onChange={(e) => updateSetting(field.key, e.target.checked)}
                className="w-4.5 h-4.5 rounded border-slate-200 text-indigo-600 focus:ring-2 focus:ring-indigo-500 bg-white"
              />
              <span className="text-xs font-semibold text-slate-700">{field.label}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}
