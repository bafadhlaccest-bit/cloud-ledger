import React, { ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    const { hasError, error } = this.state;
    // @ts-ignore
    const { children, fallback } = this.props;

    if (hasError) {
      let errorMessage = 'Something went wrong.';
      try {
        const errorData = JSON.parse(error?.message || '');
        if (errorData.error) {
          errorMessage = `Firestore Error: ${errorData.error} during ${errorData.operationType} on ${errorData.path}`;
        }
      } catch (e) {
        errorMessage = error?.message || errorMessage;
      }

      return (
        fallback || (
          <div className="p-8 bg-rose-50 border border-rose-100 rounded-2xl text-rose-700">
            <h2 className="text-xl font-bold mb-2">Application Error</h2>
            <p className="text-sm opacity-80">{errorMessage}</p>
            <button
              onClick={() => window.location.reload()}
              className="mt-4 px-4 py-2 bg-rose-600 text-white rounded-lg font-bold hover:bg-rose-700 transition-colors"
            >
              Reload Application
            </button>
          </div>
        )
      );
    }

    return children;
  }
}
