import React from 'react';
import { RefreshCw, Download, TrendingUp, TrendingDown, AlertCircle } from 'lucide-react';
import { useAccountingReports } from '../../hooks/useAccountingReports';
import * as XLSX from 'xlsx';

interface Props { data?: any[]; isLoading?: boolean; isRtl?: boolean; dateFrom?: string; dateTo?: string; }

export default function ProfitLossTab({ isRtl, dateFrom, dateTo }: Props) {
  const { incomeStatement, isLoading, error, refresh } = useAccountingReports(dateFrom, dateTo);
  const fmt = (n: number) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const isProfit = incomeStatement.netIncome >= 0;
  const grossProfit = incomeStatement.totalRevenue - incomeStatement.expenses.filter(a => a.type.includes('COGS') || a.name.toLowerCase().includes('cost')).reduce((s, a) => s + a.balance, 0);

  const exportExcel = () => {
    const rows = [
      { Item: isRtl ? 'الإيرادات' : 'Revenue', Amount: '' },
      ...incomeStatement.revenue.map(a => ({ Item: a.name, Amount: a.balance })),
      { Item: isRtl ? 'إجمالي الإيرادات' : 'Total Revenue', Amount: incomeStatement.totalRevenue },
      { Item: '', Amount: '' },
      { Item: isRtl ? 'المصروفات' : 'Expenses', Amount: '' },
      ...incomeStatement.expenses.map(a => ({ Item: a.name, Amount: a.balance })),
      { Item: isRtl ? 'إجمالي المصروفات' : 'Total Expenses', Amount: incomeStatement.totalExpenses },
      { Item: '', Amount: '' },
      { Item: isRtl ? 'صافي الربح/الخسارة' : 'Net Income/Loss', Amount: incomeStatement.netIncome },
    ];
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Income Statement');
    XLSX.writeFile(wb, 'income_statement.xlsx');
  };

  if (isLoading) return <div className="flex items-center justify-center py-20 text-slate-400"><RefreshCw className="w-5 h-5 animate-spin mr-2" /><span>{isRtl ? 'جارٍ التحميل...' : 'Loading...'}</span></div>;
  if (error) return <div className="p-4 bg-red-50 rounded-lg text-red-600 text-sm flex items-center gap-2"><AlertCircle className="w-4 h-4" />{error}</div>;

  return (
    <div className="space-y-4" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-800">{isRtl ? 'قائمة الدخل (الربح والخسارة)' : 'Income Statement (P&L)'}</h3>
          <p className="text-xs text-slate-500 mt-0.5">IFRS 15 · {dateFrom || '—'} {isRtl ? 'إلى' : 'to'} {dateTo || isRtl ? 'اليوم' : 'Today'}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className={`flex items-center gap-1 text-sm font-bold px-3 py-1.5 rounded-lg ${isProfit ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
            {isProfit ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            {fmt(Math.abs(incomeStatement.netIncome))} {isProfit ? (isRtl ? 'ربح' : 'Profit') : (isRtl ? 'خسارة' : 'Loss')}
          </span>
          <button onClick={exportExcel} className="flex items-center gap-1 text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700"><Download className="w-3.5 h-3.5" /> Excel</button>
          <button onClick={refresh} className="p-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-500"><RefreshCw className="w-3.5 h-3.5" /></button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue */}
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <div className="bg-emerald-600 text-white px-4 py-3 flex justify-between items-center font-bold">
            <span>{isRtl ? 'الإيرادات' : 'Revenue'}</span>
            <span className="font-mono">{fmt(incomeStatement.totalRevenue)}</span>
          </div>
          <div className="divide-y divide-slate-100">
            {incomeStatement.revenue.length === 0 ? (
              <div className="px-4 py-6 text-center text-slate-400 text-sm">{isRtl ? 'لا توجد إيرادات' : 'No revenue accounts'}</div>
            ) : incomeStatement.revenue.map(a => (
              <div key={a.id} className="flex justify-between px-4 py-2.5 text-sm hover:bg-slate-50">
                <span className="text-slate-600"><span className="text-slate-400 font-mono mr-2">{a.code}</span>{a.name}</span>
                <span className="font-mono text-emerald-700 font-medium">{fmt(a.balance)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Expenses */}
        <div className="border border-slate-200 rounded-xl overflow-hidden">
          <div className="bg-rose-600 text-white px-4 py-3 flex justify-between items-center font-bold">
            <span>{isRtl ? 'المصروفات' : 'Expenses'}</span>
            <span className="font-mono">{fmt(incomeStatement.totalExpenses)}</span>
          </div>
          <div className="divide-y divide-slate-100">
            {incomeStatement.expenses.length === 0 ? (
              <div className="px-4 py-6 text-center text-slate-400 text-sm">{isRtl ? 'لا توجد مصروفات' : 'No expense accounts'}</div>
            ) : incomeStatement.expenses.map(a => (
              <div key={a.id} className="flex justify-between px-4 py-2.5 text-sm hover:bg-slate-50">
                <span className="text-slate-600"><span className="text-slate-400 font-mono mr-2">{a.code}</span>{a.name}</span>
                <span className="font-mono text-rose-700 font-medium">{fmt(a.balance)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: isRtl ? 'إجمالي الإيرادات' : 'Total Revenue', value: incomeStatement.totalRevenue, color: 'emerald' },
          { label: isRtl ? 'إجمالي المصروفات' : 'Total Expenses', value: incomeStatement.totalExpenses, color: 'rose' },
          { label: isRtl ? 'صافي الربح / الخسارة' : 'Net Income / Loss', value: incomeStatement.netIncome, color: isProfit ? 'emerald' : 'red' },
        ].map(item => (
          <div key={item.label} className={`p-4 rounded-xl border-2 ${item.color === 'emerald' ? 'border-emerald-200 bg-emerald-50' : item.color === 'rose' ? 'border-rose-200 bg-rose-50' : isProfit ? 'border-emerald-300 bg-emerald-100' : 'border-red-300 bg-red-100'}`}>
            <div className="text-xs text-slate-500 mb-1">{item.label}</div>
            <div className={`text-xl font-bold font-mono ${item.color === 'rose' ? 'text-rose-700' : isProfit ? 'text-emerald-700' : 'text-red-700'}`}>
              {fmt(Math.abs(item.value))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
