import React, { useState, useEffect } from 'react';
import { useAccounting } from '../../context/AccountingContext';
import { JournalLine } from '../../services/PostingEngine';
import { useAuthStore } from '../../store/useAuthStore';
import { handleFirestoreError, OperationType } from '../../lib/errorHandlers';
import { db, collection, onSnapshot, query, where } from '../../firebase';

interface StatementLine extends JournalLine {
  date?: string;
  reference?: string;
}

interface AccountLedgerStatementProps {
  data?: any[];
  isLoading?: boolean;
  isRtl?: boolean;
}

export const AccountLedgerStatement: React.FC<AccountLedgerStatementProps> = ({ 
  data = [], 
  isLoading = false, 
  isRtl = true 
}) => {
  const { accounts } = useAccounting();
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [selectedBranchId, setSelectedBranchId] = useState<string>('');
  const [selectedCostCenterId, setSelectedCostCenterId] = useState<string>('');
  const [ledgerLines, setLedgerLines] = useState<StatementLine[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>('');

  // 1. تصفية شجرة الحسابات: استبعاد الحسابات الرئيسية (1000, 2000...) والأب لضمان كشف الحساب للفرعيات فقط
  const postableSubAccounts = (data.length > 0 ? data : accounts).filter(acc => 
    !acc.isRoot && 
    !acc.hasChildren &&
    (acc.name.includes(searchTerm) || acc.code.includes(searchTerm))
  );

  // 2. خط جلب الحركات الفعلي من دفتر الأستاذ العام (General Ledger Lines)
  useEffect(() => {
    if (!selectedAccountId || !isAuthenticated) {
      setLedgerLines([]);
      return;
    }

    // Connect standard reactive Firebase Firestore lookup directly to the production database instance
    const q = query(
      collection(db, 'journalEntries'),
      where('status', '==', 'POSTED')
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      const matchedLines: StatementLine[] = [];

      snap.forEach((docSnap) => {
        const entry = docSnap.data();
        if (!entry || !entry.lines) return;

        // Map the incoming snapshot array fields safely to prevent application UI screen crashes
        entry.lines.forEach((line: any) => {
          if (line && (line.accountId === selectedAccountId || line.accountCode === selectedAccountId)) {
            // Apply corporate multi-tenant branch and cost center segment filters
            if (selectedBranchId && line.branchId !== selectedBranchId && entry.branchId !== selectedBranchId) {
              return;
            }
            if (selectedCostCenterId && line.costCenterId !== selectedCostCenterId && entry.costCenterId !== selectedCostCenterId) {
              return;
            }

            matchedLines.push({
              id: line.id || `${docSnap.id}-${line.accountCode || ''}-${Math.random()}`,
              accountId: line.accountId || '',
              accountCode: line.accountCode || '',
              accountType: line.accountType || '',
              description: line.description || entry.description || '',
              debit: Number(line.debit) || 0,
              credit: Number(line.credit) || 0,
              amountInBaseCurrency: Number(line.amountInBaseCurrency) || (Number(line.debit) || 0) - (Number(line.credit) || 0),
              date: entry.date || '',
              reference: entry.reference || ''
            });
          }
        });
      });

      // Order the results strictly chronologically by transaction date ascending
      matchedLines.sort((a, b) => {
        const dateA = a.date ? new Date(a.date).getTime() : 0;
        const dateB = b.date ? new Date(b.date).getTime() : 0;
        return dateA - dateB;
      });

      setLedgerLines(matchedLines);
    }, (error) => {
      console.warn("Account ledger statement reactive hook paused:", error.message);
      handleFirestoreError(error, OperationType.GET, 'journalEntries');
    });

    return () => unsubscribe();
  }, [selectedAccountId, isAuthenticated, selectedBranchId, selectedCostCenterId]);

  let runningBalance = 0;
  let totalDebits = 0;
  let totalCredits = 0;

  ledgerLines.forEach(line => {
    totalDebits += line.debit;
    totalCredits += line.credit;
  });

  return (
    <div className="p-6 bg-white rounded-2xl shadow-sm mt-4 text-right" dir="rtl">
      <div className="border-b pb-4 mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-900">📄 كشف الحساب التفصيلي للدفتر العام</h2>
          <p className="text-sm text-gray-500 mt-1">تتبع الحركات المالية القيود، المبالغ، والرصيد المتحرك لكل حساب فرعي تشغيلي</p>
        </div>
        
        {/* زر الطباعة المباشرة المتوافق مع الفواتير والتقارير القانونية */}
        {selectedAccountId && (
          <button 
            onClick={() => window.print()} 
            className="px-4 py-2 bg-indigo-600 text-white rounded-xl font-medium text-sm hover:bg-indigo-700 transition cursor-pointer"
          >
            🖨️ تصدير وطباعة كشف الحساب
          </button>
        )}
      </div>

      {/* محرك الفلترة والاختيار الذكي */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 bg-gray-50 p-4 rounded-xl">
        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1.5 font-sans">ابحث عن الحساب الفرعي (اسم أو كود):</label>
          <input 
            type="text"
            placeholder="مثال: ذمم، بنك، عميل، مورد، صندوق..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-2 border rounded-lg bg-white text-sm text-gray-950 focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1.5 font-sans">اختر الحساب المستهدف لفتح كشفه:</label>
          <select
            value={selectedAccountId}
            onChange={(e) => setSelectedAccountId(e.target.value)}
            className="w-full p-2 border rounded-lg bg-white text-sm text-gray-950 font-medium focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">-- اضغط لاستعراض الحسابات الفرعية التشغيلية --</option>
            {postableSubAccounts.map(acc => (
              <option key={acc.id} value={acc.id}>{acc.code} - {acc.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1.5 font-sans">تصفية حسب فرع المنشأة:</label>
          <select
            value={selectedBranchId}
            onChange={(e) => setSelectedBranchId(e.target.value)}
            className="w-full p-2 border rounded-lg bg-white text-sm text-gray-950 font-medium focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">-- كافة فروع المؤسسة --</option>
            <option value="Sana'a Main HQ branch">فرع صنعاء الرئيسي (Sana'a Main HQ)</option>
            <option value="Aden Port Operations branch">فرع عمليات ميناء عدن (Aden Port)</option>
            <option value="Taiz Cold Store Branch">فرع تعز للتبريد (Taiz Cold Store)</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1.5 font-sans">تصفية مركز التكلفة:</label>
          <select
            value={selectedCostCenterId}
            onChange={(e) => setSelectedCostCenterId(e.target.value)}
            className="w-full p-2 border rounded-lg bg-white text-sm text-gray-950 font-medium focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">-- كافة مراكز التكلفة المحاسبية --</option>
            <option value="Admin HQ Operations Center">عمليات الإدارة العامة (Admin HQ)</option>
            <option value="Sales Hub YER Ledger">مركز مبيعات صنعاء (Sales Hub YER)</option>
          </select>
        </div>
      </div>

      {/* Recalculate and display running segment metrics */}
      {selectedAccountId && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="p-4 bg-emerald-50/55 rounded-xl border border-emerald-100/70 flex flex-col items-center">
            <span className="text-xs text-emerald-700 font-extrabold font-sans">إجمالي التداولات المدينة (Debits)</span>
            <span className="text-lg font-mono font-black text-emerald-600 mt-1">
              +{totalDebits.toLocaleString('en-US', {minimumFractionDigits: 2})} YER
            </span>
          </div>
          <div className="p-4 bg-rose-50/55 rounded-xl border border-rose-100/70 flex flex-col items-center">
            <span className="text-xs text-rose-700 font-extrabold font-sans">إجمالي التداولات الدائنة (Credits)</span>
            <span className="text-lg font-mono font-black text-rose-600 mt-1">
              -{totalCredits.toLocaleString('en-US', {minimumFractionDigits: 2})} YER
            </span>
          </div>
          <div className="p-4 bg-indigo-50/50 rounded-xl border border-indigo-100/60 flex flex-col items-center">
            <span className="text-xs text-indigo-700 font-extrabold font-sans">الرصيد الصافي المؤثر في هذا القطاع</span>
            <span className="text-lg font-mono font-black text-indigo-600 mt-1">
              {(totalDebits - totalCredits).toLocaleString('en-US', {minimumFractionDigits: 2})} YER
            </span>
          </div>
        </div>
      )}

      {/* جدول البيانات المالي المباشر */}
      {selectedAccountId ? (
        <div className="overflow-x-auto border rounded-xl">
          <table className="w-full text-center border-collapse text-sm">
            <thead>
              <tr className="bg-gray-100 border-b text-gray-700 font-bold">
                <th className="p-3">التاريخ</th>
                <th className="p-3">رقم المرجع</th>
                <th className="p-3 text-right">البيان / تفاصيل الحركة</th>
                <th className="p-3 text-emerald-600">مدين (+)</th>
                <th className="p-3 text-rose-600">دائن (-)</th>
                <th className="p-3 text-indigo-600 bg-indigo-50/50 font-extrabold">الرصيد التراكمي</th>
              </tr>
            </thead>
            <tbody>
              {ledgerLines.length > 0 ? (
                ledgerLines.map((line) => {
                  // تحديث الرصيد التراكمي الفعلي
                  runningBalance += (line.debit - line.credit);
                  
                  return (
                    <tr key={line.id} className="border-b hover:bg-gray-50/70 transition text-gray-900 font-medium">
                      <td className="p-3 text-gray-500 font-mono text-xs">{line.date}</td>
                      <td className="p-3 font-mono text-gray-400 text-xs">{line.reference}</td>
                      <td className="p-3 text-right font-semibold">{line.description}</td>
                      <td className="p-3 text-emerald-600 font-bold">{line.debit > 0 ? line.debit.toLocaleString('en-US', {minimumFractionDigits: 2}) : '-'}</td>
                      <td className="p-3 text-rose-600 font-bold">{line.credit > 0 ? line.credit.toLocaleString('en-US', {minimumFractionDigits: 2}) : '-'}</td>
                      <td className="p-3 text-indigo-600 font-extrabold bg-indigo-50/10 font-mono">{runningBalance.toLocaleString('en-US', {minimumFractionDigits: 2})} YER</td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="p-8 text-gray-400 font-medium bg-gray-50/30">
                    لا توجد أي حركات محاسبية أو قيود رحلت على هذا الحساب خلال الفترة المالية الحالية.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="border border-dashed border-amber-300 bg-amber-50 text-amber-900 rounded-xl p-6 text-center font-medium text-sm">
          ⚠️ يرجى تصفية واختيار حساب فرعي تشغيلي من القائمة العلوية لعرض كشف حسابه التاريخي المتزن فوراً.
        </div>
      )}
    </div>
  );
};

export default AccountLedgerStatement;
