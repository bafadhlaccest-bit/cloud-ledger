import React, { useState, useMemo } from 'react';
import { RefreshCw, Download, Search, ChevronDown, ChevronRight, AlertCircle } from 'lucide-react';
import { useAccountingReports } from '../../hooks/useAccountingReports';
import * as XLSX from 'xlsx';

interface Props { data?: any[]; isLoading?: boolean; isRtl?: boolean; dateFrom?: string; dateTo?: string; }

export default function GeneralLedgerTab({ isRtl, dateFrom, dateTo }: Props) {
  const { accounts, journalLines, isLoading, error, refresh } = useAccountingReports(dateFrom, dateTo);
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const fmt = (n: number) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const accountsWithLines = useMemo(() => {
    const filtered = accounts.filter(a =>
      !search || a.name.toLowerCase().includes(search.toLowerCase()) || a.code.includes(search)
    );
    return filtered.map(a => ({
      ...a,
      lines: journalLines
        .filter(l => l.accountId === a.id)
        .sort((x, y) => x.date.localeCompare(y.date)),
    })).filter(a => a.lines.length > 0 || a.openingBalance !== 0);
  }, [accounts, journalLines, search]);

  const toggleExpand = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const exportExcel = () => {
    const rows: any[] = [];
    accountsWithLines.forEach(a => {
      rows.push({ Account: `${a.code} — ${a.name}`, Date: '', Description: '', Debit: '', Credit: '', Balance: a.openingBalance });
      let running = a.openingBalance;
      a.lines.forEach(l => {
        running += (a.normalBalance === 'debit') ? (l.debit - l.credit) : (l.credit - l.debit);
        rows.push({ Account: '', Date: l.date, Description: l.description, Debit: l.debit || '', Credit: l.credit || '', Balance: running });
      });
    });
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'General Ledger');
    XLSX.writeFile(wb, 'general_ledger.xlsx');
  };

  if (isLoading) return <div className="flex items-center justify-center py-20 text-slate-400"><RefreshCw className="w-5 h-5 animate-spin mr-2" />{isRtl ? 'جارٍ التحميل...' : 'Loading...'}</div>;
  if (error) return <div className="p-4 bg-red-50 rounded-lg text-red-600 text-sm flex items-center gap-2"><AlertCircle className="w-4 h-4" />{error}</div>;

  return (
    <div className="space-y-4" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-800">{isRtl ? 'دفتر الأستاذ العام' : 'General Ledger'}</h3>
          <p className="text-xs text-slate-500 mt-0.5">{accountsWithLines.length} {isRtl ? 'حساب بحركة' : 'accounts with activity'}</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setExpanded(new Set(accountsWithLines.map(a => a.id)))} className="text-xs text-indigo-600 hover:underline">{isRtl ? 'توسيع الكل' : 'Expand All'}</button>
          <button onClick={() => setExpanded(new Set())} className="text-xs text-slate-500 hover:underline">{isRtl ? 'طي الكل' : 'Collapse All'}</button>
          <button onClick={exportExcel} className="flex items-center gap-1 text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700"><Download className="w-3.5 h-3.5" /> Excel</button>
          <button onClick={refresh} className="p-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-500"><RefreshCw className="w-3.5 h-3.5" /></button>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder={isRtl ? 'بحث في الحسابات...' : 'Search accounts...'} className="w-full pl-8 pr-3 py-2 text-sm border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500" />
      </div>

      {accountsWithLines.length === 0 ? (
        <div className="text-center py-12 text-slate-400 text-sm border border-dashed border-slate-200 rounded-xl">
          {isRtl ? 'لا توجد قيود محاسبية بعد' : 'No journal entries yet'}
        </div>
      ) : (
        <div className="space-y-2">
          {accountsWithLines.map(a => {
            const isOpen = expanded.has(a.id);
            let running = a.openingBalance;
            return (
              <div key={a.id} className="border border-slate-200 rounded-xl overflow-hidden">
                <button onClick={() => toggleExpand(a.id)} className="w-full flex items-center justify-between px-4 py-3 bg-slate-50 hover:bg-slate-100 transition-colors text-left">
                  <span className="flex items-center gap-2 font-semibold text-slate-800 text-sm">
                    {isOpen ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
                    <span className="font-mono text-slate-400 text-xs">{a.code}</span>
                    {a.name}
                    <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${a.type === 'ASSET' ? 'bg-blue-100 text-blue-700' : a.type === 'LIABILITY' ? 'bg-orange-100 text-orange-700' : a.type === 'EQUITY' ? 'bg-purple-100 text-purple-700' : a.type === 'REVENUE' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>{a.type}</span>
                  </span>
                  <span className={`font-mono font-bold text-sm ${a.balance < 0 ? 'text-red-600' : 'text-slate-800'}`}>{fmt(a.balance)}</span>
                </button>

                {isOpen && (
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="bg-slate-800 text-slate-300">
                        <th className="text-left px-4 py-2">{isRtl ? 'التاريخ' : 'Date'}</th>
                        <th className="text-left px-4 py-2">{isRtl ? 'المرجع' : 'Ref'}</th>
                        <th className="text-left px-4 py-2">{isRtl ? 'البيان' : 'Description'}</th>
                        <th className="text-right px-4 py-2">{isRtl ? 'مدين' : 'Debit'}</th>
                        <th className="text-right px-4 py-2">{isRtl ? 'دائن' : 'Credit'}</th>
                        <th className="text-right px-4 py-2">{isRtl ? 'الرصيد' : 'Balance'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {a.openingBalance !== 0 && (
                        <tr className="bg-amber-50">
                          <td className="px-4 py-2 text-slate-400">—</td>
                          <td className="px-4 py-2 text-slate-400">—</td>
                          <td className="px-4 py-2 text-slate-600 italic">{isRtl ? 'رصيد افتتاحي' : 'Opening Balance'}</td>
                          <td className="px-4 py-2 text-right">—</td>
                          <td className="px-4 py-2 text-right">—</td>
                          <td className="px-4 py-2 text-right font-mono font-bold text-amber-700">{fmt(a.openingBalance)}</td>
                        </tr>
                      )}
                      {a.lines.map(l => {
                        running += a.normalBalance === 'debit' ? (l.debit - l.credit) : (l.credit - l.debit);
                        return (
                          <tr key={l.id} className="hover:bg-slate-50">
                            <td className="px-4 py-2 text-slate-500 font-mono">{l.date}</td>
                            <td className="px-4 py-2 text-slate-500">{l.reference}</td>
                            <td className="px-4 py-2 text-slate-700 max-w-xs truncate">{l.description}</td>
                            <td className="px-4 py-2 text-right font-mono text-blue-700">{l.debit > 0 ? fmt(l.debit) : '—'}</td>
                            <td className="px-4 py-2 text-right font-mono text-orange-700">{l.credit > 0 ? fmt(l.credit) : '—'}</td>
                            <td className={`px-4 py-2 text-right font-mono font-semibold ${running < 0 ? 'text-red-600' : 'text-slate-800'}`}>{fmt(Math.abs(running))}{running < 0 ? ' Cr' : ''}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
