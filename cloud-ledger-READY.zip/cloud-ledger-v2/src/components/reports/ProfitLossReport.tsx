import React, { useEffect, useState } from 'react';
import { JournalLine, IFRSMapping } from '../../types';
import { db, collection, getDocs, query, where, doc } from '../../firebase';

export const ProfitLossReport: React.FC<{ companyId: string }> = ({ companyId }) => {
  const [revenue, setRevenue] = useState<number>(0);
  const [cogs, setCogs] = useState<number>(0);
  const [operatingExpenses, setOperatingExpenses] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchLedgerData = async () => {
      try {
        // جلب جميع قيود اليومية المرحلة للشركة
        const entriesRef = collection(db, 'journalEntries');
        const q = query(entriesRef, where('companyId', '==', companyId), where('status', '==', 'POSTED'));
        const snapshot = await getDocs(q);

        let tempRevenue = 0;
        let tempCogs = 0;
        let tempOpex = 0;

        snapshot.forEach((doc) => {
          const entry = doc.data();
          if (entry.lines) {
            entry.lines.forEach((line: JournalLine) => {
              // التجميع المالي الصارم بناءً على IFRSMapping وليس أرقام الأكواد النصية
              if (line.ifrsMapping === IFRSMapping.REVENUE) {
                tempRevenue += (line.credit - line.debit);
              } else if (line.ifrsMapping === IFRSMapping.COGS) {
                tempCogs += (line.debit - line.credit);
              } else if (line.ifrsMapping === IFRSMapping.OPERATING_EXPENSE) {
                tempOpex += (line.debit - line.credit);
              }
            });
          }
        });

        setRevenue(tempRevenue);
        setCogs(tempCogs);
        setOperatingExpenses(tempOpex);
      } catch (error) {
        console.error("Error calculating IFRS statements:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchLedgerData();
  }, [companyId]);

  const grossProfit = revenue - cogs;
  const netIncome = grossProfit - operatingExpenses;

  if (loading) return <div>جاري تحميل التقرير المالي وفقاً لمعايير IFRS...</div>;

  return (
    <div className="p-6 bg-white rounded-lg shadow-md" dir="rtl">
      <h2 className="text-xl font-bold mb-4 border-b pb-2 text-gray-800">📊 قائمة الأرباح والخسائر (IFRS Compliant Profit & Loss)</h2>
      
      <div className="space-y-3">
        <div className="flex justify-between items-center text-lg">
          <span className="text-gray-600">إجمالي الإيرادات التشغيلية:</span>
          <span className="font-mono text-green-600 font-bold">{revenue.toFixed(2)}</span>
        </div>
        
        <div className="flex justify-between items-center text-lg">
          <span className="text-gray-600">تكلفة البضاعة المباعة (COGS):</span>
          <span className="font-mono text-red-500">({cogs.toFixed(2)})</span>
        </div>
        
        <hr className="border-gray-300" />
        
        <div className="flex justify-between items-center text-xl font-semibold bg-gray-50 p-2 rounded">
          <span className="text-gray-800">إجمالي الربح (Gross Profit):</span>
          <span className="font-mono text-gray-900">{grossProfit.toFixed(2)}</span>
        </div>

        <div className="flex justify-between items-center text-lg">
          <span className="text-gray-600">المصاريف الإدارية والعمومية (OPEX):</span>
          <span className="font-mono text-red-500">({operatingExpenses.toFixed(2)})</span>
        </div>

        <hr className="border-double border-b-4 border-gray-400" />

        <div className="flex justify-between items-center text-2xl font-bold bg-blue-50 p-3 rounded">
          <span className="text-blue-900">صافي الدخل المالي (Net Income):</span>
          <span className={`font-mono ${netIncome >= 0 ? 'text-green-700' : 'text-red-700'}`}>
            {netIncome.toFixed(2)}
          </span>
         </div>
      </div>
    </div>
  );
};
