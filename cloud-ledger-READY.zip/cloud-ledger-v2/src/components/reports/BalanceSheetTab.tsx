import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Download, RefreshCw, CheckCircle2, AlertCircle, ChevronDown, ChevronRight } from 'lucide-react';
import { useAccountingReports, AccountBalance } from '../../hooks/useAccountingReports';
import * as XLSX from 'xlsx';

interface Props { data?: any[]; isLoading?: boolean; isRtl?: boolean; dateFrom?: string; dateTo?: string; }

function Section({ title, accounts, isRtl, total, color }: { title: string; accounts: AccountBalance[]; isRtl: boolean; total: number; color: string }) {
  const [open, setOpen] = useState(true);
  const fmt = (n: number) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return (
    <div className="mb-4">
      <button onClick={() => setOpen(o => !o)} className={`w-full flex items-center justify-between px-4 py-2.5 rounded-lg text-sm font-bold text-white ${color}`}>
        <span className="flex items-center gap-2">
          {open ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          {title}
        </span>
        <span className="font-mono">{fmt(total)}</span>
      </button>
      {open && accounts.length > 0 && (
        <div className="mt-1 border border-slate-200 rounded-lg overflow-hidden">
          {accounts.map(a => (
            <div key={a.id} className="flex justify-between px-4 py-2 text-sm hover:bg-slate-50 border-b border-slate-100 last:border-0">
              <span className="text-slate-600"><span className="text-slate-400 font-mono mr-2">{a.code}</span>{a.name}</span>
              <span className="font-mono text-slate-800 font-medium">{fmt(a.balance)}</span>
            </div>
          ))}
        </div>
      )}
      {open && accounts.length === 0 && (
        <div className="px-4 py-3 text-xs text-slate-400 italic border border-slate-100 rounded-lg mt-1">
          {isRtl ? 'لا توجد حسابات في هذا القسم' : 'No accounts in this section'}
        </div>
      )}
    </div>
  );
}

export default function BalanceSheetTab({ isRtl, dateFrom, dateTo }: Props) {
  const { balanceSheet, isLoading, error, refresh } = useAccountingReports(dateFrom, dateTo);
  const fmt = (n: number) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const isBalanced = Math.abs(balanceSheet.totalAssets - balanceSheet.totalLiabEquity) < 0.01;

  const exportExcel = () => {
    const rows: any[] = [];
    const addSection = (name: string, accs: AccountBalance[]) => {
      rows.push({ Section: `== ${name} ==`, Code: '', Account: '', Balance: '' });
      accs.forEach(a => rows.push({ Section: '', Code: a.code, Account: a.name, Balance: a.balance }));
    };
    addSection(isRtl ? 'الأصول المتداولة' : 'Current Assets', balanceSheet.currentAssets);
    addSection(isRtl ? 'أصول غير متداولة' : 'Non-Current Assets', balanceSheet.nonCurrentAssets);
    addSection(isRtl ? 'المطلوبات المتداولة' : 'Current Liabilities', balanceSheet.currentLiab);
    addSection(isRtl ? 'مطلوبات غير متداولة' : 'Non-Current Liabilities', balanceSheet.nonCurrentLiab);
    addSection(isRtl ? 'حقوق الملكية' : 'Equity', balanceSheet.equity);
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Balance Sheet');
    XLSX.writeFile(wb, 'balance_sheet.xlsx');
  };

  if (isLoading) return (
    <div className="flex items-center justify-center py-20 text-slate-400">
      <RefreshCw className="w-5 h-5 animate-spin mr-2" />
      <span>{isRtl ? 'جارٍ التحميل...' : 'Loading...'}</span>
    </div>
  );

  if (error) return <div className="p-4 bg-red-50 rounded-lg text-red-600 text-sm flex items-center gap-2"><AlertCircle className="w-4 h-4" />{error}</div>;

  return (
    <div className="space-y-4" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-800">{isRtl ? 'الميزانية العمومية' : 'Balance Sheet'}</h3>
          <p className="text-xs text-slate-500 mt-0.5">IFRS — {new Date().toLocaleDateString()}</p>
        </div>
        <div className="flex items-center gap-2">
          {isBalanced
            ? <span className="flex items-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-1 rounded-full"><CheckCircle2 className="w-3.5 h-3.5" />{isRtl ? 'متوازنة' : 'Balanced'}</span>
            : <span className="flex items-center gap-1 text-xs font-semibold text-red-600 bg-red-50 border border-red-200 px-2 py-1 rounded-full"><AlertCircle className="w-3.5 h-3.5" />{isRtl ? 'غير متوازنة' : 'Unbalanced'}</span>
          }
          <button onClick={exportExcel} className="flex items-center gap-1 text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700"><Download className="w-3.5 h-3.5" /> Excel</button>
          <button onClick={refresh} className="p-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-500"><RefreshCw className="w-3.5 h-3.5" /></button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Assets */}
        <div>
          <h4 className="text-sm font-bold text-slate-700 mb-3 pb-2 border-b border-slate-200">{isRtl ? '📊 الأصول' : '📊 ASSETS'}</h4>
          <Section title={isRtl ? 'الأصول المتداولة' : 'Current Assets'} accounts={balanceSheet.currentAssets} isRtl={isRtl || false} total={balanceSheet.currentAssets.reduce((s, a) => s + a.balance, 0)} color="bg-blue-600" />
          <Section title={isRtl ? 'أصول غير متداولة' : 'Non-Current Assets'} accounts={balanceSheet.nonCurrentAssets} isRtl={isRtl || false} total={balanceSheet.nonCurrentAssets.reduce((s, a) => s + a.balance, 0)} color="bg-blue-800" />
          <div className="flex justify-between px-4 py-3 bg-blue-900 text-white rounded-lg mt-2 font-bold">
            <span>{isRtl ? 'إجمالي الأصول' : 'Total Assets'}</span>
            <span className="font-mono">{fmt(balanceSheet.totalAssets)}</span>
          </div>
        </div>

        {/* Liabilities + Equity */}
        <div>
          <h4 className="text-sm font-bold text-slate-700 mb-3 pb-2 border-b border-slate-200">{isRtl ? '📋 المطلوبات وحقوق الملكية' : '📋 LIABILITIES & EQUITY'}</h4>
          <Section title={isRtl ? 'المطلوبات المتداولة' : 'Current Liabilities'} accounts={balanceSheet.currentLiab} isRtl={isRtl || false} total={balanceSheet.currentLiab.reduce((s, a) => s + a.balance, 0)} color="bg-orange-600" />
          <Section title={isRtl ? 'مطلوبات غير متداولة' : 'Non-Current Liabilities'} accounts={balanceSheet.nonCurrentLiab} isRtl={isRtl || false} total={balanceSheet.nonCurrentLiab.reduce((s, a) => s + a.balance, 0)} color="bg-orange-800" />
          <Section title={isRtl ? 'حقوق الملكية' : 'Equity'} accounts={balanceSheet.equity} isRtl={isRtl || false} total={balanceSheet.equity.reduce((s, a) => s + a.balance, 0)} color="bg-purple-700" />
          <div className="flex justify-between px-4 py-3 bg-slate-800 text-white rounded-lg mt-2 font-bold">
            <span>{isRtl ? 'إجمالي المطلوبات والملكية' : 'Total Liabilities & Equity'}</span>
            <span className="font-mono">{fmt(balanceSheet.totalLiabEquity)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
