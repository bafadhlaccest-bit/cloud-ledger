// src/components/reports/ForexAuditDashboard.tsx
import React, { useState } from 'react';
import { processEnterpriseLedger, JournalLine } from '../../utils/financialEngine';

interface ForexAuditDashboardProps {
  rawJournalLines: JournalLine[];
  isRtl: boolean;
}

export default function ForexAuditDashboard({ rawJournalLines, isRtl }: ForexAuditDashboardProps) {
  // المحاكاة الحية لأسعار الصرف المتغيرة لليوم (مثال من Open Exchange Rates)
  const [marketRates] = useState<Record<string, number>>({
    YER: 1,
    USD: 250, // سعر الصرف الافتراضي للمحاكاة
    SAR: 66.6,
  });

  const systemCurrency = 'YER';
  const processedData = processEnterpriseLedger(rawJournalLines, systemCurrency, marketRates);

  // إجمالي أرباح/خسائر فروق الصرف غير المحققة في النظام بالكامل
  const totalSystemForexVariance = processedData.reduce((sum, item) => sum + item.forexVariance, 0);

  return (
    <div id="forex-audit-dashboard-root" className="w-full p-6 bg-slate-900 text-slate-100 rounded-3xl shadow-xl border border-slate-800">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-6 mb-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-indigo-500/10 text-indigo-400 text-xs px-3 py-1 rounded-full font-semibold mb-2">
            🛡️ Enterprise Financial Integrity Core
          </div>
          <h2 className="text-2xl font-black tracking-tight">
            {isRtl ? 'لوحة الرقابة المالية الذكية وفروقات العملة' : 'Financial Integrity & Forex Ledger Audit'}
          </h2>
        </div>

        <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700 font-mono text-xs">
          <span className="text-slate-400 block mb-1">{isRtl ? 'العملة الأم للنظام' : 'System Anchor Currency'}</span>
          <span className="text-emerald-400 font-bold text-sm">1.00 {systemCurrency}</span>
        </div>
      </div>

      {/* العدادات الاستراتيجية الصادمة */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div id="card-unrealized-forex" className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800">
          <span className="text-xs text-slate-400 block mb-1">
            {isRtl ? 'مركز تسويات فروق الصرف (Forex)' : 'Unrealized Forex Impact'}
          </span>
          <span className={`text-xl font-black font-mono ${totalSystemForexVariance >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {totalSystemForexVariance.toLocaleString('en-US', { minimumFractionDigits: 2 })} {systemCurrency}
          </span>
        </div>

        <div id="card-cross-ledger-matching" className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800">
          <span className="text-xs text-slate-400 block mb-1">
            {isRtl ? 'حالة القيود المتقاطعة' : 'Cross-Ledger Matching'}
          </span>
          <span className="text-xl font-black text-slate-200 flex items-center gap-2">
            <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse" />
            {isRtl ? 'متطابقة 100%' : '100% Consolidated'}
          </span>
        </div>

        <div id="card-audit-ledger-status" className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-900/50">
          <span className="text-xs text-indigo-400 block mb-1">
            {isRtl ? 'مؤشر النزاهة الدفترية' : 'Audit Ledger Status'}
          </span>
          <span className="text-xl font-black text-indigo-300">
            {isRtl ? 'مغلق ومحمي (Immutable)' : 'Immutable & Sealed'}
          </span>
        </div>
      </div>

      {/* جدول كشف الحسابات المعقد العملات للفحص الرقابي */}
      <div className="overflow-x-auto rounded-xl border border-slate-800">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-800/60 text-slate-300 uppercase font-mono tracking-wider border-b border-slate-800">
              <th className="p-3 text-right">{isRtl ? 'رمز الحساب' : 'Account Code'}</th>
              <th className="p-3 text-right">{isRtl ? 'اسم الحساب المالي' : 'Account Name'}</th>
              <th className="p-3 text-center">{isRtl ? 'المدين (المحلي)' : 'Debit (Local)'}</th>
              <th className="p-3 text-center">{isRtl ? 'الدائن (المحلي)' : 'Credit (Local)'}</th>
              <th className="p-3 text-center">{isRtl ? 'الرصيد الموحد الحركي' : 'Dynamic Evaluation'}</th>
              <th className="p-3 text-center">{isRtl ? 'انحراف الصرف' : 'Forex Drift'}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800 font-mono">
            {processedData.map((row) => (
              <tr key={row.accountId} className="hover:bg-slate-800/30 transition-colors">
                <td className="p-3 font-bold text-slate-400 text-right">{row.accountCode}</td>
                <td className="p-3 text-slate-200 font-sans text-right">{row.accountName}</td>
                <td className="p-3 text-center text-slate-300">{row.localDebit.toLocaleString()}</td>
                <td className="p-3 text-center text-slate-300">{row.localCredit.toLocaleString()}</td>
                <td className="p-3 text-center text-indigo-400 font-bold">
                  {(row.systemDebit - row.systemCredit).toLocaleString()}
                </td>
                <td className={`p-3 text-center font-bold ${row.forexVariance >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                  {row.forexVariance === 0 ? '0.00' : row.forexVariance.toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
