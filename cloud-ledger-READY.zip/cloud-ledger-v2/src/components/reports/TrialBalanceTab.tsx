import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Download, RefreshCw, CheckCircle2, AlertCircle, Search } from 'lucide-react';
import { useAccountingReports } from '../../hooks/useAccountingReports';
import * as XLSX from 'xlsx';

interface Props { data?: any[]; isLoading?: boolean; isRtl?: boolean; dateFrom?: string; dateTo?: string; }

export default function TrialBalanceTab({ isRtl, dateFrom, dateTo }: Props) {
  const { t } = useTranslation();
  const [search, setSearch] = useState('');
  const { trialBalance, accounts, isLoading, error, refresh } = useAccountingReports(dateFrom, dateTo);

  const totalDebit  = trialBalance.reduce((s, a) => s + a.totalDebit, 0);
  const totalCredit = trialBalance.reduce((s, a) => s + a.totalCredit, 0);
  const isBalanced  = Math.abs(totalDebit - totalCredit) < 0.01;

  const filtered = trialBalance.filter(a =>
    !search || a.name.toLowerCase().includes(search.toLowerCase()) || a.code.includes(search)
  );

  const fmt = (n: number) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const exportExcel = () => {
    const rows = filtered.map(a => ({
      'Code': a.code, 'Account': a.name, 'Type': a.type,
      'Debit': a.totalDebit, 'Credit': a.totalCredit,
      'Balance': a.balance,
    }));
    rows.push({ 'Code': '', 'Account': 'TOTAL', 'Type': '', 'Debit': totalDebit, 'Credit': totalCredit, 'Balance': totalDebit - totalCredit });
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Trial Balance');
    XLSX.writeFile(wb, 'trial_balance.xlsx');
  };

  if (isLoading) return (
    <div className="flex items-center justify-center py-20 text-slate-400">
      <RefreshCw className="w-5 h-5 animate-spin mr-2" />
      <span>Loading trial balance...</span>
    </div>
  );

  if (error) return (
    <div className="p-4 bg-red-50 rounded-lg text-red-600 text-sm flex items-center gap-2">
      <AlertCircle className="w-4 h-4" /> {error}
    </div>
  );

  return (
    <div className="space-y-4" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-slate-800">
            {isRtl ? 'ميزان المراجعة' : 'Trial Balance'}
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            {accounts.length} {isRtl ? 'حساب' : 'accounts'} · {trialBalance.length} {isRtl ? 'بحركة' : 'with movement'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isBalanced
            ? <span className="flex items-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 border border-emerald-200 px-2 py-1 rounded-full"><CheckCircle2 className="w-3.5 h-3.5" />{isRtl ? 'متوازن' : 'Balanced'}</span>
            : <span className="flex items-center gap-1 text-xs font-semibold text-red-600 bg-red-50 border border-red-200 px-2 py-1 rounded-full"><AlertCircle className="w-3.5 h-3.5" />{isRtl ? 'غير متوازن' : 'Unbalanced'}</span>
          }
          <button onClick={exportExcel} className="flex items-center gap-1 text-xs px-3 py-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700">
            <Download className="w-3.5 h-3.5" /> Excel
          </button>
          <button onClick={refresh} className="p-1.5 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-500">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
        <input
          value={search} onChange={e => setSearch(e.target.value)}
          placeholder={isRtl ? 'بحث...' : 'Search accounts...'}
          className="w-full pl-8 pr-3 py-2 text-sm border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
        />
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-200">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="text-left px-4 py-2.5 text-xs font-semibold text-slate-500">{isRtl ? 'كود' : 'Code'}</th>
              <th className="text-left px-4 py-2.5 text-xs font-semibold text-slate-500">{isRtl ? 'اسم الحساب' : 'Account Name'}</th>
              <th className="text-left px-4 py-2.5 text-xs font-semibold text-slate-500">{isRtl ? 'النوع' : 'Type'}</th>
              <th className="text-right px-4 py-2.5 text-xs font-semibold text-slate-500">{isRtl ? 'مدين' : 'Debit'}</th>
              <th className="text-right px-4 py-2.5 text-xs font-semibold text-slate-500">{isRtl ? 'دائن' : 'Credit'}</th>
              <th className="text-right px-4 py-2.5 text-xs font-semibold text-slate-500">{isRtl ? 'الرصيد' : 'Balance'}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.length === 0 ? (
              <tr><td colSpan={6} className="text-center py-12 text-slate-400 text-sm">
                {isRtl ? 'لا توجد بيانات — أضف قيود محاسبية أولاً' : 'No data — add journal entries first'}
              </td></tr>
            ) : filtered.map(a => (
              <tr key={a.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-2.5 text-slate-500 font-mono text-xs">{a.code}</td>
                <td className="px-4 py-2.5 font-medium text-slate-800">{a.name}</td>
                <td className="px-4 py-2.5">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    a.type === 'ASSET' ? 'bg-blue-50 text-blue-700' :
                    a.type === 'LIABILITY' ? 'bg-orange-50 text-orange-700' :
                    a.type === 'EQUITY' ? 'bg-purple-50 text-purple-700' :
                    a.type === 'REVENUE' ? 'bg-emerald-50 text-emerald-700' :
                    'bg-rose-50 text-rose-700'
                  }`}>{a.type}</span>
                </td>
                <td className="px-4 py-2.5 text-right font-mono text-slate-700">{a.totalDebit > 0 ? fmt(a.totalDebit) : '—'}</td>
                <td className="px-4 py-2.5 text-right font-mono text-slate-700">{a.totalCredit > 0 ? fmt(a.totalCredit) : '—'}</td>
                <td className={`px-4 py-2.5 text-right font-mono font-semibold ${a.balance < 0 ? 'text-red-600' : 'text-slate-800'}`}>
                  {fmt(Math.abs(a.balance))}{a.balance < 0 ? ' Cr' : ''}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="bg-slate-800 text-white">
              <td colSpan={3} className="px-4 py-3 font-bold text-sm">{isRtl ? 'الإجمالي' : 'TOTAL'}</td>
              <td className="px-4 py-3 text-right font-mono font-bold">{fmt(totalDebit)}</td>
              <td className="px-4 py-3 text-right font-mono font-bold">{fmt(totalCredit)}</td>
              <td className={`px-4 py-3 text-right font-mono font-bold ${isBalanced ? 'text-emerald-400' : 'text-red-400'}`}>
                {isBalanced ? '✓ 0.00' : fmt(Math.abs(totalDebit - totalCredit))}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
