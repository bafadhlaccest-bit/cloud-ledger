import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import Sidebar from './Sidebar';
import { useAuthStore } from '../store/useAuthStore';
import { useRBAC } from '../hooks/useRBAC';
import { useSettingsStore } from '../store/useSettingsStore';
import { Bell, Search, Loader2, Wifi, WifiOff, RefreshCw, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { db, collection, addDoc, onSnapshot, query, where } from '../firebase';
import { useTranslation } from 'react-i18next';
import { offlineDb } from '../utils/offlineDb';

export default function Layout() {
  const { isAuthenticated, user } = useAuthStore();
  const { companyId } = useRBAC();
  const { i18n, t } = useTranslation();
  const [isAuthReady, setIsAuthReady] = React.useState(false);
  const loadSettings = useSettingsStore((state) => state.loadSettings);

  const [isOnline, setIsOnline] = React.useState(navigator.onLine);
  const [pendingCount, setPendingCount] = React.useState(0);
  const [isSyncing, setIsSyncing] = React.useState(false);
  const [syncProgress, setSyncProgress] = React.useState('');
  const [showSuccessToast, setShowSuccessToast] = React.useState(false);

  const updatePendingCount = React.useCallback(async () => {
    const count = await offlineDb.countAllPending();
    setPendingCount(count);
  }, []);

  React.useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  React.useEffect(() => {
    const dir = i18n.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.setAttribute('dir', dir);
    document.documentElement.setAttribute('lang', i18n.language);
  }, [i18n.language]);

  React.useEffect(() => {
    supabase.auth.getSession().then(() => setIsAuthReady(true));
    const { data: listener } = supabase.auth.onAuthStateChange(() => setIsAuthReady(true));
    return () => listener.subscription.unsubscribe();
  }, []);

  React.useEffect(() => {
    updatePendingCount();

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    const handleDbUpdate = () => updatePendingCount();

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('offline-db-updated', handleDbUpdate);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('offline-db-updated', handleDbUpdate);
    };
  }, [updatePendingCount]);

  React.useEffect(() => {
    if (!isAuthenticated || !isAuthReady) return;
    
    const q = query(
      collection(db, 'journalEntries'),
      where('companyId', '==', companyId)
    );
    
    const unsubscribeSnapshot = onSnapshot(q, async (snapshot) => {
      const entriesList = snapshot.docs.map(docSnapshot => ({
        id: docSnapshot.id,
        ...docSnapshot.data()
      }));
      
      try {
        await fetch('/api/sync-journal-entries', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ entries: entriesList })
        });
      } catch (err) {
        console.warn('Real-time journal snapshot synchronization warning:', err);
      }
    }, (error) => {
      console.warn('Real-time journal collection subscription background notification (fallback active):', error.message);
    });

    return () => unsubscribeSnapshot();
  }, [isAuthenticated, isAuthReady]);

  const handleManualSync = async () => {
    if (isSyncing || pendingCount === 0) return;
    setIsSyncing(true);
    setSyncProgress(i18n.language === 'en' ? 'Initializing database transfer...' : 'بدء عملية نقل البيانات مع خادم السحابة...');

    try {
      const invoices = await offlineDb.getPendingRecords('offline_sales_invoices');
      const bills = await offlineDb.getPendingRecords('offline_purchase_bills');
      const journals = await offlineDb.getPendingRecords('offline_journal_entries');

      const allPending = [
        ...invoices.map(item => ({ ...item, store: 'offline_sales_invoices' as const, collectionPath: 'invoices' })),
        ...bills.map(item => ({ ...item, store: 'offline_purchase_bills' as const, collectionPath: 'bills' })),
        ...journals.map(item => ({ ...item, store: 'offline_journal_entries' as const, collectionPath: 'journalEntries' }))
      ];

      const total = allPending.length;
      for (let i = 0; i < total; i++) {
        const item = allPending[i];
        
        let label = 'Data';
        if (item.collectionPath === 'invoices') label = i18n.language === 'en' ? 'Invoices' : 'الفواتير مبيعات';
        if (item.collectionPath === 'bills') label = i18n.language === 'en' ? 'Purchase Bills' : 'فواتير المشتريات';
        if (item.collectionPath === 'journalEntries') label = i18n.language === 'en' ? 'Journals' : 'القيود اليومية';

        setSyncProgress(
          i18n.language === 'en' 
            ? `Syncing ${label} (${i + 1} of ${total})...` 
            : `جاري مزامنة ${label} (${i + 1} من ${total})...`
        );

        // Sanitize payload from temporary offline flags
        const cleanPayload = { ...item.payload };
        delete cleanPayload.isOfflineDraft;
        delete cleanPayload.id;

        // Save to Firebase production collection!
        await addDoc(collection(db, item.collectionPath), cleanPayload);

        // Clear offline queue
        await offlineDb.removeRecord(item.store, item.id);
      }

      await updatePendingCount();
      setShowSuccessToast(true);
      setTimeout(() => setShowSuccessToast(false), 5000);
    } catch (e) {
      console.error('Offline Data Sync Exception:', e);
      alert(i18n.language === 'en' ? 'Sync failed. Please check your cloud network connection.' : 'فشلت المزامنة. يرجى التحقق من اتصال الشبكة وسرعة النت.');
    } finally {
      setIsSyncing(false);
      setSyncProgress('');
    }
  };

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (!isAuthReady) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Sync Progress Loading Bar Overlay */}
        {isSyncing && (
          <div className="bg-indigo-600 text-white px-8 py-2.5 text-xs font-semibold flex items-center justify-between gap-4 animate-pulse shadow-md z-[50]">
            <div className="flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-200" />
              <span>{syncProgress}</span>
            </div>
            <div className="w-32 bg-indigo-805 h-1.5 rounded-full overflow-hidden">
              <div className="bg-white h-full animate-infinite-loading" style={{ width: '50%' }} />
            </div>
          </div>
        )}

        {/* Global Floating Custom Sync Success Message Toast */}
        {showSuccessToast && (
          <div className="fixed top-4 right-4 z-50 max-w-sm w-full bg-emerald-500 text-white p-4 rounded-xl shadow-2xl flex items-start gap-3 border border-emerald-400 animate-slide-in">
            <CheckCircle className="w-5 h-5 text-emerald-100 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-sm">
                {i18n.language === 'en' ? 'Sync Completed' : 'تمت المزامنة بنجاح'}
              </p>
              <p className="text-xs text-emerald-100 mt-1 font-medium select-none leading-relaxed">
                {i18n.language === 'en' 
                  ? 'All operations successfully synchronized with the main cloud server!' 
                  : 'تم مزامنة جميع العمليات السابقة بنجاح مع خادم قاعدة البيانات السحابية!'}
              </p>
            </div>
          </div>
        )}

        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 shrink-0">
          <div className="flex items-center bg-slate-100 rounded-full px-4 py-2 w-80 shrink-0">
            <Search className="w-4 h-4 text-slate-400 mr-2 rtl:mr-0 rtl:ml-2" />
            <input 
              type="text" 
              placeholder={t('common.search')} 
              className="bg-transparent border-none focus:ring-0 text-sm w-full"
            />
          </div>

          {/* Sync Widget & Network Indicators Bar */}
          <div className="flex items-center gap-4 px-4 py-1 mx-4 border-l border-r border-slate-200/80">
            {/* Live Network Status Indicator Badge */}
            {isOnline ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full text-[11px] font-bold">
                <Wifi className="w-3.5 h-3.5 text-emerald-500" />
                <span>Online (متصل)</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded-full text-[11px] font-bold">
                <WifiOff className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                <span>Offline Mode (منقطع)</span>
              </span>
            )}

            {/* Amber Manual Sync Trigger Button */}
            {pendingCount > 0 && (
              <button
                onClick={handleManualSync}
                disabled={isSyncing || !isOnline}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 active:bg-amber-700 disabled:opacity-40 text-slate-905 rounded-lg text-xs font-bold transition-all duration-200 shadow-sm shadow-amber-500/20 uppercase tracking-wider shrink-0 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-slate-900 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>
                  {i18n.language === 'en' 
                    ? `Sync Pending (${pendingCount})` 
                    : `مزامنة البيانات (${pendingCount})`}
                </span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-6">
            <a href="/advisor" title="المستشار المالي الذكي"
              className="relative p-2 text-slate-400 hover:text-indigo-600 transition-colors">
              <Bell className="w-5 h-5" />
              {pendingCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white flex items-center justify-center text-[9px] text-white font-bold">
                  {pendingCount > 9 ? '9+' : pendingCount}
                </span>
              )}
            </a>
            
            <div className="flex items-center gap-3 border-l pl-6 border-slate-200 rtl:border-l-0 rtl:border-r rtl:pl-0 rtl:pr-6">
              <div className="text-right">
                <p className="text-sm font-semibold text-slate-900">{user?.name}</p>
                <p className="text-xs text-slate-500 capitalize">{user?.role}</p>
              </div>
              <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold">
                {user?.name.charAt(0)}
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
