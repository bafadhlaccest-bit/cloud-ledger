import React from 'react';

// تعريف بنية الحساب القادم من شجرة الحسابات
export interface Account {
  id: string;
  code: string;
  name: string;
  type: string;
  isRoot?: boolean;      // هل هو حساب رئيسي من الخمسة؟
  hasChildren?: boolean; // هل تندرج تحته حسابات أخرى؟ (حساب أب)
  parentId?: string;
  balance?: number;
}

interface AccountSelectProps {
  accountsList: Account[];         // كامل شجرة الحسابات بالنظام
  selectedAccountId: string;       // الحساب المحدد حالياً
  onAccountChange: (id: string) => void; // تابع يرسل المعرف عند الاختيار لتحديث الصفحة
  filterByType?: string | string[]; // فلترة اختيارية (مثلاً: إظهار حسابات الإيرادات فقط)
  placeholder?: string;
  className?: string; // إمكانية تمرير تنسيق مخصص مريح
}

export const AccountDropdownSelector: React.FC<AccountSelectProps> = ({
  accountsList,
  selectedAccountId,
  onAccountChange,
  filterByType = 'Income',
  placeholder = "اختر الحساب المحاسبي المربوط...",
  className = "w-full p-2.5 border rounded-lg bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 font-medium text-right"
}) => {
  
  // 1. فلترة وتجهيز الحسابات الاستباقية وتصفية الحسابات التشغيلية الفرعية فقط لمنع الترحيل العشوائي
  const processedAccounts = accountsList.filter(account => {
    // إذا كان هناك فلترة بناءً على نوع الحساب (مثال: 'Income')
    if (filterByType) {
      const typeMatches = Array.isArray(filterByType)
        ? filterByType.includes(account.type)
        : account.type === filterByType;
      if (!typeMatches) return false;
    }

    // الشرط المحاسبي الصارم: تصفية واستبعاد الحسابات الرئيسية والتجميعية تماماً من القائمة
    const isMainAccount = 
      account.isRoot === true || 
      ['1000', '2000', '3000', '4000', '5000'].includes(account.code) || 
      account.hasChildren === true ||
      (account as any).isParent === true ||
      accountsList.some(a => a.parentId === account.id);

    return !isMainAccount; // الاستبقاء للحسابات الفرعية التشغيلية القابلة للترحيل فقط
  });

  return (
    <div className="flex flex-col w-full text-right" dir="rtl">
      <select
        value={selectedAccountId}
        onChange={(e) => onAccountChange(e.target.value)}
        className={className}
        required
      >
        <option value="">{placeholder}</option>
        
        {processedAccounts.map((account) => {
          return (
            <option
              key={account.id}
              value={account.id}
              className="text-slate-900 font-normal"
              style={{
                fontWeight: 'normal',
                color: '#111827',
                paddingRight: account.parentId ? '16px' : '8px'
              }}
            >
              {account.code} - {account.name} {` (${account.type})`}
            </option>
          );
        })}
      </select>
    </div>
  );
};
