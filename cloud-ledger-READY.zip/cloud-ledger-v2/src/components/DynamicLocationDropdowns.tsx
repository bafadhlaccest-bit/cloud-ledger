// src/components/DynamicLocationDropdowns.tsx
import React, { useState, useEffect } from 'react';
import { Country, State } from 'country-state-city';
import { Globe2, MapPin } from 'lucide-react';

interface LocationData {
  country: string;
  state: string;
}

interface DynamicLocationDropdownsProps {
  onLocationChange: (location: LocationData) => void;
  isRtl?: boolean;
}

export function DynamicLocationDropdowns({ onLocationChange, isRtl = true }: DynamicLocationDropdownsProps) {
  const [allCountries] = useState(Country.getAllCountries());
  const [filteredStates, setFilteredStates] = useState<any[]>([]);
  
  const [selectedCountryCode, setSelectedCountryCode] = useState('');
  const [selectedStateCode, setSelectedStateCode] = useState('');

  // Automatically update provinces/states dynamically upon country selection change
  useEffect(() => {
    if (selectedCountryCode) {
      const statesList = State.getStatesOfCountry(selectedCountryCode);
      setFilteredStates(statesList);
    } else {
      setFilteredStates([]);
    }
    setSelectedStateCode(''); // Clear previous state to prevent crossover state
  }, [selectedCountryCode]);

  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const countryVal = e.target.value;
    setSelectedCountryCode(countryVal);
    onLocationChange({ country: countryVal, state: '' });
  };

  const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const stateVal = e.target.value;
    setSelectedStateCode(stateVal);
    onLocationChange({ country: selectedCountryCode, state: stateVal });
  };

  return (
    <div 
      className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full text-slate-100 bg-slate-900/40 p-4 border border-slate-800 rounded-3xl" 
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      {/* Country Selection */}
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
          <Globe2 className="w-3.5 h-3.5 text-indigo-400" />
          {isRtl ? 'الدولة الجغرافية' : 'Country'}
        </label>
        <select
          value={selectedCountryCode}
          onChange={handleCountryChange}
          className="w-full border border-slate-800 focus:border-indigo-500 rounded-xl p-3 bg-slate-950 text-white font-medium text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all cursor-pointer"
        >
          <option value="" className="bg-slate-900">
            {isRtl ? 'اختر الدولة...' : 'Select Country...'}
          </option>
          {allCountries.map((country) => (
            <option key={country.isoCode} value={country.isoCode} className="bg-slate-900">
              {country.name} {country.flag}
            </option>
          ))}
        </select>
      </div>

      {/* State / Governorate Selection */}
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-emerald-400" />
          {isRtl ? 'المحافظة / الولاية' : 'Governorate / State'}
        </label>
        <select
          value={selectedStateCode}
          disabled={!selectedCountryCode}
          onChange={handleStateChange}
          className="w-full border border-slate-800 focus:border-indigo-500 rounded-xl p-3 bg-slate-950 text-white font-medium text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          <option value="" className="bg-slate-900">
            {selectedCountryCode 
              ? (isRtl ? 'اختر المحافظة...' : 'Select State...') 
              : (isRtl ? 'يرجى اختيار الدولة أولاً' : 'Please select country first')}
          </option>
          {filteredStates.map((state) => (
            <option key={state.isoCode} value={state.isoCode} className="bg-slate-900">
              {state.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}
