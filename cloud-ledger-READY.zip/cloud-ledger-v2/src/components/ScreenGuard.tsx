import React from 'react';
import { useLocation } from 'react-router-dom';
import { useRBAC } from '../hooks/useRBAC';

interface ScreenGuardProps {
  children: React.ReactNode;
}

export default function ScreenGuard({ children }: ScreenGuardProps) {
  const { canAccessScreen, userRole } = useRBAC();
  const location = useLocation();

  if (!canAccessScreen(location.pathname)) {
    console.warn(`ScreenGuard blocked access to ${location.pathname} for role: ${userRole}`);
    return (
      <div className="flex flex-col items-center justify-center p-12 min-h-[50vh] text-center font-sans">
        <div className="w-16 h-16 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mb-6">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-8 h-8">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-2">
          Access Denied / غير مصرح بالدخول
        </h2>
        <p className="text-slate-500 max-w-sm mb-4">
          Your active role ({userRole}) does not have permission to access this dynamic screen under company_id bounds.
        </p>
      </div>
    );
  }

  return <>{children}</>;
}
