// src/components/ChartOfAccounts.tsx
import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Edit2, ShieldAlert, Ban } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface ChartAccount {
  id: string;
  code?: string;
  accountCode?: string;
  name?: string;
  accountName?: string;
  type?: string;
  accountType?: string;
  status?: string;
  balance?: number;
  description?: string;
  parentId?: string;
}

interface ChartOfAccountsProps {
  accounts: ChartAccount[];
  onEditAccount: (account: ChartAccount) => void;
  isRtl?: boolean;
}

export function ChartOfAccounts({ accounts, onEditAccount, isRtl = true }: ChartOfAccountsProps) {
  // Collapsed status mapping
  const [collapsedAccounts, setCollapsedAccounts] = useState<Record<string, boolean>>({});

  const toggleCollapse = (code: string) => {
    setCollapsedAccounts(prev => ({ ...prev, [code]: !prev[code] }));
  };

  // Sovereign/Root codes forbidden from editing/modifications to ensure compliance
  const frozenRootCodes = ['1000', '2000', '3000', '4050', '5000'];

  // Normalizers to support both payload formats seamlessly
  const getCode = (acc: ChartAccount) => acc.accountCode || acc.code || '';
  const getName = (acc: ChartAccount) => acc.accountName || acc.name || '';
  const getType = (acc: ChartAccount) => acc.accountType || acc.type || 'Asset';

  // Sorter to keep accounting codes numerical and structured
  const sortedAccounts = [...accounts].sort((a, b) => getCode(a).localeCompare(getCode(b)));

  // Filter out children under collapsed parent nodes dynamically
  const visibleAccounts = sortedAccounts.filter(acc => {
    const code = getCode(acc);
    // Find if any root/parent code of this node is collapsed
    for (const parentCode of Object.keys(collapsedAccounts)) {
      if (collapsedAccounts[parentCode] && code.startsWith(parentCode) && code !== parentCode) {
        return false;
      }
    }
    return true;
  });

  return (
    <div 
      id="chart-of-accounts-sub-root" 
      className={`w-full p-6 bg-slate-900 border border-slate-800 text-slate-100 rounded-3xl shadow-xl ${isRtl ? 'text-right' : 'text-left'}`}
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      {/* Header Guard */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <div className="inline-flex items-center gap-2 bg-indigo-500/10 text-indigo-400 text-xs px-3 py-1 rounded-full font-semibold mb-2 font-sans">
            🛡️ {isRtl ? 'شجرة الحسابات السيادية والمحصّنة' : 'Immutable Chart of Accounts Guard'}
          </div>
          <h3 className="text-lg font-black tracking-tight text-white font-sans">
            {isRtl ? 'دليل الحسابات التفاعلي' : 'Interactive General Ledger Explorer'}
          </h3>
          <p className="text-xs text-slate-400 mt-1 font-sans">
            {isRtl 
              ? 'الحسابات الرئيسية (1000-5000) مشتتة سيادياً ومبرمجة كأرصدة مغلقة لا يمكن تعديلها.' 
              : 'Root-level accounts (1000-5000) are sealed under immutable ledger compliance rules.'}
          </p>
        </div>
      </div>

      {/* Accordion Ledger Items */}
      <div className="space-y-2.5 font-mono text-xs">
        <AnimatePresence initial={false}>
          {visibleAccounts.map((account) => {
            const code = getCode(account);
            const name = getName(account);
            const type = getType(account);
            const isRoot = frozenRootCodes.includes(account.accountCode || code);
            const isCollapsed = collapsedAccounts[code];

            // Determine depth dynamically by checking length or hierarchy
            const depth = code.length > 4 ? Math.floor((code.length - 4) / 2) + 1 : 0;

            return (
              <motion.div
                key={account.id}
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.15 }}
                className={`group border border-slate-800/65 p-3 rounded-2xl flex flex-col gap-3 transition-all ${
                  isRoot 
                    ? 'bg-slate-850 border-l-4 border-l-amber-500/80 bg-slate-800/35' 
                    : 'bg-slate-900 hover:bg-slate-800/40'
                }`}
                style={{
                  marginRight: isRtl ? `${depth * 1.5}rem` : '0px',
                  marginLeft: !isRtl ? `${depth * 1.5}rem` : '0px'
                }}
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    {/* Expand/Collapse Trigger */}
                    {isRoot ? (
                      <button 
                        type="button"
                        onClick={() => toggleCollapse(code)} 
                        className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg cursor-pointer transition"
                        aria-label="Toggle Collapse"
                      >
                        {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    ) : (
                      <span className="w-7 h-7 flex items-center justify-center text-slate-600 font-bold">•</span>
                    )}

                    <div className="flex flex-col">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-indigo-400 text-xs bg-indigo-950/40 px-2 py-0.5 rounded border border-indigo-900/30">
                          {code}
                        </span>
                        <span className="font-semibold text-slate-100 text-sm font-sans">
                          {name}
                        </span>
                        {isRoot && (
                          <span className="inline-flex items-center gap-1 bg-amber-500/10 text-amber-400 text-[10px] px-2 py-0.5 rounded-full font-bold">
                            <ShieldAlert className="w-3.5 h-3.5" />
                            {isRtl ? 'حساب سيادي مغلق' : 'Sovereign Root'}
                          </span>
                        )}
                      </div>
                      {account.description && (
                        <p className="text-[11px] text-slate-400 mt-1 font-sans">
                          {account.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 justify-end">
                    {/* Account Type Ribbon */}
                    <span className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider ${
                      type.toUpperCase() === 'ASSET' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                      type.toUpperCase() === 'LIABILITY' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                      type.toUpperCase() === 'EQUITY' ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20' :
                      type.toUpperCase() === 'INCOME' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                      'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    }`}>
                      {type}
                    </span>

                    {/* Account Balance if present */}
                    {account.balance !== undefined && (
                      <span className="text-slate-300 font-bold text-xs">
                        {account.balance.toLocaleString(undefined, { minimumFractionDigits: 2 })} YER
                      </span>
                    )}

                    {/* Edit button adhering directly to specified structures */}
                    <button
                      type="button"
                      disabled={isRoot}
                      onClick={() => onEditAccount(account)}
                      className={`p-2 rounded-xl flex items-center gap-1.5 font-bold transition text-xs ${
                        isRoot 
                          ? 'bg-slate-800/40 text-slate-500 cursor-not-allowed opacity-60' 
                          : 'bg-indigo-500/10 text-indigo-400 hover:bg-indigo-600 hover:text-white border border-indigo-500/20 cursor-pointer'
                      }`}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>{isRoot ? (isRtl ? 'محظور التعديل' : 'Frozen') : (isRtl ? 'تعديل' : 'Edit')}</span>
                    </button>
                  </div>
                </div>

                {/* Collapse warning message for folded classification */}
                {isRoot && isCollapsed && (
                  <div className="mr-8 mt-1.5 p-2 bg-slate-950/40 rounded-lg text-[11px] text-slate-400 border-r-2 border-indigo-500 font-sans">
                    {isRtl ? 'تم طي الحسابات الفرعية التابعة لهذه الفئة السيادية.' : 'Sub-accounts under this sovereign classification have been collapsed.'}
                  </div>
                )}
              </motion.div>
            );
          })}
        </AnimatePresence>

        {visibleAccounts.length === 0 && (
          <div className="p-8 text-center border border-dashed border-slate-800 rounded-3xl bg-slate-900/50">
            <p className="text-xs text-slate-500 font-mono">
              {isRtl ? 'لا توجد حسابات متطابقة مع خيارات الفرز والتصفية.' : 'No matched accounts in the selected taxonomy.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
