// src/components/ContactForm.tsx
import React, { useState, useEffect } from 'react';
import { Country, State } from 'country-state-city';
import { Trash2, UserPlus, ShieldAlert, CheckCircle, Mail, Phone, MapPin, Loader2 } from 'lucide-react';
import { 
  collection, 
  query, 
  where, 
  getDocs, 
  deleteDoc, 
  doc, 
  addDoc, 
  onSnapshot, 
  serverTimestamp 
import { handleFirestoreError, OperationType } from '../lib/errorHandlers';
import { executeSafeSecureDelete } from '../utils/secureDelete';
import { db, collection, addDoc, getDocs, deleteDoc, onSnapshot, query, where, serverTimestamp, doc } from '../firebase';
import { useRBAC } from '../hooks/useRBAC';

export interface ContactData {
  id: string;
  name: string;
  email: string;
  phone: string;
  country: string;
  state: string;
  type: 'CUSTOMER' | 'VENDOR';
  createdAt?: any;
}

interface ContactFormProps {
  contactType?: 'CUSTOMER' | 'VENDOR';
  isRtl?: boolean;
  companyId?: string;
}

export function ContactForm({ contactType = 'CUSTOMER', isRtl = true, companyId: propCompanyId }: ContactFormProps) {
  const { companyId: rbacCompanyId } = useRBAC();
  const companyId = propCompanyId || rbacCompanyId;
  const [countries] = useState(Country.getAllCountries());
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [states, setStates] = useState<any[]>([]);
  
  // Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  
  // UI States
  const [contacts, setContacts] = useState<ContactData[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [notification, setNotification] = useState('');
  const [errorNotification, setErrorNotification] = useState('');

  // Real-time listener for current contacts list matching the type
  useEffect(() => {
    setIsLoading(true);
    const q = query(
      collection(db, 'contacts'),
      where('type', '==', contactType)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const items: ContactData[] = [];
        snapshot.forEach((docSnap) => {
          items.push({ id: docSnap.id, ...docSnap.data() } as ContactData);
        });
        setContacts(items);
        setIsLoading(false);
      },
      (err) => {
        console.error('Error fetching contacts:', err);
        setIsLoading(false);
      }
    );

    return () => unsubscribe();
  }, [contactType]);

  // Load States automatically when Country selection changes
  useEffect(() => {
    if (selectedCountry) {
      const countryStates = State.getStatesOfCountry(selectedCountry);
      setStates(countryStates);
      setSelectedState('');
    } else {
      setStates([]);
      setSelectedState('');
    }
  }, [selectedCountry]);

  // Submit new contact
  const handleAddContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorNotification(isRtl ? 'الرجاء إدخال اسم الجهة!' : 'Please enter contact name!');
      return;
    }

    setIsSaving(true);
    setNotification('');
    setErrorNotification('');

    try {
      const countryName = countries.find(c => c.isoCode === selectedCountry)?.name || selectedCountry;
      const stateName = states.find(s => s.isoCode === selectedState)?.name || selectedState;

      const newContact = {
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        country: countryName,
        state: stateName,
        type: contactType,
        createdAt: serverTimestamp()
      };

      await addDoc(collection(db, 'contacts'), newContact);
      
      // Reset form fields
      setName('');
      setEmail('');
      setPhone('');
      setSelectedCountry('');
      setSelectedState('');

      setNotification(
        isRtl 
          ? '🎉 تم إضافة الجهة بنجاح إلى الدفاتر الفرعية المحمية!' 
          : '🎉 Contact successfully recorded in secure auxiliary ledgers!'
      );
    } catch (err: any) {
      console.error(err);
      setErrorNotification(err.message || 'Error occurred while saving contact');
    } finally {
      setIsSaving(false);
    }
  };

  // Safe delete handler with accounting checks
  const handleDeleteContact = async (contactId: string) => {
    setNotification('');
    setErrorNotification('');

    try {
      const res = await executeSafeSecureDelete({
        itemId: contactId,
        targetCollection: 'contacts',
        companyId
      });

      if (res.success) {
        setNotification(res.message || '✅ تم حذف الكيان بنجاح.');
      } else {
        if (res.message) {
          setErrorNotification(res.message);
        }
      }
    } catch (err: any) {
      setErrorNotification(`خطأ في تنفيذ العملية: ${err.message}`);
    }
  };

  return (
    <div 
      className="p-6 bg-slate-900 border border-slate-800 text-slate-100 rounded-3xl shadow-xl max-w-4xl mx-auto" 
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      {/* Header Banner */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
          <span className="inline-flex items-center gap-1.5 bg-indigo-500/10 text-indigo-400 text-xs px-3 py-1 rounded-full font-bold mb-2">
            🛡️ {contactType === 'CUSTOMER' 
              ? (isRtl ? 'دفتر العملاء الفرعي' : 'Customer Sub-Ledger') 
              : (isRtl ? 'دفتر الموردين الفرعي' : 'Vendor Sub-Ledger')}
          </span>
          <h2 className="text-xl font-black text-white tracking-tight">
            {isRtl ? 'إدارة جهات الاتصال والشركاء' : 'Partner & Contact Directory'}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isRtl 
              ? 'تسمح هذه الواجهة بتسجيل وفحص الجهات بشكل آمن بالاعتماد على التحقق الجغرافي وحماية القيود المالية الحية.' 
              : 'Add and control commercial partners protected by location compliance verification.'}
          </p>
        </div>
      </div>

      {/* Notifications */}
      {notification && (
        <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-2xl flex items-center gap-3">
          <CheckCircle className="w-5 h-5 shrink-0" />
          <span className="text-xs font-bold font-sans">{notification}</span>
        </div>
      )}

      {errorNotification && (
        <div className="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-2xl flex items-center gap-3">
          <ShieldAlert className="w-5 h-5 shrink-0" />
          <span className="text-xs font-bold font-sans">{errorNotification}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Form Box */}
        <form onSubmit={handleAddContact} className="space-y-4">
          <h3 className="text-sm font-bold text-slate-300 border-b border-slate-800 pb-2 mb-4 flex items-center gap-2">
            <UserPlus className="w-4 h-4 text-indigo-400" />
            {isRtl ? 'تسجيل شريك جديد' : 'Register New Partner'}
          </h3>

          <div>
            <label className="block mb-1.5 text-xs font-bold text-slate-400">
              {isRtl ? 'الاسم بالكامل' : 'Full Name'} <span className="text-rose-500">*</span>
            </label>
            <input 
              type="text" 
              required
              value={name} 
              onChange={(e) => setName(e.target.value)}
              className="w-full border border-slate-800 focus:border-indigo-500 rounded-xl p-3 bg-slate-950 text-white text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all placeholder:text-slate-600"
              placeholder={isRtl ? 'أدخل اسم الشريك التجاري...' : 'Business partner displayName...'}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block mb-1.5 text-xs font-bold text-slate-400">
                {isRtl ? 'البريد الإلكتروني' : 'Email Address'}
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                <input 
                  type="email" 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full border border-slate-800 focus:border-indigo-500 rounded-xl p-3 pl-10 bg-slate-950 text-white text-xs font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all placeholder:text-slate-700"
                  placeholder="name@company.com"
                />
              </div>
            </div>

            <div>
              <label className="block mb-1.5 text-xs font-bold text-slate-400">
                {isRtl ? 'رقم الهاتف' : 'Telephone / Phone'}
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                <input 
                  type="tel" 
                  value={phone} 
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full border border-slate-800 focus:border-indigo-500 rounded-xl p-3 pl-10 bg-slate-950 text-white text-xs font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all placeholder:text-slate-700"
                  placeholder="+967..."
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block mb-1.5 text-xs font-bold text-slate-400">
                {isRtl ? 'الدولة الجغرافية' : 'Country'}
              </label>
              <select 
                value={selectedCountry} 
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="w-full border border-slate-800 focus:border-indigo-500 rounded-xl p-3 bg-slate-950 text-white text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
              >
                <option value="" className="bg-slate-900">{isRtl ? 'اختر الدولة...' : 'Select Country...'}</option>
                {countries.map(c => (
                  <option key={c.isoCode} value={c.isoCode} className="bg-slate-900">
                    {c.name} {c.flag}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block mb-1.5 text-xs font-bold text-slate-400">
                {isRtl ? 'المحافظة / الولاية' : ' Governorate / State'}
              </label>
              <select 
                value={selectedState}
                onChange={(e) => setSelectedState(e.target.value)}
                disabled={!selectedCountry}
                className="w-full border border-slate-800 focus:border-indigo-500 rounded-xl p-3 bg-slate-950 text-white text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <option value="" className="bg-slate-900">{isRtl ? 'اختر المحافظة...' : 'Select State...'}</option>
                {states.map(s => (
                  <option key={s.isoCode} value={s.isoCode} className="bg-slate-900">
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isSaving}
            className="w-full mt-2 font-bold text-xs p-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl flex items-center justify-center gap-2 transition pointer-cursor disabled:opacity-60 disabled:cursor-not-allowed uppercase tracking-wider"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                {isRtl ? 'جاري الحفظ والتوثيق...' : 'Securing partner records...'}
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                {isRtl ? 'توثيق الشريك محاسبياً' : 'Add Partner To Directory'}
              </>
            )}
          </button>
        </form>

        {/* Directory/List Box */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-300 border-b border-slate-800 pb-2 mb-4 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-emerald-400" />
            {isRtl ? 'قائمة الجهات المسجلة' : 'Registered Entities Ledger'}
          </h3>

          {isLoading ? (
            <div className="p-8 text-center bg-slate-950/40 border border-slate-800 rounded-2xl flex flex-col items-center justify-center gap-3">
              <Loader2 className="w-6 h-6 animate-spin text-indigo-400" />
              <p className="text-[10px] text-slate-500 font-mono">Loading Core Entities Stream...</p>
            </div>
          ) : contacts.length === 0 ? (
            <div className="p-8 text-center bg-slate-950/20 border border-dashed border-slate-800 rounded-2xl">
              <p className="text-xs text-slate-500 font-sans">
                {isRtl ? 'لا توجد جهات مسجلة حالياً.' : 'No registered records found.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
              {contacts.map((c) => (
                <div 
                  key={c.id} 
                  className="p-3 bg-slate-950/40 border border-slate-850 hover:bg-slate-900/30 rounded-xl flex items-center justify-between gap-3 transition"
                >
                  <div className="flex flex-col min-w-0">
                    <span className="font-bold text-slate-100 text-xs truncate font-sans">
                      {c.name}
                    </span>
                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 mt-1 text-[10px] text-slate-500 font-mono">
                      {c.email && (
                        <span className="flex items-center gap-1">
                          <Mail className="w-3 h-3 text-slate-600" />
                          {c.email}
                        </span>
                      )}
                      {c.phone && (
                        <span className="flex items-center gap-1">
                          <Phone className="w-3 h-3 text-slate-600" />
                          {c.phone}
                        </span>
                      )}
                      {(c.country || c.state) && (
                        <span className="flex items-center gap-1 text-indigo-400/80">
                          <MapPin className="w-3 h-3" />
                          {c.state ? `${c.state}, ` : ''}{c.country}
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => handleDeleteContact(c.id)}
                    className="p-2 bg-rose-500/10 text-rose-400 hover:bg-rose-500 hover:text-white border border-rose-500/20 rounded-xl transition cursor-pointer shrink-0"
                    title={isRtl ? 'حذف الشريك بأمان' : 'Safely Deprecate Entity'}
                    type="button"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
