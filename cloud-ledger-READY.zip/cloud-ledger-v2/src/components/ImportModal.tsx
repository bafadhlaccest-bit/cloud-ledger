import React, { useState, useRef } from 'react';
import { UploadCloud, FileSpreadsheet, Download, RefreshCcw, AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';
import Modal from './Modal';
import * as XLSX from 'xlsx';
import { MODULE_SCHEMAS, downloadExcelTemplate } from '../utils/exportImport';
import { db, collection, addDoc, serverTimestamp } from '../firebase';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  moduleId: string;
  existingRecords: any[];
  onImportSuccess: (count: number) => void;
}

export default function ImportModal({ isOpen, onClose, moduleId, existingRecords, onImportSuccess }: ImportModalProps) {
  const schema = MODULE_SCHEMAS[moduleId];
  const [dragActive, setDragActive] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [errorList, setErrorList] = useState<string[]>([]);
  const [parsedRows, setParsedRows] = useState<any[]>([]);
  const [successCount, setSuccessCount] = useState<number | null>(null);
  const [adapterSource, setAdapterSource] = useState<'Standard' | 'Type_A' | 'Type_B' | 'Type_C'>('Standard');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!schema) return null;

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = (file: File) => {
    setIsParsing(true);
    setErrorList([]);
    setParsedRows([]);
    setSuccessCount(null);

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const rawBytes = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(rawBytes, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const rows = XLSX.utils.sheet_to_json(worksheet);

        if (rows.length === 0) {
          setErrorList(["The uploaded file appears to be completely empty of any data rows."]);
          setIsParsing(false);
          return;
        }

        // Apply Migration Adapter Mapping
        let transformedRows = rows;
        if (moduleId === 'accounts') {
          if (adapterSource === 'Type_A') {
            transformedRows = rows.map((r: any) => ({
              'Code': r['Number'] || r['accountNumber'] || r['Code'] || r['Account Number'] || '',
              'Account Name': r['Name'] || r['accountName'] || r['Account Name'] || r['Account name'] || '',
              'Account Type': r['Type'] || r['accountType'] || r['Account Type'] || r['Account type'] || '',
              'Description': r['Description'] || r['memo'] || r['Description'] || ''
            }));
          } else if (adapterSource === 'Type_B') {
            transformedRows = rows.map((r: any) => ({
              'Code': r['Account Code'] || r['Code'] || '',
              'Account Name': r['Account Name'] || r['Account name'] || '',
              'Account Type': r['Account Type'] || r['Account type'] || '',
              'Description': r['Description'] || r['notes'] || ''
            }));
          } else if (adapterSource === 'Type_C') {
            transformedRows = rows.map((r: any) => ({
              'Code': r['Code'] || r['Account Code'] || '',
              'Account Name': r['Name'] || r['Account Name'] || '',
              'Account Type': r['Type'] || r['Account Type'] || '',
              'Description': r['Description'] || ''
            }));
          }
        }

        // Validate rows
        const errors: string[] = [];
        const validatedRows: any[] = [];

        transformedRows.forEach((row: any, idx: number) => {
          // Fallback cleanups
          if (!row['Code'] && row['Code '] !== undefined) row['Code'] = row['Code '];
          
          const validationError = schema.validators(row, idx, [...existingRecords, ...validatedRows]);
          if (validationError) {
            errors.push(validationError);
          } else {
            validatedRows.push(schema.transform(row));
          }
        });

        if (errors.length > 0) {
          setErrorList(errors);
        } else {
          setParsedRows(validatedRows);
        }
      } catch (err: any) {
        setErrorList([`Failed to correctly parse Excel/CSV spreadsheet: ${err?.message || err}`]);
      } finally {
        setIsParsing(false);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleBoxClick = () => {
    fileInputRef.current?.click();
  };

  const triggerDownloadTemplate = () => {
    downloadExcelTemplate(moduleId);
  };

  const executeLiveImport = async () => {
    if (parsedRows.length === 0) return;
    setIsImporting(true);
    let success = 0;

    try {
      const activeColRef = collection(db, schema.collectionName);
      
      // Batch write simulation using parallel addDocs
      await Promise.all(
        parsedRows.map(async (row) => {
          await addDoc(activeColRef, {
            ...row,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          });
          success++;
        })
      );

      setSuccessCount(success);
      onImportSuccess(success);
      setParsedRows([]);
    } catch (err: any) {
      setErrorList([`Firestore Import failed: ${err.message || err}`]);
    } finally {
      setIsImporting(false);
    }
  };

  const resetUploader = () => {
    setParsedRows([]);
    setErrorList([]);
    setSuccessCount(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Excel & CSV Bulk Import - ${schema.name}`} size="md">
      <div className="flex flex-col gap-5">
        
        {/* Step Header Instructions */}
        <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex items-start gap-4">
          <div className="bg-indigo-50 text-indigo-650 p-2.5 rounded-xl mt-0.5 font-bold">
            <Download className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h4 className="text-sm font-black text-slate-800">1. Download Blank Sample Template (ملف النموذج سمبل)</h4>
            <p className="text-xs text-slate-500 mt-1">
              Ensure system-compatible alignment and validation. Columns must strictly map our data grid order.
            </p>
            <button
              onClick={triggerDownloadTemplate}
              className="mt-3 inline-flex items-center gap-1.5 text-xs font-black text-indigo-650 hover:text-indigo-800 bg-white border border-indigo-100 py-1.5 px-3 rounded-lg shadow-sm hover:shadow transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              Download Dynamic Template (.xlsx)
            </button>
          </div>
        </div>

        {/* Migration Data Ingestion Adaptor (Only for Chart of Accounts module since it has complex external variations) */}
        {moduleId === 'accounts' && successCount === null && parsedRows.length === 0 && (
          <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-sm">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <RefreshCcw className="w-3.5 h-3.5 text-indigo-500" />
              Ingestion Source Schema Adapter (محول الأنظمة الخارجية)
            </h4>
            <p className="text-[11px] text-slate-500">
              Select your source platform if you are importing exports directly from other accounting structures. Our adapter cleans and aligns the columns on-the-fly.
            </p>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
              {[
                { id: 'Standard', label: 'Standard ERP' },
                { id: 'Type_A', label: 'Segment Type A' },
                { id: 'Type_B', label: 'Segment Type B' },
                { id: 'Type_C', label: 'Compact Ledger' }
              ].map((plat) => (
                <button
                  key={plat.id}
                  type="button"
                  onClick={() => setAdapterSource(plat.id as any)}
                  className={`py-2 px-3 text-[11px] font-bold rounded-xl border text-center transition-all cursor-pointer ${
                    adapterSource === plat.id 
                      ? 'bg-slate-950 border-slate-950 text-white shadow-sm' 
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {plat.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Drag and Drop Zone */}
        {successCount === null && parsedRows.length === 0 && errorList.length === 0 && (
          <div
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={handleBoxClick}
            className={`flex flex-col items-center justify-center border-2 border-dashed rounded-3xl p-10 cursor-pointer select-none transition-all ${
              dragActive
                ? 'border-indigo-500 bg-indigo-50/50 scale-[0.99]'
                : 'border-slate-200 hover:border-indigo-400 bg-slate-50/40 hover:bg-slate-50/80'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={handleFileChange}
              className="hidden"
            />
            {isParsing ? (
              <div className="flex flex-col items-center gap-3">
                <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
                <span className="text-sm font-bold text-slate-600">Reading and validating rows...</span>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-3 text-center">
                <div className="bg-white p-4 rounded-full shadow-md text-slate-400 hover:text-indigo-650 transition-colors">
                  <UploadCloud className="w-10 h-10" />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="text-sm font-extrabold text-slate-700">Drag & Drop your file here</p>
                  <p className="text-xs text-slate-400">or click to browse from computing drive</p>
                </div>
                <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 mt-2 bg-slate-100 py-1 px-2.5 rounded-full">
                  Supports Excel (.xlsx, .xls) and CSV
                </span>
              </div>
            )}
          </div>
        )}

        {/* Validation Errors Box */}
        {errorList.length > 0 && (
          <div className="bg-rose-50 border border-rose-100 rounded-2xl p-4 flex flex-col gap-3">
            <div className="flex items-center gap-2 text-rose-800">
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <h4 className="text-sm font-black uppercase">Formatting Rules Breached ({errorList.length} Errors Found)</h4>
            </div>
            
            <div className="max-h-40 overflow-y-auto pl-1 pr-1 flex flex-col gap-1.5 border-t border-dashed border-rose-200 pt-3">
              {errorList.slice(0, 15).map((err, idx) => (
                <div key={idx} className="text-xs text-rose-700 font-medium font-mono pl-3 border-l-2 border-rose-400">
                  {err}
                </div>
              ))}
              {errorList.length > 15 && (
                <div className="text-xs text-rose-500 italic pl-3">
                  And {errorList.length - 15} more formatting issues... Please download the sample template and review headers.
                </div>
              )}
            </div>

            <div className="flex gap-2.5 mt-2 border-t border-rose-200/40 pt-3">
              <button
                onClick={resetUploader}
                className="text-xs font-black text-rose-800 bg-white border border-rose-200 py-1.5 px-3 rounded-lg hover:bg-rose-100 transition-colors inline-flex items-center gap-1.5 shadow-sm"
              >
                <RefreshCcw className="w-3.5 h-3.5" />
                Retry Re-Upload File
              </button>
            </div>
          </div>
        )}

        {/* Parsed and Welcomed rows for Execution */}
        {parsedRows.length > 0 && (
          <div className="bg-slate-50 border border-slate-200 rounded-3xl p-5 flex flex-col gap-4">
            <div className="flex items-center gap-2 text-emerald-800">
              <FileSpreadsheet className="w-6 h-6 shrink-0 text-emerald-600 animate-bounce" />
              <div className="flex flex-col">
                <span className="text-sm font-black leading-none uppercase">Spreadsheet Parsed & Verified</span>
                <span className="text-xs text-slate-500 mt-1">{parsedRows.length} rows aligned with {schema.name} rules</span>
              </div>
            </div>

            {/* Quick columns summary */}
            <div className="border border-slate-200/60 bg-white rounded-xl p-3 max-h-32 overflow-y-auto">
              <span className="text-[10px] font-black uppercase text-slate-400 block mb-2">Ingestion Header Mappings</span>
              <div className="flex flex-wrap gap-1.5">
                {schema.headers.map((h, i) => (
                  <span key={i} className="text-[10px] font-bold text-slate-600 bg-slate-100 py-0.5 px-2 rounded">
                    {h}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3 border-t border-slate-200 pt-4">
              <button
                onClick={executeLiveImport}
                disabled={isImporting}
                className="flex-1 text-xs font-black text-white bg-indigo-650 hover:bg-indigo-800 border border-indigo-700 py-2.5 px-4 rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {isImporting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Committing Ingestion...
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    Commmit {parsedRows.length} Records to live database
                  </>
                )}
              </button>
              <button
                onClick={resetUploader}
                className="text-xs font-bold text-slate-600 bg-white border border-slate-200 py-2.5 px-4 rounded-xl hover:bg-slate-50 transition-colors shadow-sm"
              >
                Reset
              </button>
            </div>
          </div>
        )}

        {/* Success complete state */}
        {successCount !== null && (
          <div className="bg-emerald-50 border border-emerald-200 rounded-3xl p-6 text-center flex flex-col items-center gap-4">
            <div className="bg-emerald-100 text-emerald-600 p-4 rounded-full shadow-sm">
              <CheckCircle className="w-12 h-12 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-black text-emerald-900 uppercase">Process Completed!</h3>
              <p className="text-xs text-emerald-700 font-bold mt-1">
                {successCount} records have been successfully parsed, validated, and inserted live into the database!
              </p>
            </div>
            <div className="flex gap-2.5 mt-2">
              <button
                onClick={onClose}
                className="text-xs font-black text-white bg-emerald-600 border border-emerald-700 py-2 px-4 rounded-xl hover:bg-emerald-700 shadow-md transition-all"
              >
                Done & Close Panel
              </button>
              <button
                onClick={resetUploader}
                className="text-xs font-black text-slate-700 bg-white border border-slate-200 py-2 px-4 rounded-xl hover:bg-slate-50 transition-all shadow-sm"
              >
                Import Another File
              </button>
            </div>
          </div>
        )}

      </div>
    </Modal>
  );
}
