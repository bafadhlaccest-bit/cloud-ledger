import React from 'react';
import { Bill, Vendor } from '../types';
import { formatCurrency, formatDate, cn } from '../lib/utils';

const fontStyleMap = {
  Inter: "'Inter', sans-serif",
  Arial: "Arial, sans-serif",
  Roboto: "'Roboto', sans-serif",
  Tajawal: "'Tajawal', sans-serif",
  'Courier New': "'Courier New', Courier, monospace"
};

interface BillPaperPreviewProps {
  bill?: Bill | null;
  vendors: Vendor[];
  settings: {
    templateStyle: 'standard' | 'professional' | 'modern';
    logoUrl: string;
    logoAlignment: 'left' | 'center' | 'right';
    logoSize: 'small' | 'medium' | 'large';
    primaryColor: string;
    secondaryColor: string;
    fontFamily: 'Inter' | 'Arial' | 'Roboto' | 'Tajawal' | 'Courier New';
    hideTaxColumn: boolean;
    hideShippingCharges: boolean;
    hideTermsAndConditions: boolean;
    hideCustomerNotes: boolean;
  };
}

export default function BillPaperPreview({ bill, vendors, settings }: BillPaperPreviewProps) {
  // Use either the passed bill, or a highly polished mockup bill
  const sampleBill: Bill = {
    id: 'sample-bill',
    number: 'BILL-2026-001',
    vendorId: 'sample-vendor',
    vendorName: 'Global Equipment Supplier Ltd',
    date: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    subTotal: 120000.00,
    discountPercent: 5,
    shippingCharges: 2500.00,
    adjustment: 0.00,
    total: 116500.00,
    status: 'Unpaid',
    customerNotes: 'Deliver to main warehouse in Sana\'a.',
    termsConditions: '1. Net 30 payment terms.\n2. Please mention the Bill Number in bank transfer references.',
    items: [
      {
        itemId: 'it-1',
        name: 'High Performance Database Server Pro',
        sku: 'HWD-DB-91',
        quantity: 1,
        rate: 100000.00,
        taxPercent: 5,
        taxLabel: 'VAT (5%)',
        amount: 105000.00,
        accountId: 'acc-asset-1',
        accountName: 'Inventory Asset'
      },
      {
        itemId: 'it-2',
        name: 'SDR Ethernet Routing Hubs',
        sku: 'NET-HUB-04',
        quantity: 2,
        rate: 10000.00,
        taxPercent: 15,
        taxLabel: 'VAT (15%)',
        amount: 23000.00,
        accountId: 'acc-exp-1',
        accountName: 'Cost of Goods Sold'
      }
    ]
  };

  const activeBill = bill || sampleBill;
  const activeVendor = vendors.find(v => v.id === activeBill.vendorId);

  // Derive address parts
  const vendorAddress = activeVendor 
    ? [activeVendor.streetAddress, activeVendor.city, activeVendor.governorate, activeVendor.country].filter(Boolean).join('\n')
    : "88 Ring Road\nSana'a\nYemen";

  // Calculations
  const itemsList = activeBill.items || [];
  const subTotalAmount = activeBill.subTotal ?? itemsList.reduce((acc, it) => acc + (it.quantity * it.rate), 0);
  const discountPercent = activeBill.discountPercent ?? 0;
  const calculatedDiscount = (subTotalAmount * discountPercent) / 100;
  
  // Calculate raw taxes to display
  const totalTaxAmount = itemsList.reduce((sum, item) => {
    const qty = item.quantity || 0;
    const rate = item.rate || 0;
    const tax = item.taxPercent || 0;
    return sum + (qty * rate * (tax / 100));
  }, 0);

  const shippingCharges = settings.hideShippingCharges ? 0 : (activeBill.shippingCharges ?? 0);
  const adjustment = activeBill.adjustment ?? 0;
  const grandTotal = subTotalAmount - calculatedDiscount + shippingCharges + adjustment + totalTaxAmount;

  const fontStyle = fontStyleMap[settings.fontFamily] || fontStyleMap.Inter;

  // Custom logo size classes
  const logoSizeClass = {
    small: 'h-10 max-h-10',
    medium: 'h-16 max-h-16',
    large: 'h-24 max-h-24'
  }[settings.logoSize];

  // Custom logo alignment wrapper
  const logoAlignClass = {
    left: 'justify-start',
    center: 'justify-center',
    right: 'justify-end'
  }[settings.logoAlignment];

  return (
    <div 
      className="bg-white border border-slate-200 shadow-xl rounded-2xl mx-auto w-full transition-all duration-300 overflow-hidden" 
      style={{ fontFamily: fontStyle, minHeight: '650px' }}
    >
      {/* 1. Header Branded Band (Professional Style Specific) */}
      {settings.templateStyle === 'professional' && (
        <div style={{ backgroundColor: settings.primaryColor }} className="p-6 text-white text-left">
          <div className={cn("flex mb-4", logoAlignClass)}>
            {settings.logoUrl ? (
              <img src={settings.logoUrl} alt="Logo" className={cn("object-contain filter brightness-100", logoSizeClass)} />
            ) : (
              <div className="text-xs font-bold bg-white/20 px-3 py-1.5 rounded-lg tracking-wider uppercase bg-opacity-20 inline-block">Your Logo</div>
            )}
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mt-2">
            <div>
              <h1 className="text-2xl font-black uppercase tracking-tight text-white m-0">PURCHASE BILL</h1>
              <p className="text-xs text-white/80 mt-1 font-bold">
                Number: {activeBill.number} | Date: {formatDate(activeBill.date)}
              </p>
            </div>
            <div className="sm:text-right text-left text-xs text-white/90 leading-relaxed font-semibold">
              <p className="font-extrabold text-sm uppercase">Yemen Finance Systems</p>
              <p>Main Office, Sana'a, Yemen</p>
              <p>VAT Registration: 120-993-211</p>
            </div>
          </div>
        </div>
      )}

      <div className="p-6 sm:p-8 space-y-6 text-left">
        {/* 2. Brand Block (Standard & Modern Specific) */}
        {settings.templateStyle !== 'professional' && (
          <div 
            className={cn(
              "pb-6 flex flex-col md:flex-row md:items-start justify-between gap-6",
              settings.templateStyle === 'modern' ? "border-b-4" : "border-b border-slate-100"
            )}
            style={settings.templateStyle === 'modern' ? { borderBottomColor: settings.primaryColor } : {}}
          >
            {/* Logo */}
            <div className={cn("flex flex-1", lgAlign(settings.logoAlignment, logoAlignClass))}>
              {settings.logoUrl ? (
                <img src={settings.logoUrl} alt="Logo" className={cn("object-contain", logoSizeClass)} />
              ) : (
                <div 
                  className="text-xs font-extrabold px-3 py-2 rounded-lg tracking-wider uppercase border border-dashed border-slate-300 text-slate-400 bg-slate-50"
                >
                  Company Logo Placeholder
                </div>
              )}
            </div>

            {/* Corporate identity */}
            <div className="text-right space-y-1 block mt-0.5">
              <h2 className="text-lg font-black uppercase tracking-tight" style={{ color: settings.primaryColor }}>
                Yemen Finance Systems
              </h2>
              <p className="text-xs font-semibold" style={{ color: settings.secondaryColor }}>Main Office, Sana'a, Yemen</p>
              <p className="text-[11px] text-slate-400 font-medium">VAT Reg No: 120-993-211</p>
            </div>
          </div>
        )}

        {/* 3. Meta Grid (Standard & Modern Specific) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-2">
          {/* Vendor Info */}
          <div>
            <h3 className="text-[11px] font-black uppercase tracking-wider text-slate-400 block mb-2">
              Vendor (Bill From)
            </h3>
            <div className="space-y-1">
              <p className="font-extrabold text-sm text-slate-800">{activeBill.vendorName}</p>
              <p className="text-xs text-slate-500 whitespace-pre-line leading-relaxed font-semibold">
                {vendorAddress}
              </p>
            </div>
          </div>

          {/* Bill Date / Info */}
          <div className="md:text-right flex flex-col md:items-end justify-between text-left">
            {settings.templateStyle !== 'professional' && (
              <div>
                <h1 className="text-2xl font-black uppercase tracking-tight mb-2" style={{ color: settings.primaryColor }}>
                  BILL
                </h1>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-slate-500 font-semibold md:justify-items-end text-left md:text-right">
                  <span className="text-slate-400">Bill #:</span>
                  <span className="font-bold text-slate-800">{activeBill.number}</span>
                  <span className="text-slate-400">Bill Date:</span>
                  <span className="font-medium">{formatDate(activeBill.date)}</span>
                  <span className="text-slate-400">Due Date:</span>
                  <span className="font-medium text-rose-600">{formatDate(activeBill.dueDate)}</span>
                  <span className="text-slate-400">Status:</span>
                  <span 
                    className="font-extrabold uppercase py-0.5 px-2 rounded-full text-[9px] w-max select-none"
                    style={{ backgroundColor: settings.primaryColor + '15', color: settings.primaryColor }}
                  >
                    {activeBill.status}
                  </span>
                </div>
              </div>
            )}

            {settings.templateStyle === 'professional' && (
              <div className="text-left md:text-right">
                <h3 className="text-[11px] font-black uppercase tracking-wider text-slate-400 block mb-1">
                  Payment Details
                </h3>
                <div className="text-xs space-y-1 text-slate-600 font-semibold">
                  <p><span className="text-slate-400">Due Date:</span> <span className="font-bold text-rose-600">{formatDate(activeBill.dueDate)}</span></p>
                  <p>
                    <span className="text-slate-400">Status: </span>
                    <span className="uppercase text-[9px] font-bold px-2 py-0.5 rounded-full" style={{ backgroundColor: '#22c55e1a', color: '#16a34a' }}>
                      {activeBill.status}
                    </span>
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 4. Core Details Table */}
        <div className="pt-4">
          <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-sm overflow-hidden bg-white">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr 
                  className="font-bold text-[11px] uppercase tracking-wider text-slate-600"
                  style={settings.templateStyle === 'professional' ? { backgroundColor: settings.primaryColor, color: '#ffffff' } : { backgroundColor: '#f8fafc' }}
                >
                  <th className="px-4 py-3 font-extrabold">Item Details</th>
                  <th className="px-4 py-3 font-extrabold w-[160px]">Account</th>
                  <th className="px-4 py-3 text-right font-extrabold w-20">Qty</th>
                  <th className="px-4 py-3 text-right font-extrabold w-28">Rate</th>
                  {!settings.hideTaxColumn && (
                    <th className="px-4 py-3 text-left font-extrabold w-24">Tax</th>
                  )}
                  <th className="px-4 py-3 text-right font-extrabold w-28">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-semibold text-slate-700">
                {itemsList.map((item, index) => {
                  const qty = item.quantity || 0;
                  const rate = item.rate || 0;
                  const taxPercent = item.taxPercent || 0;
                  const itemSubtotal = qty * rate;
                  const rowFinalAmount = itemSubtotal * (1 + taxPercent / 100);

                  return (
                    <tr key={item.itemId || index} className="hover:bg-slate-50/40 transition">
                      <td className="px-4 py-3">
                        <p className="font-black text-slate-800 text-[12px]">{item.name}</p>
                        {item.sku && <p className="text-[10px] text-slate-400 font-mono mt-0.5">{item.sku}</p>}
                      </td>
                      <td className="px-4 py-3">
                        {item.accountName ? (
                          <span className="text-slate-700 font-semibold text-xs">{item.accountName}</span>
                        ) : (
                          <span className="text-slate-400 font-normal italic">Unassigned</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right font-bold text-slate-600">{qty.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right text-slate-500">{formatCurrency(rate, 'YER')}</td>
                      {!settings.hideTaxColumn && (
                        <td className="px-4 py-3 text-left">
                          <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
                            {item.taxLabel || `${item.taxPercent}%`}
                          </span>
                        </td>
                      )}
                      <td className="px-4 py-3 text-right font-bold text-slate-800 font-sans">
                        {formatCurrency(rowFinalAmount, 'YER')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* 5. Pricing Summary Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
          {/* Notes & Terms on left */}
          <div className="space-y-4 text-xs font-semibold text-slate-500 leading-relaxed text-left">
            {!settings.hideCustomerNotes && activeBill.customerNotes && (
              <div>
                <h4 className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">
                  Vendor Notes
                </h4>
                <p className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-slate-600 italic">
                  {activeBill.customerNotes}
                </p>
              </div>
            )}
            {!settings.hideTermsAndConditions && activeBill.termsConditions && (
              <div>
                <h4 className="text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">
                  Terms & Conditions
                </h4>
                <p className="whitespace-pre-line text-[11px] text-slate-600">
                  {activeBill.termsConditions}
                </p>
              </div>
            )}
          </div>

          {/* Calculations on right */}
          <div className="space-y-2 bg-slate-50/50 p-4 rounded-2xl border border-slate-100 text-xs text-left h-max">
            <div className="flex justify-between font-semibold text-slate-500">
              <span>Sub Total</span>
              <span className="font-bold text-slate-800">{formatCurrency(subTotalAmount, 'YER')}</span>
            </div>

            {discountPercent > 0 && (
              <div className="flex justify-between font-semibold text-rose-600">
                <span>Discount ({discountPercent}%)</span>
                <span>-{formatCurrency(calculatedDiscount, 'YER')}</span>
              </div>
            )}

            {!settings.hideTaxColumn && totalTaxAmount > 0 && (
              <div className="flex justify-between font-semibold text-slate-500">
                <span>Total Taxes (VAT)</span>
                <span className="font-bold text-slate-800">+{formatCurrency(totalTaxAmount, 'YER')}</span>
              </div>
            )}

            {!settings.hideShippingCharges && (activeBill.shippingCharges ?? 0) > 0 && (
              <div className="flex justify-between font-semibold text-slate-500">
                <span>Shipping Charges</span>
                <span className="font-bold text-slate-800">+{formatCurrency(activeBill.shippingCharges || 0, 'YER')}</span>
              </div>
            )}

            {adjustment !== 0 && (
              <div className="flex justify-between font-semibold text-slate-500">
                <span>Adjustment</span>
                <span className={cn("font-bold", adjustment < 0 ? "text-rose-600" : "text-emerald-600")}>
                  {adjustment > 0 ? "+" : ""}{formatCurrency(adjustment, 'YER')}
                </span>
              </div>
            )}

            <div 
              className="flex justify-between text-sm font-extrabold pt-2 border-t border-dashed border-slate-200 mt-2"
              style={{ color: settings.primaryColor }}
            >
              <span>Grand Total (YER)</span>
              <span>{formatCurrency(grandTotal, 'YER')}</span>
            </div>
          </div>
        </div>

        {/* 6. Professional Footer */}
        <div className="border-t border-slate-100 pt-6 text-center text-[10px] text-slate-400 font-medium">
          <p>Thank you for choosing Yemen Finance Systems.</p>
          <p className="mt-0.5">Sana'a Main Headquarters | Tel: +967 1 234 567 | Support Email: help@yemenfin.ye</p>
        </div>
      </div>
    </div>
  );
}

function lgAlign(align: string, original: string): string {
  if (align === 'left') return 'justify-start';
  if (align === 'center') return 'justify-center md:justify-center';
  if (align === 'right') return 'justify-end md:justify-end';
  return original;
}
