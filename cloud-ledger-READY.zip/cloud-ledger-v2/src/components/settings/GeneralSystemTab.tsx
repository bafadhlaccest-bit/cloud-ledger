import React from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Building2, 
  Globe, 
  Users, 
  ShieldAlert, 
  History, 
  Key, 
  Play, 
  Database, 
  Cpu, 
  Plus, 
  RefreshCw,
  Download,
  Info 
} from 'lucide-react';
import { cn } from '../../lib/utils';

export default function GeneralSystemTab({
  activeCategory,
  formConfig,
  handleInputChange,
  handlePermissionsChange,
  handleLanguageChange,
  users,
  apiKeys,
  automationRules,
  isRtl
}: {
  activeCategory: string;
  formConfig: any;
  handleInputChange: (key: string, value: any) => void;
  handlePermissionsChange: (role: 'Admin' | 'Accountant' | 'Vendor', action: 'read' | 'create' | 'update' | 'delete', checked: boolean) => void;
  handleLanguageChange: (lang: string) => void;
  users: any[];
  apiKeys: any[];
  automationRules: any[];
  isRtl: boolean;
}) {
  const { t, i18n } = useTranslation();

  return (
    <div className="space-y-6">
      {/* CATEGORY 1: General Parameters */}
      {activeCategory === 'cat_general' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {t('settings.company_profile', 'Company Profile')}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">
                  {t('settings.company_name', 'Company Name')}*
                </label>
                <input
                  type="text"
                  required
                  value={formConfig.systemName}
                  onChange={(e) => handleInputChange('systemName', e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">
                  {isRtl ? 'رابط شعار النظام (System Logo URL)' : 'Corporate Logo URL'}
                </label>
                <input
                  type="text"
                  value={formConfig.systemLogo}
                  onChange={(e) => handleInputChange('systemLogo', e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                />
              </div>
            </div>

            {/* Quick Logo presets */}
            <div className="mt-4 p-3 bg-slate-50 border border-slate-200/60 rounded-xl">
              <p className="text-xs font-semibold text-slate-600 mb-2">
                {isRtl ? 'اختيار شعار الشركة الافتراضي للعلامة التجارية بسرعة' : 'Choose Corporate Branding Logo Preset'}
              </p>
              <div className="flex flex-wrap gap-2">
                {[
                  { name: 'Al-Huraibi Trading Company', url: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=128&q=80' },
                  { name: 'Strategic Enterprise Orange', url: 'https://api.dicebear.com/7.x/initials/svg?seed=EO' },
                  { name: 'Modern Suite Premium Violet', url: 'https://api.dicebear.com/7.x/initials/svg?seed=PV' },
                  { name: 'Classic Green General ledger', url: 'https://api.dicebear.com/7.x/initials/svg?seed=GL' }
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleInputChange('systemLogo', preset.url)}
                    className="bg-white border text-xs px-2.5 py-1 rounded-lg hover:bg-indigo-50 hover:border-indigo-300 transition-colors cursor-pointer text-slate-700 font-medium"
                  >
                    {preset.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'معلومات الاتصال المؤسسية للتقارير' : 'Corporate Contact Parameters'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'عنوان المقر الرئيسي' : 'Registered Address'}</label>
                <input
                  type="text"
                  defaultValue="Sana'a - Sixty Street, Yemen"
                  className="px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-sm text-slate-500 cursor-not-allowed"
                  disabled
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'هاتف التواصل الرئيسي' : 'Primary Phone'}</label>
                <input
                  type="text"
                  defaultValue="+967 1 445566"
                  className="px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-sm text-slate-500 cursor-not-allowed"
                  disabled
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY 2: Localization */}
      {activeCategory === 'cat_localization' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'خيارات اللغة والتوطين والمناطق الزمنية' : 'Primary Timezones & Localization Values'}
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">
                  {t('settings.language')}
                </label>
                <select
                  value={i18n.language}
                  onChange={(e) => handleLanguageChange(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                >
                  <option value="en">English (US)</option>
                  <option value="ar">العربية (اليمن - ar-YE)</option>
                </select>
                <p className="text-2xs text-slate-400 leading-normal mt-0.5">
                  {isRtl 
                    ? 'معيار اللغة المحدد يؤثر تلقائياً على محرك ضبط محاذات القراءة والمصطلحات المحاسبية والضريبية الكلية.' 
                    : 'Standard language configuration changes layout alignments, numeric separators and accounting templates immediately.'
                  }
                </p>
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{t('settings.timezone')}</label>
                <select
                  value={formConfig.timezone}
                  onChange={(e) => handleInputChange('timezone', e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                >
                  <option value="Asia/Aden">Asia/Aden (GMT+3)</option>
                  <option value="Asia/Riyadh">Asia/Riyadh (GMT+3)</option>
                  <option value="Asia/Dubai">Asia/Dubai (GMT+4)</option>
                  <option value="UTC">Coordinated Universal Time (UTC)</option>
                </select>
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{t('settings.currency')}</label>
                <select
                  value={formConfig.currency}
                  onChange={(e) => handleInputChange('currency', e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                >
                  <option value="YER">YER (Yemeni Rial - ر.ي.)</option>
                  <option value="SAR">SAR (Saudi Riyal - ر.س.)</option>
                  <option value="USD">USD (US Dollar - $)</option>
                  <option value="EUR">EUR (Euro - €)</option>
                </select>
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'تمثيل الكسور والمسافات العشرية بالعمليات والمخرجات' : 'Decimal Format Display in Ledgers'}</label>
                <select
                  defaultValue="2 Decimals (.00)"
                  className="px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-sm text-slate-500 cursor-not-allowed"
                  disabled
                >
                  <option>2 Decimals (.00)</option>
                  <option>3 Decimals (.000)</option>
                  <option>0 Decimals (Whole numbers)</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY 10: Users */}
      {activeCategory === 'cat_user_auth' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <div className="flex justify-between items-center border-b pb-2 mb-4">
              <h2 className="text-lg font-bold text-slate-900">
                {isRtl ? 'سجل حسابات وصلاحيات الموظفين المعتمدة' : 'Operational Users Roster'}
              </h2>
              <button className="flex items-center gap-1.5 bg-indigo-600 text-white rounded-xl text-xs px-3 py-1.5 hover:bg-indigo-700 transition-colors font-semibold">
                <Plus className="w-3.5 h-3.5" />
                {isRtl ? 'إضافة موظف جديد' : 'New User account'}
              </button>
            </div>

            <div className="overflow-x-auto border border-slate-150 rounded-xl">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 text-xs font-semibold text-slate-700 uppercase border-b border-slate-200 font-mono">
                  <tr>
                    <th className="px-4 py-3">{isRtl ? 'الاسم' : 'User Name'}</th>
                    <th className="px-4 py-3">{isRtl ? 'البريد الإلكتروني' : 'Email address'}</th>
                    <th className="px-4 py-3">{isRtl ? 'المسمى الوظيفي' : 'System Role'}</th>
                    <th className="px-4 py-3">{isRtl ? 'حالة الحساب' : 'Authorization'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map(u => (
                    <tr key={u.id} className="hover:bg-slate-50/50">
                      <td className="px-4 py-3.5 font-semibold text-slate-900">{u.name}</td>
                      <td className="px-4 py-3.5 font-mono text-xs text-slate-500">{u.email}</td>
                      <td className="px-4 py-3.5 text-xs font-medium text-slate-900">{u.role}</td>
                      <td className="px-4 py-3.5">
                        <span className={cn(
                          "px-2 py-0.5 rounded text-2xs font-bold",
                          u.status === 'Active' ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-amber-50 text-amber-700 border border-amber-200"
                        )}>
                          {u.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY 11: Permissions Matrix */}
      {activeCategory === 'cat_permission_matrix' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'مصفوفة ضبط الحقوق والولوج الأمن للعمليات' : 'ERP System Permissions Audit Matrix'}
            </h2>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed">
              {isRtl 
                ? 'تخصيص مستويات الوصول لدفاتر الحسابات ودفتر قيود اليومية للموظفين، المحاسبين، والمندوبين بشكل منفصل وصارم.' 
                : 'Adjust fine-grained rights and transaction boundaries for system profiles.'
              }
            </p>

            <div className="overflow-x-auto border border-slate-200 rounded-xl shadow-sm bg-white">
              <table className="w-full text-left text-sm border-collapse">
                <thead className="bg-slate-50 text-slate-700 uppercase text-xs font-semibold border-b border-slate-200">
                  <tr>
                    <th className="px-5 py-3.5">{isRtl ? 'الدور الوظيفي' : 'System Role'}</th>
                    <th className="px-5 py-3.5 text-center">{isRtl ? 'قراءة' : 'Read'}</th>
                    <th className="px-5 py-3.5 text-center">{isRtl ? 'إنشاء' : 'Create'}</th>
                    <th className="px-5 py-3.5 text-center">{isRtl ? 'تعديل' : 'Update'}</th>
                    <th className="px-5 py-3.5 text-center">{isRtl ? 'حذف' : 'Delete'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {(['Admin', 'Accountant', 'Vendor'] as const).map((role) => (
                    <tr key={role} className="hover:bg-slate-50/50">
                      <td className="px-5 py-4 font-bold text-slate-900">{role}</td>
                      
                      <td className="px-5 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={formConfig.permissionsMatrix[role].read}
                          onChange={(e) => handlePermissionsChange(role, 'read', e.target.checked)}
                          className="w-4.5 h-4.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>

                      <td className="px-5 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={formConfig.permissionsMatrix[role].create}
                          onChange={(e) => handlePermissionsChange(role, 'create', e.target.checked)}
                          className="w-4.5 h-4.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>

                      <td className="px-5 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={formConfig.permissionsMatrix[role].update}
                          onChange={(e) => handlePermissionsChange(role, 'update', e.target.checked)}
                          className="w-4.5 h-4.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>

                      <td className="px-5 py-4 text-center">
                        <input
                          type="checkbox"
                          checked={formConfig.permissionsMatrix[role].delete}
                          onChange={(e) => handlePermissionsChange(role, 'delete', e.target.checked)}
                          className="w-4.5 h-4.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY: Audit Logs */}
      {activeCategory === 'cat_audit_logs' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'سجل المراجعة والنشاط الأمني لقواعد البيانات' : 'Security Audits Tracker logs'}
            </h2>
            <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
              {[
                { time: '2026-06-07 10:14', actor: 'acc.ali.bafadhl@gmail.com', desc: 'Updated VAT Ratio metrics to 15%' },
                { time: '2026-06-07 09:30', actor: 'waleed.m@huraibi.com', desc: 'Authorized manual journal draft entry reverse' },
                { time: '2026-06-06 14:22', actor: 'acc.ali.bafadhl@gmail.com', desc: 'Mapped default COA Cash Account to Al-Kuraimi Exchange' }
              ].map((log, idx) => (
                <div key={idx} className="p-3 bg-slate-50 border border-slate-150 rounded-xl text-xs flex justify-between gap-4">
                  <div>
                    <span className="font-mono bg-slate-200 px-1.5 py-0.5 rounded text-indigo-700 font-bold">{log.actor}</span>
                    <p className="text-slate-600 mt-1">{log.desc}</p>
                  </div>
                  <span className="text-3xs text-slate-400 font-mono mt-0.5">{log.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY: API Channels */}
      {activeCategory === 'cat_api_channels' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'قنوات الربط المباشر الـ API ومفاتيح المطورين' : 'External Integrator Credentials'}
            </h2>
            <div className="space-y-4">
              {apiKeys.map((key, idx) => (
                <div key={idx} className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl">
                  <h4 className="text-sm font-bold text-slate-900">{key.name}</h4>
                  <span className="font-mono text-xs text-indigo-700 bg-indigo-50/50 px-2 py-0.5 rounded inline-block mt-2 font-bold">{key.key}</span>
                  <p className="text-2xs text-slate-400 mt-2">Scope: {key.scope} | Created: {key.created}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY: Automated Rules */}
      {activeCategory === 'cat_automated_rules' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'إجراءات وقواعد الأتمتة البرمجية التلقائية' : 'Automated Trigger Pipelines'}
            </h2>
            <div className="space-y-3">
              {automationRules.map(rule => (
                <div key={rule.id} className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl flex justify-between items-center gap-4">
                  <div>
                    <h4 className="text-sm font-bold text-slate-950">{rule.name}</h4>
                    <p className="text-xs text-slate-605 mt-1">If Trigger: <span className="font-mono text-slate-600 font-bold">{rule.trigger}</span> | Action: <span className="font-medium">{rule.action}</span></p>
                  </div>
                  <span className={cn(
                    "px-2.5 py-1.5 rounded-full text-3xs font-extrabold uppercase tracking-wide",
                    rule.isActive ? "bg-emerald-100 text-emerald-800" : "bg-slate-200 text-slate-600"
                  )}>{rule.isActive ? 'Active' : 'Disabled'}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY: Diagnostics & Backup */}
      {activeCategory === 'cat_diagnostics' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'الفحص الإداري والنسخ الاحتياطي لقواعد البيانات' : 'System Diagnostic Health & SQL ledger archive management'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="flex items-center justify-between text-xs font-semibold mb-2 text-slate-700">
                  <span>PostgreSQL Engine RAM allocations</span>
                  <span>94.8% Operational SLA</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-full w-[94.8%]" />
                </div>
                <p className="text-3xs text-slate-400 mt-2 leading-relaxed">Checking ledger table indexes blocks, custom query optimizer channels is performing healthy.</p>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-800">Complete Ledger SQL Database Export</h4>
                  <p className="text-3xs text-slate-400 mt-1">Simulate immediate safe retrieval local backup file dump of full accounting accounts, logs and values.</p>
                </div>
                <button className="flex items-center justify-center gap-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold py-2 mt-4 hover:bg-indigo-700 transition-colors">
                  <Download className="w-3.5 h-3.5" />
                  Download ledgers backup (254.2 MB)
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY: AI Processing */}
      {activeCategory === 'cat_ai_accountant' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'تخصيص سلوك وبنية المحاسب الذكي ومراجعة الـ OCR' : 'AI Processing parameters configuration'}
            </h2>
            <div className="space-y-4">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'تعليمات وقواعد المعالج الذكي الأساسية' : 'AI Custom System Context Guidelines'}</label>
                <textarea 
                  rows={4}
                  defaultValue="You are the ultimate corporate AI Auditor for Al-Huraibi Trading. Filter out duplicate VAT codes, align credit lines safely, and matching Accounts Payable bounds before pushing drafts directly."
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
