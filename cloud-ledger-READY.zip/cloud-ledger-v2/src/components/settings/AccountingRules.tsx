import React from 'react';
import { useTranslation } from 'react-i18next';
import { SlidersHorizontal, Percent, Calendar, ShieldAlert, BarChart3, Info, RefreshCw } from 'lucide-react';

interface AccountingRulesProps {
  formConfig: any;
  handleInputChange: (key: string, value: any) => void;
  accountsList: any[];
  isAccountsLoading: boolean;
  isRtl: boolean;
}

export default function AccountingRules({
  formConfig,
  handleInputChange,
  accountsList,
  isAccountsLoading,
  isRtl
}: AccountingRulesProps) {
  const { t } = useTranslation();

  return (
    <div className="space-y-6 animate-fadeIn" id="accounting-rules-container">
      {/* 1. COA Mappings */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6" id="coa-mapping-card">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl" id="sliders-icon-wrapper">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-950 text-base">
              {isRtl ? 'التوجيه الحسابي التلقائي لمعاملات الدورة المستندية' : 'Chart of Accounts Workflow Mapping'}
            </h3>
            <p className="text-xs text-slate-500">
              {isRtl ? 'ربط وتوجيه حركات المستندات والمبيعات والمشتريات والقبض المحفوظة بالحسابات الفعلية في شجرة الحسابات بدقة.' : 'Set the target mapping configuration in General Ledger accounts for automated balance flows.'}
            </p>
          </div>
        </div>

        {isAccountsLoading ? (
          <div className="h-32 flex items-center justify-center text-indigo-600 gap-2 font-medium" id="accounts-loading-state">
            <RefreshCw className="w-5 h-5 animate-spin" />
            <span>{isRtl ? 'جاري تحميل شجرة الحسابات...' : 'Fetching Chart of Accounts lists...'}</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100" id="coa-mapping-inputs">
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-slate-700">
                {isRtl ? 'حساب إيرادات المبيعات الافتراضي (Sales Revenue Account)*' : 'Default Sales Revenue Account*'}
              </label>
              <select
                value={formConfig.defaultSalesAccountId}
                id="default-sales-account-selector"
                onChange={(e) => handleInputChange('defaultSalesAccountId', e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
              >
                <option value="">{isRtl ? '-- حدد حساب الإيرادات --' : '-- Choose Revenue Account --'}</option>
                {accountsList.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.code} - {acc.name} ({acc.type})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-slate-700">
                {isRtl ? 'حساب الموردين والدائنين الافتراضي (Accounts Payable)*' : 'Default Accounts Payable (Creditors)*'}
              </label>
              <select
                value={formConfig.defaultPayableAccountId}
                id="default-payable-account-selector"
                onChange={(e) => handleInputChange('defaultPayableAccountId', e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
              >
                <option value="">{isRtl ? '-- حدد حساب المطلوبات/الدائنون --' : '-- Choose Liabilities Account --'}</option>
                {accountsList.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.code} - {acc.name} ({acc.type})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-slate-700">
                {isRtl ? 'حساب النقد المباشر والصناديق الافتراضي (Cash On Hand)*' : 'Default Cash Account*'}
              </label>
              <select
                value={formConfig.defaultCashAccountId}
                id="default-cash-account-selector"
                onChange={(e) => handleInputChange('defaultCashAccountId', e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
              >
                <option value="">{isRtl ? '-- حدد حساب النقدية والبنك --' : '-- Choose Assets Account --'}</option>
                {accountsList.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.code} - {acc.name} ({acc.type})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-slate-700">
                {isRtl ? 'نسبة ضريبة القيمة المضافة الحكومية المتوقعة (%)' : 'Standard Corporate VAT Percentage (%)'}
              </label>
              <div className="relative">
                <input
                  type="number"
                  id="vat-percentage-input"
                  value={formConfig.vatPercentage}
                  onChange={(e) => handleInputChange('vatPercentage', Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none pl-12 font-mono font-bold text-slate-800"
                />
                <Percent className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 2. Accounting Period & Control Indicators */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6" id="period-closure-card">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl" id="calendar-icon-wrapper">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-950 text-base">
              {isRtl ? 'الفترة المحاسبية وإغلاق الدفاتر' : 'Accounting Period Boundaries & Closure Lock'}
            </h3>
            <p className="text-xs text-slate-500">
              {isRtl ? 'تأمين الحركات السابقة ومنع التعديل على البيانات بعد اعتماد التسويات الختامية السنوية.' : 'Enforce lockouts preventing edits to journal entries once quarterly audited reports compile.'}
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 flex flex-col md:flex-row gap-6 justify-between items-start md:items-center">
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-slate-900">{isRtl ? 'تاريخ إقفال الدفاتر الحالي' : 'Active Financial Ledger Lock Date'}</h4>
            <span className="inline-block bg-rose-50 border border-rose-200 text-rose-700 text-xs px-2.5 py-1 rounded-lg font-mono font-semibold">2025-12-31</span>
            <p className="text-[11px] text-slate-400 max-w-lg leading-relaxed mt-2">
              {isRtl ? '* لن يتمكن أي محاسب من تعديل القيود اليومية أو المستندات المؤرخة قبل هذا التاريخ لحماية النزاهة المالية.' : '* Transactions dated prior to this lock date are completely immutable, protecting general ledger auditing compliance.'}
            </p>
          </div>
          <button
            type="button"
            className="px-4 py-2 bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold rounded-xl hover:bg-indigo-100 transition-colors cursor-pointer"
          >
            {isRtl ? 'تعديل تاريخ الإقفال' : 'Modify Lock Boundary'}
          </button>
        </div>
      </div>
    </div>
  );
}
