import React from 'react';
import { useTranslation } from 'react-i18next';
import { 
  RefreshCw, 
  Info, 
  SlidersHorizontal, 
  FileText, 
  Percent, 
  Lock, 
  Calendar, 
  AlertTriangle,
  Building,
  Layers,
  Boxes
} from 'lucide-react';
import { cn } from '../../lib/utils';

export default function AccountingConfigurationsTab({
  activeCategory,
  formConfig,
  handleInputChange,
  accountsList,
  isAccountsLoading,
  companies,
  isRtl
}: {
  activeCategory: string;
  formConfig: any;
  handleInputChange: (key: string, value: any) => void;
  accountsList: any[];
  isAccountsLoading: boolean;
  companies: any[];
  isRtl: boolean;
}) {
  const { t } = useTranslation();

  return (
    <div className="space-y-6">
      {/* CATEGORY 3: COA Mapping */}
      {activeCategory === 'cat_coa_mapping' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'التوجيه الحسابي التلقائي لمعاملات الدورة المستندية' : 'Chart of Accounts Workflow Mapping'}
            </h2>
            <p className="text-xs text-slate-400 mb-4 font-medium">
              {isRtl 
                ? 'ربط وتوجيه حركات المستندات والمبيعات والمشتريات والقبض المحفوظة بالحسابات الفعلية في شجرة الحسابات بدقة.' 
                : 'Set the target mapping configuration in General Ledger accounts for automated balance flows.'
              }
            </p>

            {isAccountsLoading ? (
              <div className="h-32 flex items-center justify-center text-indigo-600 gap-2 font-medium">
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>{isRtl ? 'جاري تحميل شجرة الحسابات...' : 'Fetching Chart of Accounts lists...'}</span>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                <div className="flex flex-col gap-2">
                  <label className="text-xs font-semibold text-slate-700">
                    {isRtl ? 'حساب إيرادات المبيعات الافتراضي (Sales Revenue Account)*' : 'Default Sales Revenue Account*'}
                  </label>
                  <select
                    value={formConfig.defaultSalesAccountId}
                    onChange={(e) => handleInputChange('defaultSalesAccountId', e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  >
                    <option value="">{isRtl ? '-- حدد حساب الإيرادات --' : '-- Choose Revenue Account --'}</option>
                    {accountsList.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.code} - {acc.name} ({acc.type})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col gap-2">
                  <label className="text-xs font-semibold text-slate-700">
                    {isRtl ? 'حساب الموردين والدائنين الافتراضي (Accounts Payable)*' : 'Default Accounts Payable (Creditors)*'}
                  </label>
                  <select
                    value={formConfig.defaultPayableAccountId}
                    onChange={(e) => handleInputChange('defaultPayableAccountId', e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  >
                    <option value="">{isRtl ? '-- حدد حساب المطلوبات/الدائنون --' : '-- Choose Liabilities Account --'}</option>
                    {accountsList.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.code} - {acc.name} ({acc.type})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col gap-2">
                  <label className="text-xs font-semibold text-slate-700">
                    {isRtl ? 'حساب النقد المباشر والصناديق الافتراضي (Cash On Hand)*' : 'Default Cash Account*'}
                  </label>
                  <select
                    value={formConfig.defaultCashAccountId}
                    onChange={(e) => handleInputChange('defaultCashAccountId', e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  >
                    <option value="">{isRtl ? '-- حدد حساب النقدية والبنك --' : '-- Choose Liquidity Account --'}</option>
                    {accountsList.map((acc) => (
                      <option key={acc.id} value={acc.id}>
                        {acc.code} - {acc.name} ({acc.type})
                      </option>
                    ))}
                  </select>
                </div>

              </div>
            )}
          </div>
        </div>
      )}

      {/* CATEGORY 4: VAT Rules */}
      {activeCategory === 'cat_vat_rules' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'ضريبة القيمة المضافة ومعدلات الاحتساب' : 'Tax & Value Added Tax Configuration'}
            </h2>
            <p className="text-xs text-slate-400 mb-4 font-medium">
              {isRtl 
                ? 'معدلات الحساب الضريبي للزكاة والدخل وقيم ضريبة المبيعات والمشتريات الافتراضية للبلد المستهدف.' 
                : 'Adjust percentage parameters for dynamic invoice taxation checks.'
              }
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">
                  {isRtl ? 'معدل ونسبة ضريبة القيمة المضافة (%)*' : 'Active VAT Ratio (%)*'}
                </label>
                <input
                  type="number"
                  required
                  value={formConfig.vatPercentage}
                  onChange={(e) => handleInputChange('vatPercentage', Number(e.target.value))}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  min="0"
                  max="100"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">
                  {isRtl ? 'حالة التفعيل الافتراضية للضرائب' : 'Default Tax Application Mode'}
                </label>
                <select
                  defaultValue="Inclusive"
                  className="px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-sm text-slate-500 cursor-not-allowed"
                  disabled
                >
                  <option>Inclusive (الأسعار شاملة الضريبة)</option>
                  <option>Exclusive (يتم إضافة الضريبة للإجمالي)</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY 5: Invoice Sequence */}
      {activeCategory === 'cat_inv_sequence' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-950 border-b pb-2 mb-4 font-sans tracking-tight">
              {isRtl ? 'تسلسل وترميز فواتير المبيعات' : 'Sales Invoice Numbering Sequence'}
            </h2>
            <p className="text-xs text-slate-400 mb-4 font-medium">
              {isRtl 
                ? 'نموذج ترميز وتركيب الفاتورة لتجنب الفراغات أو تضارب المعاملات.' 
                : 'Fine-tune document number generators to match local legal accounting requirements.'
              }
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'البادئة (Prefix)*' : 'Invoice Prefix*'}</label>
                <input
                  type="text"
                  required
                  value={formConfig.invoicePrefix}
                  onChange={(e) => handleInputChange('invoicePrefix', e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none font-mono"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'اللاحقة (Suffix)' : 'Invoice Suffix'}</label>
                <input
                  type="text"
                  value={formConfig.invoiceSuffix}
                  onChange={(e) => handleInputChange('invoiceSuffix', e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none font-mono"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'الرقم التسلسلي التالي للمعاينة' : 'Sample Format Preview'}</label>
                <div className="px-3 py-2.5 bg-slate-150 border border-slate-200/80 rounded-xl text-sm font-mono text-indigo-700 bg-indigo-50/50 font-bold">
                  {formConfig.invoicePrefix}-2026-001{formConfig.invoiceSuffix}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY 6: Bill Sequence */}
      {activeCategory === 'cat_bill_sequence' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-950 border-b pb-2 mb-4 font-sans tracking-tight">
              {isRtl ? 'تسلسل وترميز فواتير المشتريات والموردين' : 'Purchase Bill Numbering Sequence'}
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'البادئة (Prefix)*' : 'Bill Prefix*'}</label>
                <input
                  type="text"
                  required
                  value={formConfig.billPrefix}
                  onChange={(e) => handleInputChange('billPrefix', e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none font-mono"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'اللاحقة (Suffix)' : 'Bill Suffix'}</label>
                <input
                  type="text"
                  value={formConfig.billSuffix}
                  onChange={(e) => handleInputChange('billSuffix', e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none font-mono"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'الرقم التسلسلي التالي للمعاينة' : 'Sample Format Preview'}</label>
                <div className="px-3 py-2.5 bg-slate-150 border border-slate-200/80 rounded-xl text-sm font-mono text-indigo-700 bg-indigo-50/50 font-bold">
                  {formConfig.billPrefix}-2026-001{formConfig.billSuffix}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY 7: Customer Credit Details */}
      {activeCategory === 'cat_cust_credit' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'الحدود الائتمانية للعملاء والديون' : 'Customer Credit Limits & Control bounds'}
            </h2>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-4 shadow-sm hover:border-slate-300">
              <div className="max-w-xl">
                <h4 className="text-sm font-bold text-slate-950">
                  {isRtl ? 'تفعيل فحص الحدود الائتمانية عند بيع الفواتير*' : 'Restrict client invoice post exceeding absolute credit limits'}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  {isRtl 
                    ? 'تشغيل الحماية لمنع منسوبي المبيعات من بيع بضائع بالأجل لعميل تجاوز حده الائتماني المعتمد يدوياً.' 
                    : 'Ensure invoice workflows block sales posting if customer balances violate safety limits.'
                  }
                </p>
              </div>

              <button
                type="button"
                onClick={() => handleInputChange('customerCreditLimitRestriction', !formConfig.customerCreditLimitRestriction)}
                className={cn(
                  "w-12 h-6.5 rounded-full p-1 transition-colors cursor-pointer shrink-0 focus:outline-none",
                  formConfig.customerCreditLimitRestriction ? "bg-indigo-600" : "bg-slate-250"
                )}
              >
                <div className={cn(
                  "w-4.5 h-4.5 rounded-full bg-white shadow-sm transition-transform",
                  formConfig.customerCreditLimitRestriction ? (isRtl ? "-translate-x-5.5" : "translate-x-5.5") : "translate-x-0"
                )} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY 8: Vendor Payment Terms */}
      {activeCategory === 'cat_vendor_terms' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-950 border-b pb-2 mb-4 font-sans tracking-tight">
              {isRtl ? 'فترات السداد الذاتية وتنبيهات الاستحقاق للموردين' : 'Primary Vendor Account Terms'}
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">
                  {isRtl ? 'فترة السداد الافتراضية بالفواتير المستلمة (بالأيام)*' : 'Default Purchase payment threshold (Days)*'}
                </label>
                <input
                  type="number"
                  required
                  value={formConfig.vendorPaymentTermThreshold}
                  onChange={(e) => handleInputChange('vendorPaymentTermThreshold', Number(e.target.value))}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
                  min="1"
                  max="365"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY 9: Service Maintenance Switch */}
      {activeCategory === 'cat_service_module' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'بوابة إدارة الصيانة وورش التشغيل الفني' : 'Specialized Service & Technical Maintenance Switch'}
            </h2>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-4 shadow-sm hover:border-slate-300">
              <div className="max-w-xl">
                <h4 className="text-sm font-bold text-slate-950">
                  {isRtl ? 'تفعيل وحدة فواتير خدمات الموردين وعقد التشغيل الذاتي*' : 'Activate service orders within Purchase Invoices'}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  {isRtl 
                    ? 'إظهار مسارات صيانة العربات الفنية وقطع الغيار والتكلفة والمورد والموعد المخطط لوصولها.' 
                    : 'Inject specialized job order fields inside bills and enable tracking views throughout the workspace.'
                  }
                </p>
              </div>

              <button
                type="button"
                onClick={() => handleInputChange('enableServiceModule', !formConfig.enableServiceModule)}
                className={cn(
                  "w-12 h-6.5 rounded-full p-1 transition-colors cursor-pointer shrink-0 focus:outline-none",
                  formConfig.enableServiceModule ? "bg-indigo-600" : "bg-slate-250"
                )}
              >
                <div className={cn(
                  "w-4.5 h-4.5 rounded-full bg-white shadow-sm transition-transform",
                  formConfig.enableServiceModule ? (isRtl ? "-translate-x-5.5" : "translate-x-5.5") : "translate-x-0"
                )} />
              </button>
            </div>

            <div className="mt-4 p-4 rounded-xl bg-amber-50 border border-amber-200/70 text-amber-900 text-xs flex gap-3">
              <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">{isRtl ? 'تنبيه النظم المحاسبية:' : 'Notice to System Managers:'}</span>
                <p className="mt-1 leading-relaxed">
                  {isRtl 
                    ? 'تعطيل هذا الخواص سيقوم فوراً بإخفاء قنوات متابعة التسليم وأشكال الصيانة لحقول وواجهة الـ Service Bills لتجنب التشويش على بقية منسوبي الفروع.' 
                    : 'Deactivating this module hides all mechanical service lines and receiving dashboards from operations to keep workspaces lean and clean.'
                  }
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY: Multi Company */}
      {activeCategory === 'cat_multi_company' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'إدارة مجموعة وتفرع الفروع والشركات القابضة' : 'Multi-Company Consolidations & Division structure'}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {companies.map(c => (
                <div key={c.id} className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl shadow-xs">
                  <span className="text-2xs font-extrabold bg-slate-200 px-1.5 py-0.5 rounded text-indigo-800 font-mono">{c.code}</span>
                  <h4 className="text-sm font-bold text-slate-900 mt-2">{c.name}</h4>
                  <p className="text-xs text-slate-450 mt-1">{c.address}</p>
                  {c.isDefault && <span className="inline-block mt-3 text-3xs font-extrabold bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">Primary Headquarters</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* CATEGORY: Inventory Control */}
      {activeCategory === 'cat_inventory_control' && (
        <div className="space-y-6 animate-fadeIn">
          <div>
            <h2 className="text-lg font-bold text-slate-900 border-b pb-2 mb-4">
              {isRtl ? 'ضوابط المستودعات وسياسة حظر تلاعب الكميات بفئات المخزن' : 'Warehousing Control Metrics'}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-slate-700">{isRtl ? 'طريقة حساب تكلفة الصنف وسحبه يدوياً' : 'System Inventory Removal Strategy'}</label>
                <select className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
                  <option>FIFO (الوارد أولاً يصرف أولاً)</option>
                  <option>LIFO (الوارد أخيراً يصرف أولاً)</option>
                  <option>FEFO (قريب انتهاء الصلاحية يصرف أولاً)</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
