import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Building2, Globe, Sparkles, Layers, Sliders, CheckCircle2, RefreshCw, AlertCircle } from 'lucide-react';
import { cn } from '../../lib/utils';
import { CurrencyService, GLOBAL_CURRENCIES, custom_exchange_rates } from '../../services/CurrencyService';

interface GeneralSettingsProps {
  formConfig: any;
  handleInputChange: (key: string, value: any) => void;
  handleLanguageChange: (lang: string) => void;
  isRtl: boolean;
}

export default function GeneralSettings({
  formConfig,
  handleInputChange,
  handleLanguageChange,
  isRtl
}: GeneralSettingsProps) {
  const { t, i18n } = useTranslation();

  // Exchange rate states
  const [officialRates, setOfficialRates] = useState<Record<string, number>>({
    'USD': 1.0, 'EUR': 0.92, 'SAR': 3.75, 'YER': 250.0, 'AED': 3.67, 'EGP': 47.0
  });
  const [customRates, setCustomRates] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    GLOBAL_CURRENCIES.forEach(curr => {
      if (custom_exchange_rates[curr.code] !== undefined) {
        initial[curr.code] = String(custom_exchange_rates[curr.code]);
      }
    });
    return initial;
  });
  const [isFetching, setIsFetching] = useState(false);
  const [fetchStatus, setFetchStatus] = useState<'idle' | 'success' | 'error'>('idle');

  // Synchronize dynamic rates and overrides on baseCurrency/formConfig change
  useEffect(() => {
    const updatedCustom: Record<string, string> = {};
    GLOBAL_CURRENCIES.forEach(curr => {
      if (custom_exchange_rates[curr.code] !== undefined) {
        updatedCustom[curr.code] = String(custom_exchange_rates[curr.code]);
      }
    });
    setCustomRates(updatedCustom);

    let active = true;
    CurrencyService.fetchIMFRates(formConfig.currency)
      .then(rates => {
        if (active) {
          setOfficialRates(rates);
        }
      })
      .catch(err => {
        console.warn("Silent initial IMF fetch failed:", err);
      });
    return () => { active = false; };
  }, [formConfig.currency]);

  // Fetch from IMF Service API
  const handleFetchIMFRates = async () => {
    setIsFetching(true);
    setFetchStatus('idle');
    try {
      const rates = await CurrencyService.fetchIMFRates(formConfig.currency);
      setOfficialRates(rates);
      setFetchStatus('success');
      setTimeout(() => setFetchStatus('idle'), 4000);
    } catch (err) {
      console.error("IMF Fetch error in UI:", err);
      setFetchStatus('error');
      setTimeout(() => setFetchStatus('idle'), 4000);
    } finally {
      setIsFetching(false);
    }
  };

  // Override handler
  const handleCustomRateChange = (code: string, value: string) => {
    setCustomRates(prev => ({ ...prev, [code]: value }));
    const num = parseFloat(value);
    if (!value || isNaN(num) || num <= 0) {
      CurrencyService.saveCustomRate(code, undefined);
    } else {
      CurrencyService.saveCustomRate(code, num);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn" id="general-settings-container">
      {/* Company Details Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6" id="company-profile-card">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl" id="logo-icon-wrapper">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-950 text-base">
              {t('settings.company_profile', 'Company Identity Profile')}
            </h3>
            <p className="text-xs text-slate-500">
              {isRtl ? 'تعديل المعايير الأساسية وهوية العلامة التجارية للشركة في التقارير المحاسبية والمثبتة للأطراف الخارجية.' : 'Adjust corporate metadata and visual branding assets engraved into accounting sheets.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100">
          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-slate-700">
              {t('settings.company_name', 'Company Name')}*
            </label>
            <input
              type="text"
              required
              id="system-name-input"
              value={formConfig.systemName}
              onChange={(e) => handleInputChange('systemName', e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none focus:border-indigo-500 transition-all font-medium"
            />
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-slate-700">
              {isRtl ? 'رابط شعار النظام (System Logo URL)' : 'Corporate Logo URL'}
            </label>
            <input
              type="text"
              id="system-logo-input"
              value={formConfig.systemLogo}
              onChange={(e) => handleInputChange('systemLogo', e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none focus:border-indigo-500 transition-all font-mono text-xs"
            />
          </div>
        </div>

        {/* Logo presets */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/60" id="logo-presets-container">
          <p className="text-xs font-semibold text-slate-600 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
            {isRtl ? 'اختيار شعار الشركة الافتراضي للعلامة التجارية بسرعة' : 'Choose Corporate Branding Logo Preset'}
          </p>
          <div className="flex flex-wrap gap-2">
            {[
              { name: 'Al-Huraibi Trading Company', url: 'https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=128&q=80' },
              { name: 'Strategic Enterprise Orange', url: 'https://api.dicebear.com/7.x/initials/svg?seed=EO' },
              { name: 'Modern Suite Premium Violet', url: 'https://api.dicebear.com/7.x/initials/svg?seed=PV' },
              { name: 'Classic Green General ledger', url: 'https://api.dicebear.com/7.x/initials/svg?seed=GL' }
            ].map((preset, idx) => (
              <button
                key={idx}
                type="button"
                id={`preset-logo-btn-${idx}`}
                onClick={() => handleInputChange('systemLogo', preset.url)}
                className="bg-white border text-[11px] px-2.5 py-1 rounded-lg hover:bg-indigo-50 hover:border-indigo-300 transition-colors cursor-pointer text-slate-700 font-medium"
              >
                {preset.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Localization Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6" id="localization-settings-card">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl" id="globe-icon-wrapper">
            <Globe className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-950 text-base">
              {t('settings.cat_localization', 'Regional & Language Controls')}
            </h3>
            <p className="text-xs text-slate-500">
              {isRtl ? 'تكييف خيارات اللغة الافتراضية للواجهة وسلاسل الترقيم لتسهيل الانتقال الآني بين العربية والانجليزية.' : 'Fine-tune time zone values, multi-currency defaults, and RTL localization vectors.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 border-t border-slate-100">
          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-slate-700">
              {t('settings.language', 'Language')}
            </label>
            <select
              value={i18n.language}
              id="language-selector"
              onChange={(e) => handleLanguageChange(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
            >
              <option value="ar">العربية (Arabic - RTL)</option>
              <option value="en">English (US - LTR)</option>
            </select>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-slate-700 font-medium">
              {isRtl ? 'العملة الأساسية للنظام (Base Currency)' : 'System Base Currency'}
            </label>
            <select
              value={formConfig.currency}
              id="currency-selector"
              onChange={(e) => handleInputChange('currency', e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none font-medium text-slate-900"
            >
              {GLOBAL_CURRENCIES.map(curr => (
                <option key={curr.code} value={curr.code}>
                  {curr.flag} {curr.code} ({curr.name})
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-slate-700 font-medium">
              {isRtl ? 'المنطقة الزمنية (Timezone)' : 'System Timezone'}
            </label>
            <select
              value={formConfig.timezone}
              id="timezone-selector"
              onChange={(e) => handleInputChange('timezone', e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none font-medium"
            >
              <option value="Asia/Aden">Asia/Aden (YER HQ)</option>
              <option value="Asia/Riyadh">Asia/Riyadh (GMT+3)</option>
              <option value="America/New_York">America/New_York (EST)</option>
            </select>
          </div>
        </div>

        {/* Divider and Exchange Rate Management section */}
        <div className="border-t border-slate-100 pt-6 mt-6 space-y-4" id="rates-management-section">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h4 className="text-sm font-bold text-slate-950 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-indigo-600" />
                {isRtl ? 'لوحة أسعار الصرف وتحويل العملات' : 'Exchange Rates Management Dashboard'}
              </h4>
              <p className="text-xs text-slate-500">
                {isRtl
                  ? 'جلب أسعار الصرف الرسمية من صندوق النقد الدولي (SDR) وتعديل أسعار الصرف المحاسبية الفعلية حسب متطلبات الصيرفة والتسوية اليومية.'
                  : 'Fetch SDR rates from IMF and specify custom accounting rates to use instead of central reference rates.'}
              </p>
            </div>

            <button
              type="button"
              id="fetch-rates-btn"
              onClick={handleFetchIMFRates}
              disabled={isFetching}
              className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold rounded-lg text-xs transition-all cursor-pointer disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed select-none border border-indigo-100"
            >
              <RefreshCw className={cn("w-3.5 h-3.5", isFetching && "animate-spin")} />
              {isRtl ? 'تحديث الأسعار' : 'Fetch IMF Rates'}
            </button>
          </div>

          {fetchStatus === 'success' && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 animate-fadeIn" id="rates-fetch-success-msg">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                {isRtl
                  ? 'تم تحديث الأسعار الرسمية بنجاح وإعادة معايرتها بالنسبة للعملة الأساس.'
                  : 'Official rates fetched successfully from IMF services and recalibrated to base.'}
              </span>
            </div>
          )}

          {fetchStatus === 'error' && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2 animate-fadeIn" id="rates-fetch-error-msg">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>
                {isRtl
                  ? 'تعذر الاتصال بخوادم صندوق النقد الدولي المباشرة. تم تفعيل أسعار معيارية احتياطية تفادياً لأي توقف في المعاملات.'
                  : 'IMF connection failure. Applied robust localized fallback rates to keep ledger stable.'}
              </span>
            </div>
          )}

          {/* Table of Currencies */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl bg-slate-50/20 shadow-xs" id="currency-rates-table-wrapper">
            <table className="w-full text-xs text-left text-slate-700 font-medium" dir={isRtl ? 'rtl' : 'ltr'}>
              <thead className="text-[11px] font-bold uppercase tracking-wider text-slate-500 bg-slate-50 border-b border-slate-200">
                <tr>
                  <th scope="col" className="px-4 py-3 text-center w-16">
                    {isRtl ? 'العلم' : 'Flag'}
                  </th>
                  <th scope="col" className={cn("px-4 py-3", isRtl ? "text-right" : "text-left")}>
                    {isRtl ? 'رمز العملة' : 'Code'}
                  </th>
                  <th scope="col" className={cn("px-4 py-3", isRtl ? "text-right" : "text-left")}>
                    {isRtl ? 'اسم العملة' : 'Name'}
                  </th>
                  <th scope="col" className={cn("px-4 py-3", isRtl ? "text-right" : "text-left")}>
                    {isRtl ? 'سعر IMF المقيّم' : 'IMF Official Rate'}
                  </th>
                  <th scope="col" className={cn("px-4 py-3 max-w-[170px]", isRtl ? "text-left pl-6" : "text-right pr-6")}>
                    {isRtl ? 'السعر الفعلي (تعديل يدوي)' : 'Custom Override Rate'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {GLOBAL_CURRENCIES.map((curr) => {
                  const officialVal = officialRates[curr.code] || 1.0;
                  const customVal = customRates[curr.code] || '';
                  const isBase = curr.code === formConfig.currency;

                  return (
                    <tr key={curr.code} className={cn("hover:bg-slate-50/50 transition-colors", isBase && "bg-indigo-50/20 font-semibold text-slate-900 border-indigo-100")}>
                      <td className="px-4 py-3 text-center text-base select-none">
                        {curr.flag}
                      </td>
                      <td className={cn("px-4 py-3 font-mono font-bold text-xs", isBase ? "text-indigo-900" : "text-slate-600")}>
                        {curr.code}
                      </td>
                      <td className="px-4 py-3 text-slate-600 text-xs">
                        {curr.name} <span className="text-[10px] text-slate-400 font-bold">({curr.symbol})</span>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs">
                        {isBase ? (
                          <span className="text-indigo-700 bg-indigo-50/60 px-2 py-0.5 rounded-md border border-indigo-100 font-bold text-[10px]">
                            1.0000 ({isRtl ? 'أساسية' : 'Base'})
                          </span>
                        ) : (
                          officialVal.toFixed(5)
                        )}
                      </td>
                      <td className={cn("px-4 py-2 text-right max-w-[170px]", isRtl ? "text-left" : "text-right")}>
                        {isBase ? (
                          <input
                            type="text"
                            disabled
                            value="1.0"
                            className="w-full max-w-[130px] text-center px-3 py-1 bg-slate-100 border border-slate-200 text-slate-400 rounded-lg text-xs font-mono font-bold cursor-not-allowed select-none inline-block"
                          />
                        ) : (
                          <div className="relative inline-block w-full max-w-[130px] text-left">
                            <input
                              type="number"
                              step="any"
                              min="0"
                              value={customVal}
                              onChange={(e) => handleCustomRateChange(curr.code, e.target.value)}
                              placeholder={officialVal.toFixed(4)}
                              className="w-full text-center px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold focus:ring-2 focus:ring-indigo-500/20 focus:outline-none focus:border-indigo-500 transition-all text-slate-900"
                            />
                            {customVal && (
                              <span className="absolute right-2 top-2.5 w-1.5 h-1.5 rounded-full bg-indigo-600 animate-pulse" title="Manual Override Active" />
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Multi-Company Group Ledger Structure */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6" id="multi-company-group-card">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl" id="layers-icon-wrapper">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-950 text-base">
              {isRtl ? 'المنشآت المتعددة والفروع' : 'Multi-Company & Corporate Branches'}
            </h3>
            <p className="text-xs text-slate-500">
              {isRtl ? 'إدارة دمج الفروع والشركات الشريكة تحت مظلة دليل حسابات موحد وهيكل مرجع مركزي.' : 'Configure corporate branches and legal entities to execute cross-ledger consolidation.'}
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex justify-between items-center">
              <div>
                <h4 className="text-xs font-bold text-slate-900">Al-Huraibi Trading Company HQ</h4>
                <p className="text-[10px] text-indigo-600 font-mono">Code: AHTC | Default Entity</p>
              </div>
              <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-700 text-[10px] font-bold">HQ Primary</span>
            </div>
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex justify-between items-center">
              <div>
                <h4 className="text-xs font-bold text-slate-900">Al-Huraibi Logistics & Retail LLC</h4>
                <p className="text-[10px] text-slate-500 font-mono">Code: AHLR | Sub-Subsidiary</p>
              </div>
              <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px] font-medium">Branch Corp</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
