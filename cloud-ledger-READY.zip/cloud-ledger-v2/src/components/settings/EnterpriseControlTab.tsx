import React from 'react';
import { useTranslation } from 'react-i18next';
import { useSettings } from '../../context/SettingsContext';
import { 
  Building2, 
  Layers, 
  SlidersHorizontal, 
  ShieldAlert, 
  ShieldCheck, 
  HelpCircle, 
  RefreshCw,
  Database,
  Search,
  Check,
  Building,
  DollarSign,
  TrendingUp,
  Coins,
  BarChart3,
  Scale,
  Calendar,
  RotateCcw,
  AlertTriangle
} from 'lucide-react';
import { YearEndClosingService } from '../../services/YearEndClosingService';
import { db, collection, getDocs, updateDoc, query, where, doc } from '../../firebase';
import { useRBAC } from '../../hooks/useRBAC';

export default function EnterpriseControlTab({ 
  accountsList, 
  isAccountsLoading,
  isRtl 
}: { 
  accountsList: any[];
  isAccountsLoading: boolean;
  isRtl: boolean;
}) {
  const { t } = useTranslation();
  const { settings, updateSettings } = useSettings();

  const [actualsMap, setActualsMap] = React.useState<{[key: string]: number}>({});
  const [localBudgets, setLocalBudgets] = React.useState<{[key: string]: string}>({});
  const [savingBudgetId, setSavingBudgetId] = React.useState<string | null>(null);
  const [searchFilter, setSearchFilter] = React.useState('');
  const [categoryFilter, setCategoryFilter] = React.useState('EXPENSE');
  const [isLoadingActuals, setIsLoadingActuals] = React.useState(false);

  // States for Year-End Closing and Accrual Reversals
  const [closingYear, setClosingYear] = React.useState<number>(new Date().getFullYear());
  const [retainedEarningsAccount, setRetainedEarningsAccount] = React.useState<string>('acc_retained_earnings');
  const [isExecutingClose, setIsExecutingClose] = React.useState<boolean>(false);
  const [unreversedAccruals, setUnreversedAccruals] = React.useState<any[]>([]);
  const [isLoadingAccruals, setIsLoadingAccruals] = React.useState<boolean>(false);
  const [reversingEntryId, setReversingEntryId] = React.useState<string | null>(null);

  const fetchUnreversedAccruals = async () => {
    setIsLoadingAccruals(true);
    try {
      const q = query(
        collection(db, 'journalEntries'),
        where('companyId', '==', companyId),
        where('status', '==', 'Posted')
      );
      const snap = await getDocs(q);
      const list: any[] = [];
      snap.forEach(docSnap => {
        const d = docSnap.data();
        if (d.autoReverse === true && !d.reversalDate) {
          list.push({ id: docSnap.id, ...d });
        }
      });
      setUnreversedAccruals(list);
    } catch (err) {
      console.error("Failed to load eligible unreversed accruals:", err);
    } finally {
      setIsLoadingAccruals(false);
    }
  };

  const fetchSpentActuals = async () => {
    setIsLoadingActuals(true);
    try {
      const querySnapshot = await getDocs(query(
        collection(db, 'journalEntries'),
        where('companyId', '==', companyId),
        where('status', '==', 'Posted')
      ));
      const tempActuals: {[key: string]: number} = {};
      const currentYear = new Date().getFullYear();

      querySnapshot.forEach((docSnap) => {
        const data = docSnap.data();
        const entryYear = new Date(data.date).getFullYear();
        if (entryYear === currentYear && data.lines) {
          data.lines.forEach((line: any) => {
            const accId = line.accountId;
            const debit = Number(line.debit || 0);
            const credit = Number(line.credit || 0);
            tempActuals[accId] = (tempActuals[accId] || 0) + (debit - credit);
          });
        }
      });
      setActualsMap(tempActuals);
    } catch (err) {
      console.warn("Could not calculate exact posted spend actuals:", err);
    } finally {
      setIsLoadingActuals(false);
    }
  };

  React.useEffect(() => {
    fetchSpentActuals();
    fetchUnreversedAccruals();
  }, []);

  React.useEffect(() => {
    if (accountsList) {
      const budgets: {[key: string]: string} = {};
      accountsList.forEach(acc => {
        budgets[acc.id] = acc.budget !== undefined ? String(acc.budget) : '0';
      });
      setLocalBudgets(budgets);
    }
  }, [accountsList]);

  const handleSaveBudget = async (accountId: string) => {
    setSavingBudgetId(accountId);
    try {
      const bValue = Number(localBudgets[accountId]) || 0;
      await updateDoc(doc(db, 'accounts', accountId), { budget: bValue });
      alert(isRtl ? "تم بنجاح حفظ وتخصيص الميزانية التقديرية للحساب." : "Account-level budget allocation ceiling updated successfully.");
    } catch (err) {
      console.error(err);
      alert(isRtl ? "فشل تحديث البيانات في قاعدة البيانات" : "Could not complete database write operation.");
    } finally {
      setSavingBudgetId(null);
    }
  };

  const handleUpdateSetting = async (key: string, value: any) => {
    await updateSettings({ [key]: value });
  };

  const handleYearEndClosing = async () => {
    if (!confirm(isRtl 
      ? `هل أنت متأكد من رغبتك في تشغيل سلسلة الإقفال السنوي للعام المالي ${closingYear}؟\nسيقوم النظام بتصفير أرصدة الإيرادات والمصاريف وترحيل صافي الرصيد إلى الأرباح المبقاة.`
      : `Are you sure you want to execute the Year-End Closing Sequence for fiscal calendar window ${closingYear}?\nThis will set all income/expense accounts balance to zero and roll up the net profit/loss to retained earnings.`
    )) return;

    setIsExecutingClose(true);
    try {
      const result = await YearEndClosingService.executeYearEndClosing(companyId, closingYear, retainedEarningsAccount);
      if (result.success) {
        alert(isRtl 
          ? `SUCCESS: تم تنفيذ وإقفال العام المالي ${closingYear} بنجاح! رقم سند قيد الإقفال: YEC-${closingYear}`
          : `SUCCESS: Fiscal year closing sequence for ${closingYear} has been successfully logged! Entry Reference: YEC-${closingYear}`
        );
        fetchSpentActuals();
        fetchUnreversedAccruals();
      } else {
        alert(isRtl
          ? `فشل قيد الإقفال السنوي: ${result.error}`
          : `Year-End closing aborted: ${result.error}`
        );
      }
    } catch (err: any) {
      console.error(err);
      alert(`Critical Closing failure: ${err.message || err}`);
    } finally {
      setIsExecutingClose(false);
    }
  };

  const handleExecuteReversal = async (entryId: string, refCode: string) => {
    if (!confirm(isRtl 
      ? `هل أنت متأكد من عكس قيد التسوية بالكامل #${refCode}؟\nسيقوم النظام بتبديل المدين والدائن في اليوم الأول من الشهر الجديد.`
      : `Are you sure you want to execute the automated reversal for accrued adjustment entry #${refCode}?\nThis will create a mirrored entry with flipped debit/credit rows post-dated to day 1 of the new month.`
    )) return;

    setReversingEntryId(entryId);
    try {
      const result = await YearEndClosingService.createReversingEntry(companyId, entryId);
      if (result.success) {
        alert(isRtl
          ? `SUCCESS: تم تدوير وعكس قيد التسويات بنجاح!`
          : `SUCCESS: Accrual adjusting entry reversed successfully!`
        );
        fetchUnreversedAccruals();
      } else {
        alert(isRtl
          ? `فشل معالجة القيد العكسي: ${result.error}`
          : `Accrual reversal process failed: ${result.error}`
        );
      }
    } catch (err: any) {
      console.error(err);
      alert(`Critical Reversal failure: ${err.message || err}`);
    } finally {
      setReversingEntryId(null);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* 1. Cost Centers Manager */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-950 text-base">
                {t('settings.cost_centers', 'Analytical Cost Centers')}
              </h3>
              <p className="text-xs text-slate-500 max-w-xl">
                {t('settings.cost_centers_desc', 'Activate cost centers mapping across standard accounts to track operational profitability per department.')}
              </p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input 
              type="checkbox" 
              checked={settings.enable_cost_centers}
              onChange={(e) => handleUpdateSetting('enable_cost_centers', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
          </label>
        </div>

        {settings.enable_cost_centers && (
          <div className="pt-4 border-t border-slate-100 space-y-4">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {isRtl ? 'بنية مراكز التكلفة النشطة بمؤسستنا' : 'Active Cost Centers Structure'}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
                <span className="text-[10px] font-bold text-indigo-600 uppercase font-mono">CC-MAIN-01</span>
                <h4 className="font-bold text-slate-900 text-xs">Admin HQ Operations Center</h4>
                <p className="text-[10px] text-slate-500">{isRtl ? 'المقر الرئيسي - الإدارة العامة' : 'Corporate HQ General Management'}</p>
                <span className="inline-block mt-2 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[9px] font-bold">
                  {isRtl ? 'نشط وقابل للتوجيه' : 'Active and routable'}
                </span>
              </div>
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
                <span className="text-[10px] font-bold text-indigo-600 uppercase font-mono">CC-WH-MAIN</span>
                <h4 className="font-bold text-slate-900 text-xs">WH-MAIN (Sana'a)</h4>
                <p className="text-[10px] text-slate-500">{isRtl ? 'مستودع صنعاء الرئيسي واللوجستيات' : 'Sana\'a Main Central Depot'}</p>
                <span className="inline-block mt-2 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[9px] font-bold">
                  {isRtl ? 'نشط وقابل للتوجيه' : 'Active and routable'}
                </span>
              </div>
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1">
                <span className="text-[10px] font-bold text-indigo-600 uppercase font-mono">CC-SLS-RETAIL</span>
                <h4 className="font-bold text-slate-900 text-xs">Sales Operations (Retail Branch)</h4>
                <p className="text-[10px] text-slate-500">{isRtl ? 'مبيعات التجزئة والتوزيع المحلي' : 'Local Retail Sales and Logistics'}</p>
                <span className="inline-block mt-2 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[9px] font-bold">
                  {isRtl ? 'نشط وقابل للتوجيه' : 'Active and routable'}
                </span>
              </div>
            </div>

            <div className="rounded-xl border border-slate-100 bg-indigo-50/10 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                  <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
                  {isRtl ? 'توجيه شجرة الحسابات التشغيلية لمراكز التكلفة' : 'Chart of Accounts analytical expense routing'}
                </div>
                <span className="text-[10px] text-indigo-600 font-bold bg-indigo-100/60 px-2 py-0.5 rounded-full">
                  ERP Auto-allocation Enabled
                </span>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs p-2 rounded-lg bg-white border border-slate-200/60 shadow-xs">
                  <span className="text-slate-700 font-medium">510101 - Salaries & Wages (الرواتب والأجور)</span>
                  <span className="text-[10px] text-indigo-600 font-mono bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
                    {isRtl ? 'مقسم بالتساوي (33.3% لكل مركز)' : 'Split evenly (33.3% per CC)'}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs p-2 rounded-lg bg-white border border-slate-200/60 shadow-xs">
                  <span className="text-slate-700 font-medium">510202 - Office & Rent Expenses (إيجار المقر ومصروفات المكتب)</span>
                  <span className="text-[10px] text-indigo-600 font-mono bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded">
                    Admin HQ Operations Only (100%)
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 2. Workflow & Approval Engine */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-950 text-base">
                {t('settings.workflow_approvals', 'Workflow Approvals Engine')}
              </h3>
              <p className="text-xs text-slate-500 max-w-xl">
                {t('settings.workflow_approvals_desc', 'Define authorized limits and approval hierarchy paths for corporate invoices.')}
              </p>
            </div>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">
                {isRtl ? 'الحد الأدنى لطلب موافقة المدير للفاتورة (YER)' : 'Require Manager approval if invoice total exceeds (YER)'}
              </label>
              <div className="relative">
                <input 
                  type="number"
                  value={settings.require_invoice_approval_above}
                  onChange={(e) => handleUpdateSetting('require_invoice_approval_above', Number(e.target.value))}
                  className="w-full text-sm p-2.5 bg-slate-50 border border-slate-200 rounded-xl pl-9 font-medium font-mono text-indigo-700" 
                />
                <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">YER</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">
                {isRtl ? 'المعاملات المالية التي تزيد عن هذا الحد ستُدخل بحالة مسودة كقيد معلق موافقة المدير العام قبل النشر.' : 'Transactions exceeding this threshold enter draft pending general manager approval before final ledger lock.'}
              </p>
            </div>

            <div className="space-y-4 bg-slate-50/50 border border-slate-200 p-4 rounded-xl">
              <div className="text-xs font-bold text-slate-800">{isRtl ? 'قواعد سير الأعمال المفعّلة' : 'Active Workflow Rules'}</div>
              <div className="space-y-2.5">
                <div className="flex items-start gap-2 text-xs">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-1.5 shrink-0" />
                  <div>
                    <span className="font-bold">{isRtl ? 'فواتير المبيعات' : 'Sales Invoices'}</span>: {isRtl ? 'موافقة Accountant أولية وإعتماد تلقائي.' : 'Accountant verification is sufficient.'}
                  </div>
                </div>
                <div className="flex items-start gap-2 text-xs">
                  <div className="w-1.5 h-1.5 rounded-full bg-indigo-600 mt-1.5 shrink-0" />
                  <div>
                    <span className="font-bold">{isRtl ? 'سندات الشراء والتوريد' : 'Purchase Bills'}</span>: {isRtl ? 'تتطلب موافقة مزدوجة من Accountant ومدير المشتريات التمكيني.' : 'Requires dual approval from Accountant and CEO.'}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Budget & Forecasting Constraints */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-950 text-base">
                {t('settings.budget_forecast', 'Budget & Expense Forecasting')}
              </h3>
              <p className="text-xs text-slate-500 max-w-xl">
                {t('settings.budget_forecast_desc', 'Set real-time alerts and hard-stops when operational expense ledger boundaries exceed assigned budgets.')}
              </p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input 
              type="checkbox" 
              checked={settings.enforce_budget_expense_ledger}
              onChange={(e) => handleUpdateSetting('enforce_budget_expense_ledger', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
          </label>
        </div>

        {settings.enforce_budget_expense_ledger && (
          <div className="pt-4 border-t border-slate-100 space-y-4">
            <div className="p-4 bg-amber-50 text-amber-900 rounded-xl border border-amber-200/70 text-xs flex gap-3">
              <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">{isRtl ? 'حظر الصرف والتجاوز المالي مفعّل' : 'Hard-stop financial breach prevention activated.'}</span>
                <p className="text-amber-700/90 mt-1">
                  {isRtl 
                    ? 'سيقوم النظام فوراً برفض القيود اليومية أو المعاملات التبادلية في حال تجاوز القيمة الإجمالية للمصروفات ربع السنوية للميزانية المحددة.' 
                    : 'The transaction engine will block General Ledger posts instantly if active transactions violate quarterly budget caps.'
                  }
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-xl bg-slate-50/50 flex justify-between items-center">
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{isRtl ? 'حد التحذير المبكر للمصروفات' : 'Early Warning threshold indicator'}</h4>
                  <p className="text-[10px] text-slate-400">{isRtl ? 'يبدأ التنبيه والوميض عندما يقترب الصرف من' : 'Alert starts blinking once expenditures reach'}</p>
                </div>
                <span className="text-xs font-bold font-mono text-indigo-700 bg-white border border-slate-200/80 px-2.5 py-1 rounded-lg">85%</span>
              </div>
              <div className="p-4 border rounded-xl bg-slate-50/50 flex justify-between items-center">
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{isRtl ? 'دورة المراجعة الربع سنوية' : 'Quarterly Audit Cycles'}</h4>
                  <p className="text-[10px] text-slate-400">{isRtl ? 'إعادة ضبط مؤشرات الميزانيات التقديرية' : 'Budget allocations boundaries expire'}</p>
                </div>
                <span className="text-xs font-bold text-slate-600 bg-white border border-slate-200/80 px-2.5 py-1 rounded-lg">
                  {isRtl ? 'كل 90 يوم' : 'Every 90 days'}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 3.5. BUDGETARY VARIANCE CALCULATOR */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-950 text-base">
                {isRtl ? 'حاسبة انحراف الموازنة التقديرية (الفعلي مقابل المخطط)' : 'Budgetary Variance Tracking Center'}
              </h3>
              <p className="text-xs text-slate-500 max-w-xl">
                {isRtl 
                  ? 'راقب انحرافات الموازنة لكل حساب محاسبي في الوقت الفعلي وقارن المصروفات الفعلية بالحدود المعتمدة.' 
                  : 'Track account-level actual expenditures against allocated budget limits in real time and monitor variance.'}
              </p>
            </div>
          </div>
          <button 
            type="button"
            onClick={fetchSpentActuals}
            disabled={isLoadingActuals}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-slate-500 ${isLoadingActuals ? 'animate-spin' : ''}`} />
            {isRtl ? 'تحديث الفعلي' : 'Recalculate Actuals'}
          </button>
        </div>

        {/* Filters and Search toolbar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text"
              placeholder={isRtl ? 'بحث برمز الحساب أو الاسم...' : 'Filter by account code or name...'}
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full text-xs pl-9 pr-4 py-2 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
          <div className="flex gap-1.5 overflow-x-auto">
            {['EXPENSE', 'REVENUE', 'COGS', 'ALL'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`px-3 py-1.5 text-[11px] font-bold rounded-lg transition-all ${
                  categoryFilter === cat 
                    ? 'bg-slate-950 text-white' 
                    : 'bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600'
                }`}
              >
                {cat === 'EXPENSE' ? (isRtl ? 'المصروفات' : 'Expenses') :
                 cat === 'REVENUE' ? (isRtl ? 'الإيرادات' : 'Revenue') :
                 cat === 'COGS' ? (isRtl ? 'تكلفة المبيعات' : 'COGS') :
                 (isRtl ? 'الكل' : 'All Accounts')}
              </button>
            ))}
          </div>
        </div>

        {/* Real-time analytical matrix table */}
        <div className="border border-slate-200/80 rounded-xl overflow-hidden bg-slate-50/20">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="py-2.5 px-3.5">{isRtl ? 'الحساب' : 'Account (Code - Name)'}</th>
                  <th className="py-2.5 px-3.5">{isRtl ? 'النوع' : 'Type'}</th>
                  <th className="py-2.5 px-3.5 text-right w-[160px]">{isRtl ? 'الموازنة السنوية (ريال)' : 'Annual Budget (YER)'}</th>
                  <th className="py-2.5 px-3.5 text-right">{isRtl ? 'الفعلي الحالي (YTD)' : 'Actual Spent (YTD)'}</th>
                  <th className="py-2.5 px-3.5 text-right">{isRtl ? 'الانحراف المالي' : 'Variance / Utilization'}</th>
                  <th className="py-2.5 px-3.5 text-center w-[60px]"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {(() => {
                  const filtered = (accountsList || []).filter(acc => {
                    const matchText = 
                      acc.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
                      acc.code.toLowerCase().includes(searchFilter.toLowerCase());
                    
                    if (!matchText) return false;
                    if (categoryFilter === 'ALL') return true;
                    if (categoryFilter === 'EXPENSE') return acc.type.toLowerCase().includes('expense');
                    if (categoryFilter === 'REVENUE') return acc.type.toLowerCase().includes('revenue') || acc.type.toLowerCase().includes('sales');
                    if (categoryFilter === 'COGS') return acc.type.toLowerCase().includes('cogs') || acc.type.toLowerCase().includes('cost of goods sold') || acc.code.startsWith('5');
                    return true;
                  });

                  if (filtered.length === 0) {
                    return (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-slate-400 font-medium">
                          {isRtl ? 'لا توجد حسابات مطابقة للمرشح المحدد' : 'No matching accounts found for the current configuration.'}
                        </td>
                      </tr>
                    );
                  }

                  return filtered.map((acc) => {
                    const actualValue = actualsMap[acc.id] || 0;
                    const bValue = Number(localBudgets[acc.id] || 0);
                    const variance = bValue - actualValue;
                    const percentUsed = bValue > 0 ? (actualValue / bValue) * 100 : 0;

                    // Compute clean health status indicators
                    let statusColor = 'text-green-600 bg-green-50 border-green-100';
                    let progressClass = 'bg-emerald-500';
                    if (percentUsed > 100) {
                      statusColor = 'text-rose-600 bg-rose-50 border-rose-100 animate-pulse';
                      progressClass = 'bg-rose-500';
                    } else if (percentUsed >= 85) {
                      statusColor = 'text-amber-600 bg-amber-50 border-amber-100';
                      progressClass = 'bg-amber-500';
                    }

                    return (
                      <tr key={acc.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="py-3 px-3.5 font-medium text-slate-900 border-r border-slate-100">
                          <div className="flex flex-col">
                            <span className="font-mono text-xs text-indigo-700 font-bold">{acc.code}</span>
                            <span className="text-xs text-slate-600 tracking-tight font-sans mt-0.5">{acc.name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-3.5">
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 text-slate-600 uppercase border border-slate-200/50">
                            {acc.type}
                          </span>
                        </td>
                        <td className="py-3 px-3.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <span className="text-slate-400 font-mono text-[10px]">YER</span>
                            <input 
                              type="number"
                              value={localBudgets[acc.id] || ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                setLocalBudgets(prev => ({ ...prev, [acc.id]: val }));
                              }}
                              className="w-24 text-right py-1 px-2 border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 rounded-lg font-mono font-medium outline-none bg-slate-50 focus:bg-white text-xs transition-all"
                            />
                          </div>
                        </td>
                        <td className="py-3 px-3.5 text-right font-mono font-medium text-slate-700">
                          {actualValue.toLocaleString()} YER
                        </td>
                        <td className="py-3 px-3.5 text-right">
                          <div className="flex flex-col items-end gap-1">
                            {bValue > 0 ? (
                              <div className="flex items-center gap-1.5">
                                <span className="font-mono text-[10px] text-slate-500">
                                  {isRtl ? 'متاح:' : 'Rem:'} {variance.toLocaleString()} YER
                                </span>
                                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold border ${statusColor}`}>
                                  {percentUsed.toFixed(0)}%
                                </span>
                              </div>
                            ) : (
                              <span className="text-[10px] text-slate-400 font-medium">
                                {isRtl ? 'بلا سقف مالي مخصص' : 'No ceiling assigned'}
                              </span>
                            )}
                            {bValue > 0 && (
                              <div className="w-32 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                                <div 
                                  className={`h-full ${progressClass}`} 
                                  style={{ width: `${Math.min(100, percentUsed)}%` }}
                                ></div>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-3.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleSaveBudget(acc.id)}
                            disabled={savingBudgetId === acc.id}
                            className={`p-1.5 rounded-lg border text-indigo-600 bg-indigo-50/50 hover:bg-indigo-50 border-indigo-100 transition-all cursor-pointer ${
                              savingBudgetId === acc.id ? 'opacity-50' : ''
                            }`}
                            title={isRtl ? 'حفظ حد الميزانية' : 'Save Budget Cap'}
                          >
                            {savingBudgetId === acc.id ? (
                              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Check className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </td>
                      </tr>
                    );
                  });
                })()}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 4. Consolidation & Branch Controls */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-950 text-base">
              {t('settings.consolidation_branch', 'Consolidation & Branch Controls')}
            </h3>
            <p className="text-xs text-slate-500 max-w-xl">
              {t('settings.consolidation_branch_desc', 'Configure group parent company consolidations and currency balance revaluations under one master ledger.')}
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">
                {isRtl ? 'المنشأة والشركة الرئيسية للدمج المالي' : 'Group Consolidation Target Parent Company'}
              </label>
              <select 
                value={settings.consolidation_company_id}
                onChange={(e) => handleUpdateSetting('consolidation_company_id', e.target.value)}
                className="w-full text-sm p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
              >
                <option value="c1">Al-Huraibi Trading HQ (AHTC)</option>
                <option value="c2">Al-Huraibi Logistics & Retail LLC (AHLR)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">
                {isRtl ? 'عملة إعادة التقييم الموحدة' : 'Unified Consolidated Revaluation Currency'}
              </label>
              <select 
                value={settings.revaluation_currency}
                onChange={(e) => handleUpdateSetting('revaluation_currency', e.target.value)}
                className="w-full text-sm p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium"
              >
                <option value="YER">YER (ريال يمني)</option>
                <option value="USD">USD (دولار أمريكي)</option>
                <option value="SAR">SAR (ريال سعودي)</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* 5. Year-End Closing & Accrual Reversal Console */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
            <Scale className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-bold text-slate-950 text-base">
              {isRtl ? 'إقفال السنة المالية والتسويات المعكوسة تلقائياً' : 'Financial Closing & Automated Accrual Reversals'}
            </h3>
            <p className="text-xs text-slate-500 max-w-xl">
              {isRtl 
                ? 'إدارة تدوير الأرباح والخسائر للعام المالي وتوليد القيود المعكوسة للتسويات المستحقة بشكل آلي دقيق.' 
                : 'Process corporate year-end balance roll-ups to retained earnings and securely trigger swapped reversal entries.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-2 border-t border-slate-100">
          {/* Year-End Closing Panel */}
          <div className="space-y-4 pr-0 lg:pr-4 border-r-0 lg:border-r border-slate-100">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-600" />
              <h4 className="text-xs font-black text-indigo-950 uppercase tracking-widest">
                {isRtl ? 'محرك قفل وإقفال الحسابات السنوي' : 'Year-End Closing Processor'}
              </h4>
            </div>
            
            <p className="text-xs text-slate-500 leading-relaxed font-sans">
              {isRtl 
                ? 'يقوم هذا المحرك بمسح كافة المعاملات المرحلة للعام المالي المحدد، وتحديد جميع الأرصدة المؤقتة (الإيرادات والمصاريف) وتصفيرها بالكامل عبر قيد إقفال سنوي متوازن ومطابق لمعايير IFRS. يتم ترحيل الفارق أو الفائض كأرباح أو خسائر مرحلة مباشرة لحساب الأرباح المبقاة.' 
                : 'Scans all posted lines in the calendar year, zeroes out temporary income/expense accounts, and posts the net consolidated profit/loss to sub-account 3200 - Retained Earnings (Equity Tree).'}
            </p>

            <div className="space-y-4 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5 flex flex-col">
                  <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block">
                    {isRtl ? 'العام المالي المستهدف' : 'Target Fiscal Year'}
                  </label>
                  <select
                    value={closingYear}
                    onChange={(e) => setClosingYear(Number(e.target.value))}
                    className="w-full text-xs font-mono font-bold p-2 bg-white border border-slate-200 rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    {[2024, 2025, 2026, 2027, 2028].map(y => (
                      <option key={y} value={y}>{y}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5 flex flex-col">
                  <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block">
                    {isRtl ? 'حساب الأرباح المبقاة' : 'Retained Earnings Account'}
                  </label>
                  <select
                    value={retainedEarningsAccount}
                    onChange={(e) => setRetainedEarningsAccount(e.target.value)}
                    className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg outline-none focus:ring-1 focus:ring-indigo-500 font-medium"
                  >
                    {accountsList
                      .filter(acc => acc.code === '3200' || (acc.type || '').toLowerCase().includes('equity'))
                      .map(acc => (
                        <option key={acc.id} value={acc.id}>
                          {acc.code} - {acc.name}
                        </option>
                      ))}
                    {accountsList.filter(acc => acc.code === '3200').length === 0 && (
                      <option value="acc_retained_earnings">3200 - Retained Earnings (الأرباح المبقاة)</option>
                    )}
                  </select>
                </div>
              </div>

              <button
                type="button"
                onClick={handleYearEndClosing}
                disabled={isExecutingClose}
                className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-200 text-white disabled:text-slate-400 rounded-lg text-xs font-bold font-sans tracking-wide transition-all shadow-sm cursor-pointer flex items-center justify-center gap-2"
              >
                {isExecutingClose ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Check className="w-3.5 h-3.5" />
                )}
                {isExecutingClose 
                  ? (isRtl ? 'جاري تشغيل سلسلة الإقفال...' : 'Executing Year-End closing sequence...') 
                  : (isRtl ? 'إجراء وإثبات الإقفال السنوي العام' : 'Execute Year-End Balance Settlement')}
              </button>
            </div>
          </div>

          {/* Accrual Reversals Panel */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-emerald-600" />
                <h4 className="text-xs font-black text-indigo-950 uppercase tracking-widest">
                  {isRtl ? 'قائمة الاستحقاقات والقيود العكسية' : 'Accrual Swapped Reversals Queue'}
                </h4>
              </div>
              <button
                type="button"
                onClick={fetchUnreversedAccruals}
                className="p-1 hover:bg-slate-100 rounded transition-all"
                title={isRtl ? 'تحديث القيود' : 'Reload Entries'}
              >
                <RefreshCw className={`w-3.5 h-3.5 text-slate-500 ${isLoadingAccruals ? 'animate-spin' : ''}`} />
              </button>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed font-sans">
              {isRtl 
                ? 'قائمة بالقيود التسوية المرحلة (مثل المستحقات الأسبوعية أو المقدمات) والتي تحمل خيار "العكس التلقائي" ولم يتم عكسها بعد في اليوم الأول من الشهر الجديد.' 
                : 'A listing of adjusting entries marked with "Auto-reverse journal next month" that are awaiting balance reversal in day 1 of the new month.'}
            </p>

            {isLoadingAccruals ? (
              <div className="py-8 flex flex-col items-center justify-center text-slate-400 gap-2">
                <RefreshCw className="w-6 h-6 animate-spin text-indigo-500" />
                <span className="text-xs font-medium">{isRtl ? 'جاري جرد القيود من الدفاتر...' : 'Polling ledger journals...'}</span>
              </div>
            ) : unreversedAccruals.length === 0 ? (
              <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl bg-slate-50/50 space-y-2">
                <span className="text-xs font-bold text-slate-600 block">
                  ✨ {isRtl ? 'جميع القيود العكسية متطابقة ومنسقة بالكامل!' : 'Perfect Accrual Synchronization!'}
                </span>
                <p className="text-[10px] text-slate-400 max-w-xs mx-auto leading-normal">
                  {isRtl 
                    ? 'لم يُعثر على قيود تسويات مرحلة بانتظار العكس التلقائي في الدفاتر المحاسبية النشطة حالياً.' 
                    : 'No pending accruals needing reversed postings were found in the active general ledger database.'}
                </p>
              </div>
            ) : (
              <div className="border border-slate-150 rounded-xl overflow-hidden shadow-xs bg-white max-h-[220px] overflow-y-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-slate-500 font-bold border-b border-slate-150 uppercase text-[9px] tracking-wider">
                      <th className="py-2 px-3">{isRtl ? 'القيد الأب' : 'Parent Reference'}</th>
                      <th className="py-2 px-3">{isRtl ? 'البيان' : 'Narration'}</th>
                      <th className="py-2 px-3 text-right">{isRtl ? 'المبلغ' : 'Amount'}</th>
                      <th className="py-2 px-3 text-center w-[100px]"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {unreversedAccruals.map(entry => {
                      const totalDebit = Number(entry.lines?.reduce((sum: number, ln: any) => sum + (ln.debit || 0), 0) || 0);
                      return (
                        <tr key={entry.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="py-2 px-3 border-r border-slate-100 font-mono font-bold text-indigo-700">
                            <div className="flex flex-col">
                              <span>{entry.reference}</span>
                              <span className="text-[9px] text-slate-400 font-normal">{entry.date}</span>
                            </div>
                          </td>
                          <td className="py-2 px-3 text-slate-600 max-w-[140px] truncate" title={entry.description}>
                            {entry.description}
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-slate-700">
                            {totalDebit.toLocaleString()}
                          </td>
                          <td className="py-2 px-3 text-center">
                            <button
                              type="button"
                              onClick={() => handleExecuteReversal(entry.id, entry.reference)}
                              disabled={reversingEntryId === entry.id}
                              className="px-2.5 py-1 rounded bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 disabled:bg-slate-50 disabled:text-slate-400 transition-all font-black text-[10px] cursor-pointer"
                            >
                              {reversingEntryId === entry.id ? (
                                <RefreshCw className="w-3 h-3 animate-spin mx-auto" />
                              ) : (
                                (isRtl ? 'عكس القيد' : 'Reverse')
                              )}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
