import React from 'react';
import { useTranslation } from 'react-i18next';
import { ShieldCheck, CheckCircle, Smartphone, Lock, Info, Plus, Trash2 } from 'lucide-react';

interface WorkflowApprovalsProps {
  formConfig: any;
  handleInputChange: (key: string, value: any) => void;
  handlePermissionsChange: (role: 'Admin' | 'Accountant' | 'Vendor', action: 'read' | 'create' | 'update' | 'delete', checked: boolean) => void;
  isRtl: boolean;
}

export default function WorkflowApprovals({
  formConfig,
  handleInputChange,
  handlePermissionsChange,
  isRtl
}: WorkflowApprovalsProps) {
  const { t } = useTranslation();

  return (
    <div className="space-y-6 animate-fadeIn" id="workflow-approvals-container">
      {/* Cost Limits & Approval Threshold Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6" id="cost-levels-card">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl" id="shield-icon-wrapper">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-950 text-base">
              {isRtl ? 'صلاحيات وإعتماد الفواتير (Workflow Approvals)' : 'Invoice Approval Workflows & Thresholds'}
            </h3>
            <p className="text-xs text-slate-500">
              {isRtl ? 'التحكم برحلة اعتماد فواتير المبيعات والمشتريات وتفويض الصلاحيات بالاعتماد المزدوج لحفظ النفقات من التلاعب.' : 'Enforce multi-level signatures based on invoice amounts before posting to reports.'}
            </p>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-6" id="limits-setup-grid">
          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold text-slate-700">
              {isRtl ? 'الحد الأدنى لموافقة المدير الضرورية (YER)' : 'Manager Approval Required Above (YER)'}
            </label>
            <div className="relative">
              <input
                type="number"
                id="invoice-approval-threshold"
                value={formConfig.require_invoice_approval_above || 1000000}
                onChange={(e) => handleInputChange('require_invoice_approval_above', Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none pl-14 font-mono font-bold text-indigo-700"
              />
              <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">YER</span>
            </div>
            <p className="text-[10px] text-slate-400">
              {isRtl ? '* الفواتير التي تتجاوز هذا القيد ستظل كمسودات معلقة حتى موافقة الإدارة العامة.' : '* Invoices exceeding this threshold require manual secondary manager approval before validation.'}
            </p>
          </div>

          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3" id="active-approval-rules">
            <h4 className="text-xs font-bold text-slate-800">{isRtl ? 'قواعد اعتماد مسار العمل النشطة' : 'Active Approval Hierarchy Rules'}</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>{isRtl ? 'تحت الحد:' : 'Below Limit:'}</strong> {isRtl ? 'اعتماد ونشر مباشر بواسطة المحاسب' : 'Post directly by assigned Accountant'}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>{isRtl ? 'فوق الحد:' : 'Above Limit:'}</strong> {isRtl ? 'تنتظر موافقة مزدوجة وقفل القيد' : 'Draft locked until Manager overrides status'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Corporate RBAC Security Grid Control Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6" id="rbac-matrix-card">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl" id="lock-icon-wrapper">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-950 text-base">
              {isRtl ? 'مصفوفة التحكم بالصلاحيات الدقيقة (RBAC Matrix)' : 'Fine-Grained Role-Based Access Matrix'}
            </h3>
            <p className="text-xs text-slate-500">
              {isRtl ? 'تخصيص مستويات الوصول وقدرات القراءة والحذف والتعديل لكل مستخدم وموظف بقواعد صارمة.' : 'Grant or revoke permissions symmetrically for standard financial operator types.'}
            </p>
          </div>
        </div>

        <div className="overflow-x-auto pt-4 border-t border-slate-100" id="rbac-table-container">
          <table className="w-full text-left font-sans text-xs border border-slate-100 shadow-3xs" id="rbac-grid-table">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="p-3 text-slate-500 font-bold uppercase">{isRtl ? 'المسمى الوظيفي / الدور الكلي' : 'System Role'}</th>
                <th className="p-3 text-slate-500 font-bold uppercase text-center">{isRtl ? 'استعراض (Read)' : 'Read'}</th>
                <th className="p-3 text-slate-500 font-bold uppercase text-center">{isRtl ? 'إضافة (Create)' : 'Create'}</th>
                <th className="p-3 text-slate-500 font-bold uppercase text-center">{isRtl ? 'تعديل (Update)' : 'Update'}</th>
                <th className="p-3 text-slate-500 font-bold uppercase text-center">{isRtl ? 'حذف (Delete)' : 'Delete'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {(['Admin', 'Accountant', 'Vendor'] as const).map((role) => (
                <tr key={role} className="hover:bg-slate-50/50">
                  <td className="p-3 font-semibold text-slate-800">{role}</td>
                  {(['read', 'create', 'update', 'delete'] as const).map((action) => {
                    const checked = formConfig.permissionsMatrix?.[role]?.[action] || false;
                    return (
                      <td key={action} className="p-3 text-center">
                        <input
                          type="checkbox"
                          checked={checked}
                          id={`cb-${role}-${action}`}
                          onChange={(e) => handlePermissionsChange(role, action, e.target.checked)}
                          className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4 border-slate-300"
                        />
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
