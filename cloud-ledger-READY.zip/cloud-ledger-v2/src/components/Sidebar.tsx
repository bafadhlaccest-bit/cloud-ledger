import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, Users, ShoppingBag, ShoppingCart, FileText, 
  PieChart, Settings, LogOut, Briefcase, CreditCard, Package,
  Building2, Sparkles, Globe, Brain, ChevronRight,
  Receipt, Clock, FileSpreadsheet, Shield, Tag, PackageCheck
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useAuthStore } from '../store/useAuthStore';
import { useSettingsStore } from '../store/useSettingsStore';
import { useTranslation } from 'react-i18next';

const SECTIONS = [
  {
    label: null,
    items: [
      { icon: LayoutDashboard, label: 'الرئيسية',      path: '/' },
      { icon: Building2,       label: 'دليل الحسابات', path: '/accounts' },
    ],
  },
  {
    label: 'المبيعات',
    items: [
      { icon: Users,       label: 'العملاء',          path: '/customers' },
      { icon: Tag,         label: 'عروض الأسعار',    path: '/quotations' },
      { icon: ShoppingBag, label: 'الفواتير',         path: '/sales' },
      { icon: Clock,       label: 'فواتير متكررة',   path: '/recurring' },
    ],
  },
  {
    label: 'المشتريات',
    items: [
      { icon: Briefcase,    label: 'الموردون',        path: '/vendors' },
      { icon: PackageCheck, label: 'أوامر الشراء',   path: '/purchase-orders' },
      { icon: ShoppingCart, label: 'فواتير الشراء',  path: '/purchases' },
      { icon: Receipt,      label: 'المصروفات',       path: '/expenses' },
    ],
  },
  {
    label: 'المحاسبة',
    items: [
      { icon: Package,      label: 'الأصناف',         path: '/items' },
      { icon: CreditCard,   label: 'البنوك والصندوق', path: '/banking' },
      { icon: FileText,     label: 'القيود المحاسبية', path: '/journals' },
    ],
  },
  {
    label: 'التقارير والضرائب',
    items: [
      { icon: PieChart,         label: 'التقارير المالية',   path: '/reports' },
      { icon: FileSpreadsheet,  label: 'تقرير ضريبة القيمة المضافة', path: '/vat-report' },
      { icon: Shield,           label: 'سجل التدقيق',        path: '/audit-trail' },
    ],
  },
  {
    label: 'الذكاء الاصطناعي',
    items: [
      { icon: Sparkles, label: 'المحاسب الذكي',   path: '/ai-accountant' },
      { icon: Brain,    label: 'المستشار المالي', path: '/advisor' },
    ],
  },
  {
    label: 'الإعدادات',
    items: [
      { icon: Globe,    label: 'التكاملات', path: '/integrations' },
      { icon: Settings, label: 'الإعدادات', path: '/settings' },
    ],
  },
];

export default function Sidebar() {
  const { t } = useTranslation();
  const location = useLocation();
  const logout = useAuthStore((state) => state.logout);
  const companyProfile = useSettingsStore((state) => state.companyProfile);

  const NavLink = ({ item }: { item: { icon: any; label: string; path: string } }) => {
    const isActive = location.pathname === item.path ||
      (item.path !== '/' && location.pathname.startsWith(item.path));
    return (
      <Link to={item.path}
        className={cn(
          'flex items-center gap-2.5 px-3 py-2 rounded-lg transition-all duration-150 group text-xs',
          isActive
            ? 'bg-indigo-600 text-white font-semibold shadow-md shadow-indigo-900/30'
            : 'text-slate-400 hover:bg-slate-800 hover:text-white'
        )}>
        <item.icon className={cn('w-4 h-4 shrink-0', isActive ? 'text-white' : 'text-slate-500 group-hover:text-white')} />
        <span className="truncate">{item.label}</span>
        {isActive && <ChevronRight className="w-3 h-3 mr-auto opacity-60" />}
      </Link>
    );
  };

  return (
    <div className="flex flex-col h-screen w-56 bg-slate-900 text-slate-300 border-r border-slate-800 shrink-0">
      {/* Brand */}
      <div className="px-4 py-3.5 border-b border-slate-800 shrink-0">
        <div className="flex items-center gap-2.5">
          {companyProfile?.logo ? (
            <img src={companyProfile.logo} alt="logo" className="w-8 h-8 rounded-lg object-contain bg-slate-800 p-0.5" />
          ) : (
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-600 to-purple-700 flex items-center justify-center shrink-0">
              <FileText className="w-4 h-4 text-white" />
            </div>
          )}
          <div className="min-w-0">
            <div className="text-white font-bold text-sm">Cloud Ledger</div>
            <div className="text-slate-500 text-[10px] truncate">{companyProfile?.arabicName || companyProfile?.name || 'شركتك'}</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 py-2 overflow-y-auto space-y-3">
        {SECTIONS.map((section, si) => (
          <div key={si}>
            {section.label && (
              <div className="text-[9px] font-bold text-slate-600 uppercase tracking-widest px-2 mb-1 mt-1">
                {section.label}
              </div>
            )}
            <div className="space-y-0.5">
              {section.items.map(item => <NavLink key={item.path} item={item} />)}
            </div>
          </div>
        ))}
      </nav>

      {/* Logout */}
      <div className="px-2 py-3 border-t border-slate-800 shrink-0">
        <button onClick={logout}
          className="flex items-center gap-2.5 px-3 py-2 w-full rounded-lg hover:bg-slate-800 hover:text-white transition-colors text-slate-500 text-xs font-medium">
          <LogOut className="w-4 h-4" />
          <span>تسجيل الخروج</span>
        </button>
      </div>
    </div>
  );
}

import { cn } from '../lib/utils';
import { useAuthStore } from '../store/useAuthStore';
import { useSettingsStore } from '../store/useSettingsStore';
import { useTranslation } from 'react-i18next';

const navItems = [
  { icon: LayoutDashboard, labelKey: 'dashboard',     path: '/' },
  { icon: Building2,       labelKey: 'accounts',      path: '/accounts' },
  { icon: Users,           labelKey: 'customers',     path: '/customers' },
  { icon: ShoppingBag,     labelKey: 'sales',         path: '/sales' },
  { icon: Briefcase,       labelKey: 'vendors',       path: '/vendors' },
  { icon: ShoppingCart,    labelKey: 'purchases',     path: '/purchases' },
  { icon: Package,         labelKey: 'items',         path: '/items' },
  { icon: CreditCard,      labelKey: 'banking',       path: '/banking' },
  { icon: FileText,        labelKey: 'journals',      path: '/journals' },
  { icon: PieChart,        labelKey: 'reports',       path: '/reports' },
];

const aiItems = [
  { icon: Sparkles, labelKey: 'ai_accountant', path: '/ai-accountant', label: 'المحاسب الذكي' },
  { icon: Brain,    labelKey: 'advisor',       path: '/advisor',       label: 'المستشار المالي' },
];

const bottomItems = [
  { icon: Globe,    labelKey: 'integrations', path: '/integrations' },
  { icon: Settings, labelKey: 'settings',     path: '/settings' },
];

