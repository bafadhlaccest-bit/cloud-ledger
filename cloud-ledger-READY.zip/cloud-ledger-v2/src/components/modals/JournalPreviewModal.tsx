import React from 'react';
import { Eye, ShieldCheck, AlertCircle, X, Layers } from 'lucide-react';

export interface JournalLine {
  id?: string;
  accountId?: string;
  accountName?: string;
  accountCode: string;
  ifrsMapping?: 'CURRENT_ASSET' | 'NON_CURRENT_ASSET' | 'CURRENT_LIABILITY' | 'NON_CURRENT_LIABILITY' | 'EQUITY_BASE' | 'REVENUE' | 'COGS' | 'OPERATING_EXPENSE' | string;
  debit: number;
  credit: number;
  description?: string;
}

interface JournalPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmPost: () => void;
  transactionData: {
    reference: string;
    date: string;
    description: string;
    lines: JournalLine[];
  };
}

export default function JournalPreviewModal({
  isOpen,
  onClose,
  onConfirmPost,
  transactionData
}: JournalPreviewModalProps) {
  if (!isOpen) return null;

  // Compute totals for mathematical symmetry validation (CFO Absolute Zero Test)
  const totalDebit = transactionData.lines.reduce((sum, l) => sum + (Number(l.debit) || 0), 0);
  const totalCredit = transactionData.lines.reduce((sum, l) => sum + (Number(l.credit) || 0), 0);
  const difference = Math.abs(totalDebit - totalCredit);
  const isBalanced = difference < 0.009; // Absolute variance threshold

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="p-6 bg-slate-50 border-b border-slate-150 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-md shadow-indigo-100">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 tracking-tight">
                Automated Journal Entry Preview
              </h3>
              <p className="text-xs text-slate-500 font-mono mt-0.5">
                Transaction Ledger Reference: {transactionData.reference}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audit Context Bar */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200/60">
            <div>
              <span className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">Target Posting Date</span>
              <span className="text-slate-800 font-mono font-bold text-sm">{transactionData.date}</span>
            </div>
            <div>
              <span className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">Header Narration / Memo</span>
              <span className="text-slate-800 font-sans font-bold text-sm">{transactionData.description}</span>
            </div>
          </div>

          {/* Symmetrical Double-Entry Table */}
          <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 uppercase font-mono tracking-wider border-b border-slate-200">
                  <th className="p-3.5 pl-5">Account Code</th>
                  <th className="p-3.5">Account Name (Chart of Accounts)</th>
                  <th className="p-3.5">IFRS Alignment Mapping</th>
                  <th className="p-3.5 text-right pr-6 w-32">Debit (Dr)</th>
                  <th className="p-3.5 text-right pr-6 w-32">Credit (Cr)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-sans">
                {transactionData.lines.map((line, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/40 transition-colors">
                    <td className="p-3.5 pl-5 font-mono font-bold text-slate-500">{line.accountCode}</td>
                    <td className="p-3.5 text-slate-900 font-semibold">{line.accountName || 'System Generated Ledger Account'}</td>
                    <td className="p-3.5">
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-indigo-50 text-indigo-700 text-[10px] font-bold rounded-md uppercase font-mono border border-indigo-100/40">
                        <Layers className="w-3 h-3" />
                        {line.ifrsMapping || 'UNMAPPED_RESERVE'}
                      </span>
                    </td>
                    <td className="p-3.5 text-right pr-6 font-mono font-bold text-emerald-600 bg-emerald-50/10">
                      {line.debit > 0 ? line.debit.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '—'}
                    </td>
                    <td className="p-3.5 text-right pr-6 font-mono font-bold text-rose-600 bg-rose-50/10">
                      {line.credit > 0 ? line.credit.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-50 border-t border-slate-200 font-bold font-mono">
                <tr className="text-slate-900 text-sm">
                  <td colSpan={3} className="p-4 pl-5 font-sans font-black">
                    Consolidated Transaction Balance
                  </td>
                  <td className="p-4 text-right pr-6 text-emerald-700 font-black bg-emerald-50/30">
                    {totalDebit.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="p-4 text-right pr-6 text-rose-700 font-black bg-rose-50/30">
                    {totalCredit.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Verification Status Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-150 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className={`flex items-center gap-2 text-xs font-bold ${isBalanced ? 'text-emerald-700' : 'text-rose-700'}`}>
            {isBalanced ? (
              <>
                <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
                <span>Ledger verification successful. Double-entry is perfectly balanced and secure.</span>
              </>
            ) : (
              <>
                <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
                <span>Mathematical Imbalance Error! Ledger out of sync by: {difference.toFixed(2)}</span>
              </>
            )}
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-none border border-slate-250 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs py-2.5 px-4 rounded-xl transition cursor-pointer"
            >
              Cancel & Edit
            </button>
            <button
              disabled={!isBalanced}
              onClick={onConfirmPost}
              className={`flex-1 sm:flex-none font-bold text-xs py-2.5 px-5 rounded-xl text-white shadow-lg transition cursor-pointer ${
                isBalanced ? 'bg-indigo-600 hover:bg-slate-900 shadow-indigo-100' : 'bg-slate-300 cursor-not-allowed'
              }`}
            >
              Post to General Ledger
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
