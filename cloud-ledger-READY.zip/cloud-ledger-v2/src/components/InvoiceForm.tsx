import React, { useState } from 'react';
import JournalPreviewModal, { JournalLine } from './modals/JournalPreviewModal';

export function InvoiceForm() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [pendingLedgerTx, setPendingLedgerTx] = useState({ reference: '', date: '', description: '', lines: [] as JournalLine[] });

  const handleInvoiceFormSubmission = () => {
    // 1. Compile lines programmatically based on the current items grid
    const dynamicLines: JournalLine[] = [
      { accountCode: '1200', accountName: 'Accounts Receivable (العملاء)', ifrsMapping: 'CURRENT_ASSET', debit: 12500.00, credit: 0 },
      { accountCode: '4100', accountName: 'Product Revenue (المبيعات)', ifrsMapping: 'REVENUE', debit: 0, credit: 12500.00 }
    ];

    setPendingLedgerTx({
      reference: 'INV-2026-8809',
      date: new Date().toISOString().split('T')[0],
      description: 'Automated revenue recognition ledger entry from Sales Hub',
      lines: dynamicLines
    });

    // 2. Intercept save operation by mounting the preview window
    setIsModalOpen(true);
  };

  const handleFinalDatabaseCommit = async () => {
    setIsModalOpen(false);
    alert('Transaction finalized and written permanently to immutable sub-ledgers.');
  };

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm max-w-xl mx-auto space-y-4">
      <div className="space-y-2">
        <h3 className="text-base font-extrabold text-slate-900">Sandbox Invoice Generator</h3>
        <p className="text-xs text-slate-500">
          This preview widget simulates advanced programmatic compiling of Ledger Lines before permanent commit.
        </p>
      </div>

      <div className="p-4 bg-slate-50 rounded-xl space-y-3">
        <div className="flex justify-between text-xs text-slate-600">
          <span>Client:</span>
          <span className="font-bold">Sana'a General Trading Co.</span>
        </div>
        <div className="flex justify-between text-xs text-slate-600">
          <span>Amount:</span>
          <span className="font-mono font-bold text-slate-900">12,500.00 YER</span>
        </div>
      </div>

      <button 
        onClick={handleInvoiceFormSubmission}
        className="w-full bg-indigo-600 hover:bg-slate-900 text-white font-bold text-xs py-3 px-5 rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-200/50 hover:shadow-slate-350 transition duration-200 cursor-pointer"
      >
        Generate Invoice & Preview Ledger
      </button>

      <JournalPreviewModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConfirmPost={handleFinalDatabaseCommit}
        transactionData={pendingLedgerTx}
      />
    </div>
  );
}
