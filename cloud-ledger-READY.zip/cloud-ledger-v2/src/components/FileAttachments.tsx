import React from 'react';
import { 
  Paperclip, 
  ChevronDown, 
  Upload, 
  Trash2, 
  Eye, 
  FileText, 
  FileSpreadsheet,
  FileImage,
  AlertCircle,
  X,
  Download
} from 'lucide-react';
import { Attachment } from '../types';
import { getAttachments, saveAttachment, deleteAttachment } from '../lib/attachmentStorage';

interface FileAttachmentsProps {
  entityId: string;
  onAttachmentsChange?: (attachments: Attachment[]) => void;
  className?: string;
}

export default function FileAttachments({ entityId, onAttachmentsChange, className = '' }: FileAttachmentsProps) {
  const [attachments, setAttachments] = React.useState<Attachment[]>([]);
  const [isDragActive, setIsDragActive] = React.useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [previewAttachment, setPreviewAttachment] = React.useState<Attachment | null>(null);
  
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  // Load attachments when entityId changes
  React.useEffect(() => {
    if (entityId) {
      loadAttachments();
    }
  }, [entityId]);

  const loadAttachments = async () => {
    try {
      const list = await getAttachments(entityId);
      setAttachments(list);
      if (onAttachmentsChange) {
        onAttachmentsChange(list);
      }
    } catch (err) {
      console.error('Error loading attachments:', err);
    }
  };

  // Close dropdown on click outside
  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true);
    } else if (e.type === "dragleave") {
      setIsDragActive(false);
    }
  };

  const processFiles = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    setError(null);

    const allowedTypes = [
      'application/pdf',
      'image/jpeg',
      'image/png',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // DOCX
      'application/msword', // DOC
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // XLSX
      'application/vnd.ms-excel' // XLS
    ];

    const currentCount = attachments.length;
    const itemsToAdd = Array.from(fileList);

    if (currentCount + itemsToAdd.length > 10) {
      setError('You can upload a maximum of 10 files.');
      return;
    }

    for (const file of itemsToAdd) {
      // Check file size (10MB limit in bytes)
      const tenMB = 10 * 1024 * 1024;
      if (file.size > tenMB) {
        setError(`File "${file.name}" exceeds the 10MB individual file limit.`);
        return;
      }

      // Check file type/extensions as an extra safety measure
      const ext = file.name.split('.').pop()?.toLowerCase();
      const validExtensions = ['pdf', 'jpeg', 'jpg', 'png', 'docx', 'doc', 'xlsx', 'xls'];
      
      if (!ext || !validExtensions.includes(ext)) {
        setError(`File format for "${file.name}" is not supported. Please upload YER, PDF, JPEG, PNG, DOCX, or XLSX files.`);
        return;
      }

      // Read as base64 data URL
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64Url = reader.result as string;
          await saveAttachment(entityId, file.name, file.size, file.type || `application/${ext}`, base64Url);
          await loadAttachments();
        } catch (err) {
          console.error('Error saving file:', err);
          setError('Failed to save file attachment locally.');
        }
      };
      reader.onerror = () => {
        setError('Error reading file.');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragActive(false);
    await processFiles(e.dataTransfer.files);
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    await processFiles(e.target.files);
    // Reset file input value so same file can be selected again
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
    setIsDropdownOpen(false);
  };

  const handleRemove = async (id: string) => {
    try {
      await deleteAttachment(id);
      await loadAttachments();
    } catch (err) {
      console.error('Error removing attachment:', err);
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.includes('image/')) return <FileImage className="w-5 h-5 text-emerald-500" />;
    if (type.includes('excel') || type.includes('spreadsheet') || type.includes('xlsx') || type.includes('xls')) {
      return <FileSpreadsheet className="w-5 h-5 text-green-600" />;
    }
    if (type.includes('word') || type.includes('doc') || type.includes('document')) {
      return <FileText className="w-5 h-5 text-blue-500" />;
    }
    if (type.includes('pdf')) return <FileText className="w-5 h-5 text-rose-500" />;
    return <Paperclip className="w-5 h-5 text-slate-500" />;
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Box Zone Container */}
      <div 
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-xl p-6 transition-all flex flex-col items-center justify-center text-center ${
          isDragActive 
            ? 'border-indigo-500 bg-indigo-50/50' 
            : 'border-slate-200 bg-slate-50/50 hover:bg-slate-50 hover:border-slate-300'
        }`}
      >
        <input 
          ref={fileInputRef}
          type="file" 
          multiple 
          onChange={handleFileInputChange} 
          accept=".pdf,.jpeg,.jpg,.png,.docx,.doc,.xlsx,.xls"
          className="hidden"
        />

        {/* Paperclip Drag Area */}
        <Upload className={`w-8 h-8 mb-3 transition-transform ${isDragActive ? 'scale-110 text-indigo-500 animate-bounce' : 'text-slate-400'}`} />
        
        {/* Custom Upload Button with Dropdown arrow */}
        <div className="relative inline-flex items-center shadow-sm rounded-lg border border-slate-200 bg-white" ref={dropdownRef}>
          <button
            type="button"
            onClick={handleBrowseClick}
            className="flex items-center gap-2 px-4 py-2 hover:bg-slate-50 text-slate-700 text-sm font-semibold rounded-l-lg transition-colors border-r border-slate-200 select-none"
          >
            <Paperclip className="w-4 h-4 text-slate-500" />
            Upload File
          </button>
          
          <button
            type="button"
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="p-2 hover:bg-slate-50 text-slate-500 hover:text-slate-700 rounded-r-lg transition-colors"
          >
            <ChevronDown className="w-4 h-4" />
          </button>

          {isDropdownOpen && (
            <div className="absolute top-full left-0 right-0 lg:left-auto lg:right-0 mt-1.5 w-52 bg-white border border-slate-200 rounded-lg shadow-xl z-50 py-1 font-medium text-slate-700 text-xs">
              <button
                type="button"
                onClick={handleBrowseClick}
                className="w-full text-left px-3.5 py-2 hover:bg-slate-50 hover:text-indigo-600 transition-colors flex items-center gap-2"
              >
                <Upload className="w-3.5 h-3.5 text-slate-400" />
                From Local Computer
              </button>
              <div className="border-t border-slate-100 my-1" />
              <div className="px-3.5 py-1.5 text-[10px] text-slate-400 font-semibold leading-relaxed">
                Accepted: PDF, JPEG, PNG, DOCX, XLSX (Up to 10MB each)
              </div>
            </div>
          )}
        </div>

        {/* Drag and Drop instructions */}
        <p className="mt-2.5 text-xs text-slate-500 font-medium">
          or drag & drop files here
        </p>

        {/* Helper text specified in requirements */}
        <p className="mt-2 text-[11px] text-slate-400 font-normal">
          You can upload a maximum of 10 files, 10MB each
        </p>

        {error && (
          <div className="mt-3 flex items-start gap-1.5 p-2 bg-rose-50 border border-rose-100 rounded-lg text-rose-600 text-xs text-left max-w-sm">
            <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* List of attachments */}
      {attachments.length > 0 && (
        <div className="border border-slate-200 bg-white rounded-xl divide-y divide-slate-100 overflow-hidden shadow-sm">
          <div className="bg-slate-50 px-4 py-2 flex items-center justify-between border-b border-slate-200">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              Attached Files ({attachments.length} of 10)
            </span>
          </div>
          <div className="max-h-48 overflow-y-auto">
            {attachments.map((file) => (
              <div key={file.id} className="flex items-center justify-between p-3.5 hover:bg-slate-50 group transition-colors">
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {getFileIcon(file.type)}
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-slate-700 truncate" title={file.name}>
                      {file.name}
                    </p>
                    <p className="text-[10px] font-mono text-slate-400 mt-0.5">
                      {formatSize(file.size)}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center gap-1 ml-4 shadow-sm rounded-lg border border-slate-200 bg-white overflow-hidden p-0.5">
                  <button
                    type="button"
                    onClick={() => setPreviewAttachment(file)}
                    className="p-1 px-1.5 hover:bg-slate-50 text-slate-500 hover:text-indigo-600 rounded transition-all text-[11px] flex items-center gap-1.5 font-bold"
                    title="Preview File"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View</span>
                  </button>
                  <div className="w-px h-4 bg-slate-200 my-auto" />
                  <button
                    type="button"
                    onClick={() => handleRemove(file.id)}
                    className="p-1 px-1.5 hover:bg-slate-50 text-slate-400 hover:text-rose-600 rounded transition-all text-[11px]"
                    title="Delete File"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modern Lightbox Preview Modal */}
      {previewAttachment && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[85vh] flex flex-col overflow-hidden animate-scale-up">
            <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2 min-w-0">
                {getFileIcon(previewAttachment.type)}
                <span className="text-sm font-bold text-slate-900 truncate" title={previewAttachment.name}>
                  {previewAttachment.name}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  ({formatSize(previewAttachment.size)})
                </span>
              </div>
              <div className="flex items-center gap-2">
                <a
                  href={previewAttachment.url}
                  download={previewAttachment.name}
                  className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-slate-800 transition-colors flex items-center gap-1 text-xs font-bold"
                >
                  <Download className="w-4 h-4" />
                  Download
                </a>
                <button
                  type="button"
                  onClick={() => setPreviewAttachment(null)}
                  className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-700 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex-1 bg-slate-100 overflow-auto p-6 flex items-center justify-center min-h-[300px]">
              {previewAttachment.type.includes('image/') ? (
                <img 
                  src={previewAttachment.url} 
                  alt={previewAttachment.name} 
                  className="max-h-[55vh] object-contain rounded-lg shadow border border-slate-200"
                  referrerPolicy="no-referrer"
                />
              ) : previewAttachment.type.includes('pdf') ? (
                <iframe 
                  src={previewAttachment.url} 
                  title={previewAttachment.name} 
                  className="w-full h-[55vh] rounded-lg border border-slate-200 shadow bg-white"
                />
              ) : (
                <div className="text-center p-8 bg-white border border-slate-200 rounded-xl max-w-sm shadow-sm">
                  <FileText className="w-12 h-12 text-indigo-500 mx-auto mb-3" />
                  <h4 className="text-sm font-bold text-slate-800 mb-1">Preview not available</h4>
                  <p className="text-xs text-slate-500 leading-normal mb-4">
                    Files like DOCX and XLSX can't be rendered directly in the browser preview. Please download the file to read its contents.
                  </p>
                  <a
                    href={previewAttachment.url}
                    download={previewAttachment.name}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg text-xs font-bold shadow-sm transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download File
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
