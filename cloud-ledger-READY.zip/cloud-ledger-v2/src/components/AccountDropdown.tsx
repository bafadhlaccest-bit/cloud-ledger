import React from 'react';

// تعريف واجهة خصائص القائمة المنسدلة المحسنة
interface AccountDropdownProps {
  accounts: any[]; // مصفوفة شجرة الحسابات القادمة من الـ State الرئيسي أو قاعدة البيانات
  selectedAccountId: string; // المعرف الحالي للحساب المحدد
  onAccountChange: (accountId: string) => void; // التابع المسؤول عن حفظ الاختيار عند التغيير
  accountTypeFilter?: string | string[]; // فلاتر اختيارية (مثلاً: إظهار حسابات الأصول فقط أو المصاريف فقط)
  placeholder?: string;
  className?: string;
}

export const AccountDropdown: React.FC<AccountDropdownProps> = ({
  accounts,
  selectedAccountId,
  onAccountChange,
  accountTypeFilter,
  placeholder = "اختر الحساب المحاسبي المربوط...",
  className = "w-full p-2 border rounded-md bg-white text-right font-medium"
}) => {
  
  // فحص وتصفية الحسابات والتحقق كلياً باستبعاد الحسابات الرئيسية والتجميعية
  const filteredAccounts = accounts.filter(acc => {
    // 1. الفلترة بناءً على فلاتر النوع المطلوبة
    if (accountTypeFilter) {
      const typeMatches = Array.isArray(accountTypeFilter)
        ? accountTypeFilter.includes(acc.type)
        : acc.type === accountTypeFilter;
      if (!typeMatches) return false;
    }

    // 2. تصفية وحظر واستبعاد كل الحسابات الجذريّة والتجميعية والراعية لإعاقة الترحيل المالي الخاطئ
    const isMainAccount = 
      acc.isRoot === true || 
      ['1000', '2000', '3000', '4000', '5000'].includes(acc.code) || 
      acc.hasChildren === true ||
      acc.isParent === true ||
      accounts.some(a => a.parentId === acc.id);

    return !isMainAccount; // الحسابات الفرعية التشغيلية القابلة للنشر فقط
  });

  return (
    <div className="flex flex-col gap-1 w-full text-right" dir="rtl">
      <select
        value={selectedAccountId}
        onChange={(e) => onAccountChange(e.target.value)}
        className={className}
      >
        <option value="">-- {placeholder} --</option>
        {filteredAccounts.map((account) => {
          return (
            <option
              key={account.id}
              value={account.id}
              className="text-slate-900 font-normal"
              style={{
                fontWeight: 'normal',
                color: '#111827',
                paddingRight: account.parentId ? '16px' : '8px'
              }}
            >
              {account.code} - {account.name} {` (${account.type})`}
            </option>
          );
        })}
      </select>
    </div>
  );
};

