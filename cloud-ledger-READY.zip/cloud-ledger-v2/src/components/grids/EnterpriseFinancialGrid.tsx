import React, { useState } from 'react';
import { 
  useReactTable, 
  getCoreRowModel, 
  flexRender, 
  ColumnOrderState,
  ColumnDef
} from '@tanstack/react-table';

interface EnterpriseFinancialGridProps<TData = any> {
  data: TData[];
  columns: ColumnDef<TData, any>[];
}

export const EnterpriseFinancialGrid = <TData,>({ 
  data, 
  columns 
}: EnterpriseFinancialGridProps<TData>) => {
  const [columnOrder, setColumnOrder] = useState<ColumnOrderState>([]);
  const [columnSizing, setColumnSizing] = useState({});

  const table = useReactTable({
    data,
    columns,
    state: { columnOrder, columnSizing },
    onColumnOrderChange: setColumnOrder,
    onColumnSizingChange: setColumnSizing,
    getCoreRowModel: getCoreRowModel(),
    columnResizeMode: 'onChange',
  });

  return (
    <div className="overflow-x-auto border border-slate-300 rounded shadow-sm bg-white text-right" id="enterprise-financial-grid-wrapper">
      <table className="w-full text-erp-sm border-collapse" id="enterprise-financial-grid-table">
        <thead className="bg-finance-navy text-white sticky top-0 z-10">
          {table.getHeaderGroups().map(headerGroup => (
            <tr key={headerGroup.id}>
              {headerGroup.headers.map(header => (
                <th 
                  key={header.id} 
                  id={`header-${header.id}`}
                  className="px-2 py-1.5 border-b border-l border-slate-700 relative select-none font-bold text-right"
                  style={{ width: header.getSize() }}
                >
                  {flexRender(header.column.columnDef.header, header.getContext())}
                  {/* أداة سحب وتغيير حجم العمود (Column Resizing) */}
                  <div
                    onMouseDown={header.getResizeHandler()}
                    onTouchStart={header.getResizeHandler()}
                    className={`absolute left-0 top-0 h-full w-1 bg-slate-500 cursor-col-resize user-select-none touch-action-none ${
                      header.column.getIsResizing() ? 'bg-emerald-500 w-2' : ''
                    }`}
                  />
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map(row => (
            <tr key={row.id} className="hover:bg-slate-100 odd:bg-finance-slate transition-colors">
              {row.getVisibleCells().map(cell => (
                <td key={cell.id} className="px-2 py-1 border-b border-l border-slate-200 text-right">
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
