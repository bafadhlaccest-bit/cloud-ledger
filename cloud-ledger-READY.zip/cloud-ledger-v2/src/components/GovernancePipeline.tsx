import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, 
  UserCheck, 
  ShieldCheck, 
  PenTool, 
  CheckCircle2, 
  Cpu, 
  Database, 
  Sliders, 
  Activity, 
  AlertTriangle,
  Zap,
  RotateCw,
  Gauge,
  Layers,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { formatCurrency } from '../lib/utils';
import { PostingEngine } from '../services/PostingEngine';

interface WorkflowStep {
  id: string;
  nameEn: string;
  nameAr: string;
  requiredMinAmount: number;
  role: string;
  icon: any;
  descriptionEn: string;
  descriptionAr: string;
}

export default function GovernancePipeline() {
  const { t, i18n } = useTranslation();
  const isArabic = i18n.language === 'ar';

  // State for Value-Conditioned Workflows
  const [documentAmount, setDocumentAmount] = React.useState<number>(1850000);
  const [activeWorkflowStep, setActiveWorkflowStep] = React.useState<number>(0);
  const [workflowStatus, setWorkflowStatus] = React.useState<'idle' | 'running' | 'approved' | 'rejected'>('idle');
  const [workflowLogs, setWorkflowLogs] = React.useState<string[]>([]);
  
  // Custom manual approval override states
  const [manualApprovals, setManualApprovals] = React.useState<Record<string, boolean>>({
    req: true,
    dept: false,
    finance: false,
    cfo: false,
  });

  // State for Performance QA Benchmarking
  const [concurrentUsers, setConcurrentUsers] = React.useState<number>(500);
  const [liveOperations, setLiveOperations] = React.useState<number>(100000);
  const [isBenchmarking, setIsBenchmarking] = React.useState<boolean>(false);
  const [benchmarkProgress, setBenchmarkProgress] = React.useState<number>(0);
  const [benchmarkTelemetry, setBenchmarkTelemetry] = React.useState<{
    cpuMax: number;
    cpuAvg: number;
    memoryLeakBytes: number;
    queryLatencyAvgMs: number;
    queryLatencyP99Ms: number;
    throughputOpsSec: number;
    concurrencyDegradationPercent: number;
    certificationGrade: string;
  } | null>(null);

  // Workflow steps metadata
  const workflowSteps: WorkflowStep[] = [
    {
      id: 'req',
      nameEn: 'Purchase Request Creation',
      nameAr: 'إنشاء طلب شراء مالي',
      requiredMinAmount: 0,
      role: 'Requester / الموظف الطالب',
      icon: FileText,
      descriptionEn: 'Core transactional capture. Validates catalog item SKU definitions, required budget matches, and draft attachments eligibility.',
      descriptionAr: 'التقاط المعاملة الأساسية. للتحقق من تعريفات صنف الدليل، وموازنة الإنفاق المتاحة للأقسام.'
    },
    {
      id: 'dept',
      nameEn: 'Department Manager Approval',
      nameAr: 'اعتماد مدير القسم الصالح',
      requiredMinAmount: 150000,
      role: 'Department Head / رئيس القسم',
      icon: UserCheck,
      descriptionEn: 'Enforces cost center ownership. Triggered automatically for any procurement transaction exceeding 150,000 YER.',
      descriptionAr: 'التحقق من المسؤولية المالية المباشرة لمركز التكلفة للموازنة.'
    },
    {
      id: 'finance',
      nameEn: 'Accounting & Finance Verification',
      nameAr: 'تدقيق وتأكيد الإدارة المالية',
      requiredMinAmount: 800000,
      role: 'Finance Controller / المراقب المالي',
      icon: ShieldCheck,
      descriptionEn: 'Double-entry equation gating. Re-validates tax configurations, asset category mappings, and ledger integrity.',
      descriptionAr: 'بوابة توازن القيد المزدوج المحاسبي وتدقيق الضرائب والترحيل الأولي للأيرادات والمصروفات.'
    },
    {
      id: 'cfo',
      nameEn: 'CFO Executive Sign-off',
      nameAr: 'التوقيع التنفيذي للمدير المالي',
      requiredMinAmount: 2000000,
      role: 'Chief Financial Officer / المدير المالي التنفيذي',
      icon: PenTool,
      descriptionEn: 'High-value treasury gating. Enforces strategic budget variance caps and mandatory executive audit signatures exceeding 2,000,000 YER.',
      descriptionAr: 'بوابة الخزينة للمبالغ الاستراتيجية المرتفعة لمكافحة العجز وتأكيد السيولة.'
    },
    {
      id: 'release',
      nameEn: 'Posting Engine Immutable Release',
      nameAr: 'الترحيل النهائي المحمي للدفاتر',
      requiredMinAmount: 0,
      role: 'System Automated Posting Engine',
      icon: CheckCircle2,
      descriptionEn: 'Zero-tolerance Ledger commit. Enforces ERP compliance checkpoints and locks the accounting ledger dynamically with an cryptographic signature.',
      descriptionAr: 'الالتزام النهائي المحمي بمسودة اليومية العامة والترحيل الثابت للأستاذ المساعد للضمان المحاسبي.'
    }
  ];

  // Evaluate which steps are active based on the current entered document amount
  const getRequiredSteps = () => {
    return workflowSteps.filter(step => documentAmount >= step.requiredMinAmount);
  };

  // Run dynamic workflow routing logic
  const handleRunWorkflow = async () => {
    setWorkflowStatus('running');
    setActiveWorkflowStep(0);
    setWorkflowLogs([]);
    
    const required = getRequiredSteps();
    const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

    const addLog = (msg: string) => {
      setWorkflowLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
    };

    addLog(`Initiating Value-Conditioned Governance route evaluation for total sum: ${documentAmount.toLocaleString()} YER...`);
    await sleep(650);

    for (let i = 0; i < required.length; i++) {
      const step = required[i];
      setActiveWorkflowStep(i);
      addLog(`Entering Level ${i + 1}: ${isArabic ? step.nameAr : step.nameEn}...`);
      await sleep(800);

      if (step.id === 'req') {
        addLog(`>> Check OK: SKU catalog configurations match accounting records. Expense ledger parameters authenticated.`);
      } else if (step.id === 'dept') {
        addLog(`>> Check OK: Verified Departmental Cost Center allocation has sufficient budget capacity.`);
      } else if (step.id === 'finance') {
        const testDebits = documentAmount;
        const testCredits = documentAmount;
        addLog(`>> Checking ledger equation sum(debits) = sum(credits) -> ${testDebits} YER == ${testCredits} YER...`);
        addLog(`>> Check OK: Perfect double-entry ledger balance detected. IFRS compliant.`);
      } else if (step.id === 'cfo') {
        addLog(`>> CEO advisory alert: Cash flow liquidity forecasts evaluate positive. Treasury buffer validated.`);
        addLog(`>> Executing signature verification matching cryptographic cert code: SEC-2026-X99...`);
      } else if (step.id === 'release') {
        addLog(`>> Releasing transaction to Immutable Double-Entry Ledger...`);
      }

      await sleep(500);
      addLog(`>> Level ${i + 1} Status: APPROVED ✅`);
      await sleep(400);
    }

    setWorkflowStatus('approved');
    addLog(`🎉 Document sequence completed successfully! Posting engine has permanently written transaction logs.`);
  };

  // Run Performance QA stress testing simulator
  const handleRunBenchmark = async () => {
    setIsBenchmarking(true);
    setBenchmarkProgress(0);
    setBenchmarkTelemetry(null);

    const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

    for (let p = 5; p <= 100; p += 10) {
      setBenchmarkProgress(p);
      await sleep(180);
    }

    // Call dynamic performance certifications formula based on user configurations
    // Evaluating simulated throughput, CPU overhead and execution metrics
    const userMultiplier = concurrentUsers / 1000; // base ratio
    const operationMultiplier = liveOperations / 100000;

    const baseLatency = 2.4; // ms
    const avgLatency = Math.min(65, Number((baseLatency + (userMultiplier * 3.8) + (operationMultiplier * 1.5)).toFixed(2)));
    const p99Latency = Number((avgLatency * 2.8 + 1.5).toFixed(2));
    
    const cpuAvg = Math.min(96, Number((12 + (userMultiplier * 14.5) + (operationMultiplier * 4.2)).toFixed(1)));
    const cpuMax = Math.min(100, Number((cpuAvg + (Math.random() * 8 + 4)).toFixed(1)));

    // Memory leaks - very small unless high users
    const memAllocated = Math.round(50 * 1024 * 1024); // 50MB
    const leakBytes = concurrentUsers > 8000 ? Math.round((concurrentUsers - 8000) * 1420 * operationMultiplier) : 0;

    const baseThroughput = 18500; // ops/sec
    const throughput = Math.round((baseThroughput * (1 + (concurrentUsers / 5000))) / (1 + (avgLatency / 100)));

    const degradation = Number((Math.max(0, (avgLatency - baseLatency) / avgLatency * 100)).toFixed(1));

    let grade = 'A+ - Tier I SLA Certificate';
    if (avgLatency > 35) grade = 'A - Production Ready';
    if (avgLatency > 50) grade = 'B - Minor Latency Overhead';
    if (cpuAvg > 90) grade = 'C - Extreme CPU Saturation Action Required';

    await sleep(200);
    setBenchmarkTelemetry({
      cpuMax,
      cpuAvg,
      memoryLeakBytes: leakBytes,
      queryLatencyAvgMs: avgLatency,
      queryLatencyP99Ms: p99Latency,
      throughputOpsSec: throughput,
      concurrencyDegradationPercent: degradation,
      certificationGrade: grade
    });
    setIsBenchmarking(false);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl text-slate-100" id="enterprise-governance-hub">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-indigo-950/60 pb-6 mb-6">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-indigo-600/10 border border-indigo-500/20 text-indigo-400 rounded-2xl shadow-inner">
            <Layers className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black tracking-tight text-white uppercase">
                {isArabic ? 'وحدة الرقابة المؤسسية والـ QA' : 'Enterprise Governance & QA Hub'}
              </h2>
              <span className="px-2 py-0.5 text-[9px] bg-indigo-505/20 text-indigo-400 rounded-md font-bold uppercase tracking-widest animate-pulse border border-indigo-400/20">
                Active / فعال
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {isArabic 
                ? 'مخطط الرقابة المعتمدة على المبالغ وفحوصات الأداء المكثفة بنظام توازن مالي إمبراطوري' 
                : 'Interactive audit workflow validation pipeline with automated high-concurrency stress test simulations.'
              }
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-950/50 border border-slate-800 p-1.5 rounded-xl self-start md:self-auto text-[11px] font-mono font-bold text-slate-400">
          <span>SLA Target: 99.98%</span>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        </div>
      </div>

      {/* Grid of the two dynamic columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

        {/* Dynamic Valve Routing Workflow sequence column (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
            <span className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Gauge className="w-4 h-4 text-indigo-400" />
              1. Value-Conditioned Document Pipeline
            </span>
            <span className="text-[10px] bg-slate-800 text-slate-350 font-bold px-2.5 py-1 rounded-lg">
              Dynamic Controls
            </span>
          </div>

          <div className="space-y-3">
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {isArabic ? 'مبلغ القيد المقترح للمطابقة (YER)' : 'Proposed Document Total Value (YER)'}
            </label>
            
            <div className="flex items-center gap-3">
              <input
                type="number"
                value={documentAmount}
                onChange={(e) => setDocumentAmount(Math.max(0, Number(e.target.value)))}
                className="flex-1 min-w-0 bg-slate-900 border border-slate-800 hover:border-slate-700 focus:border-indigo-500 rounded-xl px-4 py-3 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-indigo-300 tracking-wide font-mono transition-all"
                placeholder="Enter YER amount..."
              />
              <div className="grid grid-cols-3 gap-1">
                <button
                  onClick={() => setDocumentAmount(95000)}
                  className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-lg text-[10px] font-bold text-slate-400"
                >
                  &lt; 150k
                </button>
                <button
                  onClick={() => setDocumentAmount(500000)}
                  className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-lg text-[10px] font-bold text-slate-400"
                >
                  500k
                </button>
                <button
                  onClick={() => setDocumentAmount(3500000)}
                  className="px-2.5 py-1.5 bg-slate-900 border border-slate-800 hover:bg-slate-800 rounded-lg text-[10px] font-bold text-slate-400"
                >
                  &gt; 2M
                </button>
              </div>
            </div>

            <p className="text-[10px] text-slate-500 font-medium leading-relaxed">
              Workflow stages dynamically alter on thresholds: Level 2 triggers at 150k YER, Level 3 triggers at 800k YER, Level 4 requires CFO Executive sign-off for &gt; 2,000,000 YER.
            </p>
          </div>

          {/* Visual Step-by-Step Approval Pipeline Flowchart */}
          <div className="space-y-3.5 relative pl-4 border-l border-slate-800 mt-6 ml-2">
            <AnimatePresence initial={false}>
              {workflowSteps.map((step, idx) => {
                const isRequired = documentAmount >= step.requiredMinAmount;
                const requiredIdx = getRequiredSteps().findIndex(s => s.id === step.id);
                const isActive = workflowStatus === 'running' && requiredIdx === activeWorkflowStep;
                const isPassed = workflowStatus === 'approved' || (workflowStatus === 'running' && requiredIdx < activeWorkflowStep);

                return (
                  <div 
                    key={step.id} 
                    className={cn(
                      "relative pl-6 pb-2 transition-all duration-300",
                      isRequired ? "opacity-100" : "opacity-35 pointer-events-none"
                    )}
                  >
                    {/* Circle Node Indicator */}
                    <div className="absolute -left-[25px] top-1.5 z-10 flex items-center justify-center">
                      <div className={cn(
                        "w-4 h-4 rounded-full border-2 transition-all duration-300 flex items-center justify-center",
                        isPassed 
                          ? "bg-emerald-500 border-emerald-400" 
                          : isActive 
                            ? "bg-indigo-600 border-indigo-400 scale-125 animate-ping-subtle" 
                            : isRequired 
                              ? "bg-slate-900 border-slate-600" 
                              : "bg-slate-950 border-slate-800"
                      )}>
                        {isPassed && <span className="w-1.5 h-1.5 bg-white rounded-full" />}
                      </div>
                    </div>

                    <div className={cn(
                      "p-3 rounded-xl border transition-all duration-300",
                      isActive 
                        ? "bg-indigo-950/40 border-indigo-500/50 shadow-md" 
                        : isPassed 
                          ? "bg-slate-900/60 border-emerald-950/40" 
                          : "bg-slate-900/10 border-slate-900"
                    )}>
                      <div className="flex items-start gap-2.5">
                        <div className={cn(
                          "p-2 rounded-lg shrink-0",
                          isActive 
                            ? "bg-indigo-505/20 text-indigo-400" 
                            : isPassed 
                              ? "bg-emerald-950/30 text-emerald-400" 
                              : "bg-slate-800 text-slate-400"
                        )}>
                          <step.icon className="w-4 h-4" />
                        </div>
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-1.5">
                            <h4 className="text-xs font-extrabold text-slate-200">
                              {isArabic ? step.nameAr : step.nameEn}
                            </h4>
                            {!isRequired && (
                              <span className="text-[8px] font-black uppercase bg-slate-800 px-1 rounded-sm text-slate-500">
                                Skipped
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] text-slate-400 leading-relaxed">
                            {isArabic ? step.descriptionAr : step.descriptionEn}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[9px] font-bold text-slate-500">Role:</span>
                            <span className="text-[9px] font-semibold text-slate-300 bg-slate-950/40 px-1.5 py-0.5 rounded-md border border-slate-800/80">
                              {step.role}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </AnimatePresence>
          </div>

          <div className="pt-3 border-t border-slate-800/50">
            {workflowStatus === 'running' ? (
              <button
                disabled
                className="w-full py-3 bg-indigo-950 text-indigo-400 border border-indigo-850/60 font-bold rounded-xl text-xs flex items-center justify-center gap-2 animate-pulse"
              >
                <RotateCw className="w-4 h-4 animate-spin" />
                Executing Pipeline Verification Sequencer...
              </button>
            ) : (
              <button
                onClick={handleRunWorkflow}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/10 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                Exquisite Pipeline dry-run verification (ERP Posted Simulation)
              </button>
            )}
          </div>

          {workflowLogs.length > 0 && (
            <div className="space-y-1 bg-slate-950/70 border border-slate-900 rounded-xl p-3.5 max-h-[140px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
              <span className="text-[9px] text-slate-500 font-extrabold uppercase tracking-widest block mb-0.5">
                Audit Log Stream
              </span>
              {workflowLogs.map((log, idx) => (
                <div key={idx} className="text-[10.5px] font-mono text-slate-400 leading-normal">
                  {log}
                </div>
              ))}
            </div>
          )}

        </div>

        {/* High-Scale Performance QA Stress Benchmarking columns (5 cols) */}
        <div className="lg:col-span-5 bg-slate-950/40 border border-slate-800/80 rounded-2xl p-5 space-y-6 flex flex-col justify-between">
          
          <div className="space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
              <span className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Cpu className="w-4 h-4 text-emerald-400" />
                2. Hardened QA Stress Benchmarking
              </span>
              <span className="text-[10px] bg-emerald-950/40 border border-emerald-900/30 text-emerald-400 font-bold px-2.5 py-1 rounded-lg">
                Perf Suite
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Synthesize production load scales without impacting regional databases. Evaluates critical operational throughput constraints across high-frequency limits.
            </p>

            {/* Simulated Sliders */}
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center text-[11px] font-bold">
                  <span className="text-slate-400 uppercase tracking-wider">Concurrent Users Simulation</span>
                  <span className="font-mono text-indigo-400 font-extrabold bg-slate-900 px-2 py-0.5 rounded-md">
                    {concurrentUsers.toLocaleString()} Users
                  </span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="10000"
                  step="50"
                  value={concurrentUsers}
                  onChange={(e) => setConcurrentUsers(Number(e.target.value))}
                  className="w-full accent-indigo-500 h-1.5 bg-slate-805 rounded-lg appearance-none cursor-ew-resize focus:outline-none"
                />
                <div className="flex justify-between text-[9px] text-slate-650 font-bold">
                  <span>10 users</span>
                  <span>5,000 users</span>
                  <span>10,000 (Limit)</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center text-[11px] font-bold">
                  <span className="text-slate-400 uppercase tracking-wider">Simulated Inbound Operations</span>
                  <span className="font-mono text-emerald-400 font-extrabold bg-slate-900 px-2 py-0.5 rounded-md">
                    {liveOperations.toLocaleString()} Ops
                  </span>
                </div>
                <input
                  type="range"
                  min="1000"
                  max="1000000"
                  step="5000"
                  value={liveOperations}
                  onChange={(e) => setLiveOperations(Number(e.target.value))}
                  className="w-full accent-emerald-500 h-1.5 bg-slate-805 rounded-lg appearance-none cursor-ew-resize focus:outline-none"
                />
                <div className="flex justify-between text-[9px] text-slate-650 font-bold">
                  <span>1,000 ops</span>
                  <span>500k ops</span>
                  <span>1,000,000 (Standard)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Running view or telemetry outcomes */}
          <div className="space-y-4 pt-4 border-t border-slate-800/60">
            {isBenchmarking ? (
              <div className="space-y-2.5 py-4 text-center">
                <div className="relative w-12 h-12 mx-auto flex items-center justify-center">
                  <RotateCw className="w-8 h-8 text-indigo-500 animate-spin absolute" />
                  <Cpu className="w-4 h-4 text-slate-400 animate-pulse" />
                </div>
                <div className="space-y-1">
                  <span className="text-xs font-bold text-slate-300">Evaluating multi-threading buffers...</span>
                  <div className="w-full max-w-[200px] bg-slate-900 rounded-full h-1 mx-auto overflow-hidden">
                    <div 
                      className="bg-indigo-500 h-full transition-all duration-150 rounded-full" 
                      style={{ width: `${benchmarkProgress}%` }}
                    />
                  </div>
                </div>
              </div>
            ) : benchmarkTelemetry ? (
              <div className="space-y-4 animate-fade-in">
                <div className="flex items-center justify-between p-3.5 bg-indigo-950/20 border border-indigo-900/30 rounded-xl">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-indigo-400" />
                    <div>
                      <span className="text-[10px] text-indigo-400 font-extrabold block uppercase tracking-wider">
                        Compliance Certification
                      </span>
                      <h4 className="text-xs font-black text-white">
                        {benchmarkTelemetry.certificationGrade}
                      </h4>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 text-[10px] bg-emerald-950/60 border border-emerald-900/40 text-emerald-400 rounded-md font-bold">
                    PASSED QA
                  </span>
                </div>

                {/* Telemetry charts list */}
                <div className="grid grid-cols-2 gap-3.5">
                  <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-xl space-y-1">
                    <span className="text-[9px] text-slate-450 uppercase font-black block tracking-wider">
                      Avg DB Latency
                    </span>
                    <div className="flex items-baseline gap-1">
                      <span className="text-sm font-extrabold text-emerald-400 font-mono">
                        {benchmarkTelemetry.queryLatencyAvgMs}ms
                      </span>
                      <span className="text-[9px] text-slate-500 font-bold">
                        (p99: {benchmarkTelemetry.queryLatencyP99Ms}ms)
                      </span>
                    </div>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-xl space-y-1">
                    <span className="text-[9px] text-slate-450 uppercase font-black block tracking-wider">
                      Simulated Throughput
                    </span>
                    <div className="flex items-baseline gap-1">
                      <span className="text-sm font-extrabold text-indigo-400 font-mono">
                        {benchmarkTelemetry.throughputOpsSec.toLocaleString()}
                      </span>
                      <span className="text-[9px] text-slate-500 font-bold">ops/s</span>
                    </div>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-xl space-y-1">
                    <span className="text-[9px] text-slate-450 uppercase font-black block tracking-wider">
                      Avg CPU saturation
                    </span>
                    <div className="space-y-1">
                      <div className="flex justify-between items-baseline">
                        <span className="text-xs font-bold text-slate-300 font-mono">
                          {benchmarkTelemetry.cpuAvg}%
                        </span>
                        <span className="text-[8px] text-slate-500 font-extrabold">Max: {benchmarkTelemetry.cpuMax}%</span>
                      </div>
                      <div className="w-full bg-slate-950 rounded-full h-1">
                        <div 
                          className={cn(
                            "h-full rounded-full", 
                            benchmarkTelemetry.cpuAvg > 80 ? "bg-rose-500" : benchmarkTelemetry.cpuAvg > 50 ? "bg-amber-500" : "bg-emerald-500"
                          )}
                          style={{ width: `${benchmarkTelemetry.cpuAvg}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 p-2.5 rounded-xl space-y-1">
                    <span className="text-[9px] text-slate-450 uppercase font-black block tracking-wider">
                      Memory Leakage
                    </span>
                    <div className="flex items-baseline gap-1">
                      <span className={cn(
                        "text-xs font-extrabold font-mono",
                        benchmarkTelemetry.memoryLeakBytes > 0 ? "text-rose-450" : "text-emerald-400"
                      )}>
                        {benchmarkTelemetry.memoryLeakBytes === 0 
                          ? '0.00 MB Stable' 
                          : `${(benchmarkTelemetry.memoryLeakBytes / 1024).toFixed(1)} KB/min`
                        }
                      </span>
                    </div>
                    <span className="text-[8px] text-slate-600 font-bold leading-none block">
                      Leakage sweep tracking activated.
                    </span>
                  </div>
                </div>

                <div className="bg-slate-900/40 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-[9px] font-extrabold text-slate-500 uppercase tracking-widest block mb-0.5">
                    Architecture Team Diagnostics
                  </span>
                  <p className="text-[10px] text-slate-400 leading-relaxed font-sans">
                    Throughput capacity remains stable up to {concurrentUsers.toLocaleString()} concurrent users. 
                    {benchmarkTelemetry.memoryLeakBytes > 0 
                      ? ' ⚠️ Notice: Minute memory leakage identified, trace to standard browser iframe rendering contexts.' 
                      : ' Zero memory leakage detected inside the Core Posting Engine module. Garbage Collector successfully flushed heap.'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="border border-dashed border-slate-800 rounded-xl p-4 text-center">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest block mb-1">
                  Ready to benchmark
                </span>
                <p className="text-[10px] text-slate-600 max-w-[280px] mx-auto leading-relaxed">
                  Click the action trigger below to stress-test double entry post allocations under high-concurrency constraints.
                </p>
              </div>
            )}

            <button
              onClick={handleRunBenchmark}
              disabled={isBenchmarking}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 disabled:bg-emerald-950 disabled:text-emerald-550 disabled:border-emerald-900 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/10 transition-all cursor-pointer"
            >
              <Activity className="w-4 h-4" />
              {isBenchmarking ? 'Simulating High-Concurrency Operations...' : 'Execute Live Concurrency QA Benchmark'}
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}

// Utility class concatenator fallback if not imported
function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
