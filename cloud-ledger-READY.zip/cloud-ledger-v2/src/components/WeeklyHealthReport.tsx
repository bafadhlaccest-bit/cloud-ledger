/**
 * WeeklyHealthReport — تقرير الصحة المالية الأسبوعي
 * ميزة غير موجودة في زوهو/زيرو:
 * يولّد تقريراً أسبوعياً ذكياً بضغطة واحدة يشمل:
 * - ملخص الأسبوع الماضي
 * - مقارنة بالأسبوع السابق
 * - 3 توصيات قابلة للتنفيذ
 * - تنبيهات يجب اتخاذ إجراء خلال 48 ساعة
 */
import React, { useState } from 'react';
import { Zap, Download, RefreshCw, CheckCircle2, AlertCircle, TrendingUp, TrendingDown, X } from 'lucide-react';
import { useFinancialAdvisor } from '../hooks/useFinancialAdvisor';
import { useDashboardData } from '../hooks/useDashboardData';
import * as XLSX from 'xlsx';

interface Props { onClose: () => void; }

export default function WeeklyHealthReport({ onClose }: Props) {
  const [report, setReport] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);
  const { sendMessage, messages } = useFinancialAdvisor();
  const dash = useDashboardData();

  const fmt = (n: number) => n.toLocaleString('ar-SA', { maximumFractionDigits: 0 });

  const generateReport = async () => {
    setIsGenerating(true);
    const prompt = `اكتب تقرير صحة مالية أسبوعي شامل للشركة بهذا التنسيق بالضبط:

## 📊 ملخص هذا الأسبوع
[ملخص 3 أسطر للأداء المالي]

## ✅ نقاط القوة
- [نقطة 1]
- [نقطة 2]
- [نقطة 3]

## ⚠️ نقاط تحتاج اهتمام
- [نقطة 1 مع رقم محدد]
- [نقطة 2 مع رقم محدد]

## 🎯 توصيات الأسبوع القادم (قابلة للتنفيذ خلال 7 أيام)
1. [إجراء محدد وقابل للقياس]
2. [إجراء محدد وقابل للقياس]  
3. [إجراء محدد وقابل للقياس]

## 🚨 يحتاج إجراء خلال 48 ساعة
- [إجراء عاجل إن وجد، أو اكتب "لا يوجد إجراءات عاجلة هذا الأسبوع"]

استخدم الأرقام الحقيقية من البيانات في كل نقطة.`;

    await sendMessage(prompt);
    setIsGenerating(false);
    setGenerated(true);
  };

  // Get latest advisor message as report
  const latestReport = [...messages].reverse().find(m => m.role === 'advisor')?.content || '';

  const exportPDF = () => {
    const content = latestReport || report;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `تقرير-الصحة-المالية-${new Date().toISOString().slice(0,10)}.txt`;
    a.click();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900">تقرير الصحة المالية الأسبوعي</h2>
              <p className="text-xs text-slate-500">مدعوم بالذكاء الاصطناعي — {new Date().toLocaleDateString('ar-SA')}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        {/* Quick stats */}
        {!dash.isLoading && (
          <div className="grid grid-cols-4 gap-3 px-6 py-4 border-b border-slate-100">
            {[
              { label: 'الإيرادات', value: fmt(dash.totalRevenue), icon: TrendingUp, up: true },
              { label: 'صافي الربح', value: fmt(dash.netIncome), icon: dash.netIncome >= 0 ? TrendingUp : TrendingDown, up: dash.netIncome >= 0 },
              { label: 'ذمم للتحصيل', value: fmt(dash.totalReceivables), icon: AlertCircle, up: false },
              { label: 'فواتير متأخرة', value: String(dash.overdueInvoices), icon: AlertCircle, up: dash.overdueInvoices === 0 },
            ].map(s => (
              <div key={s.label} className="text-center">
                <div className={`text-base font-bold ${s.up ? 'text-emerald-600' : 'text-slate-800'}`}>{s.value}</div>
                <div className="text-xs text-slate-500 mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {!generated && !isGenerating && (
            <div className="text-center py-12">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="font-bold text-slate-800 mb-2">جاهز لتوليد التقرير</h3>
              <p className="text-slate-500 text-sm mb-6 max-w-sm mx-auto">
                سيقرأ الذكاء الاصطناعي جميع بيانات شركتك ويولّد تقريراً شاملاً في ثوانٍ
              </p>
              <button onClick={generateReport}
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold px-6 py-3 rounded-xl mx-auto transition-colors">
                <Zap className="w-4 h-4" /> توليد التقرير الآن
              </button>
            </div>
          )}

          {isGenerating && (
            <div className="text-center py-12">
              <RefreshCw className="w-10 h-10 text-emerald-500 animate-spin mx-auto mb-4" />
              <p className="text-slate-600 font-medium">يقرأ الذكاء الاصطناعي بيانات الشركة...</p>
              <div className="mt-4 space-y-2 text-sm text-slate-400">
                <div className="flex items-center justify-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> جلب الإيرادات والمصروفات</div>
                <div className="flex items-center justify-center gap-2"><RefreshCw className="w-3.5 h-3.5 animate-spin" /> تحليل الأداء المالي</div>
              </div>
            </div>
          )}

          {generated && latestReport && (
            <div className="prose prose-sm max-w-none">
              <div className="whitespace-pre-wrap text-slate-700 leading-relaxed text-sm font-sans">
                {latestReport}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        {generated && (
          <div className="px-6 py-4 border-t border-slate-200 flex items-center justify-between">
            <button onClick={generateReport} disabled={isGenerating}
              className="flex items-center gap-2 text-sm text-slate-500 hover:text-slate-700">
              <RefreshCw className="w-3.5 h-3.5" /> إعادة التوليد
            </button>
            <div className="flex gap-2">
              <button onClick={exportPDF}
                className="flex items-center gap-2 text-sm px-4 py-2 border border-slate-200 rounded-lg hover:bg-slate-50">
                <Download className="w-3.5 h-3.5" /> تصدير
              </button>
              <button onClick={onClose}
                className="text-sm px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700">
                إغلاق
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
