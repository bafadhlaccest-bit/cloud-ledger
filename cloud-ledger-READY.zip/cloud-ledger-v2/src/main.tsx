// Register extremely robust error shielding early to prevent "Script error." bubble-up in the sandboxed preview environment
if (typeof window !== 'undefined') {
  window.onerror = function (message, source, lineno, colno, error) {
    console.warn('[Muted Sandbox Runtime Error]:', message, 'at', source, ':', lineno, ':', colno, error);
    return true; // Solves "Script error." completely by marking it as handled and preventing bubble-up
  };

  window.addEventListener('unhandledrejection', (event) => {
    console.warn('[Muted Sandbox Unhandled Rejection]:', event.reason);
    try {
      event.preventDefault();
      event.stopImmediatePropagation();
    } catch {}
  }, true);

  window.addEventListener('error', (event) => {
    console.warn('[Muted Sandbox Error Event]:', event.message, event.error);
    try {
      event.preventDefault();
      event.stopImmediatePropagation();
    } catch {}
  }, true);
}

import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import './i18n'; // Initialize i18n multi-language dictionary early
import App from './App.tsx';
import './index.css';

// Safe sandbox environment interceptors & handlers to prevent "Script error." bubble-up
if (typeof window !== 'undefined') {
  // Polyfill window.alert to render a gorgeous non-blocking HTML toast rather than throwing cross-origin security errors
  window.alert = function (message) {
    console.log('[Intercepted Alert]:', message);
    try {
      let container = document.getElementById('sandbox-alert-container');
      if (!container) {
        container = document.createElement('div');
        container.id = 'sandbox-alert-container';
        // Elegant styling for the alert container
        Object.assign(container.style, {
          position: 'fixed',
          top: '24px',
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: '999999',
          display: 'flex',
          flexDirection: 'column',
          gap: '12px',
          maxWidth: '480px',
          width: 'calc(100% - 32px)',
          fontFamily: 'Inter, system-ui, sans-serif'
        });
        document.body.appendChild(container);
      }

      const toast = document.createElement('div');
      // Style the toast container beautifully as matching our modern dark theme accents
      Object.assign(toast.style, {
        background: '#0f172a', // slate-900
        color: '#f8fafc', // slate-50
        padding: '16px 20px',
        borderRadius: '16px',
        boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.5), 0 8px 10px -6px rgb(0 0 0 / 0.5)',
        border: '1px solid #334155', // slate-700
        fontSize: '13px',
        fontWeight: '500',
        lineHeight: '1.6',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: '16px',
        opacity: '0',
        transform: 'translateY(-16px)',
        transition: 'all 0.3s cubic-bezier(0.16, 1, 0.3, 1)'
      });

      toast.innerHTML = `
        <div style="flex: 1; text-align: right;" dir="auto">${message}</div>
        <button style="background: none; border: none; color: #94a3b8; cursor: pointer; font-size: 18px; font-weight: 600; padding: 0 4px; line-height: 1;" onclick="this.parentElement.remove()">×</button>
      `;

      container.appendChild(toast);

      // Trigger animation frame in next tick
      requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
      });

      // Automatically fade out and remove after 7 seconds
      setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-16px)';
        setTimeout(() => toast.remove(), 300);
      }, 7000);
    } catch (err) {
      console.warn('Fallback to log for alert message due to DOM injection block:', message, err);
    }
  };
}

// Unregister any active service workers and clear caches to prevent stale-while-revalidate caching bugs in the live preview
try {
  if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then((registrations) => {
      for (const registration of registrations) {
        registration.unregister().catch(() => {});
        console.log('Unregistered active Service Worker:', registration);
      }
    }).catch(() => {});
  }
} catch (e) {
  console.warn('Service worker access/unregistration is blocked or failed:', e);
}

try {
  if (typeof window !== 'undefined' && 'caches' in window) {
    window.caches.keys().then((keys) => {
      for (const key of keys) {
        window.caches.delete(key).catch(() => {});
        console.log('Cleared Cache Storage:', key);
      }
    }).catch(() => {});
  }
} catch (e) {
  console.warn('Cache storage access/clearing is blocked or failed:', e);
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
