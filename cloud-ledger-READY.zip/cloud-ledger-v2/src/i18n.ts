import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import enTranslations from './locales/en.json';
import arTranslations from './locales/ar.json';
import { safeStorage } from './utils/safeStorage';

// Initialize translation settings. Check user's chosen setting in localStorage.
let savedSettings: any = null;
try {
  const localSettingsStr = safeStorage.getItem('cloud_ledger_settings');
  if (localSettingsStr) {
    savedSettings = JSON.parse(localSettingsStr);
  }
} catch (e) {
  console.warn("Could not read local settings for language initialization", e);
}

const activeLanguage = savedSettings?.systemLanguage || safeStorage.getItem('system_language') || 'ar';
const localeCode = activeLanguage && activeLanguage.toLowerCase().startsWith('en') ? 'en' : 'ar';

i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: {
        translation: enTranslations
      },
      ar: {
        translation: arTranslations
      }
    },
    lng: localeCode,
    fallbackLng: 'ar',
    interpolation: {
      escapeValue: false // React already escapes string contents
    }
  });

export default i18n;
