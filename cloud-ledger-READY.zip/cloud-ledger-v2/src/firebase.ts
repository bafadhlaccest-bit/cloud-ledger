/**
 * firebase.ts — Supabase Adapter
 * 
 * يحاكي Firestore API بالكامل باستخدام Supabase تحت الغطاء.
 * لا يحتاج أي تغيير في باقي الملفات.
 * 
 * الجداول المدعومة: 
 *   invoices, customers, vendors, items, accounts, 
 *   bankAccounts, bankTransactions, bills, journalEntries,
 *   journal_entries, journal_lines, companies, contacts,
 *   currencies, fiscalPeriods, stockMovements, erp_event_bus, finacialAuditTrails
 */

import { supabase } from './lib/supabase';

// ── Auth shim ────────────────────────────────────────────────────
export const auth = {
  currentUser: null as any,
  onAuthStateChanged: (cb: (user: any) => void) => {
    supabase.auth.getSession().then(({ data }) => {
      cb(data.session?.user ?? null);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      cb(session?.user ?? null);
    });
    return () => listener.subscription.unsubscribe();
  },
};

// ── Firestore collection → Supabase table map ───────────────────
const TABLE_MAP: Record<string, string> = {
  invoices:             'invoices',
  customers:            'customers',
  vendors:              'vendors',
  items:                'items',
  accounts:             'accounts',
  bankAccounts:         'bank_accounts',
  bankTransactions:     'bank_transactions',
  bills:                'bills',
  journalEntries:       'journal_entries',
  journal_entries:      'journal_entries',
  journal_lines:        'journal_lines',
  companies:            'companies',
  contacts:             'contacts',
  currencies:           'currencies',
  customerCurrencies:   'customer_currencies',
  vendorCurrencies:     'vendor_currencies',
  fiscalPeriods:        'fiscal_periods',
  fiscal_periods:       'fiscal_periods',
  stockMovements:       'stock_movements',
  erp_event_bus:        'erp_event_bus',
  finacialAuditTrails:  'financial_audit_trails',
};

function toTable(collectionPath: string): string {
  const name = collectionPath.split('/').pop() || collectionPath;
  return TABLE_MAP[name] || name;
}

// ── Timestamp shim ───────────────────────────────────────────────
export const serverTimestamp = () => new Date().toISOString();

// ── Query constraints ─────────────────────────────────────────────
interface WhereConstraint { type: 'where'; field: string; op: string; value: any }
interface OrderByConstraint { type: 'orderBy'; field: string; dir: 'asc' | 'desc' }
type QueryConstraint = WhereConstraint | OrderByConstraint;

export function where(field: string, op: string, value: any): WhereConstraint {
  return { type: 'where', field, op, value };
}

export function orderBy(field: string, dir: 'asc' | 'desc' = 'asc'): OrderByConstraint {
  return { type: 'orderBy', field, dir };
}

// ── Collection reference ─────────────────────────────────────────
export function collection(_db: any, path: string) {
  return { _type: 'collection', path };
}

// ── Document reference ───────────────────────────────────────────
export function doc(_db: any, path: string, id?: string) {
  const fullPath = id ? `${path}/${id}` : path;
  return { _type: 'doc', path: fullPath };
}

// ── Query builder ────────────────────────────────────────────────
export function query(ref: any, ...constraints: QueryConstraint[]) {
  return { _type: 'query', ref, constraints };
}

// ── Apply where/orderBy to a Supabase query ──────────────────────
function applyConstraints(q: any, constraints: QueryConstraint[]) {
  for (const c of constraints) {
    if (c.type === 'where') {
      const field = c.field === 'companyId' ? 'company_id' : c.field;
      if (c.op === '==')         q = q.eq(field, c.value);
      else if (c.op === '!=')    q = q.neq(field, c.value);
      else if (c.op === '>')     q = q.gt(field, c.value);
      else if (c.op === '>=')    q = q.gte(field, c.value);
      else if (c.op === '<')     q = q.lt(field, c.value);
      else if (c.op === '<=')    q = q.lte(field, c.value);
      else if (c.op === 'in')    q = q.in(field, c.value);
      else if (c.op === 'array-contains') q = q.contains(field, [c.value]);
    } else if (c.type === 'orderBy') {
      const field = c.field === 'createdAt' ? 'created_at' : c.field;
      q = q.order(field, { ascending: c.dir === 'asc' });
    }
  }
  return q;
}

// ── Row normalization ─────────────────────────────────────────────
function normalize(row: any): any {
  if (!row) return null;
  const out: any = { ...row };
  // Map snake_case → camelCase for common fields
  if ('company_id'  in out) { out.companyId  = out.company_id;  }
  if ('created_at'  in out) { out.createdAt  = out.created_at;  }
  if ('updated_at'  in out) { out.updatedAt  = out.updated_at;  }
  if ('due_date'    in out) { out.dueDate    = out.due_date;     }
  if ('tax_number'  in out) { out.taxNumber  = out.tax_number;  }
  if ('bank_name'   in out) { out.bankName   = out.bank_name;   }
  return out;
}

// ── getDocs ───────────────────────────────────────────────────────
export async function getDocs(queryOrRef: any) {
  let tableName: string;
  let constraints: QueryConstraint[] = [];

  if (queryOrRef._type === 'query') {
    tableName = toTable(queryOrRef.ref.path);
    constraints = queryOrRef.constraints;
  } else {
    tableName = toTable(queryOrRef.path);
  }

  let q = supabase.from(tableName).select('*');
  q = applyConstraints(q, constraints);

  const { data, error } = await q;
  if (error) {
    console.error(`[Supabase] getDocs(${tableName}):`, error.message);
    return { docs: [], forEach: () => {} };
  }

  const docs = (data || []).map((row: any) => ({
    id: row.id,
    data: () => normalize(row),
    exists: () => true,
  }));

  return {
    docs,
    forEach: (cb: (doc: any) => void) => docs.forEach(cb),
  };
}

// ── getDoc ────────────────────────────────────────────────────────
export async function getDoc(docRef: any) {
  const parts  = docRef.path.split('/');
  const id     = parts.pop();
  const table  = toTable(parts.join('/'));

  const { data, error } = await supabase.from(table).select('*').eq('id', id).single();
  if (error) {
    return { exists: () => false, data: () => null, id };
  }
  return {
    id,
    exists: () => !!data,
    data: () => normalize(data),
  };
}

// ── addDoc ────────────────────────────────────────────────────────
export async function addDoc(ref: any, data: any) {
  const table = toTable(ref.path);
  const payload = preparePayload(data);

  const { data: inserted, error } = await supabase
    .from(table)
    .insert([payload])
    .select()
    .single();

  if (error) {
    console.error(`[Supabase] addDoc(${table}):`, error.message);
    throw new Error(error.message);
  }
  return { id: inserted.id };
}

// ── updateDoc ─────────────────────────────────────────────────────
export async function updateDoc(docRef: any, data: any) {
  const parts = docRef.path.split('/');
  const id    = parts.pop();
  const table = toTable(parts.join('/'));
  const payload = preparePayload(data);

  const { error } = await supabase.from(table).update(payload).eq('id', id);
  if (error) {
    console.error(`[Supabase] updateDoc(${table}/${id}):`, error.message);
    throw new Error(error.message);
  }
}

// ── deleteDoc ─────────────────────────────────────────────────────
export async function deleteDoc(docRef: any) {
  const parts = docRef.path.split('/');
  const id    = parts.pop();
  const table = toTable(parts.join('/'));

  const { error } = await supabase.from(table).delete().eq('id', id);
  if (error) {
    console.error(`[Supabase] deleteDoc(${table}/${id}):`, error.message);
    throw new Error(error.message);
  }
}

// ── onSnapshot (real-time via Supabase Realtime) ─────────────────
export function onSnapshot(queryOrRef: any, callback: (snapshot: any) => void) {
  let tableName: string;
  let constraints: QueryConstraint[] = [];

  if (queryOrRef._type === 'query') {
    tableName = toTable(queryOrRef.ref.path);
    constraints = queryOrRef.constraints;
  } else {
    tableName = toTable(queryOrRef.path);
  }

  // Initial fetch
  const fetchData = async () => {
    let q = supabase.from(tableName).select('*');
    q = applyConstraints(q, constraints);
    const { data, error } = await q;
    if (error) {
      console.error(`[Supabase] onSnapshot(${tableName}):`, error.message);
      return;
    }

    const docs = (data || []).map((row: any) => ({
      id: row.id,
      data: () => normalize(row),
      exists: () => true,
    }));

    callback({
      docs,
      forEach: (cb: (doc: any) => void) => docs.forEach(cb),
      empty: docs.length === 0,
    });
  };

  fetchData();

  // Real-time subscription
  const channel = supabase
    .channel(`rt-${tableName}-${Math.random()}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: tableName }, () => {
      fetchData();
    })
    .subscribe();

  // Return unsubscribe function
  return () => {
    supabase.removeChannel(channel);
  };
}

// ── runTransaction ────────────────────────────────────────────────
export async function runTransaction(_db: any, fn: (tx: any) => Promise<any>) {
  // Supabase doesn't expose client-side transactions directly.
  // We simulate with a simple sequential executor.
  const txOps: Array<() => Promise<void>> = [];
  const tx = {
    get: async (docRef: any) => getDoc(docRef),
    update: (docRef: any, data: any) => { txOps.push(() => updateDoc(docRef, data)); },
    set:    (docRef: any, data: any) => { txOps.push(() => addDoc({ path: docRef.path.split('/').slice(0,-1).join('/') }, data)); },
    delete: (docRef: any)            => { txOps.push(() => deleteDoc(docRef)); },
  };
  await fn(tx);
  for (const op of txOps) await op();
}

// ── Payload preparation ───────────────────────────────────────────
function preparePayload(data: any): any {
  const out: any = {};
  for (const [k, v] of Object.entries(data)) {
    if (v === undefined) continue;
    // camelCase → snake_case for common fields
    const key = k
      .replace('companyId',  'company_id')
      .replace('createdAt',  'created_at')
      .replace('updatedAt',  'updated_at')
      .replace('dueDate',    'due_date')
      .replace('taxNumber',  'tax_number')
      .replace('bankName',   'bank_name');
    // Supabase stores timestamps as ISO strings
    out[key] = (v && typeof v === 'object' && 'toDate' in (v as any))
      ? (v as any).toDate().toISOString()
      : v;
  }
  return out;
}

// ── db shim (passed to functions that expect a Firestore db) ──────
export const db = { _type: 'supabase_db' };
