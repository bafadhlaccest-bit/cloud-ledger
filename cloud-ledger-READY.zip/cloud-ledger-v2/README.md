# Cloud Ledger — نظام المحاسبة السحابي

## خطوات التشغيل

### 1. تثبيت المكتبات
```bash
npm install
```

### 2. إعداد قاعدة البيانات (مرة واحدة فقط)
افتح Supabase → SQL Editor → شغّل بهذا الترتيب:
1. `database_schema.sql`
2. `supabase_additions.sql`

### 3. إضافة مفتاح Gemini AI (اختياري للمستشار الذكي)
- افتح [aistudio.google.com](https://aistudio.google.com)
- أنشئ API Key مجاني
- أضفه في `.env`:
```
GEMINI_API_KEY=your_key_here
```

### 4. تشغيل النظام
```bash
npm run dev
```
افتح: http://localhost:3000

### 5. إنشاء أول مستخدم
- افتح http://localhost:3000/register
- سجّل شركتك
- أكمل الـ Onboarding

---

## بيانات الاتصال (جاهزة)
- **Supabase Project**: myctjtloozvfgmuucpsq
- **Region**: ap-northeast-2 (Seoul)

## الصفحات المتاحة
| الصفحة | المسار |
|---|---|
| الرئيسية | / |
| دليل الحسابات | /accounts |
| العملاء | /customers |
| عروض الأسعار | /quotations |
| الفواتير | /sales |
| فواتير متكررة | /recurring |
| الموردون | /vendors |
| أوامر الشراء | /purchase-orders |
| فواتير الشراء | /purchases |
| المصروفات | /expenses |
| الأصناف | /items |
| البنوك | /banking |
| القيود | /journals |
| التقارير | /reports |
| ضريبة القيمة المضافة | /vat-report |
| سجل التدقيق | /audit-trail |
| المحاسب الذكي | /ai-accountant |
| المستشار المالي | /advisor |
| التكاملات | /integrations |
| الإعدادات | /settings |
