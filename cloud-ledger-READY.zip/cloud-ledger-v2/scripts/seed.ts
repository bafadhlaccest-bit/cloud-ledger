import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc } from 'firebase/firestore';
import * as fs from 'fs';
import * as path from 'path';

// RFC 4180 compliant CSV Parser
function parseCSV(text: string): string[][] {
  const result: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let inQuotes = false;
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];
    
    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        cell += '"';
        i++; // skip next quote
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      row.push(cell.trim());
      cell = '';
    } else if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && nextChar === '\n') {
        i++;
      }
      row.push(cell.trim());
      if (row.length > 0 && row.some(c => c !== '')) {
        result.push(row);
      }
      row = [];
      cell = '';
    } else {
      cell += char;
    }
  }
  
  if (cell || row.length > 0) {
    row.push(cell.trim());
    if (row.some(c => c !== '')) {
      result.push(row);
    }
  }
  
  return result;
}

async function runSeed() {
  console.log("Starting Firebase seeding script...");

  // Load config
  const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  if (!fs.existsSync(configPath)) {
    console.error("firebase-applet-config.json not found! Please ensure Firebase is provisioned.");
    process.exit(1);
  }
  const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));

  // Initialize
  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

  // Load countries CSV
  const countriesCsvPath = path.resolve(process.cwd(), 'src/data/countries.csv');
  if (!fs.existsSync(countriesCsvPath)) {
    console.error("countries.csv not found under src/data!");
    process.exit(1);
  }
  const countriesRaw = fs.readFileSync(countriesCsvPath, 'utf8');

  // Load states CSV
  const statesCsvPath = path.resolve(process.cwd(), 'src/data/states.csv');
  if (!fs.existsSync(statesCsvPath)) {
    console.error("states.csv not found under src/data!");
    process.exit(1);
  }
  const statesRaw = fs.readFileSync(statesCsvPath, 'utf8');

  // Parse countries
  console.log("Parsing countries...");
  const parsedCountries = parseCSV(countriesRaw);
  const countriesHeader = parsedCountries[0] || [];
  const countryRows = parsedCountries.slice(1);

  const idIndex = countriesHeader.indexOf('id');
  const nameIndex = countriesHeader.indexOf('name');
  const iso3Index = countriesHeader.indexOf('iso3');
  const iso2Index = countriesHeader.indexOf('iso2');
  const currencyIndex = countriesHeader.indexOf('currency');
  const currencyNameIndex = countriesHeader.indexOf('currency_name');
  const currencySymbolIndex = countriesHeader.indexOf('currency_symbol');

  const countries = countryRows.map(row => ({
    id: row[idIndex] || '',
    name: row[nameIndex] || '',
    iso3: row[iso3Index] || '',
    iso2: row[iso2Index] || '',
    currencyCode: row[currencyIndex] || '',
    currencyName: row[currencyNameIndex] || '',
    currencySymbol: row[currencySymbolIndex] || '',
  })).filter(c => c.id && c.name);

  // Parse states
  console.log("Parsing states...");
  const parsedStates = parseCSV(statesRaw);
  const statesHeader = parsedStates[0] || [];
  const stateRows = parsedStates.slice(1);

  const sIdIndex = statesHeader.indexOf('id');
  const sNameIndex = statesHeader.indexOf('name');
  const sCountryIdIndex = statesHeader.indexOf('country_id');
  const sCountryCodeIndex = statesHeader.indexOf('country_code');
  const sCountryNameIndex = statesHeader.indexOf('country_name');

  const states = stateRows.map(row => ({
    id: row[sIdIndex] || '',
    name: row[sNameIndex] || '',
    countryId: row[sCountryIdIndex] || '',
    countryCode: row[sCountryCodeIndex] || '',
    countryName: row[sCountryNameIndex] || '',
  })).filter(s => s.id && s.name);

  // Extract unique currencies
  const seenCurrencies = new Set<string>();
  const currencies: Array<{code: string; name: string; symbol: string}> = [];
  countries.forEach(c => {
    if (c.currencyCode && !seenCurrencies.has(c.currencyCode)) {
      seenCurrencies.add(c.currencyCode);
      currencies.push({
        code: c.currencyCode,
        name: c.currencyName || c.currencyCode,
        symbol: c.currencySymbol || '$',
      });
    }
  });

  console.log(`Extracted: ${countries.length} countries, ${states.length} states, ${currencies.length} currencies.`);

  // Write currencies
  console.log("Seeding currencies to Firestore...");
  for (const curr of currencies) {
    const docRef = doc(db, 'currencies', curr.code);
    await setDoc(docRef, curr);
  }
  console.log("Successfully seeded currencies!");

  // Write countries
  console.log("Seeding countries to Firestore...");
  for (const country of countries) {
    const docRef = doc(db, 'countries', country.id);
    await setDoc(docRef, country);
  }
  console.log("Successfully seeded countries!");

  // Write states
  console.log("Seeding states/governorates to Firestore...");
  for (const state of states) {
    const docRef = doc(db, 'states', state.id);
    await setDoc(docRef, state);
  }
  console.log("Successfully seeded states/governorates!");

  console.log("Data migration/seeding completed successfully!");
  process.exit(0);
}

runSeed().catch(err => {
  console.error("Seeding failed with error:", err);
  process.exit(1);
});
